import {mount as mountDataTracking} from '../../frontend/modules/data-tracking/index.mjs';
import {api} from '../../shared/auth-ui.mjs';
export function mount(root,data){return mountDataTracking(root,data,{identity:()=>api('session'),load:(table,reload,period)=>api('data-tracking?table='+table+(['REPORT','GR_REPORT'].includes(table)?'&year='+encodeURIComponent(period.year):'')+(reload?'&reload=1':''))});}
