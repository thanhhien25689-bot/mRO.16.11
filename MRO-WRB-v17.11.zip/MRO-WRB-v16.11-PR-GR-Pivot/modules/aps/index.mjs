import {mount as mountAps} from '../../frontend/modules/aps/index.mjs';
import {api} from '../../shared/auth-ui.mjs';
// Facade host entry: registry gọi file này; snapshot APS đã merge trong data.aps.
// 16/11/2026: thêm exportAll để nút "Tải toàn bộ dữ liệu" đọc SQL Repair + Service (2 sheet).
export function mount(root,data){return mountAps(root,data,{exportAll:()=>api('aps-export')});}
