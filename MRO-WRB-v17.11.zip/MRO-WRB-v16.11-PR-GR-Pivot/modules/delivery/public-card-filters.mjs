// Facade tương thích cho caller cũ; không chứa implementation.
export {cardFilters} from '../../frontend/modules/delivery/index.mjs';
