// Entrypoint legacy: giữ mount(root,data), chỉ nối public interface và presentation adapter.
import {mount as mountDelivery} from '../../frontend/modules/delivery/index.mjs';
import {badge} from '../../shared/ui.mjs';
import {api,canAddDelivery} from '../../shared/auth-ui.mjs';
import {icon} from '../../shared/icons.mjs';
export function mount(root,data){return mountDelivery(root,data,{badge,icon,api,canAdd:canAddDelivery});}
