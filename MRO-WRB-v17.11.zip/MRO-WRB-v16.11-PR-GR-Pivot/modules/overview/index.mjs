// Facade host: giữ mount(root,data), truyền badge/link legacy.
import {mount as mountOverview} from '../../frontend/modules/overview/index.mjs';
import {badge,link} from '../../shared/ui.mjs';
import {icon} from '../../shared/icons.mjs';
import {api,canUpdateBudget} from '../../shared/auth-ui.mjs';
export function mount(root,data){return mountOverview(root,data,{badge,link,icon,budgetApi:api,canUpdateBudget,savingApi:api,repairApi:api});}
