export {trackingKey,mergeTracking} from '../../frontend/modules/tracking/public-model.mjs';
