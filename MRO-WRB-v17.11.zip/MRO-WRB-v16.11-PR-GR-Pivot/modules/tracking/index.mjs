import {mount as mountTracking} from '../../frontend/modules/tracking/index.mjs';
import {badge} from '../../shared/ui.mjs';
import {icon} from '../../shared/icons.mjs';
import {api,canEditBusiness} from '../../shared/auth-ui.mjs';
export function mount(root,data){return mountTracking(root,data,{badge,icon,api,canEditBusiness});}
