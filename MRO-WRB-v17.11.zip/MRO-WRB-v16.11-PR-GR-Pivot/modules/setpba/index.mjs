import { mount as mountSp } from '../../frontend/modules/setpba/index.mjs';
import { api } from '../../shared/auth-ui.mjs';

export function mount(root, data) {
  return mountSp(root, data, { api });
}
