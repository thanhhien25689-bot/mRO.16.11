import { mount as mountOps } from '../../frontend/modules/setpba/operations.mjs';
import { api } from '../../shared/auth-ui.mjs';

export function mount(root, data) {
  return mountOps(root, data, { api });
}
