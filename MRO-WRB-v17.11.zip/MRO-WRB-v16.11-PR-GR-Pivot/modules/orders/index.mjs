// Facade host: giữ mount(root,data) và presentation adapter legacy.
import {mount as mountOrders} from '../../frontend/modules/orders/index.mjs';
import {badge} from '../../shared/ui.mjs';
import {api,canApproveOrders,canDeleteOrders,canEditBusiness} from '../../shared/auth-ui.mjs';
import {icon} from '../../shared/icons.mjs';
export function mount(root,data){return mountOrders(root,data,{badge,icon,api,canApproveOrders,canDeleteOrders,canEditBusiness});}
