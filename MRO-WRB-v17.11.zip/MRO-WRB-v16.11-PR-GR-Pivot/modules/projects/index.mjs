import {mount as mountProjects} from '../../frontend/modules/projects/index.mjs';
import {api} from '../../shared/auth-ui.mjs';
export function mount(root,data){return mountProjects(root,data,{identity:()=>api('session'),reload:year=>api('project-status'+(year?'?year='+encodeURIComponent(year):''))});}
