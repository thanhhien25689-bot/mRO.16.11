// Public compatibility facade, không chứa implementation.
export {cardFilters,locationFilter} from '../../frontend/modules/inventory/index.mjs';
