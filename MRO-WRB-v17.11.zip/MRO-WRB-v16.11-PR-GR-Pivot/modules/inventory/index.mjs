// Facade host: giữ mount(root,data) và badge legacy.
import {mount as mountInventory} from '../../frontend/modules/inventory/index.mjs';
import {api,canUpdateBudget} from '../../shared/auth-ui.mjs';
import {badge} from '../../shared/ui.mjs';
export function mount(root,data){return mountInventory(root,data,{badge,api,canUpdateBudget});}
