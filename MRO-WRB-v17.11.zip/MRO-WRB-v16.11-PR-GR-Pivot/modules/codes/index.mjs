import {mount as mountCodes} from '../../frontend/modules/codes/index.mjs';
import {badge} from '../../shared/ui.mjs';
import {api,canEditBusiness} from '../../shared/auth-ui.mjs';
export function mount(root,data){return mountCodes(root,data,{badge,api,canEditBusiness});}
