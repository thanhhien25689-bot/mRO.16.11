$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
$taskConfig = Get-Content -LiteralPath (Join-Path $taskRoot 'tree.config.json') -Raw | ConvertFrom-Json
$taskPort = [int]$taskConfig.port
$taskNode = (Get-Command node -ErrorAction Stop).Source
$taskRule = "MRO-WRB-LAN-$taskPort"
$existing = Get-NetFirewallRule -Name $taskRule -ErrorAction SilentlyContinue
if (-not $existing) {
    New-NetFirewallRule -Name $taskRule -DisplayName "MRO WRB LAN TCP $taskPort" -Direction Inbound -Action Allow -Protocol TCP -LocalPort $taskPort -RemoteAddress LocalSubnet -Program $taskNode -Profile Any | Out-Null
}
Get-NetFirewallRule -Name $taskRule | Select-Object Name, Enabled, Direction, Action
Write-Host "LAN enabled for local-subnet devices on TCP $taskPort. No router port forwarding is needed."
