// MRO Portal — Chế độ xem offline (READ-ONLY preview)
// Dùng snapshot cache đã lưu, KHÔNG kết nối SQL, KHÔNG ghi dữ liệu.
// Khởi chạy: node start-offline.cjs [--open]
'use strict';
process.env.MRO_OFFLINE = '1';

const fs   = require('node:fs');
const path = require('node:path');
const os   = require('node:os');
const {createServer}      = require('./backend/core/create-server.cjs');
const {getStartupConfig}  = require('./backend/core/config.cjs');

const {port, host, runtime} = getStartupConfig(__dirname);
fs.mkdirSync(runtime, {recursive: true});

// Kiểm tra cache trước khi khởi động
const cacheFile = path.join(runtime, 'cache', 'raw.json');
const hasCache  = fs.existsSync(cacheFile);
const screensDir = path.join(runtime, 'cache', 'screens');
const screenFiles = fs.existsSync(screensDir) ? fs.readdirSync(screensDir).filter(f => f.endsWith('.json')) : [];

console.log('\n════════════════════════════════════════════════════════════');
console.log('  MRO Portal — CHẾ ĐỘ XEM OFFLINE (READ-ONLY PREVIEW)');
console.log('════════════════════════════════════════════════════════════');
console.log('  Snapshot chính:   ' + (hasCache ? '✓  ' + cacheFile : '✗  Chưa có — một số màn sẽ hiển thị "Chưa có dữ liệu"'));
console.log('  Màn cache (APIs): ' + screenFiles.length + ' files trong ' + screensDir);
console.log('  Mọi thao tác ghi / mutation đã bị khoá.');
console.log('════════════════════════════════════════════════════════════\n');

const server = createServer({runtime});
server.on('error', err => {
  console.error(err.code === 'EADDRINUSE' ? `Cổng ${port} đang bận.` : err.message);
  process.exitCode = 1;
});
server.listen(port, host, () => {
  console.log(`  Portal offline: http://localhost:${port}/`);
  for (const list of Object.values(os.networkInterfaces()))
    for (const nic of list || [])
      if (nic.family === 'IPv4' && !nic.internal)
        console.log(`  LAN:            http://${nic.address}:${port}/`);
  console.log('\n  Nhấn Ctrl+C để dừng.\n');
  if (process.argv.includes('--open') && process.env.MRO_NO_BROWSER !== '1') {
    require('node:child_process').spawn(
      'powershell.exe',
      ['-NoProfile','-NonInteractive','-Command',`Start-Process -FilePath 'http://localhost:${port}/' -ErrorAction Stop`],
      {windowsHide: true, stdio: 'ignore'}
    );
  }
});

let stopping = false;
const shutdown = () => {
  if (stopping) return; stopping = true;
  const t = setTimeout(() => process.exit(0), 2000); t.unref();
  server.close(() => process.exit(0));
};
for (const sig of ['SIGINT','SIGTERM','SIGBREAK']) process.on(sig, shutdown);
