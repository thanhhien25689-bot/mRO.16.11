# Knox APIBOT launcher for the MRO WRB portal (message center, Knox proxy).
#
# Why this exists: the Portal calls http://127.0.0.1:2292 for /api/messages-*
# and /api/knox-app/*. When the local Knox Local Messenger is not running the
# message center shows "Khong ket noi duoc (ECONNREFUSED, khi goi 127.0.0.1:2292)".
# This script starts that helper silently so it can live in the Windows Startup
# folder.
#
# It is deliberately IDEMPOTENT: if something already listens on the port (for
# example a window opened by hand with KnoxChatbox\start.bat) it exits 0 without
# starting a second uvicorn, so port 2292 is never fought over.
#
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File scripts\knox-api-autostart.ps1
#   ... -Status / -Stop / -Install / -Uninstall
#
# Only localhost is used; no credential is read, stored or printed.

param(
  [switch]$Install,
  [switch]$Uninstall,
  [switch]$Status,
  [switch]$Stop,
  [int]$Port = 2292,
  [int]$WaitSeconds = 25
)

$ErrorActionPreference = 'Stop'

$portalRoot = Split-Path -Parent $PSScriptRoot
$runtimeDir = Join-Path $portalRoot '.runtime\messages'
$logPath    = Join-Path $runtimeDir 'apibot.log'
$errLogPath = Join-Path $runtimeDir 'apibot.err.log'
$pidPath    = Join-Path $runtimeDir 'apibot.pid'

function Test-PortOpen {
  param([int]$port)
  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $task = $client.ConnectAsync('127.0.0.1', $port)
    if ($task.Wait(700)) { return -not $task.IsFaulted }
    return $false
  } catch { return $false } finally { $client.Close() }
}

function Find-KnoxFolder {
  $candidates = @()
  if ($env:KNOX_CHATBOX_DIR) { $candidates += $env:KNOX_CHATBOX_DIR }
  $candidates += (Join-Path $portalRoot '..\KnoxChatbox')
  $parent = Split-Path -Parent $portalRoot
  foreach ($dir in @(Get-ChildItem -LiteralPath $parent -Directory -ErrorAction SilentlyContinue)) {
    if ($dir.Name -like '*Knox*') { $candidates += $dir.FullName }
  }
  foreach ($candidate in $candidates) {
    $full = $null
    try { $full = (Resolve-Path -LiteralPath $candidate -ErrorAction Stop).Path } catch { continue }
    if ((Test-Path -LiteralPath (Join-Path $full 'main.py')) -and
        (Test-Path -LiteralPath (Join-Path $full '.venv\Scripts\python.exe'))) { return $full }
  }
  return $null
}

function Show-Status {
  $open = Test-PortOpen -port $Port
  if ($open) {
    Write-Host ("Knox APIBOT 127.0.0.1:{0}: LISTENING" -f $Port)
    try {
      $client = New-Object System.Net.WebClient
      $health = ($client.DownloadString(("http://127.0.0.1:{0}/health" -f $Port)) | ConvertFrom-Json)
      $client.Dispose()
      Write-Host ("  /health ok={0} version={1} cdp_port={2} knox_exe_found={3} auto_restart_knox={4}" -f `
        $health.ok, $health.version, $health.cdp_port, $health.knox_exe_found, $health.auto_restart_knox)
      if (-not $health.ok) {
        Write-Host '  NOTE: Knox Teams has no debug port (CDP) yet. Sending from the Portal restarts Knox Teams with it automatically.'
      }
    } catch {
      Write-Host ("  /health failed: {0}" -f $_.Exception.Message)
    }
  } else {
    Write-Host ("Knox APIBOT 127.0.0.1:{0}: CLOSED (this is the ECONNREFUSED the message center reports)" -f $Port)
  }
  if (Test-Path -LiteralPath $pidPath) {
    Write-Host ("  started by this script: PID {0}" -f (Get-Content -LiteralPath $pidPath -Raw).Trim())
  }
}

function Rotate-Log {
  param([string]$path)
  if (Test-Path -LiteralPath $path) {
    if ((Get-Item -LiteralPath $path).Length -gt 2MB) { Move-Item -LiteralPath $path -Destination ($path + '.old') -Force }
  }
}

function Start-APIBOT {
  if (Test-PortOpen -port $Port) {
    Write-Host ("[OK] Something already listens on 127.0.0.1:{0} - nothing started." -f $Port)
    Show-Status
    exit 0
  }
  $knox = Find-KnoxFolder
  if (-not $knox) {
    Write-Host '[ERROR] KnoxChatbox folder not found (needs main.py + .venv\Scripts\python.exe).'
    Write-Host '        Set KNOX_CHATBOX_DIR to its folder, or run KnoxChatbox\start.bat by hand.'
    exit 1
  }
  if (-not (Test-Path -LiteralPath $runtimeDir)) { New-Item -ItemType Directory -Path $runtimeDir -Force | Out-Null }
  Rotate-Log -path $logPath
  Rotate-Log -path $errLogPath
  $python = Join-Path $knox '.venv\Scripts\python.exe'
  Write-Host ("Starting Knox APIBOT from {0}" -f $knox)
  $process = Start-Process -FilePath $python `
    -ArgumentList @('-m', 'uvicorn', 'main:app', '--host', '127.0.0.1', '--port', [string]$Port) `
    -WorkingDirectory $knox -WindowStyle Hidden -PassThru `
    -RedirectStandardOutput $logPath -RedirectStandardError $errLogPath
  Set-Content -LiteralPath $pidPath -Value $process.Id -Encoding ASCII
  $deadline = (Get-Date).AddSeconds($WaitSeconds)
  while ((Get-Date) -lt $deadline) {
    if (Test-PortOpen -port $Port) {
      Write-Host ("[OK] Knox APIBOT listening on 127.0.0.1:{0} (PID {1})" -f $Port, $process.Id)
      exit 0
    }
    Start-Sleep -Milliseconds 500
  }
  Write-Host ("[ERROR] port 127.0.0.1:{0} still closed after {1}s (PID {2})." -f $Port, $WaitSeconds, $process.Id)
  Write-Host ("        Last log lines: {0}" -f $errLogPath)
  if (Test-Path -LiteralPath $errLogPath) {
    foreach ($line in @(Get-Content -LiteralPath $errLogPath -Tail 8 -ErrorAction SilentlyContinue)) { Write-Host ("          " + $line) }
  }
  exit 1
}

function Stop-APIBOT {
  if (-not (Test-Path -LiteralPath $pidPath)) {
    Write-Host '[SKIP] No apibot.pid - this script did not start the service, so nothing is stopped.'
    Write-Host '       If a KnoxChatbox\start.bat window is open, close that window instead.'
    exit 0
  }
  $savedPid = [int](Get-Content -LiteralPath $pidPath -Raw).Trim()
  $process = Get-Process -Id $savedPid -ErrorAction SilentlyContinue
  if ($process -and $process.Name -eq 'python') {
    Stop-Process -Id $savedPid -Force
    Write-Host ("[OK] Stopped Knox APIBOT PID {0}" -f $savedPid)
  } elseif ($process) {
    Write-Host ("[SKIP] PID {0} is now '{1}', not python - left alone." -f $savedPid, $process.Name)
  } else {
    Write-Host ("[OK] PID {0} is already gone." -f $savedPid)
  }
  Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
}

function Shortcut-Path {
  return (Join-Path ([Environment]::GetFolderPath('Startup')) 'Knox APIBOT (MRO).lnk')
}

function Install-Shortcut {
  $vbs = Join-Path $PSScriptRoot 'knox-api-autostart.vbs'
  if (-not (Test-Path -LiteralPath $vbs)) { Write-Host ("[ERROR] missing {0}" -f $vbs); exit 1 }
  $target = Shortcut-Path
  $shell = New-Object -ComObject WScript.Shell
  $link = $shell.CreateShortcut($target)
  $link.TargetPath = (Join-Path $env:WINDIR 'System32\wscript.exe')
  $link.Arguments = '"' + $vbs + '"'
  $link.WorkingDirectory = $PSScriptRoot
  $link.Description = 'Start Knox APIBOT on 127.0.0.1:2292 at logon; skips when it is already running.'
  $link.Save()
  Write-Host ("[OK] Startup shortcut created: {0}" -f $target)
  Write-Host '     Remove it later with: npm run knox:autostart:remove'
}

function Uninstall-Shortcut {
  $target = Shortcut-Path
  if (Test-Path -LiteralPath $target) {
    Remove-Item -LiteralPath $target -Force
    Write-Host ("[OK] Removed {0}" -f $target)
  } else {
    Write-Host ("[SKIP] No startup shortcut at {0}" -f $target)
  }
}

if ($Install) { Install-Shortcut }
elseif ($Uninstall) { Uninstall-Shortcut }
elseif ($Status) { Show-Status }
elseif ($Stop) { Stop-APIBOT }
else { Start-APIBOT }

