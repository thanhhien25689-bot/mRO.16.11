# Day ban Portal MRO (thu muc chua file nay) len Git.
# Khong tao repo moi: clone repo that ve mot thu muc lam viec, copy source hien tai vao, roi commit + push.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File scripts\push-portal-to-git.ps1 -DryRun
#   powershell -NoProfile -ExecutionPolicy Bypass -File scripts\push-portal-to-git.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File scripts\push-portal-to-git.ps1 -MakeSourceRepo
#
# -DryRun        : chi clone + copy + in danh sach thay doi, KHONG commit.
# -Force         : khoi hoi Y/N (dung cho may chay tu dong).
# -MakeSourceRepo: sau khi push xong, copy .git cua workspace vao thu muc source de thu muc source
#                  tro thanh ban checkout cua repo (lenh `git status` trong source se sach).
# Tai khoan commit: -AuthorName / -AuthorEmail. File nay viet ASCII de PowerShell 5.1 doc dung,
# muon message co dau thi truyen -Message tu dong lenh.

param(
  [string]$RepoUrl = 'https://github.com/thanhhien25689-bot/Portal_MRO.git',
  [string]$Branch = 'main',
  [string]$Workspace = '',
  [string]$AuthorName = 'hien.thanh',
  [string]$AuthorEmail = 'hien.thanh@local',
  [string]$Message = 'feat(tracking): gop PR No va mot o Dien Ly do cho ca PR trong hang cho PR can bo sung Ly do' + "`n`n- table.mjs: them column.span(r) (rowspan) tuy chon, bang khong khai bao span giu nguyen DOM`n- view.mjs: gop o PR No, mot nut Dien Ly do mo bang nhap theo tung dong, them o Ly do chung`n  cho nhieu hang (checkbox chon dong), Excel de TRONG PR No cua noi`n- tests/pr-reasons.test.mjs: rang buoc cho luong nhap theo nhom PR`n- docs/pr-reason-queue-group.md + AGENTS.md: mo ta luong moi`n`nCo-Authored-By: Cline SR",
  [switch]$DryRun,
  [switch]$Force,
  [switch]$MakeSourceRepo
)

$ErrorActionPreference = 'Stop'
$Source = Split-Path -Parent $PSScriptRoot
if (-not $Workspace) { $Workspace = Join-Path (Split-Path -Parent $Source) '.git-push-Portal_MRO' }

Write-Host "Source    : $Source"
Write-Host "Workspace : $Workspace"
Write-Host "Repo      : $RepoUrl ($Branch)"
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Chua thay git trong PATH. Cai Git for Windows roi chay lai.' }
git --version
if (-not (Test-Path (Join-Path $Source 'server.cjs'))) { throw "Source khong phai thu muc Portal MRO: $Source" }

if (-not (Test-Path (Join-Path $Workspace '.git'))) {
  Write-Host 'Chua co workspace -> clone repo ve.'
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Workspace) | Out-Null
  git clone $RepoUrl $Workspace
  if ($LASTEXITCODE -ne 0) { throw 'Clone that bai (kiem tra mang / quyen truy cap repo).' }
}

Push-Location $Workspace
try {
  git remote set-url origin $RepoUrl
  git fetch origin $Branch
  if ($LASTEXITCODE -ne 0) { throw 'Fetch that bai (mang hoac credential GitHub).' }
  git checkout $Branch | Out-Null
  if ($LASTEXITCODE -ne 0) { throw "Nhanh $Branch khong ton tai tai origin." }
  git pull --ff-only origin $Branch | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'Workspace khong the cap nhat ff-only; kiem tra thu muc workspace thu cong.' }
  $dirtyBefore = git status --porcelain
  if ($dirtyBefore) { throw 'Workspace dang co thay doi chua commit. Ham thu workspace roi chay lai, hoac kiem tra: git -C "' + $Workspace + '" status' }

  # Copy source hien tai sang workspace. /MIR dong bo (xoa file source da khong con),
  # /XD bo qua thu muc sinh an; .gitignore cua source quyet dinh file nao len git.
  Write-Host 'Copy source vao workspace (robocopy /MIR) ...'
  $robArgs = @($Source, $Workspace, '/MIR', '/NFL', '/NDL', '/NJH', '/NJS', '/NP',
    '/XD', 'node_modules', '.git', '.runtime', 'artifacts', '.worktrees',
    '/XF', 'tmp-rf-test.txt', '*.log', '~$*.xlsx')
  robocopy @robArgs | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "robocopy loi (exit $LASTEXITCODE)." }
  $global:LASTEXITCODE = 0

  git add -A
  $status = @(git status --porcelain)
  $added = @($status | Where-Object { $_ -match '^\?\?|^A' }).Count
  $modified = @($status | Where-Object { $_ -match '^M|^ M|^MM' }).Count
  $removed = @($status | Where-Object { $_ -match '^D|^ D|^AD' }).Count
  Write-Host ''
  Write-Host "Thay doi se commit: $added file moi, $modified file sua, $removed file xoa (tong $($status.Count) file)."
  $status | Select-Object -First 40 | ForEach-Object { Write-Host "  $_" }
  if ($status.Count -gt 40) { Write-Host "  ... con $($status.Count - 40) file nua (xem: git -C `"$Workspace`" status)" }
  if ($status.Count -eq 0) { Write-Host 'Source khong khac repo -> khong co gi de push.'; return }
  if ($DryRun) { Write-Host '[DryRun] Dung o day, chua commit va chua push.'; return }
  if (-not $Force) {
    $answer = Read-Host 'Commit va push len origin? (Y/N)'
    if ($answer -ne 'Y') { Write-Host 'Da huy. Workspace gi nguyen trang thai de anh xem: ' + $Workspace; return }
  }

  git -c user.name="$AuthorName" -c user.email="$AuthorEmail" commit -m $Message | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'Commit that bai.' }
  git push origin ("HEAD:" + $Branch)
  if ($LASTEXITCODE -ne 0) { throw 'Push that bai (thieu credential GitHub). Thu: git -C "' + $Workspace + '" push origin HEAD:' + $Branch }
  Write-Host ''
  Write-Host "Da push $Branch len $RepoUrl"
  git log --oneline -1
} finally { Pop-Location }

if ($MakeSourceRepo) {
  $target = Join-Path $Source '.git'
  if (Test-Path $target) { Write-Warning "$target da ton tai -> khong ghi de. Tu xa thu cong roi copy." }
  else {
    Copy-Item -Recurse -Force (Join-Path $Workspace '.git') $target
    Write-Host "Da gan .git vao source. Thu muc source bay gio la ban checkout cua repo."
    Write-Host "Kiem tra: git -C `"$Source`" status -sb"
  }
}