'use strict';
// Migration Repair & Service: SQLite `.runtime/aps/aps.sqlite` → SQL Server EQM_MRO_REPAIR / EQM_MRO_SERVICE.
// Decisions 2026-10-29: mỗi installment = 1 dòng SQL (Request ID trùng, Month/Year Payment khác);
// Service thêm cột Request ID (additive, --ensure-schema); Payment Status chỉ Pending|Completed|Cancel.
// MẶC ĐỊNH DRY-RUN: chỉ sinh preview `.runtime/aps-sql-migration-preview.json`, không ghi SQL.
// --ensure-schema: thêm cột Request ID + cột PDF hợp đồng + 6 cột bổ sung Repair/Service (additive).
// --ensure-only: chỉ chạy DDL đó rồi báo cáo cột còn thiếu trên từng bảng.
// --apply: INSERT thật theo batch, mỗi batch 1 transaction, guard NOT EXISTS theo natural key;
// kết quả ghi `.runtime/aps-sql-migration-report.json`.
const fs = require('node:fs');
const path = require('node:path');
const { getStartupConfig } = require('../backend/core/config.cjs');
const { createSql } = require('../backend/modules/sql/index.cjs');

const REPAIR_TABLE = 'EQM_MRO_REPAIR';
const SERVICE_TABLE = 'EQM_MRO_SERVICE';
const BATCH_SIZE = 80;
// Sáu cột bổ sung do action aps-ensure-schema thêm (ADD-only, guard IF COL_LENGTH).
// DANH SÁCH NÀY PHẢI KHỚP mảng $apsExtraNames trong backend/modules/sql/worker.ps1 —
// thiếu một trong số đó thì tab Repair & Service hiện cảnh báo và từ chối ghi.
const APS_EXTRA_COLUMNS = ['Reject date', 'Reject reason', 'Buyer', 'IBM', 'UpdatedAt', 'UpdatedBy'];

function normStatus(value) {
  const s = String(value == null ? '' : value).trim().toLowerCase();
  if (s === 'completed' || s === 'đã tất toán' || s === 'da tat toan') return 'Completed';
  if (s === 'cancel' || s === 'cancelled' || s === 'canceled') return 'Cancel';
  return 'Pending';
}
function dateOnly(value) {
  const m = /^(\d{4}-\d{2}-\d{2})/.exec(String(value == null ? '' : value));
  return m ? m[1] : null;
}
function num(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  return Number.isFinite(n) ? String(n) : null;
}
function text(value, max) {
  if (value === null || value === undefined) return null;
  const s = String(value).trim();
  if (!s) return null;
  return max ? s.slice(0, max) : s;
}
function yn(value) { return value === true || value === 'true' || value === 'Yes' ? 'Yes' : 'No'; }
function paymentMonthYear(payment) {
  const d = dateOnly(payment && payment.date);
  if (!d) return { month: null, year: null };
  return { month: String(Number(d.slice(5, 7))), year: d.slice(0, 4) };
}
function sharedRequestCols(r) {
  const completed = normStatus(r.payment) === 'Completed';
  return {
    'Request date': dateOnly(r.date), 'Vendor APS': text(r.vendor, 200), 'Cost Center': text(r.costCenter, 100),
    'Model / Project': text(r.model, 200), 'Pic request': text(r.pic || r.requester, 100), 'Request ID': r.id,
    'Payment Status': normStatus(r.payment),
    'Month Payment': completed ? num(r.paymentMonth) : null, 'Year Payment': completed ? num(r.paymentYear) : null,
  };
}
// Guard PHẢI lấy đúng giá trị đã ghi vào cols (null ≡ thiếu khóa): guard tự do = NOT EXISTS không bắt được
// chính dòng mình đã ghi (bug trùng 31 dòng Service 29-10-2026).
function guardFrom(cols, names) {
  return names.map(name => ({ name, value: cols[name] === undefined ? null : cols[name] }));
}
function paymentRow(table, r, payment) {
  const { month, year } = paymentMonthYear(payment);
  const cols = { ...sharedRequestCols(r) };
  if (table === REPAIR_TABLE) cols.Currency = text(payment.currency || r.currency, 10); else cols.Cur = text(payment.currency || r.currency, 10);
  cols.Amount = num(payment.amount);
  cols['Amount 2 (USD)'] = num(payment.amountUSD);
  cols['Month Payment'] = month; cols['Year Payment'] = year;
  cols.Remark = text(['TT', payment.reference, payment.note].filter(Boolean).join(' '), 1000);
  return { table, kind: 'payment', cols, guard: guardFrom(cols, ['Request ID', 'Month Payment', 'Year Payment', 'Amount']) };
}
function buildRepairRows(r, payments) {
  const rows = [];
  const lines = Array.isArray(r.lines) && r.lines.length ? r.lines : [null];
  const hasPayments = payments.length > 0;
  for (const line of lines) {
    const cols = sharedRequestCols(r);
    if (line) Object.assign(cols, {
      'BQMS code': text(line.bqms, 50), 'Jig /Eqm Name': text(line.name, 200), 'Current Status / Fault': text(line.fault, 100),
      'Detail Request': text(line.detail || r.detail, 1000), 'Q\'ty': num(line.qty), 'Service code': text(line.serviceCode, 50),
      'Estimated cost': num(line.est !== null && line.est !== undefined && line.est !== '' ? line.est : r.est),
      'Final price': num(line.finalPrice), 'Currency': text(r.currency, 10), 'Final Price (USD)': num(line.finalUSD),
      'Amount': hasPayments ? null : num(line.amount), 'Amount 2 (USD)': hasPayments ? null : num(line.amount2USD),
      'Vendor Repair': text(line.vendorRepair, 200), 'PO NO': text(line.poNo, 50), 'Local/Oversea': text(line.local, 20),
      'Service Type': text(line.serviceType, 50), 'Note of service': text(line.serviceKind, 1000), 'GL': text(line.gl, 50),
      'Remark': text(line.remark, 1000), 'WRB request': text(line.wrb, 100), 'Pur accept': text(line.accept, 100),
      'Price confirm date': dateOnly(line.priceDate),
    });
    rows.push({ table: REPAIR_TABLE, kind: 'base', cols, guard: guardFrom(cols, ['Request ID', 'Jig /Eqm Name', 'Service code']) });
  }
  for (const payment of payments) rows.push(paymentRow(REPAIR_TABLE, r, payment));
  return rows;
}
function buildServiceRows(r, payments) {
  const hasPayments = payments.length > 0;
  const cols = { ...sharedRequestCols(r),
    'Current Status / Request': text(r.status, 100), 'Q\'ty': num(r.qty),
    'Estimated cost': num(r.est), 'Final price': num(r.finalPrice), 'Cur': text(r.currency, 10),
    'Final Price (USD)': num(r.finalUSD), 'Amount': hasPayments ? null : num(r.amount), 'Amount 2 (USD)': hasPayments ? null : num(r.amount2USD),
    'Vendor Repair': text(r.vendorRepair, 200), 'Local/Oversea': text(r.local, 20), 'Type': text(r.serviceType, 50), 'GL': text(r.gl, 50),
    'Remark': text([r.detail, r.notes].filter(Boolean).join(' | '), 1000),
    'Start date': dateOnly(r.start), 'End Date': dateOnly(r.end),
    'Before approval': yn(r.beforeApproval), 'Contract': yn(r.contractCreated !== undefined ? r.contractCreated : r.contract),
    'Contract signed': yn(r.contractSigned), 'ContractNo': text(r.contractNo, 200),
  };
  const rows = [{ table: SERVICE_TABLE, kind: 'base', cols, guard: guardFrom(cols, ['Request ID', 'Month Payment']) }];
  for (const payment of payments) rows.push(paymentRow(SERVICE_TABLE, r, payment));
  return rows;
}
function planMigration(requests, paymentsByReq) {
  const repair = [], service = [], warnings = [];
  for (const { id, type, body } of requests) {
    const payments = paymentsByReq.get(id) || [];
    if (type === 'Repair') repair.push(...buildRepairRows(body, payments));
    else if (type === 'Service') service.push(...buildServiceRows(body, payments));
    else warnings.push('Request ' + id + ' có type lạ \'' + type + '\' — bỏ qua');
  }
  return { repair, service, warnings };
}
function readSqlite(dbFile) {
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(dbFile, { readOnly: true });
  try {
    const requests = db.prepare('SELECT id,type,body FROM requests').all().map(row => {
      let body = {}; try { body = JSON.parse(row.body) || {}; } catch { body = {}; }
      return { id: row.id, type: row.type, body: { ...body, id: body.id || row.id, type: body.type || row.type } };
    });
    const paymentsByReq = new Map();
    for (const row of db.prepare('SELECT request_id,body FROM payments').all()) {
      let body = {}; try { body = JSON.parse(row.body) || {}; } catch { body = {}; }
      if (!paymentsByReq.has(row.request_id)) paymentsByReq.set(row.request_id, []);
      paymentsByReq.get(row.request_id).push(body);
    }
    return { requests, paymentsByReq };
  } finally { db.close(); }
}

async function main() {
  const args = process.argv.slice(2);
  const apply = args.includes('--apply');
  const ensure = args.includes('--ensure-schema');
  const ensureOnly = args.includes('--ensure-only');
  const { runtime } = getStartupConfig();
  const sql = createSql({ runtime });
  if (ensureOnly) {
    /* Chỉ chạy additive DDL đã duyệt (Request ID + cột PDF hợp đồng + 6 cột bổ sung Repair/Service)
       rồi báo cáo cột còn thiếu trên từng bảng; không đọc SQLite, không ghi dữ liệu nghiệp vụ. */
    await sql.ensureApsSchema();
    const schema = await sql.readApsSchema();
    const columnsOf = name => (((schema || {})[name] || {}).columns || []).map(c => c.name);
    const contractEntry = schema.EQM_MRO_ServiceContract || {};
    const names = columnsOf('EQM_MRO_ServiceContract');
    const missing = ['PdfData', 'PdfName', 'PdfSize', 'PdfUploadedAt', 'PdfUploadedBy'].filter(c => !names.includes(c));
    console.log('Đã chạy additive DDL (idempotent): EQM_MRO_SERVICE.[Request ID] + cột PDF hợp đồng + 6 cột bổ sung trên EQM_MRO_REPAIR và EQM_MRO_SERVICE.');
    if (!contractEntry.exists) console.log('CẢNH BÁO: EQM_MRO_ServiceContract không tồn tại trong database đã cấu hình (schema dbo).');
    else console.log(missing.length ? 'Cột PDF CÒN THIẾU: ' + missing.join(', ') + ' — kiểm tra quyền ALTER của tài khoản SQL.' : 'Cột PDF đã đủ: PdfData (varbinary MAX) + PdfName/PdfSize/PdfUploadedAt/PdfUploadedBy.');
    const stillMissing = [];
    for (const table of [REPAIR_TABLE, SERVICE_TABLE]) {
      const have = columnsOf(table);
      if (!have.length) { stillMissing.push(table + ' (không đọc được cấu trúc bảng)'); continue; }
      for (const column of APS_EXTRA_COLUMNS) if (!have.includes(column)) stillMissing.push(table + '.' + column);
    }
    console.log(stillMissing.length
      ? 'Cột bổ sung Repair/Service CÒN THIẾU: ' + stillMissing.join(', ') + ' — tài khoản SQL cấu hình trong Portal cần quyền ALTER trên hai bảng này.'
      : 'Cột bổ sung Repair/Service đã đủ 6/6 trên cả hai bảng: Reject date, Reject reason, Buyer, IBM, UpdatedAt, UpdatedBy.');
    return;
  }
  const dbFile = process.env.MRO_APS_DB || path.join(runtime, 'aps', 'aps.sqlite');
  if (!fs.existsSync(dbFile)) { console.error('LỖI: không thấy SQLite ' + dbFile); process.exitCode = 1; return; }
  if (ensure) { await sql.ensureApsSchema(); console.log('Đã bảo đảm cột Request ID trên EQM_MRO_SERVICE và cột PDF hợp đồng (additive, idempotent).'); }
  const schema = await sql.readApsSchema();
  const serviceEntry = schema[SERVICE_TABLE];
  if (!serviceEntry || serviceEntry.exists !== true) { console.error('LỖI: EQM_MRO_SERVICE không tồn tại trong database đã cấu hình (schema dbo).'); process.exitCode = 1; return; }
  if (!(serviceEntry.columns || []).some(c => c.name === 'Request ID')) {
    console.error('LỖI: EQM_MRO_SERVICE chưa có cột Request ID. Chạy lại với --ensure-schema (thay đổi additive đã duyệt 29-10-2026).');
    process.exitCode = 1; return;
  }
  const { requests, paymentsByReq } = readSqlite(dbFile);
  const plan = planMigration(requests, paymentsByReq);
  const rows = [...plan.repair, ...plan.service];
  const preview = {
    generatedAt: new Date().toISOString(), sqlite: dbFile, mode: apply ? 'APPLY' : 'DRY-RUN',
    source: { requests: requests.length, requestsWithPayments: paymentsByReq.size },
    plan: { repairRows: plan.repair.length, serviceRows: plan.service.length, baseRows: plan.repair.filter(r => r.kind === 'base').length + plan.service.filter(r => r.kind === 'base').length, installmentRows: rows.filter(r => r.kind === 'payment').length, warnings: plan.warnings },
    amountByCurrency: amountTotals(rows),
    sample: { repair: plan.repair.slice(0, 2), service: plan.service.slice(0, 2) },
  };
  const previewFile = path.join(runtime, 'aps-sql-migration-preview.json');
  fs.writeFileSync(previewFile, JSON.stringify(preview, null, 1));
  console.log('Nguồn: ' + requests.length + ' requests -> ' + plan.repair.length + ' dòng Repair, ' + plan.service.length + ' dòng Service (installments: ' + preview.plan.installmentRows + '), warnings: ' + plan.warnings.length);
  console.log('Preview: ' + previewFile);
  if (!apply) { console.log('DRY-RUN — chưa ghi SQL. Kiểm preview rồi chạy lại với --apply.'); return; }
  const report = { startedAt: new Date().toISOString(), batches: [], inserted: 0, skipped: 0 };
  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);
    const result = await sql.migrateAps(batch);
    report.batches.push({ from: i, count: batch.length, inserted: result.inserted, skipped: result.skipped });
    report.inserted += result.inserted; report.skipped += result.skipped;
    console.log('Batch ' + (i / BATCH_SIZE + 1) + ': inserted=' + result.inserted + ' skipped=' + result.skipped);
  }
  const after = await sql.readApsSchema();
  report.rowCountAfter = { EQM_MRO_REPAIR: after[REPAIR_TABLE] && after[REPAIR_TABLE].rowCount, EQM_MRO_SERVICE: after[SERVICE_TABLE] && after[SERVICE_TABLE].rowCount };
  // Natural key của guard có thể trùng nhau trong chính kế hoạch (dòng lặp trong nguồn); NOT EXISTS gộp chúng,
  // nên đối chiếu theo SỐ KHÓA PHÂN BIỆT, không theo số dòng kế hoạch thô.
  const distinctKeys = list => new Set(list.map(r => JSON.stringify((r.guard || []).map(g => [g.name, g.value === undefined ? null : g.value])))).size;
  const repairDistinct = distinctKeys(plan.repair), serviceDistinct = distinctKeys(plan.service);
  report.reconcile = {
    repair: { planned: plan.repair.length, distinct: repairDistinct, sql: report.rowCountAfter.EQM_MRO_REPAIR, ok: report.rowCountAfter.EQM_MRO_REPAIR >= repairDistinct },
    service: { planned: plan.service.length, distinct: serviceDistinct, sql: report.rowCountAfter.EQM_MRO_SERVICE, ok: report.rowCountAfter.EQM_MRO_SERVICE >= serviceDistinct },
  };
  report.finishedAt = new Date().toISOString();
  const reportFile = path.join(runtime, 'aps-sql-migration-report.json');
  fs.writeFileSync(reportFile, JSON.stringify(report, null, 1));
  console.log('HOÀN TẤT: inserted=' + report.inserted + ' skipped=' + report.skipped + '; SQL sau migration: Repair=' + report.rowCountAfter.EQM_MRO_REPAIR + ', Service=' + report.rowCountAfter.EQM_MRO_SERVICE);
  console.log('Báo cáo: ' + reportFile);
}
function amountTotals(rows) {
  const out = {};
  for (const row of rows) {
    const currency = row.cols.Currency || row.cols.Cur || 'n/a';
    const bucket = out[currency] || (out[currency] = { amount: 0, amountUSD: 0, estimated: 0, final: 0 });
    bucket.amount += Number(row.cols.Amount) || 0;
    bucket.amountUSD += Number(row.cols['Amount 2 (USD)']) || 0;
    bucket.estimated += Number(row.cols['Estimated cost']) || 0;
    bucket.final += Number(row.cols['Final price']) || 0;
  }
  return out;
}

module.exports = { normStatus, dateOnly, num, text, yn, paymentMonthYear, buildRepairRows, buildServiceRows, planMigration, amountTotals, readSqlite, REPAIR_TABLE, SERVICE_TABLE, BATCH_SIZE };
if (require.main === module) main().catch(error => { console.error('LỖI: ' + ((error && error.message) || error)); process.exitCode = 1; });

