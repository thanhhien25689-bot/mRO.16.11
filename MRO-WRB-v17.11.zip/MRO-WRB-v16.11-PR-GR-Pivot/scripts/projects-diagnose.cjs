'use strict';
// Chẩn đoán read-only màn Project Status: không ghi SQL, không sửa dữ liệu, không mở API/static mới.
// Chạy đúng đường dữ liệu Project Status đang dùng: sql.readProjectPR(năm) + sql.readOrders() ->
// mapProjects -> mergeProjectSources -> consolidateProjectRows -> dropPendingPRDuplicates, sau đó tính
// Tiến độ mua hàng bằng chính selectors của frontend theo 3 cách đếm để so sánh:
//   THEO CODE  = quy tắc hiện hành (mỗi ITEM_CODE một lần, lấy bước sớm nhất) -> số đang hiển thị
//   THEO DÒNG  = đếm từng dòng PR/PO theo trạng thái của chính dòng đó
//   MUỘN NHẤT  = mỗi code lấy bước muộn nhất (phương án nghiệp vụ nếu anh muốn đổi)
// Máy chủ đã lưu kết nối SQL (chạy trên máy chủ, bằng Windows account đã lưu mật khẩu DPAPI):
//   npm run projects:diagnose -- --project="EARLY EXECUTION" [--year=2026] [--all]
// Kết quả: console + .runtime/projects-diagnose.json (chỉ metadata, không chứa credential).
const fs = require('node:fs');
const path = require('node:path');
const { getStartupConfig } = require('../backend/core/config.cjs');
const { createSql } = require('../backend/modules/sql/index.cjs');
const { mapProjects, mapOrderProjects, mergeProjectSources, consolidateProjectRows, dropPendingPRDuplicates } = require('../backend/modules/projects/index.cjs');
const { prState } = require('../backend/modules/tracking/index.cjs');

const canonical = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[đĐ]/g, 'd').toUpperCase().replace(/[^0-9A-Z]+/g, ' ').trim();
const arg = (name, fallback) => { const hit = process.argv.find(v => v.startsWith(`--${name}=`)); return hit ? hit.slice(name.length + 3) : fallback; };
const states = ['Chờ Cập nhật PR', 'Đã cập nhật PR', 'Đã có PO', 'Đang giao', 'Đã nhận đủ'];
// Đếm một danh sách trạng thái thành dòng "trạng thái=số" theo đúng thứ tự 5 bước.
const tally = values => states.map(status => `${status}=${values.filter(value => value === status).length}`).join('  ');
// Bar tiến độ của màn hình là lũy kế: bar đầu chỉ đếm code chưa có PR No, bar thứ i đếm code đã đạt từ bước i trở lên.
const cumulative = codes => states.map((status, index) => `${status}=${codes.filter(code => { const i = states.indexOf(code.status); return i >= 0 && (index === 0 ? i === 0 : i >= index); }).length}`).join('  ');
// Gom dòng theo ITEM_CODE trong một dự án; latest=false là công thức "bước sớm nhất" hiện hành.
function codesOf(rows, latest) {
  const byCode = new Map();
  for (const row of rows) { if (!row.itemCode) continue; const list = byCode.get(row.itemCode) || []; list.push(row); byCode.set(row.itemCode, list); }
  return [...byCode].map(([code, list]) => {
    const phases = list.map(row => states.indexOf(row.status));
    const status = phases.some(index => index < 0) ? 'Chưa xác định' : states[latest ? Math.max(...phases) : Math.min(...phases)];
    return { code, status, list, withPR: list.filter(row => row.prNo).length, pending: list.filter(row => !row.prNo && row.source !== 'order').length };
  });
}
// In chẩn đoán cho từng dự án có tên chứa từ khóa (so khớp không dấu, không hoa/thường).
function printProjects(rows, matched, needle) {
  const ids = [...new Set(matched.map(row => row.projectId))];
  if (!ids.length) { console.log(`\nKHÔNG thấy dự án nào có tên chứa "${needle}" sau khi gộp tên. Dùng --all để xem toàn bộ danh sách.`); return []; }
  const report = [];
  for (const id of ids) {
    const before = rows.pr.filter(row => row.projectId === id);
    const after = rows.after.filter(row => row.projectId === id);
    const codes = codesOf(after), latest = codesOf(after, true);
    const rawNames = new Map();
    for (const row of after) rawNames.set(row.project, (rawNames.get(row.project) || 0) + 1);
    const entry = {
      projectId: id, name: after[0].project, type: after.map(row => row.type).join('/'),
      rawProjectNames: [...rawNames].map(([name, count]) => `"${name}" x${count}`).join(', '),
      rowsBeforeDedup: before.length, rowsAfterDedup: after.length, distinctCodes: codes.length,
      byCode: cumulative(codes), byCodeExclusive: tally(codes.map(c => c.status)), byLine: tally(after.map(row => row.status)),
      byCodeBefore: cumulative(codesOf(before)),
      byCodeLatest: tally(latest.map(c => c.status)),
      dropped: before.filter(row => !after.includes(row)).map(row => `${row.itemCode} | PR ${row.prNo || 'trống'} | ${row.status} | ${row.description}`),
      codes: codes.map(c => ({ code: c.code, status: c.status, lines: c.list.length, withPR: c.withPR, pending: c.pending, lines_status: c.list.map(row => `${row.prNo || 'CHUA PR No'}/${row.poNo || 'chua PO'}=${row.status}`).join(' ; ') })),
    };
    report.push(entry);
    console.log(`\n=== ${entry.name} ===`);
    console.log(`Type: ${[...new Set(after.map(row => row.type))].join('/')} | Dòng: ${entry.rowsBeforeDedup} -> ${entry.rowsAfterDedup} sau khử trùng (bỏ ${entry.rowsBeforeDedup - entry.rowsAfterDedup}) | Code khác nhau: ${entry.distinctCodes}`);
    console.log(`Tên Project gốc trong PURCHASE_REQ_INFO: ${entry.rawProjectNames}`);
    console.log(`THEO CODE LŨY KẾ NẾU CHƯA khử trùng (số UI trước bản sửa): ${entry.byCodeBefore}`);
    console.log(`TIẾN ĐỘ THEO CODE LŨY KẾ (màn hình hiển thị): ${entry.byCode}`);
    console.log(`TIẾN ĐỘ THEO CODE không lũy kế (tham khảo) : ${entry.byCodeExclusive}`);
    console.log(`TIẾN ĐỘ THEO DÒNG (đếm từng dòng)          : ${entry.byLine}`);
    if (entry.dropped.length) { console.log('Dòng bị bỏ vì code đã có dòng PR khác:'); entry.dropped.forEach(text => console.log('  - ' + text)); }
    console.log('Theo từng code:');
    for (const code of entry.codes) console.log(`  ${code.code} | ${code.lines} dòng (có PR ${code.withPR}, chưa PR ${code.pending}) | ${code.status} | ${code.lines_status}`);
  }
  return report;
}
async function main() {
  const { runtime } = getStartupConfig();
  if (!fs.existsSync(path.join(runtime, 'sql', 'connection.json'))) { console.error('LỖI: chưa có cấu hình kết nối SQL. Đăng nhập portal bằng developer và lưu kết nối SQL trước.'); process.exitCode = 1; return; }
  const year = Number(arg('year', new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Ho_Chi_Minh', year: 'numeric' }).format(new Date())));
  const keyword = arg('project', 'EARLY EXECUTION'), needle = canonical(keyword);
  const sql = createSql({ runtime });
  let raw = [], readError = '';
  try { raw = await sql.readProjectPR(year); } catch (error) { readError = 'PR: ' + error.message; }
  let orderRows = [];
  try { orderRows = mapOrderProjects(await sql.readOrders(), year); } catch (error) { readError += (readError ? ' | ' : '') + 'Orders: ' + error.message; }
  const mapped = mapProjects(raw, year, [], prState);
  const merged = consolidateProjectRows(mergeProjectSources(mapped.projectRows, orderRows));
  const deduped = dropPendingPRDuplicates(merged);
  console.log(`Năm ${year}: EQM_MRO_PR đọc ${Array.isArray(raw) ? raw.length : 0} dòng -> PR Project hợp lệ ${mapped.projectRows.length} (loại theo PR/PO status ${mapped.projectExcludedStatuses}, sai năm/ngày ${mapped.projectInvalidDates}, mô tả sai format ${mapped.projectUnparsedInfo}, thiếu ITEM_CODE ${mapped.projectMissingCodes}) + Order Remark ${orderRows.length}.`);
  console.log(`Sau gộp tên dự án: ${merged.length} dòng. Sau bỏ dòng chưa có PR No trùng code đã có PR: ${deduped.rows.length} dòng (bỏ ${deduped.skipped}).${readError ? ' CẢNH BÁO: ' + readError : ''}`);
  if (process.argv.includes('--all')) {
    const groups = new Map();
    for (const row of deduped.rows) groups.set(row.projectId, (groups.get(row.projectId) || 0) + 1);
    console.log('\nToàn bộ dự án (dòng | code | Type | tên):');
    for (const [id, count] of [...groups].sort((a, b) => b[1] - a[1])) {
      const list = deduped.rows.filter(row => row.projectId === id);
      console.log(`  ${String(count).padStart(5)} | ${String(codesOf(list).length).padStart(4)} | ${[...new Set(list.map(row => row.type))].join(',')} | ${list[0].project}`);
    }
  }
  const matched = deduped.rows.filter(row => canonical(row.project).includes(needle));
  const report = printProjects({ pr: merged, after: deduped.rows }, matched, keyword);
  const withoutCode = matched.filter(row => !row.itemCode).length;
  if (withoutCode) console.log(`\nLưu ý: ${withoutCode} dòng khớp dự án nhưng thiếu ITEM_CODE nên không vào số code/tiến độ.`);
  fs.writeFileSync(path.join(runtime, 'projects-diagnose.json'), JSON.stringify({ year, keyword, generatedAt: new Date().toISOString(), readError, sqlRows: Array.isArray(raw) ? raw.length : 0, parsedPRRows: mapped.projectRows.length, orderRows: orderRows.length, consolidatedRows: merged.length, dedupedRows: deduped.rows.length, projects: report }, null, 2));
  console.log(`\nChi tiết đã ghi: ${path.join(runtime, 'projects-diagnose.json')} (file vận hành, không commit, không phục vụ static).`);
}
module.exports = { canonical, tally, codesOf, printProjects, main };
if (require.main === module) main().catch(error => { console.error('LỖI:', error && error.stack || error); process.exitCode = 1; });


