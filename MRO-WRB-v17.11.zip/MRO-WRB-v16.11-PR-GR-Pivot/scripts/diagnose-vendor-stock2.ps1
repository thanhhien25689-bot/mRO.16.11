$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.Data
$root = Split-Path -Parent $PSScriptRoot
$connectionPath = Join-Path $root '.runtime\sql\connection.json'
$outPath = Join-Path $root '.runtime\vendor-stock-diagnose.json'
$c = Get-Content $connectionPath -Raw | ConvertFrom-Json
$bytes = [Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($c.secret), $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
$builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
$builder['Data Source'] = 'tcp:' + $c.server + ',' + $c.port
$builder['Initial Catalog'] = $c.database
$builder['User ID'] = $c.user
$builder['Password'] = [Text.Encoding]::UTF8.GetString($bytes)
$builder['Encrypt'] = $true
$builder['TrustServerCertificate'] = [bool]$c.trustServerCertificate
$builder['Connect Timeout'] = 15
$builder['Pooling'] = $false
$connection = New-Object System.Data.SqlClient.SqlConnection($builder.ConnectionString)
$connection.Open()
function Get-Rows($sql) {
  $adapter = New-Object System.Data.SqlClient.SqlDataAdapter($sql, $connection)
  $table = New-Object System.Data.DataTable
  [void]$adapter.Fill($table)
  return ,$table
}
$script:result = [ordered]@{ at = (Get-Date).ToUniversalTime().ToString('o'); checks = @(); issues = @(); modelUsing = @() }
function Add-Check($name, $value) {
  $script:result.checks += [ordered]@{ name = $name; value = $value }
  Write-Host ('  - ' + $name + ' = ' + $value)
}
function Add-Issue($text) {
  $script:result.issues += $text
  Write-Host ('[LOI] ' + $text) -ForegroundColor Red
}
try {
  Write-Host "[1] So dong cac bang nguon"
  $counts = Get-Rows "SELECT (SELECT COUNT(*) FROM dbo.EQM_MRO_MasterData) AS MasterData, (SELECT COUNT(*) FROM dbo.EQM_MRO_Inventory) AS Inventory, (SELECT COUNT(*) FROM dbo.[Production]) AS Production, (SELECT COUNT(*) FROM dbo.EQM_MRO_Inventory_vendor) AS Inventory_vendor, (SELECT COUNT(*) FROM dbo.EQM_MRO_InOut_Vendor) AS InOut_Vendor, (SELECT COUNT(*) FROM dbo.EQM_MRO_VendorTransferConfirm) AS TransferConfirm"
  $row = $counts.Rows[0]
  foreach ($column in $counts.Columns) { Add-Check ('rows ' + $column.ColumnName) ([string]$row[$column.ColumnName]) }
  if ([int64]$row['MasterData'] -eq 0) { Add-Issue 'EQM_MRO_MasterData trong -> ca 2 man deu khong co dong nao' }
  Write-Host "[2] EQM_MRO_MasterData [Item code] - nghi van cho CA 2 man"
  $blank = Get-Rows "SELECT COUNT(*) AS Total, SUM(CASE WHEN LTRIM(RTRIM(ISNULL([Item code],'')))='' THEN 1 ELSE 0 END) AS Blank, COUNT(DISTINCT LTRIM(RTRIM([Item code]))) AS DistinctCodes FROM dbo.EQM_MRO_MasterData"
  $b = $blank.Rows[0]
  Add-Check 'MasterData tong dong' ([string]$b['Total'])
  Add-Check 'MasterData Item code trong hoac NULL' ([string]$b['Blank'])
  Add-Check 'MasterData Item code phan biet' ([string]$b['DistinctCodes'])
  if ([int64]$b['Blank'] -gt 0) { Add-Issue ('MasterData co ' + $b['Blank'] + '/' + $b['Total'] + ' dong Item code trong. catalog() man Vendor loc theo Item code nen bang Ton kho chi tiet rong; vendorBalances() man Ton kho tong hop nem 422 MasterData thieu/trung Item code -> 2 man cung mat du lieu') }
  $duplicates = Get-Rows "SELECT LTRIM(RTRIM([Item code])) AS Code, COUNT(*) AS Cnt FROM dbo.EQM_MRO_MasterData WHERE LTRIM(RTRIM(ISNULL([Item code],''))) <> '' GROUP BY LTRIM(RTRIM([Item code])) HAVING COUNT(*) > 1"
  Add-Check 'MasterData Item code trung - so nhom' ([string]$duplicates.Rows.Count)
  if ($duplicates.Rows.Count -gt 0) {
    $duplicates.Rows | Select-Object -First 10 | ForEach-Object { Write-Host ('      trung: ' + $_['Code'] + ' x' + $_['Cnt']) }
    Add-Issue 'MasterData trung Item code -> catalog() nem 422, man Vendor khong tai duoc gi'
  }

  Write-Host "[3] EQM_MRO_Inventory_vendor - ton dau ky Vendor"
  $vendors = Get-Rows "SELECT LTRIM(RTRIM(ISNULL([Vendor],''))) AS V, COUNT(*) AS Cnt, SUM(CASE WHEN LTRIM(RTRIM(ISNULL([Purchase_Code],'')))='' THEN 1 ELSE 0 END) AS BlankCode, SUM(CASE WHEN [Opening_QTY] IS NULL THEN 1 ELSE 0 END) AS NullOpening FROM dbo.EQM_MRO_Inventory_vendor GROUP BY LTRIM(RTRIM(ISNULL([Vendor],'')))"
  if ($vendors.Rows.Count -eq 0) { Add-Issue 'EQM_MRO_Inventory_vendor trong -> khong Vendor nao co ton dau ky' }
  $known = @('ALT', 'ALV', 'BJ', 'CW')
  foreach ($v in $vendors.Rows) {
    $name = [string]$v['V']
    $display = $name
    if ($display -eq '') { $display = '(trong)' }
    Write-Host ('  - Vendor=' + $display + ' dong=' + $v['Cnt'] + ' Purchase_Code_trong=' + $v['BlankCode'] + ' Opening_QTY_NULL=' + $v['NullOpening'])
    if ($known -notcontains $name.ToUpper()) { Add-Issue ('Inventory_vendor co Vendor=' + $display + ' ngoai ALT/ALV/BJ/CW -> portal bo qua toan bo dong do') }
  }
  $dupVendor = Get-Rows "SELECT LTRIM(RTRIM(ISNULL([Vendor],''))) AS V, LTRIM(RTRIM(ISNULL([Purchase_Code],''))) AS P, COUNT(*) AS Cnt FROM dbo.EQM_MRO_Inventory_vendor GROUP BY LTRIM(RTRIM(ISNULL([Vendor],''))),LTRIM(RTRIM(ISNULL([Purchase_Code],''))) HAVING COUNT(*) > 1"
  Add-Check 'Inventory_vendor trung Vendor va Purchase_Code - so nhom' ([string]$dupVendor.Rows.Count)
  if ($dupVendor.Rows.Count -gt 0) {
    $dupVendor.Rows | Select-Object -First 10 | ForEach-Object { Write-Host ('      trung: ' + $_['V'] + ' / ' + $_['P'] + ' x' + $_['Cnt']) }
    Add-Issue 'Inventory_vendor trung Vendor/Purchase_Code -> mapStock nem 422, ca tab Vendor loi'
  }
  $orphan = Get-Rows "SELECT COUNT(*) AS Cnt FROM dbo.EQM_MRO_Inventory_vendor v LEFT JOIN dbo.EQM_MRO_MasterData m ON LTRIM(RTRIM(m.[Item code])) = LTRIM(RTRIM(v.[Purchase_Code])) WHERE LTRIM(RTRIM(ISNULL(v.[Purchase_Code],''))) <> '' AND m.[Item code] IS NULL"
  Add-Check 'Purchase_Code khong co trong MasterData' ([string]$orphan.Rows[0]['Cnt'])
  if ([int64]$orphan.Rows[0]['Cnt'] -gt 0) { Add-Issue 'Co Purchase_Code khong khop MasterData -> Ton kho tong hop nem 422 MasterData thieu/trung Item code cua Inventory Vendor' }


  Write-Host "[4] Model Using - bo loc pham vi Vendor"
  $listed = @{ 'Almus Tech' = @('WATCH8','WATCH9','WATCH','WATCH&BUD','TAB','L71','ALLMODEL'); 'Almus Vina' = @('BUDS4','BUD','WATCH&BUD','BUDS3FE','R640','ALLMODEL'); 'Bujeon' = @('BUDS4','BUD','WATCH&BUD','BUDS3FE','R640','ALLMODEL'); 'Chitwing' = @('KEYBOARD','WATCH&BUD','ALLMODEL') }
  $models = Get-Rows "SELECT LTRIM(RTRIM(ISNULL([Model Using],''))) AS M, COUNT(*) AS Cnt FROM dbo.EQM_MRO_MasterData GROUP BY LTRIM(RTRIM(ISNULL([Model Using],'')))"
  $unmatched = @()
  $perVendor = @{}
  foreach ($m in $models.Rows) {
    $raw = [string]$m['M']
    $tokens = @()
    if ($raw -ne '') { $tokens = @($raw -split '[,/-]' | ForEach-Object { $_.Trim().ToUpper().Replace(' ', '') } | Where-Object { $_ -ne '' }) }
    $hit = @()
    $unknown = @()
    foreach ($token in $tokens) {
      $found = $false
      foreach ($list in $listed.Values) { if ($list -contains $token) { $found = $true } }
      if ($found) { $hit += $token } else { $unknown += $token }
    }
    $script:result.modelUsing += [ordered]@{ value = $raw; rows = [int64]$m['Cnt']; tokens = ($tokens -join '|'); matched = ($hit -join '|'); unmatched = ($unknown -join '|') }
    Write-Host ('  - [' + $raw + '] x' + $m['Cnt'] + '  khop=' + ($hit -join ',') + '  KHONG_khop=' + ($unknown -join ','))
    if ($tokens.Count -eq 0) { Add-Issue 'Co dong MasterData Model Using trong -> moi Vendor deu bi loai ma hang do' }
    foreach ($token in $unknown) { if ($unmatched -notcontains $token) { $unmatched += $token } }
    foreach ($vendorName in $listed.Keys) { foreach ($token in $tokens) { if ($listed[$vendorName] -contains $token) { $perVendor[$vendorName] = [int]$perVendor[$vendorName] + [int64]$m['Cnt'] } } }
  }
  if ($unmatched.Count -gt 0) { Write-Host ('[CHU Y] Model chua khai bao trong itemModels: ' + ($unmatched -join ', ') + ' -> them vao backend/modules/vendor/index.cjs') -ForegroundColor Yellow }
  foreach ($vendorName in $listed.Keys) { Add-Check ('dong MasterData thuoc pham vi ' + $vendorName) ([string]$perVendor[$vendorName]) }
  Write-Host "[5] Production - san luong tuan"
  $prodModels = Get-Rows "SELECT LTRIM(RTRIM(ISNULL([Model],''))) AS M, COUNT(*) AS RowsPerModel FROM dbo.[Production] GROUP BY LTRIM(RTRIM(ISNULL([Model],'')))"
  Add-Check 'Production so model' ([string]$prodModels.Rows.Count)
  $prodModels.Rows | ForEach-Object { Write-Host ('      ' + $_['M'] + ' - ' + $_['RowsPerModel'] + ' dong nam') }
  $summary = 'Khong phat hien loi cau truc'
  if ($result.issues.Count -gt 0) { $summary = [string]$result.issues.Count + ' van de du lieu (xem dong [LOI] o tren)' }
  Write-Host ('==> KET LUAN: ' + $summary)
} finally {
  $connection.Close()
  $result | ConvertTo-Json -Depth 6 | Set-Content -Path $outPath -Encoding UTF8
  Write-Host ('Da luu chi tiet: ' + $outPath)
}

