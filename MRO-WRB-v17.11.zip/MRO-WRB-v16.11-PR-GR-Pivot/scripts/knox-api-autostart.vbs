' Runs knox-api-autostart.ps1 with no console window, a moment after logon.
' The PowerShell script skips the start when 127.0.0.1:2292 already listens,
' so this file never fights with a hand-opened KnoxChatbox\start.bat window.
Option Explicit

Dim shell, folder, command
Set shell = CreateObject("WScript.Shell")

' Give Windows a moment to restore the network session and Knox Teams.
WScript.Sleep 20000

folder = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & folder & "knox-api-autostart.ps1"""

' 0 = hidden window, False = do not wait.
shell.Run command, 0, False
