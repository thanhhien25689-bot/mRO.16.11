'use strict';
// Chẩn đoán kết nối Knox APIBOT, chạy TRÊN MÁY CHỦ Portal (read-only, không ghi file, không gửi tin).
// Cách chạy: npm run knox:check
//   --url=http://may:2292   chỉ kiểm tra một URL cụ thể (mặc định: lấy URL đã lưu trong .runtime/messages/settings.json)
//   --port=2292            port để quét cổng đang nghe (mặc định 2292 hoặc port lấy từ URL đã lưu)
//   --timeout=4000          giây chờ mỗi lần thử (mặc định 4000)
//   --runtime=<thu-muc>     thu muc .runtime khac (mac dinh ./.runtime)
//   --no-netstat            bo qua buoc liet ke cong TCP dang nghe
//   --json                  xuat ket qua may doc duoc
// Portal goi Knox APIBOT tu chinh may chủ (không phải từ máy người dùng), nên must chạy script này ở máy chủ.
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const DEFAULT_PORT = 2292;

function parseArgs(argv) {
  const args = { url: '', port: 0, timeout: 4000, runtime: path.resolve(__dirname, '..', '.runtime'), json: false, netstat: true };
  for (const arg of argv) {
    const [flag, value] = arg.includes('=') ? [arg.slice(0, arg.indexOf('=')), arg.slice(arg.indexOf('=') + 1)] : [arg, ''];
    if (flag === '--url') args.url = String(value || '').trim();
    else if (flag === '--port') args.port = Number(value) || 0;
    else if (flag === '--timeout') args.timeout = Math.min(20000, Math.max(300, Number(value) || 4000));
    else if (flag === '--runtime') args.runtime = path.resolve(String(value || '.'));
    else if (flag === '--json') args.json = true;
    else if (flag === '--no-netstat') args.netstat = false;
    else throw new Error(`Tham số không hỗ trợ: ${arg}`);
  }
  return args;
}

// Đọc URL APIBOT đã lưu qua public API của module tin nhắn (không tự parse file cấu hình).
function readStoredUrl(runtime) {
  try {
    const { createMessages } = require('../backend/modules/messages/index.cjs');
    const messages = createMessages({ runtime, autoStartScheduler: false });
    const stored = messages.readConfig();
    return String((stored && stored.apibotUrl) || '').trim();
  } catch { return ''; }
}

// Mã lỗi thật có thể nằm ở cause.code, error.code, hoặc chỉ trong chuỗi message (tùy phiên bản Node/undici).
const ERROR_CODES = /\b(ECONNREFUSED|ECONNRESET|ECONNABORTED|EHOSTUNREACH|ENETUNREACH|ENOTFOUND|EAI_AGAIN|EACCES|ETIMEDOUT|ERR_[A-Z0-9_]+|TimeoutError|AbortError)\b/;
function describeError(error) {
  const cause = (error && error.cause) || null;
  const message = String((cause && cause.message) || (cause && cause.code) || (error && error.message) || '').slice(0, 200);
  const code = String((cause && cause.code) || (error && error.code) || (message.match(ERROR_CODES) || [])[1] || (error && error.name) || 'UNKNOWN').slice(0, 40);
  const host = cause && cause.address ? String(cause.address) : '';
  const port = cause && cause.port ? String(cause.port) : '';
  const fromMessage = /\b(?:connect|connect_ex|read)\s+\S+\s+((?:\[[0-9a-f:]+\]|[\w.-]+):\d+)/i.exec(message);
  const tried = host ? `${host}${port ? `:${port}` : ''}` : (fromMessage ? fromMessage[1] : '');
  const syscall = cause && cause.syscall ? String(cause.syscall) : '';
  return { code, ...(syscall ? { syscall } : {}), ...(tried ? { tried } : {}), message };
}

async function probe(url, timeoutMs) {
  const started = Date.now();
  try {
    const response = await fetch(url, { method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(timeoutMs) });
    let info = {};
    try { info = await response.json(); } catch { /* không phải JSON (FastAPI docs, nginx, IIS...) */ }
    // ok = HTTP trả lời; ready = /health báo Knox Teams đã nối được CDP (server sống nhưng Knox Teams tắt thì ok:false).
    return {
      url,
      ok: response.ok,
      ready: response.ok && info.ok !== false,
      status: response.status,
      ...(info.version ? { version: String(info.version).slice(0, 24) } : {}),
      ...(info.cdp_port === undefined ? {} : { cdpPort: String(info.cdp_port).slice(0, 10) }),
      ...(typeof info.knox_exe_found === 'boolean' ? { knoxExeFound: info.knox_exe_found } : {}),
      ...(info.knox_exe ? { knoxExe: String(info.knox_exe).slice(0, 180) } : {}),
      ms: Date.now() - started,
    };
  } catch (error) {
    return { url, ok: false, ms: Date.now() - started, ...describeError(error) };
  }
}

// Ứng viên cần thử: URL đã lưu + mọi cách trỏ về chính máy chủ trên cùng port.
function candidateUrls({ url, port, addresses }) {
  const list = [];
  const push = value => { if (value && !list.includes(value)) list.push(value); };
  push(url);
  const usePort = port || (url ? Number(new URL(url).port) || DEFAULT_PORT : DEFAULT_PORT);
  if (!url) push(`http://127.0.0.1:${usePort}`);
  push(`http://127.0.0.1:${usePort}`);
  push(`http://localhost:${usePort}`);
  push(`http://[::1]:${usePort}`);
  for (const address of addresses) push(`http://${address}:${usePort}`);
  return list;
}

function machineAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) for (const item of list || []) if (item.family === 'IPv4' && !item.internal) out.push(item.address);
  return out;
}

function parseNetstat(text, port) {
  const listeners = [];
  for (const line of String(text || '').split(/\r?\n/)) {
    const cells = line.trim().split(/\s+/);
    if (cells.length < 5 || !/^TCP$/i.test(cells[0]) || !/LISTENING/i.test(cells[3])) continue;
    const local = cells[1];
    const match = /^(.+):(\d+)$/.exec(local);
    if (!match) continue;
    const host = match[1].replace(/^\[|\]$/g, '');
    const localPort = Number(match[2]);
    if (port && localPort !== Number(port)) continue;
    listeners.push({ host, port: localPort, pid: Number(cells[4]) || 0, ipv6: host.includes(':') || host === '::' });
  }
  return listeners;
}

function listeningSockets(port) {
  if (process.platform !== 'win32') throw new Error('Liệt kê cổng TCP tự động chỉ hỗ trợ Windows; dùng --url để kiểm tra thủ công.');
  return parseNetstat(execFileSync('netstat', ['-ano', '-p', 'TCP'], { encoding: 'utf8', timeout: 15000 }), port);
}

function processName(pid) {
  try {
    const out = execFileSync('tasklist', ['/FI', `PID eq ${pid}`, '/NH', '/FO', 'CSV'], { encoding: 'utf8', timeout: 15000 });
    const line = out.split(/\r?\n/).find(cell => cell.includes(`"${pid}"`));
    const name = line ? String(line.split('","')[0].replace(/^"*/, '')) : '';
    return name || '';
  } catch { return ''; }
}
const LOOPBACK = new Set(['127.0.0.1', 'localhost', '::1', '[::1]']);
const hostOf = value => { try { return new URL(value).hostname.replace(/^\[|\]$/g, ''); } catch { return ''; } };

// Kết luận nguyên nhân từ kết quả thử /health + danh sách cổng đang nghe. Hàm thuần để test không cần mạng.
function classify({ configuredUrl, probes, listeners, netstatError }) {
  const findings = [];
  const fixes = [];
  const okProbe = probes.find(entry => entry.ok);
  const configured = probes.find(entry => entry.url === configuredUrl);
  const portsOpen = probes.filter(entry => entry.status);
  if (okProbe) {
    // Knox Local Messenger trả lời nhưng /health báo ok:false: server sống, cửa sổ Knox Teams chưa điều khiển được.
    const notReady = okProbe.ready === false || (configured && configured.ok && configured.ready === false);
    if (configured && configured.ok) {
      if (!notReady) return { verdict: 'ok', findings: [`Knox APIBOT trả /health OK (HTTP ${okProbe.status}${okProbe.version ? `, version ${okProbe.version}` : ''}) tại chính URL đã lưu ${okProbe.url}.`], fixes: [] };
      const exeMissing = okProbe.knoxExeFound === false || (configured && configured.knoxExeFound === false);
      const cdp = (okProbe.cdpPort || (configured && configured.cdpPort) || '').trim();
      return {
        verdict: 'knox_not_ready',
        findings: [
          `Knox Local Messenger ĐANG CHẠY tại ${configured.url} (HTTP ${configured.status}${okProbe.version ? `, version ${okProbe.version}` : ''}) nhưng /health trả ok:false — server sống mà chưa điều khiển được cửa sổ Knox Teams.`,
          ...(exeMissing ? [`Không tìm thấy KnoxTeams.exe tại ${((okProbe.knoxExe || (configured && configured.knoxExe)) || '(để trống)').trim()} — biến KNOX_TEAMS_EXE trong file .env sai.`] : []),
          `Knox Local Messenger chỉ gửi được khi cửa sổ Knox Teams trên máy này đang mở và đăng nhập (kênh CDP${cdp ? ` port ${cdp}` : ''}).`,
        ],
        fixes: exeMissing
          ? ['Sửa KNOX_TEAMS_EXE trong file .env của thư mục KnoxChatbox về đúng đường dẫn KnoxTeams.exe, chạy lại start.bat, rồi chạy lại npm run knox:check.']
          : ['Mở Knox Teams và đăng nhập, rồi chạy start-knox-cdp.bat (hoặc chạy start.bat để bật cả hai) trong thư mục KnoxChatbox.', 'Chạy lại npm run knox:check, rồi mở Trung tâm tin nhắn nhấn "Xem trước" để xác nhận.'],
      };
    }
    if (notReady) findings.push(`Knox Local Messenger trả lời tại ${okProbe.url} nhưng /health báo ok:false (chưa điều khiển được cửa sổ Knox Teams).`);
    findings.push(`Knox APIBOT trả /health OK tại ${okProbe.url}, nhưng URL đã lưu trong Portal (${configuredUrl || 'chưa cấu hình'}) ${configured ? (configured.status ? `trả HTTP ${configured.status}` : `không kết nối được (${configured.code})`) : 'không được thử'}.`);
    fixes.push(`Sửa ô "URL Knox APIBOT" trong Trung tâm tin nhắn thành ${okProbe.url} rồi nhấn Lưu cấu hình.`);
    return { verdict: 'misconfigured', findings, fixes };
  }
  const port = (configuredUrl ? Number(new URL(configuredUrl).port) : 0) || (probes[0] ? Number(new URL(probes[0].url).port) : 0) || DEFAULT_PORT;
  if (netstatError) findings.push(`Chưa kiểm tra được danh sách cổng TCP đang nghe (${netstatError}), vì vậy chưa khẳng định Knox có chạy hay không.`);
  else if (!listeners.length) findings.push(`Không có tiến trình nào trên máy này đang LISTENING cổng ${port}.`);
  else {
    const hosts = [...new Set(listeners.map(item => item.host))];
    const pids = [...new Set(listeners.map(item => item.pid).filter(Boolean))];
    const names = [...new Set(listeners.map(item => item.process).filter(Boolean))];
    findings.push(`Cổng ${port} có tiến trình đang nghe trên: ${hosts.join(', ')}${pids.length ? ` (PID ${pids.join(', PID ')}${names.length ? `, ${names.join(', ')}` : ''}).` : '.'}`);
    const loopbackOnly = hosts.every(host => LOOPBACK.has(host) || host === '0.0.0.0' || host === '*');
    if (portsOpen.length) findings.push(`Cổng ${port} có trả HTTP (${portsOpen.map(item => `${item.url} → ${item.status}`).join(', ')}) nhưng không phải /health của Knox APIBOT — nhiều khả năng dịch vụ khác đang chiếm cổng.`);
    else if (loopbackOnly) findings.push('Knox chỉ bind loopback nên chỉ tiến trình trên chính máy chủ Portal gọi được.');
    const configuredHost = hostOf(configuredUrl);
    if (configuredHost === 'localhost' && hosts.includes('127.0.0.1') && !hosts.includes('::1')) {
      findings.push('URL đã lưu dùng "localhost" trong khi Knox (uvicorn) chỉ nghe IPv4 127.0.0.1 → Node nhận ::1 trước nên báo ECONNREFUSED.');
      fixes.push(`Đổi URL đã lưu thành http://127.0.0.1:${port} (không dùng localhost).`);
    }
    if (configuredHost && !LOOPBACK.has(configuredHost) && loopbackOnly) {
      findings.push(`URL đã lưu trỏ tới ${configuredHost} nhưng Knox trên máy này chỉ bind loopback.`);
      fixes.push(`Nếu Knox chạy ngay trên máy chủ Portal: nhập http://127.0.0.1:${port}. Nếu Knox chạy ở máy khác: chạy Knox với host 0.0.0.0 (VD: python run.py --host 0.0.0.0) rồi nhập http://<IP-may-Knox>:${port}.`);
    }
    if (!loopbackOnly) {
      const external = hosts.find(host => !LOOPBACK.has(host));
      if (external) fixes.push(`Thử URL http://${external}:${port} — Knox đang bind đúng IP này, không bind loopback.`);
    }
  }
  if (!fixes.length) {
    if (portsOpen.length) fixes.push(`Kiểm tra dịch vụ đang chiếm cổng ${port} (taskkill theo PID ở trên hoặc đổi port cho Knox).`);
    else if (!listeners.length && !netstatError) {
      findings.push('Knox APIBOT chưa chạy trên máy chủ Portal (python run.py chưa chạy, chạy ở máy khác, hoặc chạy port khác).');
      fixes.push(`Chạy Knox APIBOT trên chính máy chủ Portal với đúng port ${port}, rồi chạy lại npm run knox:check.`);
      fixes.push(`Nếu buộc phải chạy Knox ở máy khác: mở port + bind 0.0.0.0 trên máy đó, rồi nhập http://<IP-may-Knox>:${port} vào Trung tâm tin nhắn.`);
    } else if (!listeners.length) {
      fixes.push(`Chạy Knox APIBOT (python run.py) trên chính máy chủ Portal với đúng port ${port}, rồi chạy lại npm run knox:check.`);
      fixes.push('Chạy lại CLI không kèm --no-netstat trên Windows để liệt kê cổng đang nghe và tiến trình chiếm cổng.');
    } else fixes.push('Knox đang nghe nhưng Portal không kết nối được: kiểm tra tường lửa/phần mềm bảo mật chặn kết nối loopback, hoặc Knox vừa khởi động lại — thử lại sau ít phút.');
  }
  return { verdict: 'unreachable', findings, fixes };
}
// Một dòng in cho một lần thử /health (tách hàm để tránh template lồng nhiều tầng).
function probeLine(entry) {
  if (entry.ok) return `OK   ${entry.url} → HTTP ${entry.status}${entry.version ? ` version ${entry.version}` : ''} · ${entry.ms} ms${entry.ready === false ? ' · /health ok:false (chưa điều khiển được Knox Teams)' : ''}`;
  const why = `${entry.code || 'LOI'}${entry.tried ? ` khi connect ${entry.tried}` : ''}${entry.status ? ` (HTTP ${entry.status})` : ''}`;
  return `LỖI  ${entry.url} → ${why} · ${entry.ms} ms`;
}

// Chạy toàn bộ phép thử cho một URL đã lưu (tách khỏi main để test không cần spawn tiến trình).
async function runChecks({ configuredUrl, port, timeoutMs, netstat }) {
  const urls = candidateUrls({ url: configuredUrl, port, addresses: machineAddresses() });
  const probes = [];
  // probe gọi <url>/health nhưng phần tử kết quả giữ đúng URL cấu hình để so được với URL đã lưu.
  for (const url of urls) probes.push({ ...(await probe(`${url}/health`, timeoutMs)), url });
  let listeners = [];
  let netstatError = '';
  if (netstat) {
    try { listeners = listeningSockets(port).map(item => ({ ...item, process: item.pid ? processName(item.pid) : '' })); }
    catch (error) { netstatError = String((error && error.message) || error).slice(0, 140); }
  } else netstatError = 'bỏ qua (--no-netstat)';
  return { configuredUrl, port, timeoutMs, probes, listeners, netstatError, ...classify({ configuredUrl, probes, listeners, netstatError }) };
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const storedUrl = args.url ? '' : readStoredUrl(args.runtime);
  let configuredUrl = args.url || storedUrl || `http://127.0.0.1:${DEFAULT_PORT}`;
  try { new URL(configuredUrl); } catch { console.error(`LỖI: URL không hợp lệ: ${configuredUrl}`); return 1; }
  const port = args.port || Number(new URL(configuredUrl).port) || DEFAULT_PORT;
  const result = await runChecks({ configuredUrl, port, timeoutMs: args.timeout, netstat: args.netstat });
  const { probes, listeners, netstatError } = result;
  result.fromSettings = !args.url && !!storedUrl;
  if (args.json) { console.log(JSON.stringify(result, null, 2)); return result.verdict === 'ok' ? 0 : 2; }
  console.log(`URL Knox APIBOT đang kiểm tra: ${configuredUrl}${result.fromSettings ? ' (lấy từ .runtime/messages/settings.json)' : (args.url ? ' (nhập bằng --url)' : ' (chưa có cấu hình, dùng mặc định)')}`);
  console.log(`\nGọi /health từ máy chủ Portal (${probes.length} ứng viên, timeout ${args.timeout} ms):`);
  for (const entry of probes) console.log(probeLine(entry));
  if (netstatError) console.log(`\nCổng TCP: ${netstatError}`);
  else if (!listeners.length) console.log(`\nCổng TCP: không tiến trình nào LISTENING cổng ${port}.`);
  else { console.log(`\nCổng ${port} đang nghe:`); for (const item of listeners) console.log(` ${item.host}:${item.port} · PID ${item.pid}${item.process ? ` (${item.process})` : ''}`); }
  console.log(`\nKẾT LUẬN: ${result.verdict === 'ok' ? 'Knox APIBOT kết nối được từ máy chủ Portal.' : result.verdict === 'misconfigured' ? 'Knox APIBOT được, nhưng URL đã lưu trong Portal sai.' : result.verdict === 'knox_not_ready' ? 'Knox Local Messenger đã chạy nhưng chưa điều khiển được cửa sổ Knox Teams (tin chưa gửi được).' : 'Knox APIBOT không kết nối được từ máy chủ Portal.'}`);
  for (const line of result.findings) console.log(` • ${line}`);
  if (result.fixes.length) { console.log('\nCần làm:'); for (const line of result.fixes) console.log(` - ${line}`); }
  console.log('\nLưu ý: Portal gọi Knox APIBOT từ máy chủ (không phải từ máy người dùng); lịch gửi tự động cũng chạy trên máy chủ.');
  return result.verdict === 'ok' ? 0 : 2;
}

module.exports = { parseArgs, candidateUrls, describeError, parseNetstat, classify, probe, runChecks, readStoredUrl, machineAddresses, listeningSockets, probeLine };
if (require.main === module) main().then(code => { process.exitCode = code; }).catch(error => { console.error(`LỖI: ${(error && error.message) || error}`); process.exitCode = 1; });