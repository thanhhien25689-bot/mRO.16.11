// Audit chỉ-đọc bảng Cost Saving: node scripts/audit-cost-saving.cjs [năm]
// Chạy trên máy chủ đã lưu cấu hình SQL. Chỉ SELECT, không ghi SQL/file, không in mật khẩu.
const path = require('node:path');
const { createSql } = require('../backend/modules/sql/index.cjs');
const { createCostSaving } = require('../backend/modules/cost-saving/index.cjs');

const root = path.resolve(__dirname, '..');
const runtime = process.env.MRO_RUNTIME || path.join(root, '.runtime');
const year = Number(process.argv[2]) || new Date().getFullYear();

(async () => {
  const sql = createSql({runtime});
  try {
    const rows = await sql.readCostSaving();
    console.log(`Bảng dbo.EQM_CostSavingActivity: ${rows.length} dòng.`);
    const columns = [...new Set(rows.flatMap(row => Object.keys(row || {})))];
    console.log('Tên cột đọc được:', columns.length ? columns.join(' | ') : '(không có cột nào)');
    console.log('15 dòng đầu (nguyên văn JSON):');
    rows.slice(0, 15).forEach((row, index) => console.log(`[${index + 1}]`, JSON.stringify(row)));
    const costSaving = createCostSaving({sql});
    const value = await costSaving.read(year);
    const mapping = value.mapping || {};
    console.log(`\nCột đã khớp: kiểu=${mapping.shape || '—'} | Trạng thái="${mapping.type || '—'}" | Năm="${mapping.year || '—'}" | Plan="${mapping.plan || '—'}" | Actual="${mapping.actual || '—'}" | Tháng="${mapping.month || '—'}" | Ngày="${mapping.date || '—'}"`);
    if (value.monthColumns) console.log('Cột tháng dạng ngang nhận được:', value.monthColumns);
    if (mapping.plan && mapping.plan.toLowerCase().trim() !== 'plan') console.log('Cảnh báo: cột Plan khớp được không đúng nguyên văn, kiểm tra lại bảng.');
    if (mapping.actual && mapping.actual.toLowerCase().trim() !== 'actual') console.log('Cảnh báo: cột Actual khớp được không đúng nguyên văn, kiểm tra lại bảng.');
    const format = new Intl.NumberFormat('en-US', {maximumFractionDigits: 2});
    console.log(`\nÁnh xạ đang dùng cho năm ${year} (đơn vị K$):`);
    value.items.forEach(item => console.log(`- ${String(item.month).padStart(2, '0')}/${year} = ${item.value === null ? 'trống' : format.format(item.value)} (nguồn: ${item.origin === 'plan' ? 'Plan của tháng tương lai' : 'Actual'}; ${item.count} dòng)`));
    console.log('Tổng:', format.format(value.total), 'K$ | Tháng Actual có số:', value.actualMonths, '| Tháng Plan tương lai:', value.planMonths);
    console.log('Nguồn:', value.source, '| Đọc lúc:', value.updatedAt || '(chưa đọc)', value.warning ? `| Cảnh báo: ${value.warning}` : '');
    if (value.source === 'empty') console.log('\nChưa đọc được bảng. Nếu 15 dòng ở trên có dữ liệu, hãy gửi lại output này để khóa đúng tên cột.');
  } catch (error) {
    console.error('Audit thất bại:', error.message);
    process.exitCode = 1;
  }
})();
