'use strict';
// Báo cáo siêu dữ liệu (read-only) cho 4 bảng SQL Repair & Service: EQM_MRO_REPAIR, EQM_MRO_SERVICE,
// EQM_MRO_ServiceContract, EQM_MRO_ServiceMonthlyPlan. Chạy trên máy chủ bằng đúng Windows account đã lưu
// kết nối SQL (mật khẩu bảo vệ bằng DPAPI CurrentUser). Chỉ SELECT INFORMATION_SCHEMA + COUNT_BIG; không ghi SQL.
// Kết quả: .runtime/aps-sql-schema-report.json (chỉ metadata, không chứa credential). Gửi file này về làm căn cứ mapping Phase 2+.
const fs = require('node:fs');
const path = require('node:path');
const { getStartupConfig } = require('../backend/core/config.cjs');
const { createSql } = require('../backend/modules/sql/index.cjs');

const TABLES = Object.freeze(['EQM_MRO_REPAIR', 'EQM_MRO_SERVICE', 'EQM_MRO_ServiceContract', 'EQM_MRO_ServiceMonthlyPlan']);
// Gợi ý cơ học theo tên cột — chỉ để nổi ứng viên khi soạn mapping, không phải ánh xạ chốt.
const CANDIDATE_GROUPS = Object.freeze({
  identifier: /(^|_)(id|no|code|key)($|_)|request/i,
  status: /status|state|tinh[_ ]?trang|trang[_ ]?thai/i,
  payment: /pay|paid|thanhtoan|all[_ ]?toan/i,
  amount: /amount|amt|price|cost|money|est|qty|soluong/i,
  currency: /curr|usd|vnd|loai[_ ]?tien|unit/i,
  contract: /contract|hop[_ ]?dong|(^|_)po(_|$)|po[_ ]?no/i,
  plan: /plan|budget|ngansach|ke[_ ]?hoach|version/i,
  date: /date|_dt$|time|ngay|month|year|nam|thang/i,
  attachment: /file|pdf|attach|tai[_ ]?lieu|duong[_ ]?dan|path|url|storage/i,
});

function candidatesOf(columns) {
  const out = {};
  for (const [group, pattern] of Object.entries(CANDIDATE_GROUPS)) {
    const hits = (columns || []).filter(c => pattern.test(String(c.name))).map(c => c.name);
    if (hits.length) out[group] = hits;
  }
  return out;
}

function summarize(schema) {
  const summary = [], missing = [];
  for (const name of TABLES) {
    const entry = schema && schema[name];
    if (!entry || entry.exists !== true) { missing.push(name); continue; }
    summary.push({ name, exists: true, columnCount: (entry.columns || []).length, rowCount: Number(entry.rowCount) || 0, candidates: candidatesOf(entry.columns) });
  }
  return { summary, missing };
}

async function main() {
  const { runtime } = getStartupConfig();
  const outFile = path.join(runtime, 'aps-sql-schema-report.json');
  if (!fs.existsSync(path.join(runtime, 'sql', 'connection.json'))) {
    console.error('LỖI: chưa có cấu hình kết nối SQL. Đăng nhập portal bằng developer và lưu kết nối trong mục SQL trước.');
    process.exitCode = 1;
    return;
  }
  const sql = createSql({ runtime });
  let schema;
  try {
    schema = await sql.readApsSchema();
  } catch (error) {
    console.error('LỖI đọc schema: ' + ((error && error.message) || error));
    console.error('Kiểm tra: đang chạy đúng máy chủ lưu kết nối? Đúng Windows account đã lưu mật khẩu (DPAPI)? SQL Server đang bật?');
    process.exitCode = 1;
    return;
  }
  const report = { generatedAt: new Date().toISOString(), source: 'aps-schema', tables: schema, ...summarize(schema) };
  fs.mkdirSync(runtime, { recursive: true });
  const temp = outFile + '.' + process.pid + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(report, null, 1));
  fs.renameSync(temp, outFile);
  console.log('Báo cáo schema Repair & Service (chỉ metadata, không credential):');
  for (const row of report.summary) {
    console.log(`  OK  ${row.name}: ${row.columnCount} cột, ${row.rowCount} dòng`);
    for (const [group, names] of Object.entries(row.candidates)) console.log(`      ${group}: ${names.join(', ')}`);
  }
  for (const name of report.missing) console.log('  MẤT ' + name + ' — bảng chưa tồn tại trong database đã cấu hình (schema dbo).');
  console.log('Đã ghi: ' + outFile);
  console.log('Bước tiếp theo: gửi file này cho bộ phận triển khai để chốt ánh xạ cột Phase 2. Script không ghi bất kỳ bảng SQL nào.');
  if (report.missing.length) process.exitCode = 2;
}

module.exports = { TABLES, summarize, candidatesOf };
if (require.main === module) main().catch(error => { console.error('LỖI: ' + ((error && error.message) || error)); process.exitCode = 1; });
