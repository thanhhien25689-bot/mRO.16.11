// Di trú Portal APS cũ (APS repair service Potal_ 4) vào PORTAL MRO WRB — chạy MỘT LẦN.
// Điều kiện: ĐÃ DỪNG server portal APS cũ. Cách chạy: node scripts/migrate-aps-app.cjs ["đường-dẫn-portal-cũ"]
const fs = require('node:fs');
const path = require('node:path');
if (require.main !== module) throw new Error('scripts/migrate-aps-app.cjs la CLI mot lan — chi chay "npm run migrate:aps"; khong require/import file nay vi se de lai backend/modules/aps/app va aps-app.');
const ROOT = path.resolve(__dirname, '..');
const OLD = path.resolve(process.argv[2] || process.env.MRO_APS_LEGACY || path.join(ROOT, '..', 'APS repair service Potal_ 4'));
const APP = path.join(ROOT, 'backend', 'modules', 'aps', 'app');
let patched = 0;
function need(cond, msg) { if (!cond) { console.error('LỖI: ' + msg); process.exit(1); } }
function patch(text, from, to, label, count = 1) {
  const n = text.split(from).length - 1;
  need(n === count, `Vị trí vá "${label}" gặp ${n} lần (cần đúng ${count}) — portal cũ đã thay đổi, kiểm tra thủ công.`);
  patched++;
  return text.split(from).join(to);
}
function copyTo(from, to) { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); }
function copyDir(from, to) { if (fs.existsSync(from)) { fs.mkdirSync(to, { recursive: true }); fs.cpSync(from, to, { recursive: true }); return true; } return false; }
need(fs.existsSync(path.join(OLD, 'server.mjs')), 'Không thấy portal APS cũ tại ' + OLD + ' — truyền đường dẫn làm tham số 1.');

// 1) dependency npm offline (fflate, fast-xml-parser...) — copy nguyên node_modules portal cũ.
if (fs.existsSync(path.join(OLD, 'node_modules'))) { copyDir(path.join(OLD, 'node_modules'), path.join(ROOT, 'node_modules')); console.log('1/5 node_modules → OK'); }
else console.log('1/5 node_modules: portal cũ không có — tự chạy: npm install fflate@0.8.3 fast-xml-parser@5.11.2');

// 2) backend: copy nguyên các module nghiệp vụ; core.mjs = server.mjs cũ (không listen, chạy trong process WRB).
fs.mkdirSync(APP, { recursive: true });
for (const f of ['store.mjs', 'domain.mjs', 'import.mjs', 'export.mjs', 'notify.mjs', 'drm-extract.ps1']) copyTo(path.join(OLD, 'backend', f), path.join(APP, 'backend', f));
let core = fs.readFileSync(path.join(OLD, 'server.mjs'), 'utf8');
core = patch(core, "const backupsRoot=path.join(root,'backups',path.basename(runtime));", "const backupsRoot=path.join(runtime,'backups');", 'backupsRoot → .runtime/aps/backups');
fs.writeFileSync(path.join(APP, 'core.mjs'), core);
copyDir(path.join(OLD, 'templates'), path.join(APP, 'templates'));
console.log('2/5 backend → backend/modules/aps/app/ OK');

// 3) frontend: ứng dụng APS tĩnh phục vụ tại /aps-app/ (WRB static allowlist), API đổi sang /api/aps-app.
const DEST = path.join(ROOT, 'aps-app');
fs.mkdirSync(DEST, { recursive: true });
let html = fs.readFileSync(path.join(OLD, 'public', 'index.html'), 'utf8');
html = patch(html, 'href="/styles.css"', 'href="./styles.css"', 'index.html stylesheet');
html = patch(html, 'src="/app.mjs"', 'src="./app.mjs"', 'index.html module script');
fs.writeFileSync(path.join(DEST, 'index.html'), html);
fs.copyFileSync(path.join(OLD, 'public', 'styles.css'), path.join(DEST, 'styles.css'));
let app = fs.readFileSync(path.join(OLD, 'public', 'app.mjs'), 'utf8');
app = patch(app, "fetch(url,{method,headers:{", "fetch('/api/aps-app'+url,{method,headers:{", 'api() prefix');
app = patch(app, "throw Object.assign(Error(result.error||'Không thực hiện được'),{status:response.status})", "throw Object.assign(Error(result.error||result.message||'Không thực hiện được'),{status:response.status})", 'api() error message từ WRB');
app = patch(app, "async function login(){const s=await api('/api/session');if(s.user){auth=s;",
  "async function login(){const w=await fetch('/api/session',{credentials:'same-origin'}).then(r=>r.json()).catch(()=>({}));if(!w.user){$('#login').innerHTML=\"<div class='login-wrap'><div class='login-card'><h1>Chưa đăng nhập MRO WRB</h1><p class='muted'>Hãy đăng nhập portal MRO WRB rồi tải lại trang này.</p></div></div>\";return}const s=await api('/api/session');if(s.user){auth={user:s.user,csrf:w.csrf};", 'boot session WRB');
app = patch(app, "await api('/api/logout',{method:'POST'});auth={};$('#app').hidden=true;await login()",
  "await fetch('/api/logout',{method:'POST',headers:{'X-CSRF-Token':auth.csrf}});top.location.href='/'", 'logout WRB');
app = patch(app, "avatarSrc=u=>'/api/avatar/'", "avatarSrc=u=>'/api/aps-app/api/avatar/'", 'avatar URL');
app = patch(app, "$('#account').onclick=()=>{const u=auth.user;modal('Tài khoản · '+u.username,",
  "$('#account').onclick=()=>{const u=auth.user;modal('Tài khoản · '+u.username,`<p>Tài khoản, mật khẩu và phân quyền do <b>portal MRO WRB</b> quản lý. Toàn bộ chức năng nghiệp vụ giữ nguyên.</p>`);return;modal('Tài khoản · '+u.username,", 'account modal WRB-info');
app = patch(app, "location.href='/api/backups/'", "location.href='/api/aps-app/api/backups/'", 'backup download URL');
app = patch(app, "a.href='/api/export'", "a.href='/api/aps-app/api/export'", 'export URL');
app = patch(app, "a.href='/api/bulk-update/export?requestId='", "a.href='/api/aps-app/api/bulk-update/export?requestId='", 'bulk-update export URL');
app = patch(app, "new EventSource('/api/events')", "new EventSource('/api/aps-app/api/events')", 'SSE URL');
app = patch(app, 'href="/api/templates/', 'href="/api/aps-app/api/templates/', 'template URLs', 2);
fs.writeFileSync(path.join(DEST, 'app.mjs'), app);
console.log('3/5 frontend → aps-app/ OK (' + patched + ' vị trí vá khớp)');

// 4) dữ liệu SQLite + file đính kèm (chỉ copy nếu chưa có để không đè dữ liệu đã phát sinh ở WRB).
const SRCRT = path.join(OLD, '.runtime'), DSTRT = path.join(ROOT, '.runtime', 'aps');
const db = path.join(SRCRT, 'aps.sqlite');
if (fs.existsSync(db)) {
  if (fs.existsSync(path.join(DSTRT, 'aps.sqlite'))) console.log('4/5 dữ liệu: .runtime/aps đã tồn tại — giữ nguyên (xóa thủ công nếu muốn copy lại)');
  else {
    fs.mkdirSync(DSTRT, { recursive: true });
    for (const suf of ['', '-wal', '-shm', '-journal']) if (fs.existsSync(db + suf)) fs.copyFileSync(db + suf, path.join(DSTRT, 'aps.sqlite' + suf));
    copyDir(path.join(SRCRT, 'files'), path.join(DSTRT, 'files'));
    console.log('4/5 dữ liệu → .runtime/aps OK');
  }
} else console.log('4/5 dữ liệu: không thấy aps.sqlite ở portal cũ — bỏ qua');
console.log('5/5 HOÀN TẤT. Bước tiếp: 1) chắc chắn đã DỪNG server portal APS cũ; 2) npm start (WRB); 3) vào tab "Repair & Service" — mọi nút chức năng hoạt động tại đây; 4) portal cũ không dùng nữa, có thể xóa khi anh quyết định.');

