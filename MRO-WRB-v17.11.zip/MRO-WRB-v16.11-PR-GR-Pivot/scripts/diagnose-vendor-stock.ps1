# Chan doan nguyen nhan "Ton kho chi tiet" (man Tong quan Vendor) va "Ton kho tong hop" trong.
# CHI SELECT. Dung lai ket noi + mat khau DPAPI da luu trong .runtime/sql/connection.json (khong hoi mat khau).
# Chay:  powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\diagnose-vendor-stock.ps1
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.Data

$root = Split-Path -Parent $PSScriptRoot
$connectionPath = Join-Path $root '.runtime\sql\connection.json'
$outPath = Join-Path $root '.runtime\vendor-stock-diagnose.json'
if (-not (Test-Path $connectionPath)) { throw "Khong thay $connectionPath" }
$c = Get-Content $connectionPath -Raw | ConvertFrom-Json
$bytes = [Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($c.secret), $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)

$builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
$builder['Data Source'] = 'tcp:' + $c.server + ',' + $c.port
$builder['Initial Catalog'] = $c.database
$builder['User ID'] = $c.user
$builder['Password'] = [Text.Encoding]::UTF8.GetString($bytes)
$builder['Encrypt'] = $true
$builder['TrustServerCertificate'] = [bool]$c.trustServerCertificate
$builder['Connect Timeout'] = 15
$builder['Pooling'] = $false
$connection = New-Object System.Data.SqlClient.SqlConnection($builder.ConnectionString)
$connection.Open()
Write-Host ('[OK] Ket noi SQL ' + $c.server + ' / ' + $c.database)

function Get-Rows($sql) {
  $adapter = New-Object System.Data.SqlClient.SqlDataAdapter($sql, $connection)
  $table = New-Object System.Data.DataTable
  [void]$adapter.Fill($table)
  return ,$table
}

$script:result = [ordered]@{ at = (Get-Date).ToUniversalTime().ToString('o'); checks = @(); issues = @(); modelUsing = @() }
function Add-Check($name, $value) {
  $script:result.checks += [ordered]@{ name = $name; value = $value }
  Write-Host ('  - ' + $name + ' = ' + $value)
}
function Add-Issue($text) { $script:result.issues += $text; Write-Host ('[LOI] ' + $text) -ForegroundColor Red }


try {
  Write-Host "`n[1] So dong cac bang nguon"
  $counts = Get-Rows "SELECT (SELECT COUNT(*) FROM dbo.EQM_MRO_MasterData) AS MasterData, (SELECT COUNT(*) FROM dbo.EQM_MRO_Inventory) AS Inventory, (SELECT COUNT(*) FROM dbo.[Production]) AS Production, (SELECT COUNT(*) FROM dbo.EQM_MRO_Inventory_vendor) AS Inventory_vendor, (SELECT COUNT(*) FROM dbo.EQM_MRO_InOut_Vendor) AS InOut_Vendor, (SELECT COUNT(*) FROM dbo.EQM_MRO_VendorTransferConfirm) AS TransferConfirm"
  $row = $counts.Rows[0]
  foreach ($column in $counts.Columns) { Add-Check ('rows ' + $column.ColumnName) ([string]$row[$column.ColumnName]) }
  if ([int64]$row['MasterData'] -eq 0) { Add-Issue 'EQM_MRO_MasterData trong -> ca 2 man deu khong co dong nao.' }

  Write-Host "`n[2] EQM_MRO_MasterData.[Item code] (nghi van cho CA 2 man)"
  $blank = Get-Rows "SELECT COUNT(*) AS Total, SUM(CASE WHEN LTRIM(RTRIM(ISNULL([Item code],'')))='' THEN 1 ELSE 0 END) AS Blank, COUNT(DISTINCT LTRIM(RTRIM([Item code]))) AS DistinctCodes FROM dbo.EQM_MRO_MasterData"
  $b = $blank.Rows[0]
  Add-Check 'MasterData tong dong' ([string]$b['Total'])
  Add-Check 'MasterData Item code trong/NULL' ([string]$b['Blank'])
  Add-Check 'MasterData Item code phan biet' ([string]$b['DistinctCodes'])
  if ([int64]$b['Blank'] -gt 0) { Add-Issue ('MasterData co ' + $b['Blank'] + '/' + $b['Total'] + " dong [Item code] trong. catalog() man Vendor loc 'Item code' nen bang Ton kho chi tiet TRONG; vendorBalances() man Ton kho tong hop nem 422 'MasterData thieu/trung Item code cua Inventory Vendor' -> 2 man cung mat du lieu.") }
  $duplicates = Get-Rows "SELECT LTRIM(RTRIM([Item code])) AS Code, COUNT(*) AS Cnt FROM dbo.EQM_MRO_MasterData WHERE LTRIM(RTRIM(ISNULL([Item code],''))) <> '' GROUP BY LTRIM(RTRIM([Item code])) HAVING COUNT(*) > 1"
  Add-Check 'MasterData Item code trung (so nhom)' ([string]$duplicates.Rows.Count)
  if ($duplicates.Rows.Count -gt 0) {
    $duplicates.Rows | Select-Object -First 10 | ForEach-Object { Write-Host ('      trung: ' + $_['Code'] + ' x' + $_['Cnt']) }
    Add-Issue 'MasterData trung Item code -> catalog() nem 422 "MasterData trung Item code", man Vendor khong tai duoc gi.'
  }

  Write-Host "`n[3] EQM_MRO_Inventory_vendor (tồn đầu kỳ Vendor)"
  $vendors = Get-Rows "SELECT LTRIM(RTRIM(ISNULL([Vendor],''))) AS V, COUNT(*) AS Cnt, SUM(CASE WHEN LTRIM(RTRIM(ISNULL([Purchase_Code],'')))='' THEN 1 ELSE 0 END) AS BlankCode, SUM(CASE WHEN [Opening_QTY] IS NULL THEN 1 ELSE 0 END) AS NullOpening FROM dbo.EQM_MRO_Inventory_vendor GROUP BY LTRIM(RTRIM(ISNULL([Vendor],'')))"
  if ($vendors.Rows.Count -eq 0) { Add-Issue 'EQM_MRO_Inventory_vendor trống -> không Vendor nào có tồn đầu kỳ.' }
  $known = @('ALT', 'ALV', 'BJ', 'CW')
  foreach ($v in $vendors.Rows) {
    $name = [string]$v['V']; $display = if ($name -eq '') { '(trống)' } else { $name }
    Write-Host ('  - Vendor=' + $display + ' dòng=' + $v['Cnt'] + ' | Purchase_Code trống=' + $v['BlankCode'] + ' | Opening_QTY NULL=' + $v['NullOpening'])
    if ($known -notcontains $name.ToUpper()) { Add-Issue ("Inventory_vendor có Vendor='" + $display + "' ngoài ALT/ALV/BJ/CW -> portal bỏ qua toàn bộ dòng đó.") }
  }
  $dupVendor = Get-Rows "SELECT LTRIM(RTRIM(ISNULL([Vendor],''))) AS V, LTRIM(RTRIM(ISNULL([Purchase_Code],''))) AS P, COUNT(*) AS Cnt FROM dbo.EQM_MRO_Inventory_vendor GROUP BY LTRIM(RTRIM(ISNULL([Vendor],''))),LTRIM(RTRIM(ISNULL([Purchase_Code],''))) HAVING COUNT(*) > 1"
  Add-Check 'Inventory_vendor trùng Vendor+Purchase_Code (số nhóm)' ([string]$dupVendor.Rows.Count)
  if ($dupVendor.Rows.Count -gt 0) {
    $dupVendor.Rows | Select-Object -First 10 | ForEach-Object { Write-Host ('      trùng: ' + $_['V'] + ' / ' + $_['P'] + ' x' + $_['Cnt']) }
    Add-Issue 'Inventory_vendor trùng Vendor/Purchase_Code -> mapStock ném 422, cả tab Vendor lỗi.'
  }
  $orphan = Get-Rows "SELECT COUNT(*) AS Cnt FROM dbo.EQM_MRO_Inventory_vendor v LEFT JOIN dbo.EQM_MRO_MasterData m ON LTRIM(RTRIM(m.[Item code])) = LTRIM(RTRIM(v.[Purchase_Code])) WHERE LTRIM(RTRIM(ISNULL(v.[Purchase_Code],''))) <> '' AND m.[Item code] IS NULL"
  Add-Check 'Inventory_vendor Purchase_Code không có trong MasterData' ([string]$orphan.Rows[0]['Cnt'])
  if ([int64]$orphan.Rows[0]['Cnt'] -gt 0) { Add-Issue 'Có Purchase_Code không khớp MasterData -> Tồn kho tổng hợp 422 "MasterData thiếu/trùng Item code của Inventory Vendor".' }

  Write-Host "`n[4] Model Using (bộ lọc phạm vi Vendor) so với itemModels trong code"
  $listed = @{ 'Almus Tech' = @('WATCH8','WATCH9','WATCH','WATCH&BUD','TAB','L71','ALLMODEL'); 'Almus Vina' = @('BUDS4','BUD','WATCH&BUD','BUDS3FE','R640','ALLMODEL'); 'Bujeon' = @('BUDS4','BUD','WATCH&BUD','BUDS3FE','R640','ALLMODEL'); 'Chitwing' = @('KEYBOARD','WATCH&BUD','ALLMODEL') }
  $models = Get-Rows "SELECT LTRIM(RTRIM(ISNULL([Model Using],''))) AS M, COUNT(*) AS Cnt FROM dbo.EQM_MRO_MasterData GROUP BY LTRIM(RTRIM(ISNULL([Model Using],'')))"
  $unmatched = @(); $perVendor = @{}
  foreach ($m in $models.Rows) {
    $raw = [string]$m['M']
    $tokens = @(); if ($raw -ne '') { $tokens = @($raw -split '[,/\-]' | ForEach-Object { $_.Trim().ToUpper().Replace(' ', '') } | Where-Object { $_ -ne '' }) }
    $hit = @(); $unknown = @()
    foreach ($token in $tokens) { $found = $false; foreach ($list in $listed.Values) { if ($list -contains $token) { $found = $true } }; if ($found) { $hit += $token } else { $unknown += $token } }
    $script:result.modelUsing += [ordered]@{ value = $raw; rows = [int64]$m['Cnt']; tokens = ($tokens -join '|'); matched = ($hit -join '|'); unmatched = ($unknown -join '|') }
    Write-Host ('  - "' + $raw + '" x' + $m['Cnt'] + '  khớp=' + ($hit -join ',') + '  KHONG khop=' + ($unknown -join ','))
    if ($tokens.Count -eq 0) { Add-Issue 'Có dòng MasterData Model Using trống -> mọi Vendor đều bị loại mã hàng đó.' }
    foreach ($token in $unknown) { if ($unmatched -notcontains $token) { $unmatched += $token } }
    foreach ($vendorName in $listed.Keys) { foreach ($token in $tokens) { if ($listed[$vendorName] -contains $token) { $perVendor[$vendorName] = [int]$perVendor[$vendorName] + [int64]$m['Cnt'] } } }
  }
  if ($unmatched.Count -gt 0) { Write-Host ('[CHÚ Ý] Model chưa khai báo trong itemModels: ' + ($unmatched -join ', ') + ' -> thêm vào backend/modules/vendor/index.cjs') -ForegroundColor Yellow }
  foreach ($vendorName in $listed.Keys) { Add-Check ('dòng MasterData thuộc phạm vi ' + $vendorName) ([string]$perVendor[$vendorName]) }

  Write-Host "`n[5] Production (sản lượng tuần)"
  $prodModels = Get-Rows "SELECT LTRIM(RTRIM(ISNULL([Model],''))) AS M, COUNT(*) AS RowsPerModel FROM dbo.[Production] GROUP BY LTRIM(RTRIM(ISNULL([Model],'')))"
  Add-Check 'Production số model' ([string]$prodModels.Rows.Count)
  $prodModels.Rows | ForEach-Object { Write-Host ('      ' + $_['M'] + ' (' + $_['RowsPerModel'] + ' dòng năm)') }

  $summary = if ($result.issues.Count) { $result.issues.Count + ' vấn đề dữ liệu (xem dòng [LỖI] ở trên)' } else { 'Không phát hiện lỗi cấu trúc; cần xem tiếp dữ liệu tuần/sản lượng' }
  Write-Host ("`n==> KẾT LUẬN: " + $summary)
} finally {
  $connection.Close()
  $result | ConvertTo-Json -Depth 6 | Set-Content -Path $outPath -Encoding UTF8
  Write-Host ('Đã lưu chi tiết: ' + $outPath)
}
