#!/usr/bin/env node
/* 09-11-2026: đẩy data/pic3.json (xác nhận PIC3 cũ) lên dbo.EQM_MRO_PRSelect theo yêu cầu
"không lưu file JSON trên máy chủ portal". Mặc định DRY-RUN: chỉ đọc SQL và in kế hoạch.
--apply mới ghi qua public adapter sql.writePrSelect (worker prselect-write, INSERT-only ở CLI này;
dòng trùng LineKey nhưng khác nội dung chỉ báo cáo để người vận hành quyết định, CLI không UPDATE/DELETE).
Chạy trên máy chủ Portal với kết nối SQL đã lưu:  npm run prselect:migrate  rồi  npm run prselect:migrate -- --apply
*/
'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {createSql}=require('../backend/modules/sql/index.cjs');
const root=path.resolve(__dirname,'..');
const argv=process.argv.slice(2);
const apply=argv.includes('--apply');
const runtimeIndex=argv.indexOf('--runtime');
const runtime=runtimeIndex>=0?path.resolve(argv[runtimeIndex+1]):path.join(root,'.runtime');
const fileIndex=argv.indexOf('--file');
const file=fileIndex>=0?path.resolve(argv[fileIndex+1]):path.join(root,'data','pic3.json');
const fail=m=>{console.error('LỖI: '+m);process.exitCode=1;};
const trimQty=v=>{const s=String(v??'');return /^\d+(?:\.\d+)?$/.test(s)?s.replace(/(\.\d*?)0+$/,'$1').replace(/\.$/,''):s;};
const dateOk=v=>/^\d{4}-\d{2}-\d{2}$/.test(String(v||''))?String(v):'';
// LineKey = đúng khóa trong tài liệu pic3.json (entries: identity(PR) 64-hex, drafts: source.key 64-hex).
// Formula phải khớp docFromRows/entryCols trong backend/modules/tracking/index.cjs (test khóa).
function planRows(doc){
 const rows=[];
 for(const group of ['entries','drafts'])for(const[key,entry]of Object.entries(doc[group]||{})){
  if(!/^[a-f0-9]{64}$/.test(key))throw Error(`Khóa không hợp lệ ở ${group}; chưa di trú.`);
  const source=entry.source||{},pr=entry.pr||null;
  rows.push({lineKey:key,purchaseCode:source.purchaseCode||'',originalCode:source.originalCode||'',itemName:source.itemName||'',vendor:source.vendor||'',orderDate:dateOk(source.date),prNo:pr?String(pr.PR_NO||''):'',prSeq:pr?String(pr.PR_SEQ||''):'',buyQty:trimQty(entry.purchaseQuantity),note:entry.note||'',sourceJson:JSON.stringify(source),prJson:pr?JSON.stringify(pr):'',revision:entry.revision||'',updatedAt:entry.updatedAt||new Date().toISOString(),updatedBy:entry.updatedBy||'migrate'});
 }
 return rows;
}
function sameJson(a,b){try{return JSON.stringify(JSON.parse(a))===JSON.stringify(JSON.parse(b));}catch{return !a&&!b;}}
function sameRow(a,row){return a.revision===(row.Revision||'')&&a.purchaseCode===String(row.PurchaseCode||'')&&a.originalCode===String(row.OriginalCode||'')&&a.itemName===String(row.ItemName||'')&&a.vendor===String(row.Vendor||'')&&a.orderDate===String(row.OrderDate||'')&&trimQty(a.buyQty)===trimQty(row.BuyQty)&&a.prNo===String(row.PRNo||'')&&a.prSeq===String(row.PRSeq||'')&&a.note===String(row.Note||'')&&sameJson(a.sourceJson,row.SourceJson)&&sameJson(a.prJson,row.PRJson);}
(async()=>{
 if(!fs.existsSync(file)){fail(`Không tìm thấy ${path.relative(root,file)}. Nếu xác nhận PIC3 đã nằm hết trên SQL thì bỏ qua CLI này.`);return;}
 let doc;try{doc=JSON.parse(fs.readFileSync(file,'utf8'));}catch(error){fail(`pic3.json không đọc được: ${error.message}`);return;}
 if(doc.version!==1||!doc.entries||!doc.drafts){fail('pic3.json sai cấu trúc (version/entries/drafts).');return;}
 const planned=planRows(doc);
 const sql=createSql({runtime});
 let table;try{table=await sql.readPrSelect();}catch(error){fail(`Không đọc được EQM_MRO_PRSelect: ${error.message}`);return;}
 const byKey=new Map((table||[]).map(r=>[String(r.LineKey||''),r]));
 const missing=[],mismatched=[],duplicatesPlanned=[];
 const seen=new Set();
 for(const row of planned){
  if(seen.has(row.lineKey)){duplicatesPlanned.push(row.lineKey);continue;}seen.add(row.lineKey);
  const existing=byKey.get(row.lineKey);
  if(!existing)missing.push(row);
  else if(!sameRow(row,existing))mismatched.push(row.lineKey);
 }
 const onlyInTable=[...byKey.keys()].filter(k=>!seen.has(k));
 console.log(`pic3.json : ${Object.keys(doc.entries).length} entries + ${Object.keys(doc.drafts).length} drafts = ${planned.length} dòng`);
 console.log(`SQL bảng  : ${(table||[]).length} dòng EQM_MRO_PRSelect`);
 console.log(`Cần INSERT: ${missing.length} | Khớp: ${planned.length-missing.length-mismatched.length-duplicatesPlanned.length} | Lệch nội dung: ${mismatched.length} | Chỉ có trên SQL: ${onlyInTable.length}${duplicatesPlanned.length?` | Khóa trùng trong JSON: ${duplicatesPlanned.length}`:''}`);
 if(mismatched.length)console.log('  LineKey lệch (CLI không tự sửa, kiểm tra thủ công):\n   '+mismatched.slice(0,10).join('\n   ')+(mismatched.length>10?`\n   ... (${mismatched.length})`:''));
 if(onlyInTable.length)console.log('  Dòng chỉ có trên SQL (giữ nguyên, thường do máy khác đã ghi trước):\n   '+onlyInTable.slice(0,10).join('\n   ')+(onlyInTable.length>10?`\n   ... (${onlyInTable.length})`:''));
 if(mismatched.length||duplicatesPlanned.length){fail('Có khóa trùng hoặc nội dung khác SQL; chưa ghi để tránh ghi đè/mất dữ liệu. Đối soát từng dòng trước.');return;}
 if(!apply){console.log('\nDRY-RUN: chưa ghi gì. Chạy lại với --apply để đẩy các dòng còn thiếu lên SQL.');return;}
 if(missing.length){
  for(let i=0;i<missing.length;i+=200){
   const chunk=missing.slice(i,i+200);
   const result=await sql.writePrSelect({inserts:chunk});
   console.log(`  Đợt ${Math.floor(i/200)+1}: inserted=${result.inserted} updated=${result.updated} deleted=${result.deleted}`);
  }
 }
 let recheck;try{recheck=await sql.readPrSelect();}catch(error){fail(`Ghi xong nhưng không đọc lại được để đối soát: ${error.message}`);return;}
 const reRows=new Map((recheck||[]).map(r=>[String(r.LineKey||''),r]));
 const stillMissing=planned.filter(row=>!reRows.has(row.lineKey));
 const different=planned.filter(row=>reRows.has(row.lineKey)&&!sameRow(row,reRows.get(row.lineKey)));
 if(stillMissing.length||different.length){fail(`Đối soát FAILED: còn ${stillMissing.length} dòng thiếu và ${different.length} dòng lệch nội dung.`);return;}
 console.log(`\nKHỚP: ${planned.length}/${planned.length} dòng pic3.json đã nằm trên EQM_MRO_PRSelect (tổng bảng ${recheck.length} dòng).`);
 console.log('Bước kế: khởi động lại Portal (code mới đọc bảng), mở tab PR & Tracking kiểm tra số dòng đã lưu;');
 console.log(`xong thì đổi tên file cũ để không ai dùng lại: rename "${path.relative(root,file)}" "${path.basename(file)}.bak-${new Date().toISOString().slice(0,10).replace(/-/g,'')}"`);
})().catch(error=>{fail(error&&error.message||String(error));});
