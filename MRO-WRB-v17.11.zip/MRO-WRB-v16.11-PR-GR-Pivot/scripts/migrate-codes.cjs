#!/usr/bin/env node
'use strict';

const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const DEFAULT_AUDIT_TIME='1970-01-01T00:00:00.000Z';
const text=value=>String(value??'');
const limited=(value,max,name)=>{const result=text(value);if(result.length>max)throw Error(name+' vượt giới hạn '+max+' ký tự.');return result;};
const dateOnly=value=>{const s=text(value);if(!s)return '';if(!/^\d{4}-\d{2}-\d{2}$/.test(s)||!Number.isFinite(Date.parse(s))||new Date(s).toISOString().slice(0,10)!==s)throw Error('Ngày Code Issue không hợp lệ: '+s);return s;};
const isoTime=value=>{const s=text(value);if(!s)return DEFAULT_AUDIT_TIME;const d=new Date(s);if(!Number.isFinite(d.getTime()))throw Error('Thời gian audit Code Issue không hợp lệ.');return d.toISOString();};
function skipSpace(source,state){while(/\s/.test(source[state.i]||'')&&state.i<source.length)state.i++;}
function readString(source,state){const start=state.i;if(source[state.i++]!=='"')throw Error('JSON key không hợp lệ.');let escaped=false;for(;state.i<source.length;state.i++){const c=source[state.i];if(escaped){escaped=false;continue;}if(c==='\\'){escaped=true;continue;}if(c==='"'){state.i++;return JSON.parse(source.slice(start,state.i));}}throw Error('JSON string chưa đóng.');}
function skipValue(source,state){skipSpace(source,state);const c=source[state.i];if(c==='"'){readString(source,state);return;}if(c==='{'){state.i++;skipSpace(source,state);if(source[state.i]==='}'){state.i++;return;}while(state.i<source.length){readString(source,state);skipSpace(source,state);if(source[state.i++]!==':')throw Error('JSON object sai cấu trúc.');skipValue(source,state);skipSpace(source,state);const end=source[state.i++];if(end==='}')return;if(end!==',')throw Error('JSON object sai cấu trúc.');skipSpace(source,state);}throw Error('JSON object chưa đóng.');}if(c==='['){state.i++;skipSpace(source,state);if(source[state.i]===']'){state.i++;return;}while(state.i<source.length){skipValue(source,state);skipSpace(source,state);const end=source[state.i++];if(end===']')return;if(end!==',')throw Error('JSON array sai cấu trúc.');}throw Error('JSON array chưa đóng.');}while(state.i<source.length&&!/[\s,}\]]/.test(source[state.i]))state.i++;if(state.i===0)throw Error('JSON value không hợp lệ.');}
function duplicateEntryKeys(source){const state={i:0},duplicates=[];skipSpace(source,state);if(source[state.i++]!=='{')return duplicates;skipSpace(source,state);if(source[state.i]==='}')return duplicates;while(state.i<source.length){const key=readString(source,state);skipSpace(source,state);if(source[state.i++]!==':')throw Error('JSON object sai cấu trúc.');skipSpace(source,state);if(key==='entries'&&source[state.i]==='{'){state.i++;skipSpace(source,state);const seen=new Set();if(source[state.i]==='}'){state.i++;}else while(state.i<source.length){const entryKey=readString(source,state);if(seen.has(entryKey))duplicates.push(entryKey);seen.add(entryKey);skipSpace(source,state);if(source[state.i++]!==':')throw Error('JSON entries sai cấu trúc.');skipValue(source,state);skipSpace(source,state);const end=source[state.i++];if(end==='}')break;if(end!==',')throw Error('JSON entries sai cấu trúc.');skipSpace(source,state);}}else skipValue(source,state);skipSpace(source,state);const end=source[state.i++];if(end==='}')break;if(end!==',')throw Error('JSON object sai cấu trúc.');skipSpace(source,state);}return duplicates;}
function planRows(doc){
 if(!doc||doc.version!==1||!doc.entries||typeof doc.entries!=='object'||Array.isArray(doc.entries))throw Error('code-issues.json sai cấu trúc (version/entries).');
 return Object.entries(doc.entries).map(([key,entry])=>{
  if(!/^[a-f0-9]{64}$/.test(key)||!entry||typeof entry!=='object'||Array.isArray(entry))throw Error('Khóa hoặc entry Code Issue không hợp lệ: '+key);
  const baseKey=text(entry.baseKey||key);if(entry.rfq!=null&&(typeof entry.rfq!=='object'||Array.isArray(entry.rfq)))throw Error('RFQ snapshot Code Issue không hợp lệ: '+key);const rfq=entry.rfq||null;
  if(!/^[a-f0-9]{64}$/.test(baseKey))throw Error('BaseKey Code Issue không hợp lệ: '+key);
  const revision=text(entry.revision)||crypto.createHash('sha256').update(JSON.stringify({key,entry})).digest('hex');if(!/^[a-f0-9]{64}$/.test(revision))throw Error('Revision Code Issue không hợp lệ: '+key);
  const createdAt=isoTime(entry.createdAt),updatedAt=isoTime(entry.updatedAt);
  const createdBy=limited(entry.createdBy||entry.updatedBy||'legacy-migration',80,'CreatedBy'),updatedBy=limited(entry.updatedBy||entry.createdBy||'legacy-migration',80,'UpdatedBy');
  const rfqJson=rfq?JSON.stringify(rfq):'';limited(rfqJson,500000,'RFQJson');
  const typeOfCode=limited(entry.typeOfCode,10,'TypeOfCode');if(!['','IMK','Direct','Local'].includes(typeOfCode))throw Error('TypeOfCode không hợp lệ: '+key);
  return{lineKey:key,baseKey,orderDate:dateOnly(entry.date),orderWeek:limited(entry.week,10,'OrderWeek'),vendor:limited(entry.vendor,200,'Vendor'),wrbCode:limited(entry.wrbCode,100,'WRBCode'),originalCode:limited(entry.originalCode,100,'OriginalCode'),purchaseCode:limited(entry.purchaseCode,100,'PurchaseCode'),typeOfCode,action:limited(entry.action,500,'Action'),status:limited(entry.status,40,'Status'),rfqItemCode:limited(rfq?.ITEM_CODE,100,'RFQItemCode'),rfqNo:limited(rfq?.QT_REQ_NO,100,'RFQNo'),rfqSeq:limited(rfq?.QT_REQ_SEQ,50,'RFQSeq'),rfqReqSubNo:limited(rfq?.RFQ_REQ_SUB_NO,100,'RFQReqSubNo'),rfqStatus:limited(rfq?.RFQ_STATUS_NAME,100,'RFQStatus'),requestDate:dateOnly(rfq?.REQUEST_DATE),receiptDate:dateOnly(rfq?.RECEIPT_DATE),contractName:limited(rfq?.CONTRACT_NAME,200,'ContractName'),rfqJson,createdAt,createdBy,updatedAt,updatedBy,revision};
 });
}
function canonical(value){if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}';return JSON.stringify(value);}
function sameRow(expected,actual){const pairs=[['LineKey','lineKey'],['BaseKey','baseKey'],['OrderDate','orderDate'],['OrderWeek','orderWeek'],['Vendor','vendor'],['WRBCode','wrbCode'],['OriginalCode','originalCode'],['PurchaseCode','purchaseCode'],['TypeOfCode','typeOfCode'],['Action','action'],['Status','status'],['RFQItemCode','rfqItemCode'],['RFQNo','rfqNo'],['RFQSeq','rfqSeq'],['RFQReqSubNo','rfqReqSubNo'],['RFQStatus','rfqStatus'],['RequestDate','requestDate'],['ReceiptDate','receiptDate'],['ContractName','contractName'],['CreatedBy','createdBy'],['UpdatedBy','updatedBy'],['Revision','revision']];for(const [sqlKey,key]of pairs)if(text(actual?.[sqlKey])!==text(expected[key]))return false;try{for(const [sqlKey,key]of [['CreatedAt','createdAt'],['UpdatedAt','updatedAt']]){const raw=text(actual?.[sqlKey]);const stamp=raw?new Date(/[zZ]|[+-]\d{2}:?\d{2}$/.test(raw)?raw:raw+'Z').toISOString():'';if(stamp!==expected[key])return false;}return canonical(actual?.RFQJson?JSON.parse(actual.RFQJson):null)===canonical(expected.rfqJson?JSON.parse(expected.rfqJson):null);}catch{return false;}}
async function reconcile({sql,doc,sourceText='',apply=false}){
 const duplicateKeys=sourceText?duplicateEntryKeys(sourceText):[];if(duplicateKeys.length)throw Error('Khóa entries trùng trong JSON: '+[...new Set(duplicateKeys)].join(', '));
 const planned=planRows(doc);if(planned.length>1000)throw Error('Migration vượt giới hạn 1,000 dòng trong một transaction.');
 const existing=await sql.readCodeIssues(),byKey=new Map(existing.map(row=>[text(row.LineKey),row])),seen=new Set(),missing=[],matching=[],mismatched=[];
 for(const row of planned){if(seen.has(row.lineKey)){mismatched.push(row.lineKey);continue;}seen.add(row.lineKey);const current=byKey.get(row.lineKey);if(!current)missing.push(row);else if(sameRow(row,current))matching.push(row.lineKey);else mismatched.push(row.lineKey);}
 const sqlOnly=existing.map(row=>text(row.LineKey)).filter(key=>!seen.has(key));if(mismatched.length)throw Object.assign(Error('Có LineKey trùng hoặc nội dung khác SQL; chưa ghi để tránh ghi đè.'),{report:{planned:planned.length,missing:missing.length,matching:matching.length,mismatched,sqlOnly}});
 const report={planned:planned.length,missing:missing.length,matching:matching.length,mismatched:[],sqlOnly};if(!apply)return report;
 if(missing.length){const result=await sql.migrateCodeIssues(missing);if(result.conflicts?.length)throw Object.assign(Error('SQL phát hiện conflict trong transaction migration.'),{report:{...report,conflicts:result.conflicts}});}
 const readback=await sql.readCodeIssues(),after=new Map(readback.map(row=>[text(row.LineKey),row])),absent=planned.filter(row=>!after.has(row.lineKey)).map(row=>row.lineKey),different=planned.filter(row=>after.has(row.lineKey)&&!sameRow(row,after.get(row.lineKey))).map(row=>row.lineKey);
 if(absent.length||different.length)throw Object.assign(Error('Đối soát sau migration thất bại.'),{report:{...report,absent,different}});
 return{...report,missing:0,verified:planned.length,sqlTotal:readback.length};
}
async function main(argv=process.argv.slice(2)){
 const args=new Set(argv.filter(v=>v.startsWith('--')));if([...args].some(v=>!['--apply','--file','--runtime'].includes(v)))throw Error('Tham số không hỗ trợ.');
 const getArg=name=>{const i=argv.indexOf(name);if(i<0)return null;if(!argv[i+1]||argv[i+1].startsWith('--'))throw Error('Thiếu giá trị cho '+name);return path.resolve(argv[i+1]);};
 const file=getArg('--file')||path.join(root,'data','code-issues.json'),runtime=getArg('--runtime')||path.join(root,'.runtime');
 if(!fs.existsSync(file))throw Error('Không tìm thấy '+path.relative(root,file));
 const sourceText=fs.readFileSync(file,'utf8'),duplicateKeys=duplicateEntryKeys(sourceText);if(duplicateKeys.length)throw Error('Khóa entries trùng trong JSON: '+[...new Set(duplicateKeys)].join(', '));
 const doc=JSON.parse(sourceText),planned=planRows(doc);if(planned.length>1000)throw Error('Migration vượt giới hạn 1,000 dòng trong một transaction.');const sql=require('../backend/modules/sql/index.cjs').createSql({runtime});
 console.log('Đảm bảo Portal đã dừng hoặc PIC2 không thể chỉnh sửa trong suốt migration.');
 const before=await sql.readCodeIssues(),byKey=new Map(before.map(row=>[text(row.LineKey),row])),missing=planned.filter(row=>!byKey.has(row.lineKey)),matching=planned.filter(row=>byKey.has(row.lineKey)&&sameRow(row,byKey.get(row.lineKey))),mismatched=planned.filter(row=>byKey.has(row.lineKey)&&!sameRow(row,byKey.get(row.lineKey))),keys=new Set(planned.map(row=>row.lineKey)),sqlOnly=before.map(row=>text(row.LineKey)).filter(key=>!keys.has(key));
 console.log(`JSON: ${planned.length} | SQL: ${before.length} | cần INSERT: ${missing.length} | khớp: ${matching.length} | lệch: ${mismatched.length} | chỉ SQL: ${sqlOnly.length}`);
 if(mismatched.length)throw Error('Có nội dung khác SQL; chưa ghi. Đối soát thủ công.');
 if(!args.has('--apply')){console.log('DRY-RUN: chưa ghi SQL. Chạy lại với --apply sau khi kiểm tra.');return;}
 const report=await reconcile({sql,doc,sourceText,apply:true});console.log(`ĐỐI SOÁT PASS: ${report.verified}/${report.planned} dòng khớp; tổng SQL ${report.sqlTotal}. JSON vẫn được giữ nguyên: ${path.relative(root,file)}`);
}
if(require.main===module)main().catch(error=>{console.error('LỖI: '+(error?.message||String(error)));if(error?.report)console.error(JSON.stringify(error.report,null,2));process.exitCode=1;});
module.exports={duplicateEntryKeys,planRows,sameRow,reconcile,main};


