'use strict';

// Startup checks only. No runtime/account/SQL data is read or changed.
const { readTreeConfig } = require('../backend/core/config.cjs');

function resolvePort(env = process.env, config = {}) {
  const envPort = String(env.PORT ?? '').trim();
  const configPort = String(config.port ?? '').trim();
  const value = envPort || configPort || '8000';
  if (!/^\d+$/.test(value) || Number(value) < 1 || Number(value) > 65535) {
    throw Error('Invalid PORT: use a whole number from 1 to 65535 in PORT or tree.config.json.');
  }
  return String(Number(value));
}

function checkDependencies() {
  for (const name of ['fflate', 'fast-xml-parser']) {
    try { require(name); }
    catch (error) {
      throw Error(`Cannot load ${name}. Extract the complete ZIP including node_modules, or run npm ci --omit=dev in the portal folder. (${error.code || error.message})`);
    }
  }
}

if (require.main === module) {
  try {
    if (Number(process.versions.node.split('.')[0]) < 20) throw Error('Node.js 20 or newer is required.');
    if (process.argv[2] === 'port') process.stdout.write(resolvePort(process.env, readTreeConfig()));
    else if (process.argv[2] === 'dependencies') checkDependencies();
    else throw Error('Usage: node scripts/startup-check.cjs port|dependencies');
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}

module.exports = { resolvePort, checkDependencies };
