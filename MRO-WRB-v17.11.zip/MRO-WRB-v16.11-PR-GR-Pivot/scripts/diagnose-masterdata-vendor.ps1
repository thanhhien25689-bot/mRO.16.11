# Chuan doan doc: doi chieu EQM_MRO_Inventory_vendor voi EQM_MRO_MasterData
# (chi SELECT, khong ghi). Tai tao dung rule gop cua backend/modules/stock/index.cjs:
# key = Trim + NFC + UPPERCASE; moi Purchase_Code phai khop DUNG 1 dong MasterData
# va dong do phai co [WRB Code].
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$cfgPath = Join-Path $root '.runtime\sql\connection.json'
if (-not (Test-Path -LiteralPath $cfgPath)) { Write-Host "Khong thay $cfgPath"; exit 1 }
$cfg = Get-Content -LiteralPath $cfgPath -Raw | ConvertFrom-Json
Add-Type -AssemblyName System.Security
try {
  $bytes = [Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($cfg.secret), $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
} catch {
  Write-Host 'Khong mo duoc mat khau SQL (DPAPI). Hay chay bang dung tai khoan Windows da ket noi portal.'; exit 1
}
$builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
$builder['Data Source'] = 'tcp:' + $cfg.server + ',' + $cfg.port
$builder['Initial Catalog'] = $cfg.database
$builder['User ID'] = $cfg.user
$builder['Password'] = [Text.Encoding]::UTF8.GetString($bytes)
$builder['Encrypt'] = $true
$builder['TrustServerCertificate'] = [bool]$cfg.trustServerCertificate
$builder['Connect Timeout'] = 10
$builder['Pooling'] = $false
$conn = New-Object System.Data.SqlClient.SqlConnection($builder.ConnectionString)
$conn.Open()
Write-Host ("Da ket noi {0}:{1} / {2}" -f $cfg.server, $cfg.port, $cfg.database)

function Read-Rows([string]$sql) {
  $cmd = $conn.CreateCommand(); $cmd.CommandText = $sql; $cmd.CommandTimeout = 60
  $da = New-Object System.Data.SqlClient.SqlDataAdapter($cmd)
  $dt = New-Object System.Data.DataTable
  [void]$da.Fill($dt)
  return ,$dt
}

$inv = Read-Rows 'SELECT [Vendor],[Purchase_Code],CONVERT(varchar(10),[Confirm_date],23) AS [Confirm_date],[Opening_QTY] FROM [dbo].[EQM_MRO_Inventory_vendor]'
$mst = Read-Rows 'SELECT [WRB Code],[Item code] FROM [dbo].[EQM_MRO_MasterData]'
$conn.Close()
Write-Host ("Inventory_vendor: {0} dong | MasterData: {1} dong" -f $inv.Rows.Count, $mst.Rows.Count)

function Norm([object]$x) { if ($null -eq $x) { return '' } ([string]$x).Trim().Normalize([Text.NormalizationForm]::FormC).ToUpperInvariant() }

$masterMap = @{}
foreach ($r in $mst.Rows) {
  $k = Norm $r['Item code']
  if (-not $masterMap.ContainsKey($k)) { $masterMap[$k] = New-Object System.Collections.ArrayList }
  [void]$masterMap[$k].Add([string]$r['WRB Code'])
}

$today = (Get-Date).ToUniversalTime().AddHours(7).ToString('yyyy-MM-dd')
$locations = @('ALT', 'ALV', 'BJ', 'CW')
$seen = @{}
$report = New-Object System.Collections.ArrayList
$summary = @{}
function Add-Issue([string]$kind, [string]$detail) {
  [void]$script:report.Add(('{0} | {1}' -f $kind, $detail))
  if (-not $script:summary.ContainsKey($kind)) { $script:summary[$kind] = 0 }
  $script:summary[$kind] = $script:summary[$kind] + 1
}

$rowNo = 0
foreach ($r in $inv.Rows) {
  $rowNo++
  $loc = Norm $r['Vendor']; $code = Norm $r['Purchase_Code']
  $tag = "dong $rowNo Vendor=$($r['Vendor']) Code=$($r['Purchase_Code'])"
  if ($code -eq '') { Add-Issue 'PURCHASE_CODE TRONG' $tag; continue }
  if ($locations -notcontains $loc) { Add-Issue 'VENDOR KHONG LE (can ALT/ALV/BJ/CW)' ("`"$($r['Vendor'])`" | $tag") }
  $id = $loc + '|' + $code
  if ($seen.ContainsKey($id)) { Add-Issue 'INVENTORY_VENDOR TRUNG (Vendor+Code)' $id }
  $seen[$id] = $true
  $confirm = [string]$r['Confirm_date']; $opening = [string]$r['Opening_QTY']
  if ($confirm -notmatch '^\d{4}-\d{2}-\d{2}$' -or $confirm -gt $today) { Add-Issue 'CONFIRM_DATE KHONG HOP LE' ("Confirm_date='$confirm' | $tag") }
  $num = 0.0
  if (-not [double]::TryParse($opening, [ref]$num) -or $num -lt 0 -or $opening -eq '') { Add-Issue 'OPENING_QTY KHONG HOP LE' ("Opening_QTY='$opening' | $tag") }
  if (-not $masterMap.ContainsKey($code)) { Add-Issue 'MASTERDATA THIEU ITEM CODE' ("$code ($tag)"); continue }
  $mrows = $masterMap[$code]
  if ($mrows.Count -gt 1) { Add-Issue 'MASTERDATA TRUNG ITEM CODE' ("$code x$($mrows.Count), WRB Code: [" + (($mrows | ForEach-Object { if ([string]::IsNullOrWhiteSpace($_)) { '(trong)' } else { $_.Trim() } }) -join ', ') + "] ($tag)"); continue }
  if ([string]::IsNullOrWhiteSpace($mrows[0])) { Add-Issue 'MASTERDATA THIEU WRB CODE' ("$code ($tag)") }
}

Write-Host ''
Write-Host '===== KET LUAN ====='
if ($report.Count -eq 0) {
  Write-Host 'KHONG phat hien loi khop. Neu portal van bao loi, doi chieu nguay nguon copy message tu tab.'
} else {
  $summary.Keys | Sort-Object | ForEach-Object { Write-Host ("{0,-40} {1}" -f $_, $summary[$_]) }
  Write-Host ''
  Write-Host '===== CHI TIET ====='
  $report | ForEach-Object { Write-Host $_ }
}
$out = Join-Path $root 'temp-masterdata-chuan-doan.txt'
$report | Out-File -LiteralPath $out -Encoding UTF8
Write-Host ''
Write-Host ("Da luu bao cao: {0}" -f $out)