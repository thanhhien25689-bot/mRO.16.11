-- SET/PBA Management - SQL Server schema V2 (Phase 4D.1)
-- Status: DRAFT, NOT EXECUTED. Run once by developer/DBA only after Project Owner approval.
-- Target database: EquipmentPart (confirmed by Project Owner, schema dbo).
-- Idempotent: each object is created only if missing. Does not touch any MRO table.
-- Runtime SQL account needs SELECT/INSERT/UPDATE only (no DELETE on Movement, no DDL).
--
-- Business rules (confirmed Phase 4D.1):
--   * SET: one row per unit; SN is Primary Key – mandatory, unique, never generated/defaulted.
--     - SET rows missing SN are EXCLUDED from production SQL. Demo/staging only with TEST-SN prefix.
--     - IMEI1/IMEI2: optional; unique when present; duplicate IMEI is an error – NOT auto-merged.
--   * PBA: stock keyed by Model + Holder + Condition, Qty >= 0.
--     - Rule for PBA key conflict: PENDING Project Owner decision (input truncated).
--   * Holders: SEV (central warehouse), ALT (Almus Tech), ALV (Almus Vina / ALMUS), Bujeon, Chitwing.
--     ALMUS alias → ALV confirmed. ALT = Almus Tech (separate from ALV/Almus Vina).
--   * Transfer adds destination stock only after receiver confirmation (Status = Received).
--   * Vendor may report NG directly; SEV receives alert (EQM_SP_NGReport.AlertStatus).
--   * Movement is an append-only ledger of every stock change.

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/* ---------- 1. Holder (reference) ---------- */
IF OBJECT_ID(N'[dbo].[EQM_SP_Holder]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_Holder](
        [HolderCode]   nvarchar(20)  NOT NULL,
        [HolderName]   nvarchar(100) NOT NULL,
        [HolderType]   nvarchar(10)  NOT NULL,           -- SEV | VENDOR
        [IsActive]     bit           NOT NULL CONSTRAINT [DF_EQM_SP_Holder_IsActive] DEFAULT (1),
        [CreatedAt]    datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_Holder_CreatedAt] DEFAULT (SYSDATETIME()),
        CONSTRAINT [PK_EQM_SP_Holder] PRIMARY KEY CLUSTERED ([HolderCode]),
        CONSTRAINT [CK_EQM_SP_Holder_Type] CHECK ([HolderType] IN (N'SEV', N'VENDOR'))
    );
    CREATE UNIQUE INDEX [UX_EQM_SP_Holder_SingleSEV] ON [dbo].[EQM_SP_Holder]([HolderType]) WHERE [HolderType] = N'SEV';
END;
GO

-- Legacy holder spelling -> HolderCode (used by migration/import only)
IF OBJECT_ID(N'[dbo].[EQM_SP_HolderAlias]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_HolderAlias](
        [Alias]        nvarchar(50) NOT NULL,
        [HolderCode]   nvarchar(20) NOT NULL,
        CONSTRAINT [PK_EQM_SP_HolderAlias] PRIMARY KEY CLUSTERED ([Alias]),
        CONSTRAINT [FK_EQM_SP_HolderAlias_Holder] FOREIGN KEY ([HolderCode]) REFERENCES [dbo].[EQM_SP_Holder]([HolderCode])
    );
END;
GO

/* ---------- 2. SET units (serialized, qty always 1) ----------
   SN policy (confirmed Phase 4D.1):
     - SN is the natural business key; mandatory; must NOT be generated/defaulted.
     - Rows without real SN are EXCLUDED from production insert.
     - Staging/demo rows may carry prefix 'TEST-SN-' and are blocked from business workflows
       via [IsDemo] flag; they must be removed before go-live.
     - Duplicate IMEI between units is an ERROR – migration must report and halt, not auto-merge.
   ---------------------------------------------------------- */
IF OBJECT_ID(N'[dbo].[EQM_SP_SetUnit]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_SetUnit](
        [SetUnitId]     bigint IDENTITY(1,1) NOT NULL,
        [SN]            nvarchar(50)  NOT NULL,
        [IMEI1]         nvarchar(20)  NULL,
        [IMEI2]         nvarchar(20)  NULL,
        [Serial]        nvarchar(50)  NULL,              -- legacy "serial" (device serial / barcode)
        [UN]            nvarchar(50)  NULL,
        [Model]         nvarchar(60)  NOT NULL,
        [BasicModel]    nvarchar(30)  NULL,
        [Origin]        nvarchar(20)  NULL,              -- SEV | SEVT | GUMI | Other | ETC
        [HolderCode]    nvarchar(20)  NOT NULL,          -- current owner; changes only on Received
        [Condition]     nvarchar(10)  NOT NULL,          -- OK | NG | Checking
        [StockState]    nvarchar(12)  NOT NULL CONSTRAINT [DF_EQM_SP_SetUnit_State] DEFAULT (N'InStock'),
        [IsDemo]        bit           NOT NULL CONSTRAINT [DF_EQM_SP_SetUnit_IsDemo] DEFAULT (0),
        -- IsDemo=1: staging/demo row (TEST-SN- prefix); excluded from business operations.
        [Location]      nvarchar(100) NULL,              -- legacy "rack"
        [Mode]          nvarchar(50)  NULL,
        [CRO]           nvarchar(100) NULL,
        [Remark]        nvarchar(500) NULL,
        [CreatedAt]     datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_SetUnit_CreatedAt] DEFAULT (SYSDATETIME()),
        [CreatedBy]     nvarchar(80)  NOT NULL,
        [UpdatedAt]     datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_SetUnit_UpdatedAt] DEFAULT (SYSDATETIME()),
        [UpdatedBy]     nvarchar(80)  NOT NULL,
        [RowVer]        rowversion    NOT NULL,
        CONSTRAINT [PK_EQM_SP_SetUnit] PRIMARY KEY CLUSTERED ([SetUnitId]),
        CONSTRAINT [UQ_EQM_SP_SetUnit_SN] UNIQUE ([SN]),
        CONSTRAINT [FK_EQM_SP_SetUnit_Holder] FOREIGN KEY ([HolderCode]) REFERENCES [dbo].[EQM_SP_Holder]([HolderCode]),
        CONSTRAINT [CK_EQM_SP_SetUnit_SN] CHECK (LEN(LTRIM(RTRIM([SN]))) > 0),
        CONSTRAINT [CK_EQM_SP_SetUnit_DemoSN] CHECK (
            [IsDemo] = 0 OR [SN] LIKE N'TEST-SN-%'),
        CONSTRAINT [CK_EQM_SP_SetUnit_ProdSN] CHECK (
            [IsDemo] = 1 OR [SN] NOT LIKE N'TEST-SN-%'),
        CONSTRAINT [CK_EQM_SP_SetUnit_Condition] CHECK ([Condition] IN (N'OK', N'NG', N'Checking')),
        CONSTRAINT [CK_EQM_SP_SetUnit_State] CHECK ([StockState] IN (N'InStock', N'InTransit', N'Scrapped')),
        CONSTRAINT [CK_EQM_SP_SetUnit_IMEI] CHECK ([IMEI2] IS NULL OR [IMEI1] IS NULL OR [IMEI1] <> [IMEI2]),
        -- NOTE: no SQL-level Transfer block on IsDemo rows.
        -- Demo rows with real SN (TEST-SN- prefix) support the full Transfer → InTransit → Received
        -- test cycle. Business layer must exclude IsDemo rows from production reports/KPIs.
    );
    CREATE UNIQUE INDEX [UX_EQM_SP_SetUnit_IMEI1] ON [dbo].[EQM_SP_SetUnit]([IMEI1]) WHERE [IMEI1] IS NOT NULL;
    CREATE UNIQUE INDEX [UX_EQM_SP_SetUnit_IMEI2] ON [dbo].[EQM_SP_SetUnit]([IMEI2]) WHERE [IMEI2] IS NOT NULL;
    CREATE INDEX [IX_EQM_SP_SetUnit_Holder] ON [dbo].[EQM_SP_SetUnit]([HolderCode], [Condition], [StockState], [IsDemo]) INCLUDE ([Model]);
    CREATE INDEX [IX_EQM_SP_SetUnit_Model] ON [dbo].[EQM_SP_SetUnit]([Model]);
    CREATE INDEX [IX_EQM_SP_SetUnit_Prod] ON [dbo].[EQM_SP_SetUnit]([HolderCode], [Condition]) WHERE [IsDemo] = 0 AND [StockState] = N'InStock';
END;
GO

/* ---------- 3. PBA stock (Model + Holder + Condition + Rack -> Qty) ----------
   Key rule (confirmed Phase 4D.1):
     Same Model + Holder + Condition at DIFFERENT Rack = separate stock row.
     Unique key: Model + HolderCode + Condition + Rack.
     Rack '' (empty string) is treated as the default/unspecified rack and is a valid key value.
   ---------------------------------------------------------- */
IF OBJECT_ID(N'[dbo].[EQM_SP_PbaStock]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_PbaStock](
        [PbaStockId]    bigint IDENTITY(1,1) NOT NULL,
        [Model]         nvarchar(60)  NOT NULL,
        [HolderCode]    nvarchar(20)  NOT NULL,
        [Condition]     nvarchar(10)  NOT NULL,
        [Rack]          nvarchar(100) NOT NULL CONSTRAINT [DF_EQM_SP_PbaStock_Rack] DEFAULT (N''),
        -- Rack is part of the unique key; '' = unspecified/default rack.
        [Qty]           int           NOT NULL,          -- on-hand, excludes qty in transit
        [BasicModel]    nvarchar(30)  NULL,
        [Origin]        nvarchar(20)  NULL,
        [Remark]        nvarchar(500) NULL,
        [UpdatedAt]     datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_PbaStock_UpdatedAt] DEFAULT (SYSDATETIME()),
        [UpdatedBy]     nvarchar(80)  NOT NULL,
        [RowVer]        rowversion    NOT NULL,
        CONSTRAINT [PK_EQM_SP_PbaStock] PRIMARY KEY CLUSTERED ([PbaStockId]),
        CONSTRAINT [UQ_EQM_SP_PbaStock_Key] UNIQUE ([Model], [HolderCode], [Condition], [Rack]),
        CONSTRAINT [FK_EQM_SP_PbaStock_Holder] FOREIGN KEY ([HolderCode]) REFERENCES [dbo].[EQM_SP_Holder]([HolderCode]),
        CONSTRAINT [CK_EQM_SP_PbaStock_Condition] CHECK ([Condition] IN (N'OK', N'NG', N'Checking')),
        CONSTRAINT [CK_EQM_SP_PbaStock_Qty] CHECK ([Qty] >= 0)
    );
    CREATE INDEX [IX_EQM_SP_PbaStock_Holder] ON [dbo].[EQM_SP_PbaStock]([HolderCode], [Condition]) INCLUDE ([Model], [Rack], [Qty]);
    CREATE INDEX [IX_EQM_SP_PbaStock_Model] ON [dbo].[EQM_SP_PbaStock]([Model], [HolderCode]) INCLUDE ([Condition], [Rack], [Qty]);
END;
GO

/* ---------- 4. Transfer header (Phase 4D.2.1) ----------
   Status flow:
     Requested      : vendor-initiated request waiting SEV approval
     InTransit      : dispatched; source stock deducted; destination NOT yet increased
     Received       : receiver confirmed ALL qty; destination stock increased; terminal
     PartialReceived: receiver confirmed SOME qty; received portion in dst;
                      remainder stays pending source confirmReturn
     Rejected       : receiver refused ALL qty; stock NOT yet returned;
                      source must call confirmReturn to credit stock back; non-terminal
     ReturnConfirmed: source confirmed physical receipt of all returned items;
                      TransferBack movements recorded; terminal after Rejected/PartialReceived
     Cancelled      : voided before dispatch; terminal

   Key timestamp separation (Phase 4D.2.1):
     ConfirmedAt/By  : set by RECEIVER at receiveTransfer or rejectTransfer
     ReturnConfAt/By : set by SOURCE at confirmReturn (only for Rejected/PartialReceived paths)
   ---------------------------------------------------------- */
IF OBJECT_ID(N'[dbo].[EQM_SP_Transfer]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_Transfer](
        [TransferId]     bigint IDENTITY(1,1) NOT NULL,
        [TransferNo]     nvarchar(30)  NOT NULL,         -- GI/RT/TR yyyymmddNNN
        [TransferType]   nvarchar(20)  NOT NULL,         -- Dispatch | Return | VendorToVendor
        [FromHolder]     nvarchar(20)  NOT NULL,
        [ToHolder]       nvarchar(20)  NOT NULL,
        [Status]         nvarchar(16)  NOT NULL,         -- widened from 12 for 'PartialReceived'
        [Reason]         nvarchar(500) NULL,
        [RequestedAt]    datetime2(3)  NULL,
        [RequestedBy]    nvarchar(80)  NULL,
        [ApprovedAt]     datetime2(3)  NULL,
        [ApprovedBy]     nvarchar(80)  NULL,
        [DispatchedAt]   datetime2(3)  NULL,
        [DispatchedBy]   nvarchar(80)  NULL,
        [ReceiptNo]      nvarchar(30)  NULL,             -- GR code, set on Received/PartialReceived
        [ConfirmedAt]    datetime2(3)  NULL,             -- when RECEIVER acted
        [ConfirmedBy]    nvarchar(80)  NULL,             -- receiver user
        [RejectReason]   nvarchar(500) NULL,
        [ReturnConfAt]   datetime2(3)  NULL,             -- when SOURCE confirmed return receipt
        [ReturnConfBy]   nvarchar(80)  NULL,             -- source user (confirmReturn)
        [CreatedAt]      datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_Transfer_CreatedAt] DEFAULT (SYSDATETIME()),
        [CreatedBy]      nvarchar(80)  NOT NULL,
        [UpdatedAt]      datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_Transfer_UpdatedAt] DEFAULT (SYSDATETIME()),
        [UpdatedBy]      nvarchar(80)  NOT NULL,
        [RowVer]         rowversion    NOT NULL,
        CONSTRAINT [PK_EQM_SP_Transfer] PRIMARY KEY CLUSTERED ([TransferId]),
        CONSTRAINT [UQ_EQM_SP_Transfer_No] UNIQUE ([TransferNo]),
        CONSTRAINT [FK_EQM_SP_Transfer_From] FOREIGN KEY ([FromHolder]) REFERENCES [dbo].[EQM_SP_Holder]([HolderCode]),
        CONSTRAINT [FK_EQM_SP_Transfer_To]   FOREIGN KEY ([ToHolder])   REFERENCES [dbo].[EQM_SP_Holder]([HolderCode]),
        CONSTRAINT [CK_EQM_SP_Transfer_Type] CHECK ([TransferType] IN (N'Dispatch', N'Return', N'VendorToVendor')),
        CONSTRAINT [CK_EQM_SP_Transfer_Status] CHECK ([Status] IN (
            N'Requested', N'InTransit', N'Received',
            N'PartialReceived', N'Rejected', N'ReturnConfirmed', N'Cancelled')),
        CONSTRAINT [CK_EQM_SP_Transfer_Route] CHECK ([FromHolder] <> [ToHolder]),
        -- Receiver must have acted before Received or PartialReceived
        CONSTRAINT [CK_EQM_SP_Transfer_Confirm] CHECK (
            [Status] NOT IN (N'Received', N'PartialReceived')
            OR ([ConfirmedAt] IS NOT NULL AND [ConfirmedBy] IS NOT NULL)),
        -- Rejected: receiver acted (ConfirmedAt set); stock not yet returned (ReturnConfAt may be NULL)
        CONSTRAINT [CK_EQM_SP_Transfer_Reject] CHECK (
            [Status] <> N'Rejected'
            OR ([ConfirmedAt] IS NOT NULL AND [ConfirmedBy] IS NOT NULL)),
        -- ReturnConfirmed: source must have confirmed
        CONSTRAINT [CK_EQM_SP_Transfer_ReturnConf] CHECK (
            [Status] <> N'ReturnConfirmed'
            OR ([ReturnConfAt] IS NOT NULL AND [ReturnConfBy] IS NOT NULL))
    );
    CREATE UNIQUE INDEX [UX_EQM_SP_Transfer_ReceiptNo] ON [dbo].[EQM_SP_Transfer]([ReceiptNo]) WHERE [ReceiptNo] IS NOT NULL;
    CREATE INDEX [IX_EQM_SP_Transfer_ToStatus]   ON [dbo].[EQM_SP_Transfer]([ToHolder],   [Status]);
    CREATE INDEX [IX_EQM_SP_Transfer_FromStatus] ON [dbo].[EQM_SP_Transfer]([FromHolder], [Status]);
    -- pending-return work queue: open items source still needs to confirmReturn
    CREATE INDEX [IX_EQM_SP_Transfer_PendingReturn] ON [dbo].[EQM_SP_Transfer]([FromHolder], [UpdatedAt])
        WHERE [Status] IN (N'Rejected', N'PartialReceived');
END;
GO

/* ---------- 5. Transfer lines ----------
   For PBA: FromRack records which Rack row was deducted at dispatch.
            ToRack records which Rack the receiver will put stock into (default '' if not specified).
            Both are needed to resolve the correct EQM_SP_PbaStock row on TransferOut/TransferIn.
   ---------------------------------------------------------- */
IF OBJECT_ID(N'[dbo].[EQM_SP_TransferLine]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_TransferLine](
        [TransferLineId] bigint IDENTITY(1,1) NOT NULL,
        [TransferId]     bigint        NOT NULL,
        [LineNo]         int           NOT NULL,
        [ItemType]       nvarchar(3)   NOT NULL,         -- SET | PBA
        [SetUnitId]      bigint        NULL,             -- SET only
        [SN]             nvarchar(50)  NULL,             -- SET snapshot
        [IMEI1]          nvarchar(20)  NULL,
        [IMEI2]          nvarchar(20)  NULL,
        [Model]          nvarchar(60)  NOT NULL,
        [BasicModel]     nvarchar(30)  NULL,
        [Condition]      nvarchar(10)  NOT NULL,         -- condition at dispatch
        [FromRack]       nvarchar(100) NULL,             -- PBA: source Rack (key lookup on TransferOut)
        [ToRack]         nvarchar(100) NULL,             -- PBA: destination Rack (key lookup on TransferIn)
        [Qty]                int           NOT NULL,
        [ReceivedQty]        int           NULL,         -- set by receiver (0..Qty); NULL = not yet acted
        [ReturnConfirmedQty] int           NULL,         -- set by source at confirmReturn (0..Qty-ReceivedQty)
        [ReturnConfirmedAt]  datetime2(3)  NULL,         -- when source confirmed return for this line
        [Origin]             nvarchar(20)  NULL,
        [Remark]             nvarchar(500) NULL,
        CONSTRAINT [PK_EQM_SP_TransferLine] PRIMARY KEY CLUSTERED ([TransferLineId]),
        CONSTRAINT [UQ_EQM_SP_TransferLine_No] UNIQUE ([TransferId], [LineNo]),
        CONSTRAINT [FK_EQM_SP_TransferLine_Transfer] FOREIGN KEY ([TransferId]) REFERENCES [dbo].[EQM_SP_Transfer]([TransferId]),
        CONSTRAINT [FK_EQM_SP_TransferLine_SetUnit] FOREIGN KEY ([SetUnitId]) REFERENCES [dbo].[EQM_SP_SetUnit]([SetUnitId]),
        CONSTRAINT [CK_EQM_SP_TransferLine_ItemType] CHECK ([ItemType] IN (N'SET', N'PBA')),
        CONSTRAINT [CK_EQM_SP_TransferLine_Condition] CHECK ([Condition] IN (N'OK', N'NG', N'Checking')),
        -- ReceivedQty: 0..Qty; NULL before receiver acts
        CONSTRAINT [CK_EQM_SP_TransferLine_RecvQty] CHECK (
            [ReceivedQty] IS NULL OR ([ReceivedQty] >= 0 AND [ReceivedQty] <= [Qty])),
        -- ReturnConfirmedQty: 0..(Qty-ReceivedQty); NULL before source confirms return
        -- Received + Returned <= Qty (no double-counting)
        CONSTRAINT [CK_EQM_SP_TransferLine_ReturnQty] CHECK (
            [ReturnConfirmedQty] IS NULL
            OR ([ReturnConfirmedQty] >= 0
                AND [ReceivedQty] IS NOT NULL
                AND [ReturnConfirmedQty] <= [Qty] - [ReceivedQty])),
        -- ReturnConfirmedAt must accompany ReturnConfirmedQty
        CONSTRAINT [CK_EQM_SP_TransferLine_ReturnAt] CHECK (
            ([ReturnConfirmedQty] IS NULL) = ([ReturnConfirmedAt] IS NULL)),
        -- SET-specific: qty always 1; no rack; SN required
        CONSTRAINT [CK_EQM_SP_TransferLine_Set] CHECK (
            ([ItemType] = N'SET' AND [Qty] = 1 AND [SN] IS NOT NULL AND [FromRack] IS NULL AND [ToRack] IS NULL) OR
            ([ItemType] = N'PBA' AND [SetUnitId] IS NULL AND [SN] IS NULL))
    );
    CREATE INDEX [IX_EQM_SP_TransferLine_SetUnit] ON [dbo].[EQM_SP_TransferLine]([SetUnitId]) WHERE [SetUnitId] IS NOT NULL;
    CREATE INDEX [IX_EQM_SP_TransferLine_Model]   ON [dbo].[EQM_SP_TransferLine]([Model]);
    -- pending-return lines: receiver acted (ReceivedQty set) but source not yet confirmed return
    CREATE INDEX [IX_EQM_SP_TransferLine_PendingReturn] ON [dbo].[EQM_SP_TransferLine]([TransferId])
        WHERE [ReceivedQty] IS NOT NULL AND [ReturnConfirmedQty] IS NULL
          AND [ReceivedQty] < [Qty];
END;
GO

/* ---------- 6. NG report (vendor -> SEV alert) ---------- */
IF OBJECT_ID(N'[dbo].[EQM_SP_NGReport]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_NGReport](
        [NGReportId]     bigint IDENTITY(1,1) NOT NULL,
        [ReportNo]       nvarchar(30)  NOT NULL,         -- NG yyyymmddNNN
        [HolderCode]     nvarchar(20)  NOT NULL,         -- reporting holder
        [ItemType]       nvarchar(3)   NOT NULL,
        [SetUnitId]      bigint        NULL,
        [SN]             nvarchar(50)  NULL,
        [IMEI1]          nvarchar(20)  NULL,
        [Model]          nvarchar(60)  NOT NULL,
        [BasicModel]     nvarchar(30)  NULL,
        [Qty]            int           NOT NULL,
        [Reason]         nvarchar(500) NOT NULL,
        [Status]         nvarchar(12)  NOT NULL,         -- Reported | Acknowledged | Closed | Rejected
        [AlertStatus]    nvarchar(10)  NOT NULL CONSTRAINT [DF_EQM_SP_NGReport_Alert] DEFAULT (N'New'), -- New | Read
        [AlertReadAt]    datetime2(3)  NULL,
        [AlertReadBy]    nvarchar(80)  NULL,
        [ReportedAt]     datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_NGReport_ReportedAt] DEFAULT (SYSDATETIME()),
        [ReportedBy]     nvarchar(80)  NOT NULL,
        [ClosedAt]       datetime2(3)  NULL,
        [ClosedBy]       nvarchar(80)  NULL,
        [CloseNote]      nvarchar(500) NULL,
        [RowVer]         rowversion    NOT NULL,
        CONSTRAINT [PK_EQM_SP_NGReport] PRIMARY KEY CLUSTERED ([NGReportId]),
        CONSTRAINT [UQ_EQM_SP_NGReport_No] UNIQUE ([ReportNo]),
        CONSTRAINT [FK_EQM_SP_NGReport_Holder] FOREIGN KEY ([HolderCode]) REFERENCES [dbo].[EQM_SP_Holder]([HolderCode]),
        CONSTRAINT [FK_EQM_SP_NGReport_SetUnit] FOREIGN KEY ([SetUnitId]) REFERENCES [dbo].[EQM_SP_SetUnit]([SetUnitId]),
        CONSTRAINT [CK_EQM_SP_NGReport_ItemType] CHECK ([ItemType] IN (N'SET', N'PBA')),
        CONSTRAINT [CK_EQM_SP_NGReport_Qty] CHECK ([Qty] > 0 AND ([ItemType] = N'PBA' OR ([Qty] = 1 AND [SN] IS NOT NULL))),
        CONSTRAINT [CK_EQM_SP_NGReport_Status] CHECK ([Status] IN (N'Reported', N'Acknowledged', N'Closed', N'Rejected')),
        CONSTRAINT [CK_EQM_SP_NGReport_Alert] CHECK ([AlertStatus] IN (N'New', N'Read'))
    );
    CREATE INDEX [IX_EQM_SP_NGReport_Alert] ON [dbo].[EQM_SP_NGReport]([AlertStatus], [ReportedAt]);
END;
GO

/* ---------- 7. Movement ledger (append-only) ---------- */
-- One row per stock delta per holder. QtyDelta: + into HolderCode, - out of HolderCode.
-- MovementType:
--   Import        initial/Excel load              (+)
--   Adjust        manual qty/info correction       (+/-)
--   ConditionChg  OK/NG/Checking change or lot split (- old condition, + new condition)
--   TransferOut   dispatch, source deducted        (-) Transfer InTransit
--   TransferIn    receiver confirmed               (+) Transfer Received
--   TransferBack  receiver rejected/cancelled      (+) back to source
--   Scrap         destroyed                        (-)
IF OBJECT_ID(N'[dbo].[EQM_SP_Movement]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_Movement](
        [MovementId]     bigint IDENTITY(1,1) NOT NULL,
        [MovementType]   nvarchar(15)  NOT NULL,
        [ItemType]       nvarchar(3)   NOT NULL,
        [HolderCode]     nvarchar(20)  NOT NULL,
        [CounterHolder]  nvarchar(20)  NULL,
        [SetUnitId]      bigint        NULL,
        [SN]             nvarchar(50)  NULL,
        [IMEI1]          nvarchar(20)  NULL,
        [Model]          nvarchar(60)  NOT NULL,
        [Condition]      nvarchar(10)  NOT NULL,
        [QtyDelta]       int           NOT NULL,
        [TransferId]     bigint        NULL,
        [TransferLineId] bigint        NULL,
        [NGReportId]     bigint        NULL,
        [RefNo]          nvarchar(30)  NULL,             -- GI/GR/NG/import batch code
        [Note]           nvarchar(500) NULL,
        [IsLegacy]       bit           NOT NULL CONSTRAINT [DF_EQM_SP_Movement_IsLegacy] DEFAULT (0),
        [CreatedAt]      datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_Movement_CreatedAt] DEFAULT (SYSDATETIME()),
        [CreatedBy]      nvarchar(80)  NOT NULL,
        CONSTRAINT [PK_EQM_SP_Movement] PRIMARY KEY CLUSTERED ([MovementId]),
        CONSTRAINT [FK_EQM_SP_Movement_Holder] FOREIGN KEY ([HolderCode]) REFERENCES [dbo].[EQM_SP_Holder]([HolderCode]),
        CONSTRAINT [FK_EQM_SP_Movement_Counter] FOREIGN KEY ([CounterHolder]) REFERENCES [dbo].[EQM_SP_Holder]([HolderCode]),
        CONSTRAINT [FK_EQM_SP_Movement_SetUnit] FOREIGN KEY ([SetUnitId]) REFERENCES [dbo].[EQM_SP_SetUnit]([SetUnitId]),
        CONSTRAINT [FK_EQM_SP_Movement_Transfer] FOREIGN KEY ([TransferId]) REFERENCES [dbo].[EQM_SP_Transfer]([TransferId]),
        CONSTRAINT [FK_EQM_SP_Movement_TransferLine] FOREIGN KEY ([TransferLineId]) REFERENCES [dbo].[EQM_SP_TransferLine]([TransferLineId]),
        CONSTRAINT [FK_EQM_SP_Movement_NGReport] FOREIGN KEY ([NGReportId]) REFERENCES [dbo].[EQM_SP_NGReport]([NGReportId]),
        CONSTRAINT [CK_EQM_SP_Movement_Type] CHECK ([MovementType] IN
            (N'Import', N'Adjust', N'ConditionChg', N'TransferOut', N'TransferIn', N'TransferBack', N'Scrap')),
        CONSTRAINT [CK_EQM_SP_Movement_ItemType] CHECK ([ItemType] IN (N'SET', N'PBA')),
        CONSTRAINT [CK_EQM_SP_Movement_Condition] CHECK ([Condition] IN (N'OK', N'NG', N'Checking')),
        CONSTRAINT [CK_EQM_SP_Movement_Delta] CHECK ([QtyDelta] <> 0 OR [IsLegacy] = 1),
        CONSTRAINT [CK_EQM_SP_Movement_Sign] CHECK (
            [IsLegacy] = 1 OR
            ([MovementType] IN (N'Import', N'TransferIn', N'TransferBack') AND [QtyDelta] > 0) OR
            ([MovementType] IN (N'TransferOut', N'Scrap') AND [QtyDelta] < 0) OR
            ([MovementType] IN (N'Adjust', N'ConditionChg'))),
        CONSTRAINT [CK_EQM_SP_Movement_TransferRef] CHECK (
            [IsLegacy] = 1 OR [MovementType] NOT IN (N'TransferOut', N'TransferIn', N'TransferBack') OR [TransferId] IS NOT NULL)
    );
    CREATE INDEX [IX_EQM_SP_Movement_Holder] ON [dbo].[EQM_SP_Movement]([HolderCode], [CreatedAt]);
    CREATE INDEX [IX_EQM_SP_Movement_Transfer] ON [dbo].[EQM_SP_Movement]([TransferId]) WHERE [TransferId] IS NOT NULL;
    CREATE INDEX [IX_EQM_SP_Movement_SetUnit] ON [dbo].[EQM_SP_Movement]([SetUnitId]) WHERE [SetUnitId] IS NOT NULL;
    CREATE INDEX [IX_EQM_SP_Movement_Model] ON [dbo].[EQM_SP_Movement]([Model], [CreatedAt]);
END;
GO

/* ---------- 8. Migration exceptions (rows that violate V2 rules) ---------- */
IF OBJECT_ID(N'[dbo].[EQM_SP_MigrationException]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_SP_MigrationException](
        [ExceptionId]    bigint IDENTITY(1,1) NOT NULL,
        [BatchNo]        nvarchar(30)  NOT NULL,
        [SourceArray]    nvarchar(20)  NOT NULL,         -- items | receipts | movements | requests
        [SourceId]       nvarchar(50)  NULL,
        [ErrorCode]      nvarchar(40)  NOT NULL,
        [SourceJson]     nvarchar(max) NOT NULL,
        [CreatedAt]      datetime2(3)  NOT NULL CONSTRAINT [DF_EQM_SP_MigrationException_CreatedAt] DEFAULT (SYSDATETIME()),
        CONSTRAINT [PK_EQM_SP_MigrationException] PRIMARY KEY CLUSTERED ([ExceptionId])
    );
END;
GO

/* ---------- 9. Read views ---------- */
-- vw_EQM_SP_StockSummary: production stock only (IsDemo=0 for SET).
-- PBA includes Rack because Rack is part of the unique key.
CREATE OR ALTER VIEW [dbo].[vw_EQM_SP_StockSummary]
AS
    SELECT N'SET' AS [ItemType], [Model], [HolderCode], [Condition],
           NULL AS [Rack], COUNT_BIG(*) AS [Qty]
    FROM [dbo].[EQM_SP_SetUnit]
    WHERE [StockState] = N'InStock' AND [IsDemo] = 0
    GROUP BY [Model], [HolderCode], [Condition]
    UNION ALL
    SELECT N'PBA', [Model], [HolderCode], [Condition],
           [Rack], CAST([Qty] AS bigint)
    FROM [dbo].[EQM_SP_PbaStock] WHERE [Qty] > 0;
GO

CREATE OR ALTER VIEW [dbo].[vw_EQM_SP_InTransit]
AS
    SELECT t.[TransferId], t.[TransferNo], t.[TransferType], t.[FromHolder], t.[ToHolder], t.[DispatchedAt],
           l.[TransferLineId], l.[ItemType], l.[SN], l.[Model], l.[Condition], l.[Qty]
    FROM [dbo].[EQM_SP_Transfer] t
    JOIN [dbo].[EQM_SP_TransferLine] l ON l.[TransferId] = t.[TransferId]
    WHERE t.[Status] = N'InTransit';
GO
