-- SET/PBA Management - Seed reference data (Phase 4D.1)
-- Status: DRAFT, NOT EXECUTED. Run after 01-create-schema.sql.
-- Idempotent: MERGE inserts only missing rows.
--
-- Holder decisions confirmed by Project Owner (Phase 4D.1):
--   ALT  = Almus Tech      (separate company)
--   ALV  = Almus Vina      (separate company; legacy JSON used "ALMUS" and "ALMUS" aliases)
--   ALMUS alias -> ALV confirmed.

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/* ---------- Holders ---------- */
MERGE [dbo].[EQM_SP_Holder] AS tgt
USING (VALUES
    (N'SEV',      N'SEV Central Warehouse', N'SEV'),
    (N'ALT',      N'Almus Tech',            N'VENDOR'),
    (N'ALV',      N'Almus Vina',            N'VENDOR'),
    (N'BUJEON',   N'Bujeon',                N'VENDOR'),
    (N'CHITWING', N'Chitwing',              N'VENDOR')
) AS src ([HolderCode], [HolderName], [HolderType])
ON tgt.[HolderCode] = src.[HolderCode]
WHEN NOT MATCHED THEN
    INSERT ([HolderCode], [HolderName], [HolderType])
    VALUES (src.[HolderCode], src.[HolderName], src.[HolderType]);
GO

/* ---------- Holder aliases (all case variants found in JSON data) ---------- */
MERGE [dbo].[EQM_SP_HolderAlias] AS tgt
USING (VALUES
    -- SEV
    (N'SEV',      N'SEV'),
    -- ALT = Almus Tech
    (N'ALT',      N'ALT'),
    -- ALV = Almus Vina; legacy JSON uses "ALMUS" and "ALMUS" (confirmed by Project Owner)
    (N'ALV',      N'ALV'),
    (N'ALMUS',    N'ALV'),
    (N'Almus',    N'ALV'),
    -- Bujeon
    (N'BUJEON',   N'BUJEON'),
    (N'Bujeon',   N'BUJEON'),
    -- Chitwing
    (N'CHITWING', N'CHITWING'),
    (N'Chitwing', N'CHITWING')
) AS src ([Alias], [HolderCode])
ON tgt.[Alias] = src.[Alias]
WHEN NOT MATCHED THEN
    INSERT ([Alias], [HolderCode])
    VALUES (src.[Alias], src.[HolderCode]);
GO
