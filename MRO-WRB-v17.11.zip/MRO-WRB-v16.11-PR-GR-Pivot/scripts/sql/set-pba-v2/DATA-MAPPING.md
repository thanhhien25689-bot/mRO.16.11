# SET/PBA V2 — Data Mapping (Phase 4D.1)

Status: **DRAFT — chưa thực thi**. Mapping từ legacy JSON (`SET/localstorage/dashboard-state.json`) sang SQL Server V2.

## Quyết định đã xác nhận (Project Owner, Phase 4D.1 — hoàn tất)

| # | Vấn đề | Quyết định |
|---|--------|------------|
| 1 | Target database | **EquipmentPart** |
| 2 | SET thiếu SN | **Loại khỏi production SQL**. Demo dùng SN = `TEST-SN-{id}`, flag `IsDemo=1`; cho phép thử Transfer → InTransit → Received đầy đủ; phải xóa trước go-live |
| 3 | IMEI trùng | **Báo lỗi, không tự merge** – migration halt, log vào `EQM_SP_MigrationException` |
| 4 | ALMUS = ALV | **Xác nhận**: ALT = Almus Tech; ALV = Almus Vina (alias ALMUS, Almus). Chỉ dùng alias đã liệt kê, không tự suy diễn |
| 5 | PBA khác Rack | **Giữ riêng**. Key chính thức: `Model + HolderCode + Condition + Rack`. Rack='' = unspecified. `Location` cũ bị đổi thành `Rack` và trở thành phần của key |
| 6 | Demo Transfer | **IsDemo row được phép đi qua Transfer → InTransit → Received** (không có SQL block). Business layer loại IsDemo khỏi KPI/report sản xuất |

## Tên tiền tố chính thức

Tất cả object SET/PBA V2 dùng tiền tố `EQM_SP_`:

| Object | Tên đầy đủ |
|--------|-----------|
| Table  | `EQM_SP_Holder`, `EQM_SP_HolderAlias`, `EQM_SP_SetUnit`, `EQM_SP_PbaStock`, `EQM_SP_Transfer`, `EQM_SP_TransferLine`, `EQM_SP_NGReport`, `EQM_SP_Movement`, `EQM_SP_MigrationException` |
| View   | `vw_EQM_SP_StockSummary`, `vw_EQM_SP_InTransit` |
| PK     | `PK_EQM_SP_<Table>` |
| UQ     | `UQ_EQM_SP_<Table>_<Key>` |
| FK     | `FK_EQM_SP_<Table>_<Ref>` |
| CK     | `CK_EQM_SP_<Table>_<Rule>` |
| DF     | `DF_EQM_SP_<Table>_<Col>` |
| IX     | `IX_EQM_SP_<Table>_<Purpose>` |
| UX (filtered unique) | `UX_EQM_SP_<Table>_<Purpose>` |

Tiền tố `EQM_SP_` (**SP** = SET/PBA) không xung đột với `EQM_MRO_` (MRO scope) đang tồn tại.

## 1. items[] → EQM_SP_SetUnit / EQM_SP_PbaStock

### SET (type = "SET")

| JSON field   | SQL column          | Ghi chú                                                |
|-------------|--------------------|---------------------------------------------------------|
| —           | SetUnitId          | IDENTITY, tự sinh                                      |
| sn          | SN                 | **Bắt buộc, unique**. 584/1400 SET thiếu SN → cần bổ sung trước migration |
| imei        | IMEI1              | NULL nếu rỗng; unique filtered index                   |
| imei2       | IMEI2              | NULL nếu rỗng; unique filtered index                   |
| serial      | Serial             | Legacy serial/barcode, riêng biệt khỏi SN             |
| un          | UN                 | Unique Number                                           |
| model       | Model              | nvarchar(60), max hiện tại 18 ký tự                    |
| basicModel  | BasicModel         | nvarchar(30), max hiện tại 7 ký tự                     |
| origin      | Origin             | SEVT / SEV / GUMI / Other / ETC                        |
| holder      | HolderCode         | Qua HolderAlias để chuẩn hóa (vd: "Chitwing" → "CHITWING") |
| status      | Condition          | OK / NG / Checking                                     |
| —           | StockState         | Default "InStock"                                       |
| rack        | Location           | nvarchar(100)                                           |
| mode        | Mode               | Rỗng 100% trong dữ liệu hiện tại                      |
| cro         | CRO                | Rỗng 100% trong dữ liệu hiện tại                      |
| remark      | Remark             |                                                         |
| updated     | UpdatedAt          | Parse "HH:mm:ss dd/MM/yyyy" → datetime2                |
| userId      | CreatedBy/UpdatedBy | Rỗng trong dữ liệu hiện tại → dùng "migration"        |

**Migration rule (đã xác nhận):**

- **584 SET không có SN**: **KHÔNG nhập production**. Nếu cần demo thì dùng SN = `TEST-SN-{id}`, flag `IsDemo=1`. Migration script phải log từng row bị skip sang `EQM_SP_MigrationException`.
- **2 IMEI1 trùng nhau**: migration **HALT** và báo cả 2 row. Không tự resolve.

### PBA (type = "PBA")

| JSON field   | SQL column          | Ghi chú                                              |
|-------------|--------------------|---------------------------------------------------------|
| —           | PbaStockId         | IDENTITY, tự sinh                                     |
| model       | Model              | Phần của key (Model + HolderCode + Condition)         |
| holder      | HolderCode         | Qua HolderAlias                                       |
| status      | Condition          | OK / NG / Checking                                    |
| qty         | Qty                | int >= 0                                               |
| basicModel  | BasicModel         |                                                         |
| origin      | Origin             |                                                         |
| rack        | Location           | Informative only, KHÔNG phải phần key                 |
| remark      | Remark             |                                                         |
| updated     | UpdatedAt          |                                                         |
| userId      | UpdatedBy          | Rỗng → "migration"                                    |

**Quyết định (confirmed):** Rack là phần của key → 2 row khác Rack là **hợp lệ**, không phải lỗi. Migration map `rack` JSON → `Rack` SQL và giữ nguyên cả 2 row.

## 2. receipts[] → EQM_SP_Transfer + EQM_SP_TransferLine

| JSON field   | SQL column (Transfer) | Ghi chú                                           |
|-------------|----------------------|---------------------------------------------------------|
| code        | TransferNo           | GI yyyymmddNNN                                        |
| from        | FromHolder           | Qua HolderAlias                                       |
| vendor      | ToHolder             | Qua HolderAlias                                       |
| —           | TransferType         | "Dispatch" (SEV→vendor)                               |
| status      | Status               | "Đã nhận" → "Received"; "Đã từ chối" → "Rejected"   |
| date        | DispatchedAt         | Parse "dd/MM/yyyy"                                     |
| grCode      | ReceiptNo            | GR code, chỉ khi status = "Đã nhận"                  |

| JSON field   | SQL column (TransferLine) | Ghi chú                                       |
|-------------|--------------------------|--------------------------------------------------|
| type        | ItemType                 | SET / PBA                                        |
| model       | Model                    |                                                   |
| basicModel  | BasicModel               |                                                   |
| serial      | SN (SET chỉ)             |                                                   |
| imei        | IMEI1                    |                                                   |
| imei2       | IMEI2                    |                                                   |
| qty         | Qty                      |                                                   |
| itemStatus  | Condition                |                                                   |

## 3. requests[] → EQM_SP_NGReport / EQM_SP_Transfer

| JSON request.type   | SQL target         | Mapping Status                                    |
|---------------------|--------------------|----------------------------------------------------|
| "Báo NG"            | EQM_SP_NGReport    | code → ReportNo; vendor → HolderCode              |
| "Trả về SEV"        | EQM_SP_Transfer    | TransferType = "Return", ToHolder = "SEV"         |
| "Chuyển Vendor"     | EQM_SP_Transfer    | TransferType = "VendorToVendor", ToHolder = target |

| JSON field   | SQL (NGReport)       | SQL (Transfer)       |
|-------------|---------------------|---------------------|
| code        | ReportNo            | TransferNo          |
| vendor      | HolderCode          | FromHolder          |
| model       | Model               | —(on line)          |
| status      | Status mapping below | Status mapping below|
| reason      | Reason              | Reason              |
| date        | ReportedAt          | RequestedAt         |

Status mapping:
- "Completed" → NGReport: "Closed" / Transfer: "Received"
- "Rejected" → NGReport: "Rejected" / Transfer: "Rejected"

## 4. movements[] → EQM_SP_Movement

| JSON field   | SQL column          | Ghi chú                                              |
|-------------|--------------------|---------------------------------------------------------|
| type        | MovementType        | Mapping below                                         |
| itemType    | ItemType            | SET / PBA                                              |
| from        | Depends on sign     | Transfer-related: from/to → HolderCode+CounterHolder |
| to          | Depends on sign     |                                                         |
| model       | Model               |                                                         |
| serial      | SN (SET)            |                                                         |
| imei        | IMEI1               |                                                         |
| status      | Condition           | OK / NG / Checking                                    |
| qty         | QtyDelta (signed)   | Xem quy tắc sign below                               |
| by          | CreatedBy           |                                                         |
| time        | CreatedAt           | Parse "HH:mm:ss dd/MM/yyyy"                          |

MovementType mapping:

| JSON type                | SQL MovementType | QtyDelta sign | HolderCode    | CounterHolder |
|-------------------------|------------------|---------------|---------------|---------------|
| "Xuất hàng"             | TransferOut      | -qty (from)   | from          | to            |
| "Xác nhận nhận hàng"    | TransferIn       | +qty (to)     | to            | from          |
| "Từ chối nhận"          | TransferBack     | +qty (from)   | from          | to            |
| "Trả hàng"             | TransferBack     | +qty (to=SEV) | SEV           | from          |
| "Luân chuyển"          | TransferOut      | -qty (from)   | from          | to            |
| "Chỉnh sửa"           | Adjust           | ±qty          | from (=to)    | NULL          |

**IsLegacy = 1** cho tất cả movement migration (bypass sign checks nếu dữ liệu gốc không nhất quán).

## 5. Bảng SQL hiện có vs V2

| Hiện có trong script.sql      | Dùng cho V2?                                              |
|------------------------------|-----------------------------------------------------------|
| EQM_MC_SET_InOut             | **KHÔNG** — cấu trúc khác (machine scan log). V2 dùng bảng mới |
| EQM_MRO_StockMovement        | **KHÔNG** — thuộc MRO, không merge vào SET/PBA             |
| EQM_MRO_Inventory_WRBG       | **KHÔNG** — MRO scope                                      |

## 6. Thứ tự chạy script

1. `01-create-schema.sql` — tạo bảng/view
2. `02-seed-holders.sql` — seed holder reference data
3. Migration tool (chưa tạo) — đọc JSON, insert dữ liệu qua API/script

## 7. Tất cả vấn đề — đã đóng

| #  | Vấn đề                                              | Trạng thái |
|----|-----------------------------------------------------|------------|
| 1  | **584 SET không có SN**                             | ✅ Loại production; demo TEST-SN- + IsDemo=1 |
| 2  | **2 IMEI1 trùng**                                   | ✅ Halt + log MigrationException |
| 3  | **ALMUS = ALV**                                     | ✅ ALT=Almus Tech; ALV=Almus Vina |
| 4  | **PBA khác Rack**                                   | ✅ Giữ riêng; Rack vào key |
| 5  | **Target database**                                 | ✅ EquipmentPart |
| 6  | **Demo Transfer cycle**                             | ✅ Không SQL block; app layer lọc IsDemo |
