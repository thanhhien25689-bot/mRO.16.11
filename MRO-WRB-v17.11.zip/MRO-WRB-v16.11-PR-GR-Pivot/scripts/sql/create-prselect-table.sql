-- Bảng lưu xác nhận PIC3 tab PR & Tracking (thay file data/pic3.json).
-- Chạy trên database mà Portal kết nối (mặc định trong màn Cấu hình SQL).
-- Tên bảng theo quy ước EQM_MRO_* của công ty. Idempotent: chạy lại không lỗi.
IF OBJECT_ID(N'[dbo].[EQM_MRO_PRSelect]', N'U') IS NULL
BEGIN
CREATE TABLE [dbo].[EQM_MRO_PRSelect](
  [No]           int IDENTITY(1,1) NOT NULL,
  [LineKey]      nvarchar(64)   NOT NULL,  -- khóa 64-hex portal sinh cho từng dòng Order x Purchase Code (bất biến)
  [PurchaseCode] nvarchar(100)  NOT NULL,  -- mã PIC2 chọn (khớp ITEM_CODE của EQM_MRO_PR)
  [OriginalCode] nvarchar(100)  NULL,      -- Original Code gốc từ Order (đối chiếu khi Purchase trống)
  [ItemName]     nvarchar(200)  NULL,      -- tên hàng từ dòng Order (thuận kiểm tra thủ công)
  [Vendor]       nvarchar(200)  NULL,      -- vendor từ dòng Order
  [OrderDate]    date           NULL,      -- tuần dòng Order (Nguồn: Orders SQL)
  [PRNo]         nvarchar(20)   NULL,      -- PR PIC3 chọn; NULL = draft chưa chọn PR
  [PRSeq]        nvarchar(10)   NULL,      -- PR Seq giữ nguyên số 0 đầu (000010)
  [BuyQty]       decimal(18,3)  NULL,      -- Số lượng mua PIC3 nhập
  [Note]         nvarchar(1000) NULL,      -- ghi chú tương thích bản cũ (UI mới chỉ hiện ghi chú Order)
  [UpdatedAt]    datetime       NOT NULL CONSTRAINT [DF_PRSelect_UpdatedAt] DEFAULT (GETDATE()),
  [UpdatedBy]    nvarchar(80)   NOT NULL,  -- username Portal lưu dòng (session WRB)
  CONSTRAINT [PK_EQM_MRO_PRSelect]   PRIMARY KEY CLUSTERED ([No]),
  CONSTRAINT [UQ_PRSelect_LineKey]   UNIQUE ([LineKey])
);
CREATE INDEX [IX_PRSelect_PurchaseCode] ON [dbo].[EQM_MRO_PRSelect]([PurchaseCode]);
END
GO
