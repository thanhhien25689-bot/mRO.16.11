-- Bổ sung cột cho dbo.EQM_MRO_PRSelect (bản tạo ngày 09/11 thiếu 3 cột máy móc + 2 cột rộng hơn).
-- CHỈ additive: không xóa/mất dữ liệu, chạy lại nhiều lần không lỗi.
-- Lý do:
--   SourceJson : 9 trường nguồn Order của dòng (key, date, originalCode, itemName, quantity,
--                unit, vendor, typeOfCode...) để Portal dựng lại đúng bản đã lưu.
--   PRJson     : snapshot PR PIC3 đã chọn (18 trường). Giữ hành vi cũ: PR mất khỏi SQL vẫn
--                còn dữ liệu hiển thị, không bìa số mới.
--   Revision   : khóa đồng bộ 64-hex (optimitic concurrency như pic3.json cũ); update/delete
--                chỉ áp dụng khi Revision khớp, lệch thì 409 "tải lại".
--   BuyQty     : UI cho nhập tối đa 6 số thập phân -> decimal(18,6) (cũ 18,3 sẽ làm tròn).
--   Note       : UI cho ghi chú tối đa 4000 ký tự -> nvarchar(4000) (cũ 1000 sẽ báo lỗi ghi).
IF OBJECT_ID(N'[dbo].[EQM_MRO_PRSelect]', N'U') IS NULL
BEGIN
  RAISERROR('Bảng dbo.EQM_MRO_PRSelect chưa tồn tại. Chạy scripts/sql/create-prselect-table.sql trước.', 16, 1);
  RETURN;
END
GO
IF COL_LENGTH('dbo.EQM_MRO_PRSelect', 'SourceJson') IS NULL
    ALTER TABLE [dbo].[EQM_MRO_PRSelect] ADD [SourceJson] nvarchar(1000) NOT NULL CONSTRAINT [DF_PRSelect_SourceJson] DEFAULT ('{}');
GO
IF COL_LENGTH('dbo.EQM_MRO_PRSelect', 'PRJson') IS NULL
    ALTER TABLE [dbo].[EQM_MRO_PRSelect] ADD [PRJson] nvarchar(max) NULL;
GO
IF COL_LENGTH('dbo.EQM_MRO_PRSelect', 'Revision') IS NULL
    ALTER TABLE [dbo].[EQM_MRO_PRSelect] ADD [Revision] nvarchar(64) NOT NULL CONSTRAINT [DF_PRSelect_Revision] DEFAULT ('');
GO
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.EQM_MRO_PRSelect') AND name = 'BuyQty' AND (precision <> 18 OR scale <> 6))
    ALTER TABLE [dbo].[EQM_MRO_PRSelect] ALTER COLUMN [BuyQty] decimal(18,6) NULL;
GO
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.EQM_MRO_PRSelect') AND name = 'Note' AND max_length <> 8000)
    ALTER TABLE [dbo].[EQM_MRO_PRSelect] ALTER COLUMN [Note] nvarchar(4000) NULL;
GO
-- Kiểm tra cuối: 15 cột portal cần phải đủ.
SELECT c.name AS column_name, t.name AS type_name, c.max_length, c.precision, c.scale, c.is_nullable
FROM sys.columns c JOIN sys.types t ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID(N'dbo.EQM_MRO_PRSelect')
ORDER BY c.column_id;
GO
