-- Dedicated SQL storage for PIC 2 Code Issue state.
-- Run once by a developer/DBA in the database configured for the Portal.
-- Runtime SQL credentials need SELECT/INSERT/UPDATE/DELETE, not CREATE TABLE.
IF OBJECT_ID(N'[dbo].[EQM_MRO_CodeIssue]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[EQM_MRO_CodeIssue](
        [No]             int IDENTITY(1,1) NOT NULL,
        [LineKey]        nvarchar(64) NOT NULL,
        [BaseKey]        nvarchar(64) NOT NULL,
        [OrderDate]      date NULL,
        [OrderWeek]      nvarchar(10) NOT NULL,
        [Vendor]         nvarchar(200) NOT NULL,
        [WRBCode]        nvarchar(100) NOT NULL,
        [OriginalCode]   nvarchar(100) NOT NULL,
        [PurchaseCode]   nvarchar(100) NOT NULL,
        [TypeOfCode]     nvarchar(10) NOT NULL,
        [Action]         nvarchar(500) NOT NULL,
        [Status]         nvarchar(40) NOT NULL,
        [RFQItemCode]    nvarchar(100) NULL,
        [RFQNo]          nvarchar(100) NULL,
        [RFQSeq]         nvarchar(50) NULL,
        [RFQReqSubNo]    nvarchar(100) NULL,
        [RFQStatus]      nvarchar(100) NULL,
        [RequestDate]    date NULL,
        [ReceiptDate]    date NULL,
        [ContractName]   nvarchar(200) NULL,
        [RFQJson]        nvarchar(max) NULL,
        [CreatedAt]      datetime2(3) NOT NULL,
        [CreatedBy]      nvarchar(80) NOT NULL,
        [UpdatedAt]      datetime2(3) NOT NULL,
        [UpdatedBy]      nvarchar(80) NOT NULL,
        [Revision]       nvarchar(64) NOT NULL,
        CONSTRAINT [PK_EQM_MRO_CodeIssue] PRIMARY KEY CLUSTERED ([No]),
        CONSTRAINT [UQ_EQM_MRO_CodeIssue_LineKey] UNIQUE ([LineKey]),
        CONSTRAINT [CK_EQM_MRO_CodeIssue_TypeOfCode] CHECK ([TypeOfCode] IN (N'',N'IMK',N'Direct',N'Local'))
    );

    CREATE INDEX [IX_EQM_MRO_CodeIssue_BaseKey] ON [dbo].[EQM_MRO_CodeIssue]([BaseKey]);
    CREATE INDEX [IX_EQM_MRO_CodeIssue_PurchaseCode] ON [dbo].[EQM_MRO_CodeIssue]([PurchaseCode]);
END;
GO


