// Offline, console-only recovery for the highest role. No recovery HTTP endpoint.
const fs=require('node:fs'),path=require('node:path'),readline=require('node:readline');
const {hashPassword}=require('../server/auth.cjs');
const root=path.resolve(__dirname,'..'),runtime=process.env.MRO_RUNTIME||path.join(root,'.runtime');
async function run(){
 const lock=path.join(runtime,'server.lock');if(fs.existsSync(lock)){const pid=Number(fs.readFileSync(lock,'utf8'));let alive=false;try{process.kill(pid,0);alive=true;}catch{}if(alive)throw Error('Stop this MRO server before recovery.');}
 if(!process.stdin.isTTY)throw Error('Run this command in an interactive terminal on the server.');
 const file=path.join(runtime,'accounts.json');const db=JSON.parse(fs.readFileSync(file,'utf8'));
 const rl=readline.createInterface({input:process.stdin,output:process.stdout});const login=await new Promise(r=>rl.question('Developer username: ',r));rl.close();
 const user=db.users.find(u=>u.username===login.trim().toLowerCase()&&u.role==='developer');if(!user)throw Error('Developer account not found.');
 const hidden=prompt=>new Promise((resolve,reject)=>{process.stdout.write(prompt);let value='';readline.emitKeypressEvents(process.stdin);process.stdin.setRawMode(true);process.stdin.resume();const listener=(str,key)=>{if(key?.ctrl&&key.name==='c'){done();reject(Error('Cancelled'));}else if(key?.name==='return'){done();resolve(value);}else if(key?.name==='backspace')value=value.slice(0,-1);else if(str&&!key?.ctrl&&str.length===1&&value.length<128)value+=str;};function done(){process.stdin.off('keypress',listener);process.stdin.setRawMode(false);process.stdin.pause();process.stdout.write('\n');}process.stdin.on('keypress',listener);});
 const password=await hidden('New password (12+ characters, hidden): '),confirm=await hidden('Repeat new password: ');if(password!==confirm)throw Error('Passwords do not match.');
 // Re-check the server lock immediately before writing.
 if(fs.existsSync(lock)){try{process.kill(Number(fs.readFileSync(lock,'utf8')),0);throw Error('Server started during recovery. Stop it and retry.');}catch(e){if(e.code!=='ESRCH')throw e;}}
 user.credential=await hashPassword(password);user.mustChangePassword=false;db.audit.push({at:new Date().toISOString(),actor:'local-console',action:'developer-recovery',target:user.id});fs.writeFileSync(file+'.tmp',JSON.stringify(db,null,2));fs.renameSync(file+'.tmp',file);console.log('Developer password recovered. Start the server again.');
}
run().catch(e=>{console.error(e.message);process.exitCode=1;});
