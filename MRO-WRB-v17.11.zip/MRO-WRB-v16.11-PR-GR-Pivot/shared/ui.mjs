// Facade tương thích; giữ các helper chưa có ownership UI thuần.
import {icon} from './icons.mjs';
import {esc} from '../frontend/shared/ui/index.mjs';
export * from '../frontend/shared/ui/index.mjs';

// Màu theo trạng thái nghiệp vụ: chưa di chuyển trong Phase 4B.1.
export function badge(text){const cls=/Hết|Quá hạn|hủy|Nguy cơ/.test(text)?'red':/Chờ|Theo dõi|Sắp|Đang kiểm|chuẩn bị/.test(text)?'amber':/Đủ|Đã GR|Ready|xác nhận|đã giao/.test(text)?'mint':'cyan';return `<span class="badge ${cls}"><i></i>${esc(text)}</span>`;}

// Giao thức điều hướng của shell: giữ nguyên cho đến khi chốt ownership.
export function link(label,route,filter=''){return `<button class="text-button" data-go="${route}" ${filter?`data-filter="${filter}"`:''}>${label}${icon('arrow')}</button>`;}
