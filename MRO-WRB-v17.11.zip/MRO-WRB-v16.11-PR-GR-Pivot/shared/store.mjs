import {screenCache} from './screen-cache.mjs';
const CACHE_KEY='mro-application-data-v1';
const GROUPS=['items','requests','codes','tracking','deliveries','budget','purchaseLines'];
// Thiếu hẳn một nhóm dữ liệu và sai cấu trúc là hai lỗi khác nhau: báo đúng để người dùng biết nguồn nào chưa về.
function missing(next){return GROUPS.filter(key=>!Array.isArray(next?.[key]));}
function valid(next){return !missing(next).length&&!!next?.asOf&&!!next?.production;}
export function createStore(fetcher=fetch){let data=null,pending=null;let cached=false,savedAt=null,account='',storageError=null;
 // Cache gắn với id tài khoản đã lưu nó: đăng xuất rồi đăng nhập lại vẫn dựng được màn hình ngay,
 // còn tài khoản khác trên cùng máy không đọc được snapshot của người trước.
 function read(id){try{const saved=JSON.parse(localStorage.getItem(`${CACHE_KEY}:${id}`));if(valid(saved?.data)){data=saved.data;savedAt=Number(saved.savedAt)||null;cached=true;return true;}}catch{}return false;}
 return {get data(){return data;},get cached(){return cached;},get savedAt(){return savedAt;},get storageError(){return storageError;},
  // Gọi ngay khi có phiên, trước load(): key cũ không gắn tài khoản bị loại nên không lộ dữ liệu lẫn nhau.
  hydrate(userId=''){const id=String(userId||'');screenCache.setUser(id);try{localStorage.removeItem(CACHE_KEY);}catch{}if(!id||id===account)return cached;account=id;return read(id);},
  clear(){data=null;pending=null;cached=false;savedAt=null;account='';screenCache.setUser('');},async load({force=false,onProgress}={}){if(pending)return pending;if(data&&!force){onProgress?.(100);return data;}pending=(async()=>{const response=await fetcher('./data/raw.json',{cache:'no-store'});if(response.status===401)document.dispatchEvent(new Event('auth-expired'));if(!response.ok)throw Error(`Không đọc được dữ liệu (${response.status})`);let next;
   if(response.body?.getReader){const reader=response.body.getReader(),chunks=[];const total=Number(response.headers?.get?.('content-length'))||0;let received=0;for(;;){const part=await reader.read();if(part.done)break;chunks.push(part.value);received+=part.value.byteLength;if(total)onProgress?.(Math.min(95,Math.round(received/total*95)));}const size=chunks.reduce((sum,chunk)=>sum+chunk.byteLength,0),bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}next=JSON.parse(new TextDecoder().decode(bytes));}else next=await response.json();
   onProgress?.(100);const gaps=missing(next);if(gaps.length)throw Error(`Thiếu dữ liệu ${gaps.join(', ')}`);if(!next.asOf||!next.production)throw Error('Dữ liệu không đúng cấu trúc');data=next;globalThis.__mroTestMode===true&&globalThis.__mroTestSnapshot?.(data);cached=false;if(account){const stored=Date.now();try{localStorage.setItem(`${CACHE_KEY}:${account}`,JSON.stringify({savedAt:stored,data:next}));savedAt=stored;storageError=null;}catch(error){storageError=String(error?.name||error.message||error).slice(0,60);}}return data;})();try{return await pending;}finally{pending=null;}}};}
