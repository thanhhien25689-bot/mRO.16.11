import {cardFilters as trackingCards} from '../modules/tracking/public-card-filters.mjs';
export function bindCards(root,module,data,controller){
 const status=s=>r=>r.status===s;
 const ready=data.codes.filter(status('Ready for PR'));
 const pending=data.purchaseLines.filter(r=>!data.tracking.some(t=>t.pr===r.pr&&t.sq===r.sq));
 const filters={tracking:trackingCards({ready,pending})};
 const cards=[...root.querySelectorAll('.kpi-grid>.kpi')];
 function activate(el,fn){el.classList.add('clickable-card');el.setAttribute('role','button');el.tabIndex=0;el.setAttribute('aria-pressed','false');el.addEventListener('click',fn);el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();fn();}});}
 function selected(id){root.querySelectorAll('.clickable-card').forEach(c=>{const yes=c.dataset.cardId===id;c.classList.toggle('card-selected',yes);c.setAttribute('aria-pressed',String(yes));});}
 root.addEventListener('table-filter-changed',e=>selected(e.detail.card));
 if(controller?.bindCards){controller.bindCards({cards,activate,selected});return;}
 if(!controller?.setCardFilter)return;
 cards.forEach((el,i)=>{const filter=(controller?.cardFilters||filters[module])?.[i]?.filter;if(!filter)return;const id=module+'-'+i;el.dataset.cardId=id;activate(el,()=>{controller.setCardFilter({id,...(typeof filter==='function'?{test:filter}:filter)});});});
 if(controller?.locationFilter)root.querySelectorAll('.location').forEach((el,i)=>{const id='location-'+i;el.dataset.cardId=id;activate(el,()=>controller.setCardFilter({id,test:controller.locationFilter(i)}));});
}
