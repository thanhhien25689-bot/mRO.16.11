// Kho snapshot theo từng màn hình, dùng chung cho mọi nguồn dữ liệu SQL của portal.
// Lý do có file này: mỗi màn (Tồn kho, Order, Codes, Tracking, Tổng quan OH, Vendor…) gọi
// một endpoint /api/*-live riêng và trước đây không màn nào được lưu lại, nên lần vào màn sau
// luôn phải chờ SQL. Ở đây lưu bản mới nhất của TỪNG endpoint trong IndexedDB (quota hàng trăm
// MB, khác với localStorage ~5 triệu ký tự vốn âm thầm mất dữ liệu khi payload lớn).
const DB_NAME='mro-screen-cache';
const DB_VERSION=1;
const STORE='snapshots';
// Một màn chỉ được coi là "còn dùng được" trong khoảng thời gian này; quá hạn vẫn dựng ngay
// nhưng giao diện sẽ báo rõ là dữ liệu cũ để người dùng không quyết định trên số cũ.
export const SNAPSHOT_MAX_AGE_MS=24*60*60*1000;
// Đường dẫn nào là dữ liệu của một màn (đọc được, lưu lại được). POST/PUT và file tải về
// không nằm trong danh sách này nên không bao giờ bị phục vụ bằng bản cũ.
const SCREEN_PATHS=[
 /^\/api\/budget-oh\/live(?:\?|$)/,
 /^\/api\/cost-saving(?:\?|$)/,
 /^\/api\/stock-live(?:\?|$)/,
 /^\/api\/orders-live(?:\?|$)/,
 /^\/api\/orders-context(?:\?|$)/,
 /^\/api\/delivery-live(?:\?|$)/,
 /^\/api\/codes-live(?:\?|$)/,
 /^\/api\/tracking-live(?:\?|$)/,
 /^\/api\/aps-live(?:\?|$)/,
 /^\/api\/vendor-data(?:\?|$)/,
 /^\/api\/data-tracking(?:\?|$)/
];
// url → khoá ổn định cho từng màn (bao gồm cả query để các năm/bảng khác nhau không đè nhau).
// Trả về null với những đường dẫn không phải dữ liệu màn hình.
export function screenKey(url){
 try{
  const path=String(typeof url==='string'?url:url?.pathname||url||'');
  const parsed=new URL(path,globalThis.location?.origin||'http://localhost');
  const full=parsed.pathname+(parsed.search||'');
  return SCREEN_PATHS.some(test=>test.test(full))?full:null;
 }catch{return null}
}
// Khoá lưu gắn với id tài khoản: người khác đăng nhập trên cùng máy không đọc được dữ liệu cũ.
export function storageKey(userId,screen){return `${userId||'anon'}|${screen}`}
export function isFresh(savedAt,now=Date.now()){const at=Number(savedAt);return Number.isFinite(at)&&now-at<=SNAPSHOT_MAX_AGE_MS}
// Chữ ký nội dung dùng để phát hiện dữ liệu mới thực sự khác bản đang dựng, tránh dựng lại màn
// chỉ vì một request nền trả về đúng số cũ.
export function signature(value){
 try{const text=JSON.stringify(value);let hash=2166136261;for(let i=0;i<text.length;i++){hash^=text.charCodeAt(i);hash=Math.imul(hash,16777619)}return String(hash>>>0)}catch{return 'unstable'}
}
// IndexedDB + dự phòng localStorage. Truyền tham số vào để test Node chạy được mà không cần trình duyệt.
export function createScreenCache({indexedDB:idb=globalThis.indexedDB,localStorage:storage=globalThis.localStorage,now=()=>Date.now()}={}){
 let account='',db=null,pending=null;
 function open(){
  if(db)return Promise.resolve(db);
  if(pending)return pending;
  pending=new Promise(resolve=>{
   if(!idb){resolve(null);return}
   let request;
   try{request=idb.open(DB_NAME,DB_VERSION)}catch{resolve(null);return}
   request.onupgradeneeded=()=>{const database=request.result;if(!database.objectStoreNames.contains(STORE))database.createObjectStore(STORE)};
   request.onsuccess=()=>{db=request.result;resolve(db)};
   request.onerror=()=>resolve(null);
   request.onblocked=()=>resolve(null);
  });
  return pending;
 }
 // localStorage vẫn dùng được khi IndexedDB bị chặn (chế độ ẩn danh, trình duyệt cũ, Knox wrapper).
 function localRead(key){try{const value=JSON.parse(storage?.getItem?.(`mro-screen-cache-v1:${key}`)||'null');return value&&value.data!==undefined?value:null}catch{return null}}
 function localWrite(key,value){if(!storage)return false;try{storage.setItem(`mro-screen-cache-v1:${key}`,JSON.stringify(value));return true}catch{return false}}
 async function transaction(mode,run){
  const database=await open();
  if(!database)return null;
  return new Promise(resolve=>{
   let request;
   try{
    const tx=database.transaction(STORE,mode);
    // done(request) phải GẮN handler chứ không đọc .result ngay: với IndexedDB thật, request
   // còn đang chờ có .result === null, đọc sớm là mọi lần đọc đều trả rỗng (snapshot ghi được
   // mà không bao giờ đọc lại được — đúng lỗi làm màn hình vẫn phải chờ SQL).
   const done=request=>{request.onsuccess=()=>resolve(request.result===undefined?null:request.result);request.onerror=()=>resolve(null)};
    run(tx.objectStore(STORE),done);
    tx.onerror=()=>resolve(null);
    tx.onabort=()=>resolve(null);
   }catch{resolve(null)}
  });
 }
 return {
  // Gọi khi có phiên đăng nhập: mọi khoá đọc/ghi từ lúc này gắn với tài khoản đó.
  setUser(userId){const id=String(userId||'');if(id!==account)account=id;return account},
  get account(){return account},
  async read(screen){
   if(!screen)return null;
   const key=storageKey(account,screen);
   const stored=await transaction('readonly',(store,done)=>{done(store.get(key))});
   if(stored&&stored.data!==undefined)return stored;
   return localRead(key);
  },
  async write(screen,data){
   if(!screen||data===undefined)return false;
   const key=storageKey(account,screen);
   const value={savedAt:now(),screen,key,data};
   // put trả về chính khoá vừa ghi; hết IndexedDB mới tới localStorage.
   const stored=await transaction('readwrite',(store,done)=>done(store.put(value,key)));
   if(stored!==null)return true;
   return localWrite(key,value);
  },
  async keys(){
   const prefix=`${account}|`;
   const stored=await transaction('readonly',(store,done)=>{done(store.getAllKeys())})||[];
   const local=[];
   try{for(let i=0;i<(storage?.length||0);i++){const name=storage.key(i);if(name&&name.startsWith(`mro-screen-cache-v1:${prefix}`))local.push(name.slice('mro-screen-cache-v1:'.length))}}catch{}
   return [...new Set([...stored.filter(k=>String(k).startsWith(prefix)),...local])];
  },
  // ── Tầng "stale-while-revalidate" cho dữ liệu từng màn ────────────────────────────────────
async clear(userId=account){
   const prefix=`${userId||'anon'}|`;
   for(const key of await this.keys())await transaction('readwrite',(store,done)=>done(store.delete(key)));
   try{for(const name of Object.keys({...storage}).filter(name=>String(name).startsWith(`mro-screen-cache-v1:${prefix}`)))storage.removeItem(name)}catch{}
  }
 };
}
// Bản dùng chung cho cả portal: shared/store.mjs gắn id tài khoản ngay khi hydrate (trước khi
// màn đầu tiên được dựng từ cache), còn app.mjs lắp nó vào window.fetch.
export const screenCache=createScreenCache();
// Đặt ở shared/ vì frontend/core bị khoá đúng 5 file (tests/frontend-core.test.mjs) và static
// handler từ chối file khác; app.mjs nối tầng này vào window.fetch trước khi khởi động.
// Quy tắc: GET vào endpoint màn hình mà đã có bản lưu -> trả bản lưu NGAY để màn hiện số,
// đồng thời gọi SQL phía sau; bản mới khác bản cũ thì phát 'screen-refreshed' cho
// module-registry dựng lại đúng màn đó. Không có bản lưu thì hành xử như fetch thường.
export const SCREEN_REFRESHED='screen-refreshed';
function cacheMetric(type,fields={}){if(globalThis.__mroTestMode!==true||typeof globalThis.__mroCacheMetric!=='function')return;try{globalThis.__mroCacheMetric({type,...fields});}catch{}}
export function createSnapshotTransport({cache:cacheIn,fetcher=globalThis.fetch?.bind(globalThis),dispatch=(event=>globalThis.document?.dispatchEvent(event)),now=()=>Date.now(),force=()=>!!globalThis.__mroForceSnapshotRefresh}={}){
 // Kho lưu mặc định dùng IndexedDB của trình duyệt; test truyền kho giả vào để chạy bằng Node.
 const store=cacheIn||createScreenCache({indexedDB:globalThis.indexedDB,localStorage:globalThis.localStorage,now});const cache=store;
 const inflight=new Map(),latest=new Map();
 async function revalidate(key,input,init){
  const started=Date.now(),sequence=(latest.get(key)||0)+1;latest.set(key,sequence);cacheMetric('screen-refresh-start',{screen:key});
  try{
   const response=await fetcher(input,init);
   if(!response?.ok){cacheMetric('screen-refresh-error',{screen:key,durationMs:Date.now()-started,status:Number(response?.status)||0});return false;}
   const fresh=await response.json().catch(()=>null);
   if(fresh===null){cacheMetric('screen-refresh-error',{screen:key,durationMs:Date.now()-started,status:0});return false;}
   if(latest.get(key)!==sequence){cacheMetric('screen-refresh-discarded',{screen:key,durationMs:Date.now()-started});return false;}
   const stored=await store.read(key);
   await store.write(key,fresh);
   const changed=!stored||signature(stored.data)!==signature(fresh);
   if(changed)dispatch(new CustomEvent(SCREEN_REFRESHED,{detail:{screen:key,savedAt:now(),data:fresh}}));
   cacheMetric('screen-refresh-success',{screen:key,durationMs:Date.now()-started,changed});
   return true;
  }catch{cacheMetric('screen-refresh-error',{screen:key,durationMs:Date.now()-started,status:0});return false}
 }
 return {
  cache,
  wrap(){
   return async function snapshotFetch(input,init){
    const settings=init||{};
    const started=Date.now();
    const raw=typeof input==='string'||(typeof URL!=='undefined'&&input instanceof URL)?String(input):input?.url||String(input);
    const method=String(settings.method||(typeof input==='object'&&input?.method)||'GET').toUpperCase();
    let key=null;
    try{key=screenKey(raw)}catch{}
    // Không phải dữ liệu màn hình, hoặc người dùng chủ động bấm Cập nhật: gọi thẳng SQL,
    // kèm x-mro-refresh để server biết không được đưa bản cũ.
    if(method!=='GET'||!key){
     if(!force())return fetcher(input,settings);
     const target=typeof input==='object'&&typeof input.clone==='function'?input.url:input;
     return fetcher(target,{...settings,method,headers:{...(settings.headers||{}),'x-mro-refresh':'1'}});
    }
    if(force())return fetcher(input,{...settings,headers:{...(settings.headers||{}),'x-mro-refresh':'1'}});
    const stored=await store.read(key);
    if(stored&&stored.data!==undefined){
     cacheMetric('screen-cache-hit',{screen:key,state:isFresh(stored.savedAt,now())?'cache':'stale'});
     if(!inflight.has(key))inflight.set(key,revalidate(key,input,settings).finally(()=>inflight.delete(key)));
     return new Response(JSON.stringify(stored.data),{status:200,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-mro-snapshot':String(stored.savedAt||''),'x-mro-stale':isFresh(stored.savedAt,now())?'cache':'stale'}});
    }
    const response=await fetcher(input,settings);
    cacheMetric(response?.ok?'screen-cache-miss':'screen-fetch-error',{screen:key,durationMs:Date.now()-started,status:Number(response?.status)||0});
    if(response?.ok&&typeof response.clone==='function'){
     void response.clone().json().then(data=>{if(data!==undefined)return store.write(key,data)}).catch(()=>{});
    }
    return response;
   };
  },
  install(){globalThis.fetch=this.wrap();return globalThis.fetch}
 };
}
