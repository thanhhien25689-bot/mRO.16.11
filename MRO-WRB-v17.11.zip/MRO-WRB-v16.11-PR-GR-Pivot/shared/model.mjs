export const sum=(rows,key)=>rows.reduce((n,r)=>n+(typeof key==='function'?key(r):Number(r[key])||0),0);
export function stockTotal(r){return r.physical+Object.values(r.vendors).reduce((a,b)=>a+b,0);}
export function coverage(r){return r.sqlStock?r.stockCalculation.coverage:r.demand?stockTotal(r)/r.demand:null;}
export function stockStatus(r){if(r.sqlStock)return r.stockCalculation.status;const c=coverage(r);return stockTotal(r)===0?'Hết hàng':c===null?'Chưa có nhu cầu':c<1?'Nguy cơ thiếu':c<=4?'Theo dõi':'Đủ tồn';}
export function ageDays(date,asOf){return Math.floor((Date.parse(asOf)-Date.parse(date))/86400000);}
export function sopLate(r,asOf){return r.sop&&!r.po&&ageDays(r.date,asOf)>=21;}
export function isAging(r,asOf){return r.sqlStock?!!r.aging?.warning:stockTotal(r)>0&&ageDays(r.lastIssue,asOf)>30;}
export function ohValue(r){return r.rawGR===null?r.forecast:r.rawGR+r.adjustment;}
// Facade legacy: public contract thuộc Tracking, không kéo renderer vào shared.
export {trackingKey,mergeTracking} from '../modules/tracking/public-model.mjs';
