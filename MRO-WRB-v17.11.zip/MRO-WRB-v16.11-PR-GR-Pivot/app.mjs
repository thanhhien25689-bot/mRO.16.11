import {createGenAIClient} from './frontend/integration/genai.mjs';
import {startDownloads} from './frontend/integration/downloads.mjs';
import {bootstrap} from './frontend/core/bootstrap.mjs';

import {startNotifications} from './frontend/integration/notifications.mjs';
import {api,startAIPreview,vendorSession} from './shared/auth-ui.mjs';
import {createSnapshotTransport,screenCache} from './shared/screen-cache.mjs';
import {startMail} from './frontend/integration/mail.mjs';
import {startMessages} from './frontend/integration/messages.mjs';
import {startApsContracts} from './frontend/integration/aps-contracts.mjs';
import {startApsPlan} from './frontend/integration/aps-plan.mjs';
import {startPresence} from './frontend/integration/presence.mjs';
// 12/11/2026 — snapshot theo từng màn: màn nào đã có bản lưu trong IndexedDB thì dựng ngay,
// SQL vẫn được gọi nền và số mới sẽ tự thay thế (shared/screen-cache.mjs).
// Lắp trước mọi request nên không màn nào bị bỏ sót; bản lưu gắn với id tài khoản đang đăng nhập.
const snapshots=createSnapshotTransport({cache:screenCache});
snapshots.install();
document.addEventListener('auth-ready',()=>snapshots.cache.setUser(vendorSession()?.id||''));
startNotifications(api);
startMail(api);startMessages(api);
startApsContracts(api);
startApsPlan(api);
startPresence(api);
const application=bootstrap();
startDownloads(api,application.getData);

startAIPreview(application.getData,{createClient:createGenAIClient,prepareReport:input=>api('ai/report','POST',input)});
