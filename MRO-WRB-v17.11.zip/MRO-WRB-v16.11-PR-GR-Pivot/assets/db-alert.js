(function(){
  const byId=id=>document.getElementById(id);
  window.dbAlert={
    show({level='error',module='SQL Server',detail=''}={}){
      const box=byId('dbAlert');if(!box)return;const warn=level==='warn';
      box.hidden=false;box.dataset.level=warn?'warn':'error';
      if(byId('dbAlertTitle'))byId('dbAlertTitle').textContent=warn?'Đang dùng dữ liệu gần nhất':'Không tải được dữ liệu';
      if(byId('dbAlertChip'))byId('dbAlertChip').textContent=warn?'CACHE':'LỖI SQL';
      if(byId('dbAlertDesc'))byId('dbAlertDesc').textContent=module+' · cần kiểm tra nguồn dữ liệu.';
      if(byId('dbAlertDetail'))byId('dbAlertDetail').textContent=String(detail||'Kiểm tra kết nối SQL rồi thử lại.');
    },
    hide(){const box=byId('dbAlert');if(box){box.hidden=true;box.dataset.level='';}}
  };
  document.addEventListener('click',event=>{const target=event.target.closest?.('#dbAlertRetry,#dbAlertClose');if(!target)return;if(target.id==='dbAlertClose')window.dbAlert.hide();else document.dispatchEvent(new CustomEvent('db-alert-retry'));});
})();
