try{document.documentElement.dataset.theme=localStorage.getItem('mro-theme')||'light';}catch{}
