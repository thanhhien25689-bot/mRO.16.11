# MRO-WRB v16.11 – PR Report Form Smart Pivot

## Scope
This patch is limited to the frontend **PR Tracking / PR Report Form**, its spreadsheet presentation options, and a small reusable pure grouping helper. The original SQL backend, login/auth logic, PR conversion rates, source filters, and the other tab layouts were not altered.

## New behavior
- PR Report Form: Excel-like navy column headers, readable columns with horizontal scrolling, and sticky header/first column.
- PR groups can be expanded/collapsed. Group/subtotal lines use the numeric values already calculated by the existing report logic, with one Grand Total visible at the bottom.
- The Grand Total is calculated from report leaf rows only; subtotal lines are not counted twice.
- Header area is more compact; saved views, Cost Center options, column selection, and PR source reconciliation are still present inside expandable panels.
- **Xuất đúng View**: exports all filtered report results (not just current pagination), respecting currently visible fields, group collapse states, subtotals, Grand Total, and month-based Amount. Static formatted XLSX; **not** an editable Excel PivotTable.
- **PR chi tiết**: optional export of ungrouped PR-source lines belonging to the same filtered report rows and displayed months.
- The **Reason can cap nhat** worksheet is retained on standard PR Report XLSX exports, with its original Cost Center scope.
- PR report values are displayed with `#,##0.00`. The exported static report is formatted with distinct group, subtotal and total rows, frozen first row/left columns.
- A single-row aggregation now follows the same month-based Amount logic as a multiple-row aggregation (rather than prematurely returning the annual source Amount).

## Tests
- `node --check` on the changed JavaScript modules.
- `node --test tests/pr-smart-pivot.test.mjs` passes 4 tests including amounts, subtotal, collapse, single dimension.
- Existing general test suite passes 27/28 checks in this environment; the one remaining test does not start because the project dependency `fflate` is not installed in this inspection environment. No changes were made to its vendor module.
- XLSX format verified with `openpyxl`: multiple sheets, values, frozen rows/columns and optional autofilter.

## Using
1. Make a backup of the current working Portal directory.
2. Extract this ZIP to a new folder; **do not merge over the running source without a backup**.
3. Run with the existing Portal startup procedure, open **PR Tracking → PR Report Form** and use sample live SQL data to compare screen vs Excel totals for the same Cost Center/month and fields.
4. Verify at least: Type + Project + month 11 + Amount, collapse a Type group, export, then compare that amount with the visible report.
5. No SQL schema migration is required.
