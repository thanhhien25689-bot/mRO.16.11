import test from 'node:test';
import assert from 'node:assert/strict';
import {createPrPivot} from '../frontend/modules/data-tracking/pr-pivot.mjs';

const columns=['Type','Project','Model','11','Amount'].map(key=>({key,label:key}));
const numeric=new Map(columns.map(c=>[c.key,['11','Amount'].includes(c.key)]));
const fixture=[
 {Type:'SETUP',Project:'Watch',Model:'Watch8',11:10.10,Amount:10.10,__detailIds:['1']},
 {Type:'SETUP',Project:'Watch',Model:'Watch9',11:21.05,Amount:21.05,__detailIds:['2']},
 {Type:'SETUP',Project:'Buds',Model:'Buds4',11:8.85,Amount:8.85,__detailIds:['3']},
 {Type:'SOP',Project:'Watch',Model:'Watch8',11:0.30,Amount:0.30,__detailIds:['4']},
 {Type:'SOP',Project:'Buds',Model:'Buds4',11:-0.10,Amount:-0.10,__detailIds:['5']}
];

test('pivot: subtotal and Grand Total derive from filtered leaf rows, not repeated subtotal lines',()=>{
 const pivot=createPrPivot(fixture,columns,numeric);
 assert.equal(pivot.grand.row.Amount,40.2);
 const setup=pivot.entries.find(x=>x.type==='subtotal'&&x.label==='Tổng SETUP');
 assert.equal(setup.row.Amount,40);
 assert.equal(setup.row['11'],40);
 assert.deepEqual(setup.row.__detailIds,['1','2','3']);
 assert.ok(pivot.entries.some(x=>x.type==='subtotal'&&x.label==='Tổng Watch'));
 assert.ok(pivot.entries.some(x=>x.type==='group'));
 assert.equal(pivot.entries.filter(x=>x.type==='row').length,fixture.length);
});

test('pivot: collapse shows grouped Amount and removes descendants but not Grand Total',()=>{
 const open=createPrPivot(fixture,columns,numeric);
 const setupId=open.entries.find(x=>x.type==='group'&&x.label==='SETUP').id;
 const collapsed=createPrPivot(fixture,columns,numeric,new Set([setupId]));
 const group=collapsed.entries.find(x=>x.type==='group'&&x.id===setupId);
 assert.equal(group.collapsed,true);
 assert.equal(group.row.Amount,40);
 assert.equal(collapsed.entries.some(x=>x.type==='subtotal'&&x.label==='Tổng SETUP'),false);
 assert.equal(collapsed.grand.row.Amount,40.2);
 assert.ok(collapsed.entries.length<open.entries.length);
});

test('pivot: single visible text dimension is not expanded into redundant groups',()=>{
 const cols=[{key:'Type'},{key:'11'},{key:'Amount'}],meta=new Map([['Type',false],['11',true],['Amount',true]]);
 const rows=[{Type:'SETUP','11':13,Amount:13},{Type:'SOP','11':7,Amount:7}];
 const pivot=createPrPivot(rows,cols,meta);
 assert.equal(pivot.groups,0);
 assert.equal(pivot.entries.length,2);
 assert.equal(pivot.grand.row.Amount,20);
});

test('pivot: filtered and single item views preserve source amount, including decimals',()=>{
 const pivot=createPrPivot([fixture[2]],columns,numeric);
 assert.equal(pivot.entries.length,1);
 assert.equal(pivot.grand.row.Amount,8.85);
 assert.equal(pivot.entries[0].row.Type,'SETUP');
});
