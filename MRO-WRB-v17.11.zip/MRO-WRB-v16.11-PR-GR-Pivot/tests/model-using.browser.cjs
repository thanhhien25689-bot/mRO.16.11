// Real UI smoke for both inventory screens, dark/light. Fixture-only loopback
// server; no corporate SQL, account store or production runtime is accessed.
const assert=require('node:assert/strict'),http=require('node:http'),path=require('node:path');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
const {createStaticHandler}=require('../backend/core/static-files.cjs');
const {calculate}=require('../backend/modules/stock/index.cjs');
const {mapOverview}=require('../backend/modules/vendor/overview.cjs');
const mapping=[{Model:'Watch8',Atb1:'WATCH',Atb2:'SM-L320'},{Model:'Watch8',Atb1:'WATCH',Atb2:'SM-L325'}];
const plan=(Vendor,Atb2,q)=>({Vendor,Atb2,Year:2026,...Object.fromEntries(Array.from({length:54},(_,i)=>['W'+String(i+1).padStart(2,'0'),q]))});
const raw={modelMapping:mapping,master:[{'Purchase Code':'P1','WRB Code':'WRB1','Vendor Item Name':'Test material','Tên Tiếng Việt':'Test material',Unit:'PAC',TYPE:'SOP','Type (MRO/Spare)':'SOP','Model Using':'Watch8',Usage:100}],production:[plan('ALT','SM-L320',100),plan('ALV','SM-L325',200)],inventory:[{'Item code':'P1','WRB Code':'WRB1','STOCK SEV':10,'Tên Tiếng Việt':'Test material'}],history:[],inout:[],vendorInout:[],transfers:[],vendorInventory:[{Vendor:'ALT',Purchase_Code:'P1',Confirm_date:'2026-01-01',Opening_QTY:6}]};raw.plan=raw.production;
const period={today:'2026-11-16',start:'2026-11-16',end:'2026-11-22',year:2026,week:47};
const inventory={...calculate(raw,new Date('2026-11-16T05:00:00Z')),asOf:period.today,stockSource:'sql'};
const vendor={...mapOverview(raw,'Almus Tech',period),scopes:['Almus Tech'],vendor:'Almus Tech',orders:[],inout:[],transfers:[],pendingTransfers:[],period,source:'sql',updatedAt:'2026-11-16T05:00:00Z'};
const handler=createStaticHandler({root,budget:{overlay:x=>x},auth:{requireUser:()=>({user:{role:'developer'}})}});
const html=(type,theme)=>`<!doctype html><html data-theme="${theme}"><head><link rel="stylesheet" href="/assets/styles.css"><link rel="stylesheet" href="/assets/readability.css"></head><body><div id="views"><div id="target" data-view="${type==='inventory'?'inventory':'vendor-overview'}"></div></div><dialog id="detail"><h2 id="detail-title"></h2><div id="detail-body"></div></dialog><div id="toast"></div><script type="module">
import {mount} from '/frontend/modules/${type==='inventory'?'inventory':'vendor'}/index.mjs';
import {badge} from '/shared/ui.mjs';
const data=${JSON.stringify(type==='inventory'?inventory:vendor)};
mount(document.querySelector('#target'),${type==='inventory'?'data,{badge}':`{}, {page:'overview',offline:true,read:async()=>data,session:()=>({user:{role:'developer'}})}`});
window.testReady=true;
</script></body></html>`;
(async()=>{
 let browser;const server=http.createServer((req,res)=>{const url=new URL(req.url,'http://localhost');if(url.pathname==='/fixture'){res.writeHead(200,{'content-type':'text/html; charset=utf-8'});res.end(html(url.searchParams.get('type'),url.searchParams.get('theme')));return;}handler(req,res,url.pathname);});
 try{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  browser=await chromium.launch({executablePath:process.env.MRO_CHROMIUM||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  for(const type of ['inventory','vendor'])for(const theme of ['dark','light']){
   const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];page.on('pageerror',error=>errors.push(error.message));
   await page.goto(`http://127.0.0.1:${server.address().port}/fixture?type=${type}&theme=${theme}`);
   await page.waitForFunction(()=>window.testReady===true);
   const table=type==='inventory'?'#inventory-table':'[data-vendor-table]';
   await page.locator(table+' tbody tr .row-open').first().click();
   await page.locator('#detail[open]').waitFor();
   const body=await page.locator('#detail-body').innerText();assert.match(body,/Watch8/);
   if(type==='inventory'){assert.match(body,/SM-L320/);assert.match(body,/Tổng sản lượng/);}else{assert.match(body,/Dự báo tồn kho theo tuần/);assert.doesNotMatch(body,/Model Using: SM-L/);}
   assert.deepEqual(errors,[]);console.log('PASS '+type+' '+theme+' detail and compact label; no page errors');await page.close();
  }
 }finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(error=>{console.error(error);process.exitCode=1;});
