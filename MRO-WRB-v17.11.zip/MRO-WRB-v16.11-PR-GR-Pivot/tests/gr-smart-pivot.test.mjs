import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {createGrPivot,grSummary,grSourceLines,grProblemReasons,grMatchesFocus} from '../frontend/modules/data-tracking/gr-pivot.mjs';
const require=createRequire(import.meta.url);
const {grReportForm}=require('../backend/modules/data-tracking/index.cjs');
const gl=[{GL_Account:'123',GL_Class:'Supplies'}];
const pr=(item,po,reason='SOP - WATCH - Watch8 - Line')=>({PR_NO:'PR-'+item,PR_SEQ:'000010',PO_NO:po,PO_SEQ:'000010',ITEM_CODE:item,GL_ACCOUNT:'123',PURCHASE_REQ_INFO:reason});
const gr=(item,po,amount,day='2026-11-05',cc='01')=>({GR_NO:`G-${item}`,GR_DATE:day,PO_NO:po,PO_SEQ:'000010',ITEM_CODE:item,GR_QTY:1,GR_AMOUNT:amount,CURRENCY:'USD',COST_CENTER_CODE:cc});
const fixture=()=>grReportForm([
 gr('A','PO1',120),gr('B','PO2',-20),gr('C','PO3',25),gr('D','PO4',10),gr('A','PO1',65,'2026-10-20','02'),
 {...gr('E','PO5',26000),CURRENCY:'VND'},
 {...gr('F','PO6','bad-number'),CURRENCY:'JPY'},
], [pr('A','PO1'),pr('B','PO2'),pr('C','PO3','bad reason'),pr('E','PO5'),pr('F','PO6')],gl,[]);

function columns(){return ['Type','Project','Model','Match Status','11','10','Amount'].map(key=>({key,label:key}));}
const meta=new Map(columns().map(c=>[c.key,['11','10','Amount'].includes(c.key)]));
test('GR: subtotal, Grand Total, namespace and collapse use only leaf rows; negative amounts remain',()=>{
 const source=fixture();assert.equal(source.audit.convertedUSD,201);
 const prepared=source.sheet.rows.map(r=>({Type:r.Type,Project:r.Project,Model:r.Model,'Match Status':r['Match Status'], '11':r['11'], '10':r['10'],Amount:r.Amount,__detailIds:r.__detailIds}));
 const pivot=createGrPivot(prepared,columns(),meta),sum=pivot.grand.row.Amount;
 assert.equal(sum,201);
 assert.ok(pivot.entries.some(x=>x.type==='group'&&x.groupKey==='Type'));
 const group=pivot.entries.find(x=>x.type==='group'&&x.label==='SOP');assert.ok(group);
 assert.ok(group.id.startsWith('GR_REPORT\u0000'));
 const collapsed=createGrPivot(prepared,columns(),meta,new Set([group.id]));
 assert.equal(collapsed.grand.row.Amount,sum);
 assert.ok(collapsed.entries.length<pivot.entries.length);
 assert.ok(collapsed.entries.find(x=>x.type==='group'&&x.id===group.id).row.__detailIds.length>1);
 assert.ok(!collapsed.entries.some(x=>x.type==='subtotal'&&x.label==='Tổng SOP'));
});

test('GR KPI: scoped original GR lines, matching status and source month, not pivot rows',()=>{
 const x=fixture();const november=grSummary(x.sheet.rows,x.details,[11]);
 assert.equal(november.amount,136); // 120 - 20 + 25 + 10 + 1 (VND) + zero unconverted
 assert.equal(november.matched,5);
 assert.equal(november.unmatched,1);
 assert.equal(november.ambiguous,0);
 assert.ok(november.issues>=2);
 assert.equal(november.unconverted,1);
 const october=grSummary(x.sheet.rows,x.details,[10]);
 assert.equal(october.amount,65);
 assert.equal(october.sourceRows,1);
 const onlyCC=x.sheet.rows.filter(r=>r.COST_CENTER==='02');
 assert.equal(grSummary(onlyCC,x.details,[10]).amount,65);
 assert.equal(grSummary(onlyCC,x.details,[11]).sourceRows,0);
});

test('GR quality filters and issue sheet source data retain unmatched and invalid currency',()=>{
 const x=fixture(),unmatched=x.sheet.rows.filter(r=>grMatchesFocus(r,'problem-pr'));
 assert.equal(unmatched.length,1);
 assert.equal(unmatched[0]['Match Status'],'Unmatched PR');
 const quality=x.sheet.rows.filter(r=>grMatchesFocus(r,'data-issues'));
 assert.ok(quality.some(row=>row.__unconverted));
 assert.ok(quality.some(row=>row['Thiếu Type']));
 const details=grSourceLines(quality,x.details,[11]);
 assert.ok(details.some(row=>row['Amount USD']===null));
 assert.ok(details.some(row=>row['Match Status']==='Unmatched PR'));
 assert.ok(details.some(row=>grProblemReasons(row).includes('Reason thiếu hoặc sai mẫu')));
 assert.equal(new Set(details.map(r=>r.id)).size,details.length);
});

test('GR frontend hooks reuse styled Pivot, 4 KPI drill-down and 4 Excel sheets',()=>{
 const ui=readFileSync(new URL('../frontend/modules/data-tracking/index.mjs',import.meta.url),'utf8');
 assert.match(ui,/if\(kind==='GR_REPORT'\)return createGrPivot\(rows,columns,meta,pivotCollapsed\)/);
 assert.match(ui,/GR Amount/);
 assert.match(ui,/data-dt-gr-focus/);
 assert.match(ui,/data-dt-gr-cell/);
 assert.match(ui,/name:issuesOnly\?'Loi doi soat':'GR detail'/);
 assert.match(ui,/grRawDetailSheet\(rows,columns,true\)/);
 assert.match(ui,/reasonIssueSheet\(value,main\)/);
 assert.match(ui,/reportKind\(kind\)&&pivot.grand/);
 assert.match(ui,/if\(reportKind\(kind\)\)return `<style>/);
});
