import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
const require=createRequire(import.meta.url);
const {createModelResolver,productionIndex}=require('../backend/integration/model-using.cjs');
const {calculate}=require('../backend/modules/stock/index.cjs');
const {mapOverview}=require('../backend/modules/vendor/overview.cjs');
const {mapStock}=require('../backend/modules/vendor/index.cjs');
const mapping=[{Model:'Watch8',Atb1:'WATCH',Atb2:'SM-L320'},{Model:'Watch8',Atb1:'WATCH',Atb2:'SM-L325'},{Model:'Watch9',Atb1:'WATCH',Atb2:'SM-L355'},{Model:'Buds4',Atb1:'BUDS',Atb2:'SM-R640'}];
const plan=(Vendor,Atb2,quantity,Year=2026)=>({Vendor,Atb2,Year,...Object.fromEntries(Array.from({length:54},(_,i)=>['W'+String(i+1).padStart(2,'0'),quantity]))});
const production=[plan('ALT','SM-L320',100),plan('ALV','SM-L320',400),plan('ALT','SM-L355',200),plan('ALV','SM-L325',500),plan('CW','SM-R640',900)];
const master=(model='Watch')=>({'Purchase Code':'P1','WRB Code':'WRB1','Vendor Item Name':'Test','Tên Tiếng Việt':'Test',Unit:'PAC',TYPE:'SOP','Type (MRO/Spare)':'SOP','Model Using':model,Usage:100});
const period={today:'2026-11-16',start:'2026-11-16',year:2026,week:47};
function snapshot(model='Watch'){
 return {modelMapping:mapping,master:[master(model)],production,plan:production,inventory:[{'Item code':'P1','WRB Code':'WRB1','STOCK SEV':10,'Tên Tiếng Việt':'Test'}],history:[],inout:[],vendorInout:[],transfers:[],vendorInventory:[{Vendor:'ALT',Purchase_Code:'P1',Confirm_date:'2026-01-01',Opening_QTY:6}]};
}
test('Project, Model, Basic, commas, case and overlap resolve to unique Basics',()=>{
 const resolve=createModelResolver(mapping,production);
 assert.deepEqual(resolve(' watch8 , Watch9,SM-L320, WATCH8 ').basics,['SM-L320','SM-L325','SM-L355']);
 assert.deepEqual(resolve('Watch').basics,resolve('Watch8,Watch9').basics);
 assert.deepEqual(resolve('sm-l325').basics,['SM-L325']);
 assert.deepEqual(resolve('Watch8,Buds4').basics,['SM-L320','SM-L325','SM-R640']);
 assert.equal(resolve('Watch88').problems.length,1);
 assert.deepEqual(resolve('Watch8-Watch9').basics,[]);
});
test('mapping duplicates are harmless; conflicting parents and ambiguous names are diagnosed',()=>{
 assert.deepEqual(createModelResolver([...mapping,mapping[0]],production)('Watch8').problems,[]);
 assert.match(createModelResolver([...mapping,{Model:'Watch9',Atb1:'WATCH',Atb2:'SM-L320'}],production)('Watch').problems.join(),/nhiều Model/);
 assert.match(createModelResolver([...mapping,{Model:'WATCH',Atb1:'BUDS',Atb2:'SM-R640'}],production)('Watch').problems.join(),/trùng tên/);
});
test('production aggregates distinct Vendors, isolates vendor and rejects duplicate or missing values',()=>{
 const index=productionIndex(production);
 assert.equal(index.values('SM-L320',2026,47),500);
 assert.equal(index.values('SM-L320',2026,47,'Almus Tech'),100);
 assert.equal(index.values('SM-L320',2026,47,'CW'),null);
 assert.equal(productionIndex([...production,production[0]]).values('SM-L320',2026,47),null);
 assert.equal(productionIndex([...production,plan('ALT','SM-L320',0,2027)]).values('SM-L320',2027,1),null);
 assert.equal(productionIndex([{...production[0],W47:null}]).values('SM-L320',2026,47),null);
 assert.equal(productionIndex([{...production[0],W47:0}]).values('SM-L320',2026,47),0);
});
test('Vendor overview uses only Basics at selected Vendor and excludes overlapping groups',()=>{
 const raw=snapshot();const row=mapOverview(raw,'Almus Tech',period).items[0];
 assert.equal(row.need,3);assert.equal(row.coverage,2);assert.equal(row.exact,true);
 assert.deepEqual(row.modelLabels,['Watch']);
 assert.equal(mapOverview({...raw,master:[master('Watch,Watch8,Watch9,SM-L320')]},'Almus Tech',period).items[0].need,3);
});
test('Vendor Order stock uses same resolver and vendor-scoped production',()=>{
 const row=mapStock(snapshot('Watch,Watch8,SM-L320'),'Almus Tech',period).items[0];
 assert.equal(row.need,3);assert.equal(row.coverage,2);assert.equal(row.exact,true);
 assert.equal(mapStock(snapshot('SM-L320'),'Almus Tech',period).items[0].need,1);
});
test('SEV & Vendor sums all Vendors once and keeps compact labels and explanation',()=>{
 const row=calculate(snapshot('Watch,Watch8,SM-L320'),new Date('2026-11-16T05:00:00Z')).items[0];
 assert.equal(row.demand,12);assert.equal(row.stockCalculation.total,16);
 assert.equal(row.stockCalculation.coverage,16/12);
 assert.equal(row.stockCalculation.model,'Watch,Watch8,SM-L320');
 assert.match(row.stockCalculation.steps[0],/Tổng sản lượng \(3 Basic\)/);
 assert.equal(row.stockCalculation.steps[0].includes('SM-L320'),false);
});
test('unknown or inconsistent mappings block forecast instead of silently reducing demand',()=>{
 for(const f of [raw=>mapOverview(raw,'Almus Tech',period).items[0],raw=>calculate(raw,new Date('2026-11-16T05:00:00Z')).items[0].stockCalculation]){
  const row=f(snapshot('Watch,Typo'));assert.equal(row.coverage,null);assert.match(row.problems.join(),/Typo/);assert.equal(row.status,'Chưa đủ dữ liệu');
 }
 assert.equal(mapStock(snapshot('Watch,Typo'),'Almus Tech',period).items[0].coverage,null);
});
test('direct Basic is compatible with legacy unscoped production',()=>{
 const raw=snapshot('SM-L320');raw.production=[plan('','SM-L320',100)];raw.modelMapping=[];
 assert.equal(calculate(raw,new Date('2026-11-16T05:00:00Z')).items[0].demand,1);
 assert.equal(mapStock(raw,'Almus Tech',period).items[0].need,1);
});
test('WRB equivalence compares expanded Basic sets instead of raw label spelling/order',()=>{
 const raw=snapshot('Watch8');raw.master.push({...master('sm-l325, SM-L320'),'Purchase Code':'P2'});
 raw.vendorInventory.push({Vendor:'ALT',Purchase_Code:'P2',Confirm_date:'2026-01-01',Opening_QTY:2});
 assert.equal(mapOverview(raw,'Almus Tech',period).items[0].stock,8);
 assert.equal(mapOverview(raw,'Almus Tech',period).items[0].invalid,undefined);
 raw.inventory.push({'Item code':'P2','WRB Code':'WRB1','STOCK SEV':2});
 assert.equal(calculate(raw,new Date('2026-11-16T05:00:00Z')).items[0].stockCalculation.problems.length,0);
});
test('missing plan differs from zero; Spare safety logic is preserved',()=>{
 const raw=snapshot('Watch8');raw.plan=[{...production[0],W47:null}];
 assert.equal(mapOverview(raw,'Almus Tech',period).items[0].coverage,null);
 raw.plan=[{...production[0],W47:0}];assert.equal(mapOverview(raw,'Almus Tech',period).items[0].need,0);
 const spare=snapshot();spare.master=[{...master('Watch'),TYPE:'Spare',Usage:null,'Safety Stock':10}];
 assert.equal(mapOverview(spare,'Almus Tech',period).items[0].status,'Nguy cơ thiếu');
});
test('SQL read paths include mapping and both Vendor adapters propagate it',()=>{
 const worker=readFileSync(new URL('../backend/modules/sql/worker.ps1',import.meta.url),'utf8');
 for(const action of ['stock','vendor-stock','vendor-overview']){
  const line=worker.split('\n').find(l=>l.includes("if ($job.action -eq '"+action+"') { $command.CommandText ="));
  assert.match(line,/SELECT \[Model\],\[Atb1\],\[Atb2\] FROM \[dbo\]\.\[EQM_MRO_Model\]/);
 }
 assert.match(worker,/vendorInout=@\(\$sets\[6\]\);modelMapping=@\(\$sets\[7\]\)/);
 const adapter=readFileSync(new URL('../backend/modules/sql/index.cjs',import.meta.url),'utf8');
 assert.equal(adapter.split('modelMapping:value.modelMapping').length-1,2);
});

test('Vendor order validation accepts mapped groups/Basics for its Vendor and rejects other Vendors',async()=>{
 const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
 const {createVendor}=require('../backend/modules/vendor/index.cjs');
 const runtime=fs.mkdtempSync(path.join(os.tmpdir(),'mro-model-order-'));
 const actor={id:'test',username:'test',role:'user',vendorScope:'Almus Tech'};let writes=0;
 try{
  for(const [i,model] of ['Watch','SM-L320','Buds4'].entries()){
   const vendor=createVendor({runtime,now:()=>new Date('2026-11-16T05:00:00Z'),sql:{readVendorStock:async()=>snapshot(model),addOrders:async()=>{writes++;return {inserted:1};}}});
   const input={vendor:'Almus Tech',week:period.start,requestId:'test-order-request-'+i,rows:[{itemCode:'P1',itemName:'Test',code:'WRB1',quantity:'1',unit:'PAC',reason:'Test',remark:'SOP - WATCH - Watch8 - Test'}]};
   const task=()=>vendor.handle({req:{method:'POST',socket:{remoteAddress:'127.0.0.1'}},url:new URL('http://localhost/api/vendor-orders'),actor,body:async()=>input,send:()=>{},protectedTransaction:async fn=>fn(),requireUser:()=>({user:actor})});
   if(model==='Buds4')await assert.rejects(task,error=>error.status===403);else assert.equal(await task(),true);
  }
  assert.equal(writes,2);
 }finally{fs.rmSync(runtime,{recursive:true,force:true});}
});
test('duplicate Vendor/Basic plan rows cannot double demand',()=>{
 const raw=snapshot();raw.plan=[...production,production[0]];
 const row=mapOverview(raw,'Almus Tech',period).items[0];assert.equal(row.coverage,null);assert.match(row.problems.join(),/Thiếu sản lượng/);
});
