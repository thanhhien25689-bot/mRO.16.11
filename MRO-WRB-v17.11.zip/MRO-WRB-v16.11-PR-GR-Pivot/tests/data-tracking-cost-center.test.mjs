import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
const require=createRequire(import.meta.url);
const {reportForm,grReportForm,createDataTracking}=require('../backend/modules/data-tracking/index.cjs');
const gl=[{GL_Account:'123',GL_Class:'Supplies'}];
const pr=(cc,amount=100)=>({PR_NO:'PR1',PR_SEQ:'000010',PO_NO:'PO1',PO_SEQ:'000010',ITEM_CODE:'P1',COST_CENTER:cc,GL_ACCOUNT:'123',PURCHASE_REQ_INFO:'SOP - WATCH - Watch8 - Line',PR_Month:11,PR_BUYING_AMOUNT:amount,BUYING_CURRENCY:'USD'});
const gr=(cc,amount=100)=>({GR_NO:'GR1',GR_DATE:'2026-11-01',PO_NO:'PO1',PO_SEQ:'000010',ITEM_CODE:'P1',COST_CENTER_CODE:cc,GR_AMOUNT:amount,CURRENCY:'USD'});
const sum=rows=>rows.reduce((s,r)=>s+Number(r.Amount||0),0);
test('PR cost center is a text dimension: distinct centers split before filtering, totals reconcile',()=>{
 const result=reportForm([pr(' 0012 ',100),pr('0020',200),pr('0012',50)],gl);
 assert.equal(result.sheet.rows.length,2);
 assert.equal(result.sheet.rows.find(r=>r.COST_CENTER==='0012').Amount,150);
 assert.equal(sum(result.sheet.rows.filter(r=>r.COST_CENTER==='0020')),200);
 assert.equal(sum(result.sheet.rows),350);assert.equal(result.audit.differenceUSD,0);
 assert.deepEqual(result.sheet.columns.find(c=>c.name==='COST_CENTER'),{name:'COST_CENTER',type:'nvarchar',numeric:false});
 assert.equal(result.details[0].COST_CENTER,'0012');
});
test('GR uses GMRO Cost Center even when the matched PR has another center',()=>{
 const result=grReportForm([gr('0012',100),gr('0020',200),gr('0012',50)],[pr('PR-CENTER')],gl);
 assert.equal(result.sheet.rows.length,2);
 assert.equal(result.sheet.rows.find(r=>r.COST_CENTER==='0012').Amount,150);
 assert.equal(sum(result.sheet.rows),350);assert.equal(result.audit.differenceUSD,0);
 assert.equal(result.details[0].COST_CENTER,'0012');
 assert.equal(result.sheet.rows.some(r=>r.COST_CENTER==='PR-CENTER'),false);
 assert.equal(result.sheet.columns.find(c=>c.name==='COST_CENTER').numeric,false);
});
test('missing Cost Center stays blank; unmatched GR keeps its source center and amount',()=>{
 const p=reportForm([pr(null,10),pr('ABC',20)],gl);assert.equal(p.sheet.rows.length,2);assert.equal(sum(p.sheet.rows),30);
 const g=grReportForm([gr('0012',100)],[],gl);
 assert.equal(g.sheet.rows[0].COST_CENTER,'0012');assert.equal(g.sheet.rows[0]['Match Status'],'Unmatched PR');assert.equal(g.sheet.rows[0].Amount,100);
});
test('Reason overrides keep precedence without replacing Cost Center',()=>{
 const overrides=[{ITEM_CODE:'P1',PR_NO:'PR1',PR_SEQ:'000010',PURCHASE_REQ_INFO_OVERRIDE:'SOP - BUDS - Buds4 - Line',IS_IGNORED:0}];
 const p=reportForm([pr('0012')],gl,overrides),g=grReportForm([gr('0020')],[pr('0012')],gl,overrides);
 assert.equal(p.sheet.rows[0].Project,'BUDS');assert.equal(p.sheet.rows[0].COST_CENTER,'0012');
 assert.equal(g.sheet.rows[0].Project,'BUDS');assert.equal(g.sheet.rows[0].COST_CENTER,'0020');
});
test('currency conversion and positive/negative GR reconcile across centers',()=>{
 const p=reportForm([{...pr('A'),PR_BUYING_AMOUNT:26000,BUYING_CURRENCY:'VND'},{...pr('B'),PR_BUYING_AMOUNT:180,BUYING_CURRENCY:'JPY'}],gl);
 assert.equal(sum(p.sheet.rows),2);assert.equal(p.audit.differenceUSD,0);
 const g=grReportForm([{...gr('A'),GR_AMOUNT:26000,CURRENCY:'VND'},{...gr('B'),GR_AMOUNT:-180,CURRENCY:'JPY'}],[pr('X')],gl);
 assert.equal(sum(g.sheet.rows),0);assert.equal(g.audit.differenceUSD,0);
});
test('public API returns Cost Center for both reports with one SQL read per report',async()=>{
 let reads=0;
 const api=createDataTracking({sql:{readReportForm:async()=>{reads++;return {pr:[pr('A')],gl};},readGRReport:async()=>{reads++;return {gr:[gr('B')],pr:[pr('X')],gl};}}});
 for(const kind of ['REPORT','GR_REPORT']){
  let response;
  await api.handle({req:{method:'GET'},url:new URL('http://localhost/api/data-tracking?table='+kind+'&year=2026&reload=1'),send:(_r,status,value)=>{assert.equal(status,200);response=value;}});
  assert.ok(response.sheet.columns.some(c=>c.name==='COST_CENTER'));
  assert.equal(response.sheet.rows[0].COST_CENTER,kind==='REPORT'?'A':'B');
 }
 assert.equal(reads,2);
});
test('SQL and frontend expose Cost Center in report group selectors and preserve prior source exclusions',()=>{
 const worker=readFileSync(new URL('../backend/modules/sql/worker.ps1',import.meta.url),'utf8');
 const prSQL=worker.slice(worker.indexOf("if ($job.action -eq 'report-form') {"),worker.indexOf("if ($job.action -eq 'gr-report') {"));
 assert.match(prSQL,/SELECT \[RECEIVER_NAME\],\[PR_NO\],\[COST_CENTER\]/);
 assert.match(worker,/\[COST_CENTER_CODE\].*C5H0Z861/);
 const ui=readFileSync(new URL('../frontend/modules/data-tracking/index.mjs',import.meta.url),'utf8');
 assert.match(ui,/REPORT:\{name:'PR report',version:2,columns:\['PR_NO','COST_CENTER'/);
 assert.match(ui,/GR_REPORT:\{name:'GR report',version:2,columns:\['PR_NO','COST_CENTER'/);
 assert.match(ui,/\['Trường nhóm',c=>!meta.get\(c.key\)\]/);
 assert.match(ui,/existing.columns.splice\(.*key:'COST_CENTER'/);
});
test('built-in check migration waits for refreshed columns and preserves saved preferences',()=>{
 const source=readFileSync(new URL('../frontend/modules/data-tracking/index.mjs',import.meta.url),'utf8');
 const start=source.indexOf(' function ensureDefaultCheck(){'),end=source.indexOf(' function saveChecks(){',start);
 const stored={name:'PR report',columns:[{key:'PR_NO',label:'Số PR',visible:true},{key:'Amount',label:'Giá trị',visible:false}],filters:{PR_NO:'PR1'},merge:['PR_NO'],search:'saved search'};
 const records=new Map([['REPORT',{sheet:{columns:[{name:'PR_NO'}]}}]]),versions=new Map([['u\nREPORT',1]]);let saves=0;
 const ensure=Function('presetFor','kind','records','user','checks','removedChecks','presetVersions','reportKind','saveChecks','defaultCheck',source.slice(start,end)+';return ensureDefaultCheck;')(()=>({name:'PR report',version:2}),'REPORT',records,'u',()=>({'PR report':stored}),new Map(),versions,()=>true,()=>saves++,()=>{throw Error('Must preserve saved check');});
 ensure();assert.equal(versions.get('u\nREPORT'),1);assert.equal(saves,0);
 records.set('REPORT',{sheet:{columns:[{name:'PR_NO'},{name:'COST_CENTER'}]}});ensure();
 assert.equal(versions.get('u\nREPORT'),2);assert.equal(saves,1);
 assert.deepEqual(stored.columns.map(c=>c.key),['PR_NO','COST_CENTER','Amount']);
 assert.deepEqual(stored.filters,{PR_NO:'PR1'});assert.equal(stored.search,'saved search');assert.equal(stored.columns[2].visible,false);assert.equal(stored.columns[0].label,'Số PR');
});
test('Report Form: COST_CENTER is an optional "Trường nhóm" card (unticked once by default) plus the outside include/exclude filter',()=>{
 const ui=readFileSync(new URL('../frontend/modules/data-tracking/index.mjs',import.meta.url),'utf8');
 assert.doesNotMatch(ui,/outsideTableColumn/);
 assert.match(ui,/if\(reportKind\(kind\)&&saved\?\.costCenterGroupDefault!==true\)\{const cc=list\.find\(c=>c\.key==='COST_CENTER'\);if\(cc\)cc\.visible=false;\}/);
 assert.match(ui,/costCenterGroupDefault:true,excludedCostCenters:/);
 assert.match(ui,/function filtered\(\)\{[^\n]*allowCostCenter\(row\)&&/);
 assert.match(ui,/rows=value\.sheet\.rows\.filter\(row=>allowCostCenter\(row\)&&/);
 assert.match(ui,/\$\{checksBox\(\)\}\$\{costCenterFilter\(value\)\}\$\{columnSlicers\(p,meta\)\}/);
});
