import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {createStaticHandler}=require('../backend/core/static-files.cjs');

async function fixture(run,{snapshot=true}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mro-raw-startup-'));
 let aggregateReads=0;
 const data={asOf:'2026-11-16',production:{plan:0,actual:0},items:[],requests:[],codes:[],tracking:[],deliveries:[],budget:[],purchaseLines:[]};
 const handler=createStaticHandler({root,budget:{overlay:base=>base},
  auth:{requireUser(req){
   const role=req.headers['x-test-role'];
   if(!role)throw {status:401};
   return {user:{role:'user',vendorScope:role==='vendor'?'ALT':undefined,mustChangePassword:role==='password'}};
  }},
  ...(snapshot?{snapshotCache:{async get(){aggregateReads++;return {data,updatedAt:'2026-11-16',source:'sql'};}}}:{})
 });
 const server=http.createServer((req,res)=>handler(req,res,new URL(req.url,'http://localhost').pathname));
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const request=(url='/data/raw.json',role='sev',method='GET')=>new Promise((resolve,reject)=>{
  const req=http.request({host:'127.0.0.1',port:server.address().port,path:url,method,headers:role?{'x-test-role':role}:{}},res=>{
   let body='';res.setEncoding('utf8');res.on('data',chunk=>body+=chunk);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,body}));
  });req.on('error',reject);req.end();
 });
 try{await run({request,root,reads:()=>aggregateReads});}
 finally{await new Promise(resolve=>server.close(resolve));fs.rmSync(root,{recursive:true,force:true});}
}

test('authenticated first load works without a physical data/raw.json',()=>fixture(async({request,root,reads})=>{
 assert.equal(fs.existsSync(path.join(root,'data/raw.json')),false);
 const r=await request();assert.equal(r.status,200);
 assert.equal(JSON.parse(r.body).asOf,'2026-11-16');assert.equal(reads(),1);
 assert.equal(r.headers['x-mro-snapshot-source'],'sql');
}));
test('vendor receives scoped bootstrap without reading SEV aggregate',()=>fixture(async({request,reads})=>{
 const r=await request('/data/raw.json','vendor');assert.equal(r.status,200);
 assert.equal(JSON.parse(r.body).stockSource,'vendor-scoped');assert.equal(reads(),0);
}));
test('missing raw.json does not bypass authentication or password gate',()=>fixture(async({request,reads})=>{
 assert.equal((await request('/data/raw.json',null)).status,401);
 assert.equal((await request('/data/raw.json','password')).status,403);assert.equal(reads(),0);
}));
test('ordinary missing/private files still return 404 and HEAD has no body',()=>fixture(async({request})=>{
 assert.equal((await request('/app.mjs')).status,404);
 assert.equal((await request('/backend/core/static-files.cjs')).status,404);
 const r=await request('/data/raw.json','sev','HEAD');assert.equal(r.status,200);assert.equal(r.body,'');
}));
test('legacy dynamic build also works without physical raw.json',()=>fixture(async({request})=>{
 const r=await request();assert.equal(r.status,200);
 const data=JSON.parse(r.body);assert.ok(data.asOf);assert.deepEqual(data.items,[]);
},{snapshot:false}));
