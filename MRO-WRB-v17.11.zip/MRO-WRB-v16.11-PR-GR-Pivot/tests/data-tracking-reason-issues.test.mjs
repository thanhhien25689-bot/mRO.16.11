import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {reportForm,grReportForm}=require('../backend/modules/data-tracking/index.cjs');
const gl=[{GL_Account:'123',GL_Class:'Supplies'}];
const pr=(o)=>({RECEIVER_NAME:'bui.thu2',PR_NO:'PR1',PR_SEQ:'000010',PO_NO:'PO1',PO_SEQ:'000010',ITEM_CODE:'A1',COST_CENTER:'0012',GL_ACCOUNT:'123',PURCHASE_REQ_INFO:'SOP - WATCH - W8 - Line',PR_Month:10,PR_BUYING_AMOUNT:100,BUYING_CURRENCY:'USD',...o});

test('PR Report Form lists each PR line without Type once, with receiver and issue',()=>{
 const r=reportForm([
  pr({}),
  pr({PR_NO:'PR2',ITEM_CODE:'B1',PURCHASE_REQ_INFO:'',RECEIVER_NAME:'an.nguyen'}),
  pr({PR_NO:'PR2',ITEM_CODE:'B1',PURCHASE_REQ_INFO:'',RECEIVER_NAME:'an.nguyen',PR_Month:11}),
  pr({PR_NO:'PR3',ITEM_CODE:'C1',PURCHASE_REQ_INFO:'Mua hàng tháng 2',COST_CENTER:'0020',PR_Month:null})
 ],gl,[]);
 assert.equal(r.audit.missingReasonRows,3);
 assert.deepEqual(r.reasonIssues.map(x=>[x.ITEM_CODE,x.PR_NO,x.PR_SEQ,x.PURCHASE_REQ_INFO,x.RECEIVER,x.Issue,x.COST_CENTERS]),[
  ['B1','PR2','000010','','an.nguyen','Reason trống',['0012']],
  ['C1','PR3','000010','Mua hàng tháng 2','bui.thu2','Reason không đúng mẫu (không đọc được Type)',['0020']]
 ]);
});

test('PR Report Form uses the override reason when it fixes the line',()=>{
 const r=reportForm([pr({PURCHASE_REQ_INFO:''})],gl,[{ITEM_CODE:'A1',PR_NO:'PR1',PR_SEQ:'000010',PURCHASE_REQ_INFO_OVERRIDE:'SETUP - RING - R2 - Line',IS_IGNORED:0}]);
 assert.deepEqual(r.reasonIssues,[]);
});

test('GR Report Form lists matched PR lines without Type; unmatched GR rows are left out',()=>{
 const gr=(o)=>({GR_NO:'G1',GR_DATE:'2026-10-02',PO_NO:'PO1',PO_SEQ:'000010',ITEM_CODE:'A1',GR_QTY:1,GR_AMOUNT:50,CURRENCY:'USD',COST_CENTER_CODE:'0012',...o});
 const r=grReportForm([gr({}),gr({GR_NO:'G2',COST_CENTER_CODE:'0020'}),gr({GR_NO:'G3',PO_NO:'PO9'})],[pr({PURCHASE_REQ_INFO:'xyz'})],gl,[]);
 assert.equal(r.reasonIssues.length,1);
 assert.deepEqual({...r.reasonIssues[0]},{ITEM_CODE:'A1',PR_NO:'PR1',PR_SEQ:'000010',PURCHASE_REQ_INFO:'xyz',RECEIVER:'bui.thu2',Issue:'Reason không đúng mẫu (không đọc được Type)',COST_CENTERS:['0012','0020']});
});

test('Data Tracking opens PR Report Form first and exports the reason sheet; GR SQL reads RECEIVER_NAME',()=>{
 const ui=readFileSync(new URL('../frontend/modules/data-tracking/index.mjs',import.meta.url),'utf8');
 assert.match(ui,/let kind='REPORT',/);
 assert.match(ui,/issues=reasonIssueSheet\(value,main\);exportWorkbook\(\[main,\.\.\.\(issues\?\[issues\]:\[\]\)\]/);
 assert.match(ui,/\['ITEM_CODE','Item code'\],\['PR_NO','PR_No'\],\['PR_SEQ','PR_SEQ'\],\['PURCHASE_REQ_INFO','Purchase_Req_Infor'\],\['RECEIVER','Receiver'\]/);
 const worker=readFileSync(new URL('../backend/modules/sql/worker.ps1',import.meta.url),'utf8');
 assert.match(worker,/SELECT \[PR_NO\],\[PR_SEQ\],\[PO_NO\],\[PO_SEQ\],\[ITEM_CODE\],\[GL_ACCOUNT\],\[PURCHASE_REQ_INFO\],\[RECEIVER_NAME\] FROM ' \+ \$prTable/);
 const snapshot=readFileSync(new URL('../backend/modules/data-tracking/index-snapshot.cjs',import.meta.url),'utf8');
 assert.match(snapshot,/reportKind\(kind\)&&!Array\.isArray\(value\?\.reasonIssues\)/);
});
