import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {render} from '../frontend/modules/projects/view.mjs';
import {recentProjects,projectFocus} from '../frontend/modules/projects/selectors.mjs';
const rows=Array.from({length:65},(_,i)=>({projectId:'p'+i,project:i===64?'Dự án cuối':'Project '+String(i).padStart(2,'0'),description:'SOP - WATCH - Test',type:'SOP',model:'Watch8',process:'Line',classification:'complete',itemCode:'C'+i,prNo:'PR'+i,prSeq:'10',poNo:'',poSeq:'',prDate:'2026-11-'+String(i%16+1).padStart(2,'0'),source:'pr',status:'Đã cập nhật PR',amountUsd:100,rowId:'r'+i,prQty:10}));
const state=project=>({project,statuses:[],pivot:[],dateFrom:'',dateTo:'',codeSearch:''});
function rootFixture(){const elements=new Map();const el=()=>({value:'',innerHTML:'',hidden:false,scrollTop:0,attrs:{},setAttribute(k,v){this.attrs[k]=v;},removeAttribute(k){delete this.attrs[k];},addEventListener(){},querySelector(){return null;},querySelectorAll(){return [];},focus(){},setCustomValidity(){},reportValidity(){return true;}});return {innerHTML:'',querySelector(selector){if(!elements.has(selector))elements.set(selector,el());return elements.get(selector);},querySelectorAll(){return [];}};}
const actions={project(){},reset(){},reload(){},dates(){},year(){},expanded:new Set()};
test('project list is visible at top beside progress, followed by four selected-project KPIs',()=>{
 for(const selected of [null,'p0']){const root=rootFixture();render(root,{projectRows:rows,projectYear:2026},state(selected),actions);
 assert.ok(root.innerHTML.startsWith('<div class="project-selection-grid">'));
 assert.match(root.innerHTML,/<h2>Dự án<\/h2>/);assert.match(root.innerHTML,/<h2>Tiến độ mua hàng<\/h2>/);
 assert.match(root.innerHTML,/aria-expanded="true" aria-controls="project-options"/);assert.doesNotMatch(root.innerHTML,/data-project-options hidden/);
 assert.equal((root.innerHTML.match(/<article class="kpi">/g)||[]).length,selected?4:0);
 if(selected)assert.ok(root.innerHTML.indexOf('projects-progress')<root.innerHTML.indexOf('project-focus-head'));
 assert.equal((root.querySelector('[data-project-options]').innerHTML.match(/data-project-option=/g)||[]).length,65);}
});
test('recent-project sorting uses latest PR/Order dates without changing source or KPI amounts',()=>{
 const f=projectFocus(rows,state('p0')),before=JSON.stringify(f.projects),list=recentProjects(f.projects);
 assert.equal(list[0].latestDate,'2026-11-16');assert.equal(list.at(-1).latestDate,'2026-11-01');assert.equal(JSON.stringify(f.projects),before);
 assert.equal(projectFocus(rows,state('p0')).amount.pr.total,100);
 const all=recentProjects([{id:'a',name:'Old',rows:[{prDate:'2026-10-01'},{prDate:'2026-11-16',source:'order'}]},{id:'b',name:'New',rows:[{prDate:'2026-11-15'}]}]);assert.equal(all[0].id,'a');
});
test('all projects remain searchable; click/Enter select; Escape clears search and keeps list visible',()=>{
 const root=rootFixture(),picked=[];render(root,{projectRows:rows,projectYear:2026},state(null),{...actions,project:id=>picked.push(id)});
 const input=root.querySelector('[data-project-search]'),list=root.querySelector('[data-project-options]');
 input.value='du an cuoi';input.oninput();assert.match(list.innerHTML,/data-project-option="p64"/);
 input.onkeydown({key:'Enter',preventDefault(){}});assert.deepEqual(picked,['p64']);
 list.onclick({target:{closest:()=>({dataset:{projectOption:'p0'}})}});assert.deepEqual(picked,['p64','p0']);
 input.onkeydown({key:'Escape'});assert.equal(input.value,'');assert.equal((list.innerHTML.match(/data-project-option=/g)||[]).length,65);assert.equal(list.hidden,false);
});
test('layout CSS defines 70/30, twelve-row scroll area, responsive stacking and preserved scroll position',()=>{
 const css=readFileSync(new URL('../assets/readability.css',import.meta.url),'utf8');
 assert.match(css,/\.project-selection-grid\{display:grid;grid-template-columns:minmax\(0,7fr\) minmax\(0,3fr\)/);
 assert.match(css,/\.project-selection-panel \.project-options\{[^}]*height:320px;overflow:auto/);
 assert.match(css,/\.project-selection-panel \.project-options li\{height:40px;min-height:40px/);
 assert.match(css,/@media\(max-width:900px\)\{\.project-selection-grid\{grid-template-columns:minmax\(0,1fr\)/);
 const controller=readFileSync(new URL('../frontend/modules/projects/index.mjs',import.meta.url),'utf8');assert.equal(controller.split("querySelectorAll('.table-scroll, .project-options')").length-1,2);
});
