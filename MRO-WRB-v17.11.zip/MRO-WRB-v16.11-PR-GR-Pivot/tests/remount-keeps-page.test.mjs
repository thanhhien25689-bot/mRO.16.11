import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const read=path=>readFileSync(new URL('../'+path,import.meta.url),'utf8');

test('registry stamps every mount with a generation and keeps the frame height while a screen is rebuilt',()=>{
 const registry=read('frontend/core/module-registry.mjs');
 assert.match(registry,/el\.dataset\.mountGen=String\(\+\+mountGeneration\);const controller=r\.module\.mount\(el,store\.data,mountOpts\);/);
 assert.match(registry,/frame\.style\.minHeight=height\+'px'/);
});
test('shared table restores page/filters only after a remount (different generation)',()=>{
 const table=read('frontend/shared/ui/table.mjs');
 assert.match(table,/function draw\(\)\{remember\(\);/);
 assert.match(table,/if\(prior&&prior\.gen!==memo\.gen\)\{const old=prior\.state;page=Math\.max\(1,Number\(old\.page\)\|\|1\);/);
});
test('Data Tracking and Repair & Service keep tab and page across remounts',()=>{
 const dt=read('frontend/modules/data-tracking/index.mjs');
 assert.match(dt,/const remembered=\{state:null\};\nexport function mount/);
 assert.match(dt,/if\(memory\)\{kind=memory\.kind;pageSize=memory\.pageSize;applied=memory\.applied;/);
 assert.match(dt,/if\(restorePage&&value\)\{page=restorePage;if\(!busy\)restorePage=0;\}page=Math\.min\(page,pages\);/);
 assert.match(dt,/data-dt-prev\]'\)\.onclick=\(\)=>\{restorePage=0;page--;draw\(\);\}/);
 const aps=read('frontend/modules/aps/index.mjs');
 assert.match(aps,/if\(apsMemory\)\{for\(const key of MEMORY_KEYS\)state\[key\]=apsMemory\[key\];/);
 assert.match(aps,/apsMemory=\{\.\.\.Object\.fromEntries\(MEMORY_KEYS\.map\(key=>\[key,state\[key\]\]\)\),expanded:\[\.\.\.state\.expanded\]\};/);
});
test('Repair & Service export: two sheets with original SQL column names, payment rows included',()=>{
 const {exportSheets}=require('../backend/modules/aps/index.cjs');
 const base={No:'1',RequestId:'RQ1',RequestDate:'2026-10-01',Vendor:'ALT',CostCenter:'0012',Model:'W8',Pic:'hien',PaymentStatus:'Pending',MonthPayment:'11',YearPayment:'2026',Qty:'2',EstimatedCost:'1,200.5',Amount:'',AmountUSD:'',Remark:''};
 const repair={...base,Src:'R',BQMSCode:'B1',JigName:'Jig A',WRB:'Y',Cur:'VND'};
 const pay={...base,Src:'R',No:'3',Remark:'TT tháng 10',Amount:'300'};
 const service={...base,Src:'S',No:'5',RequestId:'SV1',ServiceType:'Calib',BeforeApproval:'Yes',Cur:'USD'};
 const out=exportSheets({rows:[service,pay,repair]},'2026-11-16');
 assert.deepEqual(out.sheets.map(s=>[s.name,s.rows.length]),[['Repair',2],['Service',1]]);
 const [r1,r3]=out.sheets[0].rows;
 assert.equal(r1['Request ID'],'RQ1');assert.equal(r1['Jig /Eqm Name'],'Jig A');assert.equal(r1['Estimated cost'],1200.5);assert.equal(r1['Loại dòng (Portal)'],'Jig');assert.equal(r1['Bước Jig (Portal)'],'Pur chưa accept');
 assert.equal(r3['Loại dòng (Portal)'],'Thanh toán (TT)');assert.equal(r3.Amount,300);
 assert.ok(out.sheets[0].columns.includes('BQMS code')&&out.sheets[1].columns.includes('ContractNo'));
 assert.equal(out.sheets[1].rows[0].Type,'Calib');
});
test('Repair & Service export route denies viewers and vendor accounts',async()=>{
 const {createAps}=require('../backend/modules/aps/index.cjs');
 const aps=createAps({dbPath:':memory:',sql:{readApsRows:async()=>({rows:[]})}});
 const url=new URL('http://x/api/aps-export');let sent=null;const send=(res,status,value)=>{sent={status,value};};
 await assert.rejects(aps.handle({req:{method:'GET'},res:{},url,actor:{role:'viewer'},send}),/Viewer/);
 await assert.rejects(aps.handle({req:{method:'GET'},res:{},url,actor:{role:'user',vendorScope:'ALT'},send}),/Vendor/);
 assert.equal(await aps.handle({req:{method:'GET'},res:{},url,actor:{role:'user'},send}),true);
 assert.equal(sent.status,200);assert.deepEqual(sent.value.sheets.map(s=>s.name),['Repair','Service']);
});
