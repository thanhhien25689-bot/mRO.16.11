import {esc} from '../utils/format.mjs';
export function showDetail(title,html){document.getElementById('detail-title').textContent=title;document.getElementById('detail-body').innerHTML=html;document.getElementById('detail').showModal();}
export function detailFields(obj){return `<dl class="detail-fields">${Object.entries(obj).map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>`;}
