let timer;export function toast(text){const el=document.getElementById('toast');el.textContent=text;el.hidden=false;clearTimeout(timer);timer=setTimeout(()=>el.hidden=true,3500);}
