// Public UI thuần; không export badge/link nghiệp vụ của facade legacy.
export {esc,fmt,date} from '../utils/format.mjs';
export {exportCSV,exportWorkbook} from '../utils/csv.mjs';
export {kpi,panel} from './primitives.mjs';
export {metricBar,donut} from './charts.mjs';
export {showDetail,detailFields} from './dialog.mjs';
export {toast} from './toast.mjs';
export {tableController} from './table.mjs';
