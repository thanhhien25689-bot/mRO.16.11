/**
 * Shared holder selection store for SET/PBA screens.
 * Persists via sessionStorage; notifies subscribers via custom DOM event.
 * Safe to import in Node.js (all document/sessionStorage calls are guarded).
 */
export const SP_HOLDERS = ['SEV', 'ALT', 'ALV', 'BUJEON', 'CHITWING'];

// Map vendor display names (stored in auth accounts) → canonical SET/PBA holder codes.
const _VENDOR_TO_HOLDER = {
  'Almus Tech': 'ALT', 'Almustech': 'ALT', 'ALT': 'ALT',
  'Almus Vina': 'ALV', 'Almusvina': 'ALV', 'ALV': 'ALV',
  'Bujeon':     'BUJEON', 'BUJEON': 'BUJEON',
  'Chitwing':   'CHITWING', 'CHITWING': 'CHITWING',
  'SEV':        'SEV',
};

/**
 * Resolve actor.vendorScope (display name) → canonical SET/PBA holder code.
 * Returns '' if the scope is falsy or unrecognised (SEV non-vendor path).
 */
export function resolveVendorHolder(vendorScope) {
  if (!vendorScope) return '';
  return _VENDOR_TO_HOLDER[vendorScope] || _VENDOR_TO_HOLDER[vendorScope.trim()] || '';
}
const SK = 'mro-sp-holder';

export function getHolder() {
  try { return sessionStorage.getItem(SK) || ''; } catch { return ''; }
}

export function setHolder(h) {
  const v = SP_HOLDERS.includes(h) ? h : '';
  try { sessionStorage.setItem(SK, v); } catch {}
  if (typeof document !== 'undefined')
    document.dispatchEvent(new CustomEvent('sp-holder-change', { detail: v }));
}

export function onHolderChange(fn) {
  if (typeof document === 'undefined') return;
  document.addEventListener('sp-holder-change', e => fn(e.detail));
}

/**
 * Renders (or syncs) the global holder <select> into a slot element in the topbar.
 * Idempotent — safe to call from multiple modules; second call is a no-op.
 * @param {string} slotId  — id of the host element (e.g. 'sp-holder-slot')
 * @param {{ isVendor?: boolean, vendorCode?: string }} opts
 */
export function mountHolderSelect(slotId, { isVendor = false, vendorCode = '' } = {}) {
  if (typeof document === 'undefined') return;
  const slot = document.getElementById(slotId);
  if (!slot) return;
  slot.hidden = false;
  if (slot.querySelector('#sp-global-holder')) return; // already mounted
  slot.innerHTML = `<label class="sp-holder-label small muted" style="display:flex;align-items:center;gap:4px;font-size:12px">
    Holder:<select id="sp-global-holder" class="sp-holder-select" style="font-size:12px;min-width:90px">
      <option value="">Tất cả</option>
      ${SP_HOLDERS.map(h => `<option value="${h}">${h}</option>`).join('')}
    </select></label>`;
  const sel = slot.querySelector('#sp-global-holder');
  if (isVendor) {
    sel.value = vendorCode;
    sel.disabled = true;
    sel.title = `Vendor: ${vendorCode}`;
  } else {
    sel.value = getHolder();
  }
  sel.addEventListener('change', () => setHolder(sel.value));
}
