export const esc=s=>String(s??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const fmt=(n,d=0)=>Number(n).toLocaleString('vi-VN',{maximumFractionDigits:d});
export const date=s=>s?s.split('-').reverse().join('/'):'—';
