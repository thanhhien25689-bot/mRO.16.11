import {routes} from './module-registry.mjs';

export function showRoute(){const key=location.hash.slice(1)||document.querySelector('meta[name=mro-start]')?.content;const active=routes[key]?key:'overview';const r=routes[active];document.getElementById('crumb').textContent=r.label;document.getElementById('page-title').textContent=r.title;document.getElementById('eyebrow').textContent=r.eyebrow;document.getElementById('page-description').textContent=r.description;document.querySelectorAll('[data-view]').forEach(v=>v.hidden=v.dataset.view!==active);document.querySelectorAll('[data-route]').forEach(a=>{const selected=a.dataset.route===active;a.classList.toggle('active',selected);if(selected)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});window.__mroNavigation?.activate(active);const main=document.getElementById('main');main.classList.toggle('overview-main',active==='overview');main.scrollTop=0;}

export function bindRouter(setTab){
window.addEventListener('hashchange',showRoute);document.addEventListener('click',e=>{const link=e.target.closest('[data-go]');if(!link)return;location.hash=link.dataset.go;showRoute();if(link.dataset.filter)setTab(link.dataset.go,link.dataset.filter);});
}
