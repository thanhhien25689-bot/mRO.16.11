import {createStore} from '../../shared/store.mjs';
import {toast} from '../../shared/ui.mjs';

// Giữ cache/validation trong shared/store; core chỉ điều phối load và loader.
export function createApplicationData(views,mountAll){
const store=createStore();let busy=false,hasRevealed=false,warnedStorage=false;
const metric=(type,fields={})=>{if(globalThis.__mroTestMode!==true||typeof globalThis.__mroCacheMetric!=='function')return;try{globalThis.__mroCacheMetric({type,...fields});}catch{}};
// Nhãn thời điểm snapshot được lưu, để người dùng biết dữ liệu đang xem cũ tới lúc nào.
const storedLabel=()=>store.savedAt?new Date(store.savedAt).toLocaleString('vi-VN',{hour:'2-digit',minute:'2-digit',day:'2-digit',month:'2-digit'}):'phiên trước';
const lifecycle=(name,detail={})=>document.dispatchEvent(new CustomEvent(name,{detail}));
function reveal(){const origin=window.__mroRevealOrigin||{x:0,y:0};window.playCircleReveal?.(origin.x,origin.y);window.__mroRevealOrigin=null;}
async function load(force=false){
 if(busy){metric('snapshot-refresh-deduped');return;}
 const startedAt=Date.now();metric('snapshot-refresh-start',{force:!!force});
 // Cache đã được nạp theo tài khoản ngay sau khi đăng nhập (auth-gate gọi store.hydrate): dựng shell ngay, không chờ SQL/OH.
 // Request nền bắt buộc force để cache không che mất dữ liệu SQL mới nhất.
 const cachedFirst=!force&&store.data&&!hasRevealed;
 lifecycle('mro-workspace-loading',{force:!!force,cached:!!cachedFirst});
 if(cachedFirst){
  await mountAll({background:true});
  hasRevealed=true;
  document.getElementById('updated').textContent='Đang hiển thị dữ liệu lưu lúc '+storedLabel()+' · đang cập nhật SQL…';
  lifecycle('mro-workspace-ready',{cached:true});
 }
 busy=true;
 // 12/11/2026: người dùng chủ động bấm "Cập nhật" thì mọi màn phải gọi SQL thật, không lấy bản lưu.
 if(force)globalThis.__mroForceSnapshotRefresh=true;
 const overlay=document.getElementById('loading'),shell=document.getElementById('shell'),refresh=document.getElementById('refresh');
 const counter=overlay.querySelector('.loader-time'),progress=overlay.querySelector('.loader-progress'),started=performance.now();
 const count=()=>{counter.textContent=((performance.now()-started)/1000).toFixed(1);};
 counter.textContent='0.0';
 if(progress)progress.textContent='0';
 const ticker=setInterval(count,100);
 overlay.querySelector('p').textContent=force?'Đang tải lại dữ liệu…':'Đang khởi tạo không gian làm việc...';
 const background=cachedFirst;
 overlay.classList.toggle('loading-overlay--thin',background);
 if(!background){overlay.hidden=false;shell.inert=true;shell.setAttribute('aria-busy','true');}
 else {overlay.hidden=false;}
 refresh.disabled=true;
 let completed=false;
 try{
  await store.load({force:force||background,onProgress:value=>{const pct=Math.round(value);if(progress)progress.textContent=String(pct);overlay.style.setProperty('--load-progress',String(pct));lifecycle('mro-workspace-progress',{value:pct});}});
  await mountAll();
  await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  document.getElementById('updated').textContent='Đã cập nhật SQL lúc '+new Date().toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'});
  completed=true;metric('snapshot-refresh-success',{force:!!force,durationMs:Date.now()-startedAt,cached:!!cachedFirst});
  if(store.storageError&&!warnedStorage){warnedStorage=true;toast('Không lưu được snapshot vào trình duyệt ('+store.storageError+'). Lần mở sau sẽ phải chờ tải lại dữ liệu.');}
  if(force)toast('Đã tải lại dữ liệu cho tất cả màn hình.');
 }catch(error){metric('snapshot-refresh-error',{force:!!force,durationMs:Date.now()-startedAt,status:Number(error?.status)||0});
  toast(error.message);
  if(!store.data){views.innerHTML='<section class="panel error-state"><h2>Không thể tải dữ liệu</h2><p>Kiểm tra máy chủ và file data/raw.json, rồi nhấn nút thử lại.</p><button class="button primary" id="retry">Thử lại</button></section>';document.getElementById('retry').onclick=()=>load(true);}
  else {document.getElementById('updated').textContent='Đang dùng dữ liệu gần nhất · SQL chưa cập nhật';toast('Tải lại thất bại. Dữ liệu đang xem được giữ nguyên.');}
 }finally{
  clearInterval(ticker);count();if(force)globalThis.__mroForceSnapshotRefresh=false;if(!background){overlay.hidden=true;shell.inert=false;shell.removeAttribute('aria-busy');}else overlay.hidden=true;refresh.disabled=false;busy=false;
  if(!cachedFirst)lifecycle('mro-workspace-ready',{cached:false,completed});
  if(completed){if(!hasRevealed)hasRevealed=true;if(force)reveal();}
 }
}
// return releaseReveal để auth-gate mở khoá "dựng từ cache" cho phiên đăng nhập kế tiếp trong cùng tab.
return {store,load,releaseReveal(){hasRevealed=false;}};
}
