import {startAuthGate} from './auth-gate.mjs';
import {routes,navigationGroups,createModuleRegistry} from './module-registry.mjs';
import {showRoute,bindRouter} from './router.mjs';
import {createApplicationData} from './data-store.mjs';
import {icon} from '../../shared/icons.mjs';

export function bootstrap(){
const views=document.getElementById('views');
const sidebarToggle=document.getElementById('sidebar-toggle'),shell=document.getElementById('shell');
const ENTRY_REVEAL_MS=460;
let entryLayer=null,entryTimer=0,entryPlaying=false,motionFrame=0;
let motionSeen=new WeakSet(),countSeen=new WeakSet(),populatedViews=new WeakSet();
// Entrance runs once per sign-in; later passes are light tab transitions or no motion on re-render.
let entranceArmed=false,lastActiveView=null,entranceUntil=0;
window.playCircleReveal=(x=0,y=0)=>{if(entryLayer||window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;const layer=document.createElement('div');layer.className='circle-reveal-layer';layer.style.setProperty('--reveal-x',`${x}px`);layer.style.setProperty('--reveal-y',`${y}px`);document.body.append(layer);requestAnimationFrame(()=>layer.classList.add('is-active'));setTimeout(()=>layer.remove(),950);};
function clearEntry(){
 clearTimeout(entryTimer);
 entryLayer?.remove();entryLayer=null;entryPlaying=false;
 document.body.classList.remove('mro-entry-active','mro-entry-revealing');
}
function playEntry(){
 clearEntry();motionSeen=new WeakSet();countSeen=new WeakSet();populatedViews=new WeakSet();lastActiveView=null;entranceArmed=false;
 if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){scheduleMotion();return;}
 const layer=document.createElement('div');entryLayer=layer;
 layer.className='portal-entry';layer.setAttribute('role','status');layer.setAttribute('aria-live','polite');
 layer.innerHTML=`<div class="portal-entry-waves" aria-hidden="true"></div>
  <div class="portal-entry-core">
   <div class="portal-entry-mark" aria-hidden="true">
    <svg class="portal-entry-ring" viewBox="0 0 240 240"><defs><linearGradient id="entry-ring-gradient" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#53ddff" stop-opacity="0"/><stop offset=".48" stop-color="#53ddff"/><stop offset="1" stop-color="#8c7cff" stop-opacity="0"/></linearGradient></defs><circle class="portal-entry-ring-track" cx="120" cy="120" r="103"/><circle class="portal-entry-ring-light" cx="120" cy="120" r="103"/></svg>
    <span class="portal-entry-glow"></span><span class="portal-entry-logo">W</span>
   </div>
   <div class="portal-entry-brand"><strong>Wearable Group</strong><span>WORKSPACE / MRO</span></div>
   <div class="portal-entry-status"><p>Đang khởi tạo không gian làm việc...</p><div class="portal-entry-progress" role="progressbar" aria-label="Tiến trình khởi tạo"><i></i></div></div>
  </div><div class="portal-entry-flare" aria-hidden="true"></div>`;
 document.body.append(layer);
 document.body.classList.add('mro-entry-active');
}
function entryProgress(event){
 if(!entryLayer||entryPlaying)return;const value=Number(event.detail?.value);if(!Number.isFinite(value))return;
 const safe=Math.max(0,Math.min(100,value)),bar=entryLayer.querySelector('.portal-entry-progress');
 entryLayer.style.setProperty('--entry-progress',String(safe));entryLayer.classList.add('portal-entry--determinate');bar?.setAttribute('aria-valuenow',String(Math.round(safe)));
}
function finishEntry(){
 const layer=entryLayer;if(!layer||entryPlaying)return;entryPlaying=true;
 document.body.classList.add('mro-entry-revealing');layer.classList.add('portal-entry--leaving');
 // Choreography starts under the fading splash (fill:backwards), so nothing pops in after it lifts.
 entranceArmed=true;motionPass();
 entryTimer=setTimeout(()=>{if(entryLayer===layer)clearEntry();scheduleMotion();},ENTRY_REVEAL_MS+60);
}
document.addEventListener('auth-ready',playEntry);
document.addEventListener('mro-workspace-progress',entryProgress);
document.addEventListener('mro-workspace-ready',finishEntry);
document.addEventListener('signed-out',clearEntry);
// --- Entrance choreography (presentation only) ---------------------------------------------
// Web Animations on transform/opacity with fill:'backwards': no layout shift, no lingering
// transform on text, no DOM/class changes inside modules. Native chart CSS animations
// (bars/donut/metric) are re-timed in place, never replaced or remounted.
const EASE='cubic-bezier(0.22, 1, 0.36, 1)';
const KPI_SELECTOR='.kpi,.kpi-card,.aps-kpi-card,.ov-finance-stat';
const CHART_ANIMATIONS=new Set(['overview-bar-grow','donut-grow','metric-grow']);
const visible=node=>!!node&&!node.closest('[hidden]')&&node.getClientRects().length>0;
const qa=(root,selector)=>root?[...root.querySelectorAll(selector)].filter(visible):[];
function rise(node,delay,{x=0,y=0,scale=1,duration=400}={}){
 if(!node?.animate)return null;
 const move=x||y?`translate3d(${x}px,${y}px,0)`:'';const from={opacity:0};
 if(move||scale!==1)from.transform=`${move}${scale!==1?` scale(${scale})`:''}`.trim()||'none';
 return node.animate([from,{opacity:1,transform:'none'}],{duration,delay:Math.round(delay),easing:EASE,fill:'backwards'});
}
// Visual reading order: rows top→bottom (24px bands), then left→right.
function visualOrder(nodes){
 return nodes.map(node=>({node,box:node.getBoundingClientRect()})).sort((a,b)=>Math.round(a.box.top/24)-Math.round(b.box.top/24)||a.box.left-b.box.left).map(entry=>entry.node);
}
function outermost(nodes){return nodes.filter(node=>!nodes.some(other=>other!==node&&other.contains(node)));}
function retime(animation,delay,duration,easing=EASE){
 animation.effect.updateTiming({delay:Math.round(delay),duration:Math.round(duration),easing,fill:'both'});
 animation.currentTime=0;animation.play();
}
function chartEntrance(active,start){
 const charts=new Map();
 for(const animation of active.getAnimations({subtree:true})){
  if(!CHART_ANIMATIONS.has(animation.animationName))continue;
  const target=animation.effect?.target;if(!target)continue;
  const chart=target.closest('.ov-chart,.donut,.panel,section,article')||active;
  if(!charts.has(chart))charts.set(chart,[]);charts.get(chart).push({animation,target});
 }
 visualOrder([...charts.keys()]).forEach((chart,rank)=>{
  const base=start+Math.min(rank,6)*110,list=charts.get(chart);
  // Donut: sweep slices sequentially around the ring, each lasting in proportion to its share.
  const slices=list.filter(item=>item.animation.animationName==='donut-grow');
  const SWEEP=720;let elapsed=0;
  slices.forEach((item,index)=>{
   const length=parseFloat(item.target.style.getPropertyValue('--slice-length'))||0;
   const share=Math.max(0,Math.min(1,length/(Math.PI*96)));
   const last=index===slices.length-1,duration=Math.max(60,share*SWEEP);
   retime(item.animation,base+elapsed,duration,last?EASE:'linear');elapsed+=share*SWEEP;
  });
  list.filter(item=>item.animation.animationName==='metric-grow').forEach((item,index)=>retime(item.animation,base+Math.min(index,10)*55,560));
 });
 // Bars: rise from the baseline month by month, left→right. The bar height is pinned with !important
 // (so the legacy height keyframe cannot paint); a bottom-anchored clip reveal grows the bar without
 // touching layout or squashing the value label above it.
 visualOrder(qa(active,'.ov-chart').filter(chart=>chart.querySelector('.ov-bar-grow'))).forEach((chart,rank)=>{
  const base=start+Math.min(rank,4)*120;
  qa(chart,'.ov-month').forEach((month,index)=>qa(month,'.ov-bar-grow').forEach((bar,inner)=>bar.animate([{clipPath:'inset(100% -40px 0 -40px)'},{clipPath:'inset(-28px -40px 0 -40px)'}],{duration:620,delay:base+Math.min(index,14)*40+inner*30,easing:EASE,fill:'backwards'})));
 });
 // Line charts: left→right wipe (keeps dashed strokes intact); points appear as the line reaches them,
 // and hover tooltips activate only once the line is fully drawn.
 qa(active,'.ov-line svg').forEach((svg,rank)=>{
  const base=start+120+Math.min(rank,3)*120,DRAW=900;
  for(const shape of svg.querySelectorAll('.ov-line-area,.ov-line-target,.ov-line-result'))shape.animate([{clipPath:'inset(-10% 100% -10% 0)'},{clipPath:'inset(-10% 0% -10% 0)'}],{duration:DRAW,delay:base,easing:'cubic-bezier(0.45, 0, 0.25, 1)',fill:'backwards'});
  const width=svg.viewBox?.baseVal?.width||1;
  for(const point of svg.querySelectorAll('.ov-line-dot,.ov-line-diamond')){
   let x=0;try{const box=point.getBBox();x=(box.x+box.width/2)/width;}catch{}
   point.animate([{opacity:0},{opacity:1}],{duration:220,delay:Math.round(base+Math.max(0,Math.min(1,x))*DRAW),easing:'ease-out',fill:'backwards'});
  }
  const previous=svg.style.pointerEvents;svg.style.pointerEvents='none';
  setTimeout(()=>{if(svg.style.pointerEvents==='none')svg.style.pointerEvents=previous;},base+DRAW);
 });
}
function entrance(active){
 entranceUntil=performance.now()+1600;
 const sidebar=document.querySelector('.sidebar'),topbar=document.querySelector('.topbar'),heading=document.querySelector('.page-heading');
 // Phase 2 — sidebar: brand, then navigation top→bottom sliding left→right (50ms stagger).
 rise(sidebar?.querySelector('.brand'),0,{x:-10,duration:420});
 rise(sidebar?.querySelector(':scope>.nav-caption'),40,{x:-10,duration:360});
 const nav=qa(document.getElementById('navigation'),':scope>.nav-direct-link,:scope>.nav-group>.nav-group-toggle,:scope>.nav-group>.nav-group-links>a');
 nav.forEach((link,index)=>rise(link,70+Math.min(index,14)*50,{x:-12,duration:380}));
 rise(sidebar?.querySelector('.sidebar-bottom'),Math.min(70+nav.length*50,650),{y:8,duration:380});
 // Header: crumb from the left with a slight drop, then controls fade in one after another.
 rise(topbar?.querySelector('#sidebar-toggle'),0,{duration:300});
 rise(topbar?.querySelector('.breadcrumb'),30,{x:-14,y:-4,duration:420});
 qa(topbar,'.top-actions>*').forEach((control,index)=>rise(control,90+Math.min(index,8)*45,{y:-6,duration:340}));
 // Phase 4 — page title block, then any workspace tab strip.
 [heading?.querySelector('.eyebrow'),heading?.querySelector('h1'),heading?.querySelector('p'),heading?.querySelector('.page-meta')].filter(visible).forEach((node,index)=>rise(node,110+index*50,{x:-12,duration:420}));
 qa(document.getElementById('main'),':scope>.workspace-tabs').forEach(strip=>rise(strip,200,{y:6,duration:360}));
 // Phase 3 — KPI cards in reading order: up 16px, 0.98→1, 75ms apart from 150ms.
 const kpis=visualOrder(outermost(qa(active,KPI_SELECTOR)));
 kpis.forEach((card,index)=>rise(card,150+Math.min(index,6)*75,{y:16,scale:.98,duration:420}));
 // Panels without KPI cards rise as blocks; panels that hold KPIs stay put so cards keep their own stagger.
 const blocks=visualOrder(outermost(qa(active,'.panel,.ov-duo-card')).filter(block=>!block.querySelector(KPI_SELECTOR)));
 blocks.forEach((block,index)=>rise(block,220+Math.min(index,6)*70,{y:14,duration:460}));
 // Phase 4 — section/chart titles: short left→right slide, ordered by position.
 const titles=visualOrder(qa(active,'h2,h3,.panel-head .eyebrow,.ov-chart-heading>strong').filter(node=>!node.closest(KPI_SELECTOR)));
 titles.forEach((title,index)=>rise(title,260+Math.min(index,8)*40,{x:-10,duration:380}));
 // Phase 5 — charts (350ms+) and tables (450ms+; header first, then a bounded set of rows).
 chartEntrance(active,350);
 let rows=0;
 qa(active,'table').slice(0,3).forEach((table,index)=>{
  const start=450+index*90;
  rise(table.tHead,start,{duration:320});
  for(const row of table.tBodies[0]?.rows||[]){
   if(rows>=24||row.getBoundingClientRect().top>innerHeight)break;
   rise(row,start+80+Math.min(rows++,12)*28,{y:6,duration:340});
  }
 });
}
function lightTransition(nodes){
 nodes.slice(0,6).forEach((node,index)=>rise(node,index*35,{y:8,duration:260}));
}
function settleCharts(nodes){
 for(const node of nodes)for(const animation of node.getAnimations?.({subtree:true})||[])if(CHART_ANIMATIONS.has(animation.animationName))animation.finish();
}
function motionPass(){
 motionFrame=0;
 const active=views.querySelector('[data-view]:not([hidden])');
 if(!active||shell.hidden)return;
 // Wait while the splash is still covering; once it starts leaving the entrance may run.
 if(entryLayer&&!entryPlaying)return;
 if(entryLayer&&!entranceArmed)return;
 const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const isEntrance=entranceArmed;entranceArmed=false;
 const switched=active!==lastActiveView;lastActiveView=active;
 const firstContent=!populatedViews.has(active);
 const chrome=[document.querySelector('.sidebar'),document.querySelector('.topbar'),document.querySelector('.page-heading')].filter(Boolean);
 const fresh=[...active.children].filter(node=>!motionSeen.has(node));
 [...chrome,...fresh].forEach(node=>motionSeen.add(node));
 if(active.children.length)populatedViews.add(active);
 const animateCounts=isEntrance||switched||firstContent;
 if(!reduced){
  if(isEntrance)entrance(active);
  else if(switched||firstContent)lightTransition(fresh);
  // Same view re-rendered (data refresh, edits): show final values, do not replay the dashboard.
  else if(performance.now()>entranceUntil)settleCharts([active]);
 }
 if(!animateCounts)return;
 active.querySelectorAll('[data-count]').forEach(el=>{
  if(countSeen.has(el))return;countSeen.add(el);
  const target=Number(el.dataset.count),original=el.textContent;
  if(reduced||!Number.isFinite(target)||el.children.length)return;
  const start=performance.now(),from=Number(el.dataset.from||0);let last=original;
  const tick=now=>{
   if(!el.isConnected||el.textContent!==last)return;
   const p=Math.min(1,(now-start)/900),e=1-Math.pow(1-p,3);
   last=p===1||active.hidden?original:Math.round(from+(target-from)*e).toLocaleString('vi-VN');
   if(el.textContent!==last)el.textContent=last;
   if(p<1&&!active.hidden)requestAnimationFrame(tick);
  };requestAnimationFrame(tick);
 });
}
function scheduleMotion(){if(!motionFrame)motionFrame=requestAnimationFrame(motionPass);}
function setSidebar(collapsed){shell.classList.toggle('sidebar-collapsed',collapsed);sidebarToggle.setAttribute('aria-expanded',String(!collapsed));sidebarToggle.title=collapsed?'Mở rộng sidebar':'Thu gọn sidebar';sidebarToggle.setAttribute('aria-label',sidebarToggle.title);}
const narrowSidebar = window.matchMedia('(max-width: 900px)');
let sidebarPreference = null;
try { sidebarPreference = localStorage.getItem('mro-sidebar-collapsed'); } catch {}
setSidebar(sidebarPreference === null ? narrowSidebar.matches : sidebarPreference === 'true');
narrowSidebar.addEventListener('change', ({matches}) => {
  if (sidebarPreference === null) setSidebar(matches);
});
sidebarToggle.onclick = () => {
  const collapsed = !shell.classList.contains('sidebar-collapsed');
  setSidebar(collapsed);
  sidebarPreference = String(collapsed);
  try { localStorage.setItem('mro-sidebar-collapsed', sidebarPreference); } catch {}
};
const {store,load,releaseReveal}=createApplicationData(views,options=>registry.mountAll(options));
const registry=createModuleRegistry(views,store,showRoute);
const routeGroup=new Map(navigationGroups.flatMap(group=>group.routes.map(route=>[route,group.id])));
// Phase 5A: workspace tabs for all multi-route groups (not just procurement).
const groupTabStrips=new Map();
for(const group of navigationGroups){
  if(group.routes.length<2)continue;
  const strip=document.createElement('nav');
  strip.className='workspace-tabs';strip.dataset.workspaceTabs=group.id;
  strip.setAttribute('aria-label',group.label+' tabs');strip.hidden=true;
  strip.innerHTML=group.routes.map(route=>`<a href="#${route}" data-workspace-tab="${route}">${routes[route].label}</a>`).join('');
  document.getElementById('main').insertBefore(strip,views);
  groupTabStrips.set(group.id,strip);
}
// Legacy caption vocabulary retained for static/compatibility checks: QUY TRÌNH SERVICE · TỒN KHO · QUY TRÌNH MUA HÀNG.
const legacyCaptions='<div class="nav-caption legacy-nav-caption" aria-hidden="true">QUY TRÌNH SERVICE</div><div class="nav-caption legacy-nav-caption" aria-hidden="true">TỒN KHO</div><div class="nav-caption legacy-nav-caption" aria-hidden="true">QUY TRÌNH MUA HÀNG</div>';
document.getElementById('navigation').innerHTML=legacyCaptions+navigationGroups.map(group=>{if(group.routes.length===1){const key=group.routes[0];const r=routes[key];return `<a class="nav-direct-link" href="#${key}" data-route="${key}" data-nav-group="${group.id}" data-nav-group-route="${group.id}" aria-label="${r.label}" data-tip="${r.label}${r.pic?' · '+r.pic:''}">${icon(group.icon)}<span>${r.label}</span>${r.pic?`<small>${r.pic}</small>`:''}</a>`;}return `<section class="nav-group" data-nav-group="${group.id}"><button class="nav-group-toggle" type="button" data-nav-group-toggle="${group.id}" aria-expanded="true" aria-controls="nav-links-${group.id}">${icon(group.icon)}<span>${group.label}</span></button><div class="nav-group-links" id="nav-links-${group.id}" data-nav-links="${group.id}">${group.routes.map(key=>{const r=routes[key];return `<a href="#${key}" data-route="${key}" data-nav-group-route="${group.id}" aria-label="${r.label}" data-tip="${r.label}${r.pic?' · '+r.pic:''}">${icon(r.icon)}<span>${r.label}</span>${r.pic?`<small>${r.pic}</small>`:''}</a>`;}).join('')}</div></section>`;}).join('');
function setNavGroup(groupId,expanded){const group=document.querySelector(`.nav-group[data-nav-group="${groupId}"]`),button=group?.querySelector('[data-nav-group-toggle]');if(!group||!button)return;group.classList.toggle('is-open',expanded);button.setAttribute('aria-expanded',String(expanded));}
navigationGroups.forEach(group=>{if(group.routes.length>1)setNavGroup(group.id,true);});
window.__mroNavigation={routeGroup,setNavGroup,activate(route){const groupId=routeGroup.get(route);if(!groupId)return;setNavGroup(groupId,true);document.querySelectorAll('.nav-group[data-nav-group]').forEach(section=>section.classList.toggle('is-active',section.dataset.navGroup===groupId));for(const[gid,strip]of groupTabStrips)strip.hidden=gid!==groupId;const strip=groupTabStrips.get(groupId);if(strip)strip.querySelectorAll('[data-workspace-tab]').forEach(tab=>{const active=tab.dataset.workspaceTab===route;tab.classList.toggle('active',active);if(active)tab.setAttribute('aria-current','page');else tab.removeAttribute('aria-current');});}};
// Rail kính lúc thu gọn chỉ còn icon: nhãn đẩy vào nhãn nổi đặt trên body, vì .sidebar
// có overflow:auto nên tooltip thuần CSS bị cắt. Nhãn nổi cũng bật khi mở mà tên màn dài bị ellipsis.
const navList=document.getElementById('navigation'),sidebarTip=document.createElement('div');
sidebarTip.className='sidebar-tip';sidebarTip.setAttribute('aria-hidden','true');document.body.append(sidebarTip);
function hideSidebarTip(){delete sidebarTip.dataset.on;}
function showSidebarTip(link){
 if(!link||!link.dataset.tip)return;
 const label=link.querySelector('span');
 // Đang mở và nhãn hiển thị đủ rồi thì không lặp lại nhãn làm rối mắt.
 if(!shell.classList.contains('sidebar-collapsed')&&!(label&&label.scrollWidth>label.clientWidth+1))return;
 sidebarTip.textContent=link.dataset.tip;
 const box=link.getBoundingClientRect();
 sidebarTip.style.setProperty('--tip-x',`${Math.round(box.right)}px`);
 sidebarTip.style.setProperty('--tip-y',`${Math.round(box.top+box.height/2)}px`);
 sidebarTip.dataset.on='1';
}
navList.addEventListener('pointerover',event=>showSidebarTip(event.target.closest('a[data-route]')));
navList.addEventListener('pointerout',event=>{const link=event.target.closest('a[data-route]');if(link&&!link.contains(event.relatedTarget))hideSidebarTip();});
navList.addEventListener('focusin',event=>showSidebarTip(event.target.closest('a[data-route]')));
navList.addEventListener('focusout',hideSidebarTip);
navList.addEventListener('click',hideSidebarTip);
navList.addEventListener('keydown',event=>{if(event.key==='Escape')hideSidebarTip();});
// .sidebar mới là phần tử tràn cuộn (nav không), và chỉ được ẩn khi rail morph:
// transitionend bubbling từ chính hover của item sẽ làm nhãn biến mất ngay khi đang trỏ.
document.querySelector('.sidebar').addEventListener('scroll',hideSidebarTip,{passive:true});
const onMorph=event=>{if(event.target===shell&&event.propertyName==='grid-template-columns')hideSidebarTip()};
shell.addEventListener('transitionrun',onMorph);
shell.addEventListener('transitionend',onMorph);
document.getElementById('refresh').innerHTML=icon('refresh');
function themeIcon(){const dark=document.documentElement.dataset.theme==='dark';document.getElementById('theme').innerHTML=icon(dark?'sun':'moon');document.getElementById('theme').setAttribute('aria-label',dark?'Chuyển sang chế độ sáng':'Chuyển sang chế độ tối');document.getElementById('theme').title=dark?'Chế độ sáng':'Chế độ tối';}themeIcon();
document.getElementById('theme').onclick=()=>{document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';try{localStorage.setItem('mro-theme',document.documentElement.dataset.theme);}catch{}themeIcon();};
document.getElementById('refresh').onclick=event=>{const r=(event?.currentTarget||document.getElementById('refresh')).getBoundingClientRect();window.__mroRevealOrigin={x:r.left+r.width/2,y:r.top+r.height/2};load(true);};
document.getElementById('navigation').addEventListener('click',event=>{const link=event.target.closest('[data-route]');if(!link)return;const r=link.getBoundingClientRect();window.__mroRevealOrigin={x:r.left+r.width/2,y:r.top+r.height/2};setTimeout(motionPass,0);});
bindRouter(registry.setTab);
window.addEventListener('hashchange',()=>{const route=location.hash.slice(1);if(route)registry.ensure(route);});
// Opt-in viewport fitting is presentation-only; modules mark expandable content to retain scrolling.
let fitFrame;
function scheduleFit(){cancelAnimationFrame(fitFrame);fitFrame=requestAnimationFrame(()=>{
 const main=document.getElementById('main'),view=views.querySelector('[data-fit-viewport]:not([hidden])');
 if(!view)return;view.style.zoom='1';
 if(innerWidth<1100||view.querySelector('[data-allow-scroll]'))return;
 const style=getComputedStyle(main),footer=main.querySelector('.page-footer');
 const available=main.clientHeight-parseFloat(style.paddingTop)-parseFloat(style.paddingBottom)-(footer?.getBoundingClientRect().height||0)-8;
 const height=view.getBoundingClientRect().height;if(height>available&&available>0)view.style.zoom=String(Math.min(1,available/height));
});}
new ResizeObserver(scheduleFit).observe(document.getElementById('main'));
new MutationObserver(scheduleFit).observe(views,{childList:true,subtree:true,attributes:true,attributeFilter:['hidden']});
window.addEventListener('resize',scheduleFit);window.addEventListener('hashchange',scheduleFit);
// Ignore count-up text writes: observing them used to restart all animations every frame.
new MutationObserver(records=>{if(records.some(record=>record.type==='attributes'||[...record.addedNodes].some(node=>node.nodeType===1)))scheduleMotion();}).observe(views,{childList:true,subtree:true,attributes:true,attributeFilter:['hidden']});
document.getElementById('close-detail').onclick=()=>document.getElementById('detail').close();document.getElementById('detail').addEventListener('click',e=>{if(e.target===e.currentTarget && e.currentTarget.dataset.required!=='true'){const r=e.currentTarget.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.currentTarget.close();}});
showRoute();
requestAnimationFrame(motionPass);
startAuthGate(store,registry.clear,load,releaseReveal);
return {getData:()=>store.data};
}
