import {initializeAuth} from '../../shared/auth-ui.mjs';

// Chỉ nối lifecycle đăng nhập/đăng xuất; UI và session vẫn thuộc auth hiện tại.
export function startAuthGate(store,clearControllers,load,releaseReveal){
document.addEventListener('signed-out',()=>{store.clear();clearControllers();if(releaseReveal)releaseReveal();});
// Nạp cache của đúng tài khoản trước khi load: có snapshot là dựng màn hình ngay, không chờ SQL.
initializeAuth(userId=>{store.hydrate(userId);load();});
}
