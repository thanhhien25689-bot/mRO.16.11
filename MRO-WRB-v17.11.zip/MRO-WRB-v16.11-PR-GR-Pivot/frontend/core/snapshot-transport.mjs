// 12/11/2026: toàn bộ cơ chế snapshot theo màn đã dời sang shared/screen-cache.mjs vì
// frontend/core bị khoá đúng 5 file (tests/frontend-core.test.mjs + static handler 404 file khác).
// Giữ file này làm alias để không vỡ đường dẫn cũ.
export * from '../../shared/screen-cache.mjs';
// Bản legacy bên dưới KHÔNG được app nạp (chỉ để tham chiếu); code thật là shared/screen-cache.mjs.

// Một điểm duy nhất cho quy tắc "có snapshot là dựng ngay, SQL về sau cập nhật" cho MỌI màn.
// Đặt ở tầng fetch vì mỗi module tự gọi endpoint của mình (stock-live, orders-live, codes-live,
// tracking-live, delivery-live, aps-live, vendor-data, budget-oh/live, cost-saving, data-tracking);
// bọc ở đây nên không phải sửa từng module và không màn nào bị bỏ sót.
// Sự kiện 'screen-refreshed' được phát khi dữ liệu nền khác với bản đang dựng, để module-registry
// dựng lại đúng màn đó bằng số mới — người dùng không phải bấm Cập nhật.
export const SCREEN_REFRESHED='screen-refreshed';
export function createSnapshotTransport({cache=createScreenCache(),fetcher=globalThis.fetch.bind(globalThis),now=()=>Date.now(),dispatch=(event=>document.dispatchEvent(event)),force=()=>!!globalThis.__mroForceSnapshotRefresh}={}){
 let inflight=new Map();
 async function revalidate(key,url,init){
  try{
   const response=await fetcher(url,init);
   if(!response.ok)return {refreshed:false};
   const fresh=await response.json().catch(()=>null);
   if(fresh===null)return {refreshed:false};
   const stored=await cache.read(key);
   await cache.write(key,fresh);
   if(!stored||signature(stored.data)!==signature(fresh)){
    dispatch(new CustomEvent(SCREEN_REFRESHED,{detail:{screen:key,savedAt:now(),data:fresh}}));
    return {refreshed:true};
   }
   return {refreshed:true};
  }catch{return {refreshed:false}}
 }
 return {
  cache,
  // wrap(fetch) trả về hàm fetch mới: gọi trong app.mjs trước khi khởi động, mọi module dùng luôn.
  wrap(){
   return async function snapshotFetch(input,init={}){
    const raw=typeof input==='string'||input instanceof URL?String(input):input?.url||String(input);
    const method=String(init?.method||(typeof input==='object'&&input?.method)||'GET').toUpperCase();
    let key=null;
    try{key=screenKey(raw)}catch{}
    // Request không phải dữ liệu màn hình -> đi thẳng tới mạng. Nút "Cập nhật" (force) cũng đi thẳng,
    // kèm x-mro-refresh để server biết không được đưa bản cũ.
    const forced=force();
    if(method!=='GET'||!key){
     if(!forced)return fetcher(input,init);
     const target=typeof input==='object'&&typeof input.clone==='function'?input.url:input;
     const sent=(typeof input==='object'&&typeof input.clone==='function'?input.init:init)||{};
     return fetcher(target,{...sent,method,headers:{...(sent.headers||{}),'x-mro-refresh':'1'}});
    }
    const settings=typeof input==='object'&&input?{...init}:init;
    const stored=await cache.read(key);
    if(stored&&stored.data!==undefined){
     // Dựng ngay bằng bản lưu; SQL vẫn được gọi nền để số không bao giờ dừng ở bản cũ.
     if(!inflight.has(key)){
      const task=revalidate(key,input,settings).finally(()=>inflight.delete(key));
      inflight.set(key,task);
     }
     return new Response(JSON.stringify(stored.data),{status:200,headers:{'content-type':'application/json','x-mro-snapshot':String(stored.savedAt||''),'x-mro-stale':isFresh(stored.savedAt,now())?'cache':'stale'}});
    }
    const response=await fetcher(input,settings);
    if(response.ok){
     const clone=response.clone();
     void clone.json().then(data=>{if(data!==undefined)return cache.write(key,data)}).catch(()=>{});
    }
    return response;
   };
  },
  install(){globalThis.fetch=this.wrap();return globalThis.fetch},
  // Nút "Cập nhật" và các luồng POST phải đi thẳng tới SQL, không lấy bản cũ.
  bypass(){const previous=globalThis.__mroForceSnapshotRefresh;globalThis.__mroForceSnapshotRefresh=true;return ()=>{globalThis.__mroForceSnapshotRefresh=previous}}
 };
}