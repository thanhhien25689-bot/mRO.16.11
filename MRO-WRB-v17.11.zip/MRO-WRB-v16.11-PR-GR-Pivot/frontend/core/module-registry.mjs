import * as dataTracking from '../../modules/data-tracking/index.mjs';
import * as aps from '../../modules/aps/index.mjs';
import {bindCards} from '../../shared/card-filters.mjs';
import {icon} from '../../shared/icons.mjs';
import {date,esc} from '../../shared/ui.mjs';
import {SCREEN_REFRESHED} from '../../shared/screen-cache.mjs';
import {vendorSession,api as authApi} from '../../shared/auth-ui.mjs';
import * as overview from '../../modules/overview/index.mjs';
import * as inventory from '../../modules/inventory/index.mjs';
import * as delivery from '../../modules/delivery/index.mjs';
import * as orders from '../../modules/orders/index.mjs';
import * as codes from '../../modules/codes/index.mjs';
import * as projects from '../../modules/projects/index.mjs';
import * as tracking from '../../modules/tracking/index.mjs';
import * as vendor from '../../modules/vendor/index.mjs';
import * as setpba from '../../modules/setpba/index.mjs';
import * as setpbaOps from '../../modules/setpba/operations.mjs';
// Routes a Vendor account is allowed to access; all others are hidden and rejected client-side.
const VENDOR_ROUTES=['sp-overview','sp-operations','delivery','vendor-overview','vendor-weekly-orders','vendor-order-history','projects'];
// Fix Asset (15/11/2026): nhóm chức năng độc lập, hiện chỉ là trang "đang phát triển riêng".
// Placeholder đặt tại registry: không thêm file tĩnh/allowlist, không fetch, không đọc hay ghi dữ liệu, không quyền mới
// (không nằm trong VENDOR_ROUTES nên tài khoản Vendor không thấy). Khi tích hợp module quản lý tài sản chính thức:
// tạo modules/fix-asset/index.mjs (export mount) và thay `module:fixAssetPlaceholder` trong routes['fix-asset'] —
// giữ nguyên route key 'fix-asset', nhóm điều hướng và nhãn.
const FIX_ASSET_CSS=`[data-view="fix-asset"] .fa-ph{position:relative;max-width:720px;margin:32px auto;padding:40px 32px 34px;overflow:hidden;text-align:center;border:1px solid color-mix(in srgb,var(--cyan) 32%,var(--border));border-radius:var(--mro-radius,12px);background:linear-gradient(180deg,color-mix(in srgb,var(--cyan) 8%,var(--panel)),var(--panel));box-shadow:var(--shadow,none)}
[data-view="fix-asset"] .fa-ph::before{content:"";position:absolute;inset:0 0 auto;height:4px;background:linear-gradient(90deg,var(--cyan),color-mix(in srgb,var(--cyan) 35%,var(--mint,var(--cyan))))}
[data-view="fix-asset"] .fa-ph-top{display:flex;flex-direction:column;align-items:center;gap:12px;margin-bottom:18px}
[data-view="fix-asset"] .fa-ph-icon{display:inline-grid;place-items:center;width:68px;height:68px;border-radius:18px;border:1px solid color-mix(in srgb,var(--cyan) 42%,var(--border));background:color-mix(in srgb,var(--cyan) 13%,transparent);color:var(--cyan)}
[data-view="fix-asset"] .fa-ph-icon svg{width:34px;height:34px}
[data-view="fix-asset"] .fa-ph-badge{display:inline-flex;align-items:center;gap:6px;padding:3px 11px;border-radius:999px;border:1px solid var(--border);background:var(--panel-alt);color:var(--muted);font-size:11.5px;font-weight:650;letter-spacing:.03em}
[data-view="fix-asset"] .fa-ph-badge::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--amber)}
[data-view="fix-asset"] .fa-ph h2{margin:0;color:var(--text);font-size:28px;font-weight:800;letter-spacing:.09em;line-height:1.2}
[data-view="fix-asset"] .fa-ph-en{display:inline-block;margin-top:10px;padding:4px 12px;border-radius:8px;border:1px solid var(--border);background:var(--panel-alt);color:var(--cyan);font-size:13px;letter-spacing:.03em}
[data-view="fix-asset"] .fa-ph-key{display:flex;align-items:center;justify-content:center;gap:10px;margin:24px auto 18px;max-width:520px;padding:11px 16px;border:1px solid color-mix(in srgb,var(--amber) 50%,var(--border));border-left-width:4px;border-radius:10px;background:color-mix(in srgb,var(--amber) 11%,var(--panel));color:var(--amber);font-size:15px;font-weight:800;letter-spacing:.07em}
[data-view="fix-asset"] .fa-ph-key::before{content:"";flex:0 0 auto;width:9px;height:9px;transform:rotate(45deg);background:var(--amber)}
[data-view="fix-asset"] .fa-ph-desc{max-width:560px;margin:0 auto;color:var(--text);font-size:14.5px;line-height:1.65}
[data-view="fix-asset"] .fa-ph-desc strong{display:block;margin-bottom:4px;font-weight:700}
[data-view="fix-asset"] .fa-ph-desc span{color:var(--muted)}
@media(max-width:700px){[data-view="fix-asset"] .fa-ph{margin:16px auto;padding:32px 18px 26px}[data-view="fix-asset"] .fa-ph h2{font-size:22px}[data-view="fix-asset"] .fa-ph-key{font-size:13px;letter-spacing:.05em}}`;
const fixAssetPlaceholder={mount(root){
 root.innerHTML=`<style>${FIX_ASSET_CSS}</style><section class="fa-ph" aria-labelledby="fa-ph-title"><div class="fa-ph-top"><div class="fa-ph-icon" aria-hidden="true">${icon('package-check')}</div><span class="fa-ph-badge">Đang phát triển</span></div><h2 id="fa-ph-title">QUẢN LÝ TÀI SẢN</h2><code class="fa-ph-en" lang="en">Fixed Asset Management</code><p class="fa-ph-key" role="note">HẠNG MỤC ĐẶC BIỆT QUAN TRỌNG</p><p class="fa-ph-desc"><strong>Chức năng đang được phát triển riêng.</strong><span>Đây là nhóm công việc phức tạp, yêu cầu quản lý chặt chẽ và sẽ được triển khai thành module độc lập.</span></p></section>`;
 return {};
}};
// Phase 1 navigation only: route ownership stays unchanged; groups are presentation metadata.
export const navigationGroups=[
 {id:'overview',label:'Tổng quan MRO',icon:'layout-dashboard',routes:['overview']},
 {id:'fix-asset',label:'Fix Asset',icon:'package-check',routes:['fix-asset']},
 {id:'setpba',label:'SET/PBA',icon:'cpu',routes:['sp-overview','sp-operations']},
 {id:'inventory-vendor',label:'Kho & Vendor',icon:'warehouse',routes:['delivery','vendor-overview','inventory']},
 {id:'procurement',label:'Order & Mua hàng',icon:'shopping-cart',routes:['vendor-weekly-orders','vendor-order-history','orders','codes','tracking']},
 {id:'projects',label:'Project Status',icon:'layers',routes:['projects']},
 {id:'repair',label:'Repair & Service',icon:'wrench',routes:['aps']},
 {id:'data',label:'Dữ liệu & Báo cáo',icon:'database',routes:['data-tracking']}
];
export const routes={'sp-overview':{label:'SET/PBA Overview',title:'SET/PBA Overview',eyebrow:'SET / PBA INVENTORY',description:'Tổng quan tồn kho SET và PBA theo Holder.',icon:'stock',module:setpba},'sp-operations':{label:'SET/PBA Operations',title:'SET/PBA Operations',eyebrow:'SET / PBA OPERATIONS',description:'Tra cứu SET Inventory, PBA, Transfer, NG và Movement.',icon:'layers',module:setpbaOps},overview:{label:'Tổng quan',title:'Tổng quan MRO',eyebrow:'OPERATIONS OVERVIEW',description:'Tồn kho, mua hàng và ngân sách trong một góc nhìn.',icon:'overview',module:overview},delivery:{label:'Lịch sử giao hàng',title:'Lịch sử giao hàng',eyebrow:'SEV → VENDOR',description:'Ghi nhận giao hàng và truy vết chứng từ.',icon:'delivery',module:delivery},projects:{label:'Project Status',title:'Project Status',eyebrow:'PROJECT PROCUREMENT',description:'Theo dõi dự án SETUP, SOP và Spare.',icon:'layers',module:projects},'data-tracking':{label:'Data Tracking',title:'Data Tracking',eyebrow:'SQL DATA',description:'Dữ liệu gốc PR, RFQ và GMRO.',icon:'tracking',module:dataTracking},aps:{label:'Repair & Service',title:'Repair & Service',eyebrow:'APS REPAIR & SERVICE',description:'Sửa chữa, nâng cấp Jig/Equipment và dịch vụ từ portal APS.',icon:'activity',module:aps},'vendor-overview':{label:'Tổng quan Vendor',title:'Tổng quan Vendor',eyebrow:'VENDOR / INVENTORY',description:'Tồn kho, nhu cầu và cảnh báo theo Vendor.',icon:'stock',module:vendor.overview},'vendor-weekly-orders':{label:'Order hàng tuần',title:'Order hàng tuần',eyebrow:'VENDOR / WEEKLY ORDER',description:'Gửi yêu cầu lên SQL để PIC1 tiếp nhận.',icon:'order',module:vendor.weeklyOrders},'vendor-order-history':{label:'Lịch sử order',title:'Lịch sử order Vendor',eyebrow:'VENDOR / ORDER HISTORY',description:'Lịch sử gửi và xử lý Order từ SQL.',icon:'tracking',module:vendor.orderHistory},inventory:{label:'Tổng SEV & Vendor',title:'Tổng SEV & Vendor',eyebrow:'INVENTORY MANAGEMENT',description:'Theo dõi vật tư tại SEV và từng vendor.',icon:'stock',module:inventory},orders:{label:'Order & Mua hàng',title:'Order & Mua hàng',eyebrow:'PIC1 / REQUEST MANAGEMENT',description:'Tổng hợp nhu cầu, xác nhận và bàn giao xử lý mã.',icon:'order',pic:'PIC1',module:orders},codes:{label:'Code & Code Issue',title:'Code & Code Issue',eyebrow:'PIC2 / ITEM READINESS',description:'Từ yêu cầu vật tư đến mã sẵn sàng tạo PR.',icon:'code',pic:'PIC2',module:codes},tracking:{label:'PR & Tracking',title:'PR & Tracking',eyebrow:'PIC3 / PROCUREMENT',description:'Kết nối từng dòng PR với PO, giao hàng và nhận hàng.',icon:'tracking',pic:'PIC3',module:tracking},'fix-asset':{label:'Fix Asset',title:'Fix Asset',eyebrow:'FIXED ASSET MANAGEMENT',description:'Quản lý tài sản — chức năng đang được phát triển riêng.',icon:'package-check',module:fixAssetPlaceholder}};

export function createModuleRegistry(views,store,showRoute){
let controllers={},ensureRoute=()=>Promise.resolve(),frameElements={},vendorPeriod=null;
async function api(path,method='GET',body=null){const opts={method,credentials:'same-origin',headers:{}};if(body!==null){opts.headers['Content-Type']='application/json';opts.body=JSON.stringify(body);}const res=await fetch('/api/'+path,opts);if(!res.ok){let msg=res.statusText;try{const j=await res.json();msg=j.message||msg;}catch{}throw Object.assign(new Error(msg),{status:res.status});}return res.json();}
function moduleError(el,label,error){
 const message=String(error?.message||'Lỗi không xác định.').slice(0,300);
 el.innerHTML=`<section class="panel error-state" data-module-error><h2>Không thể mở ${esc(label)}</h2><p>${esc(message)}</p><button class="button primary" type="button" data-module-retry>Tải lại dữ liệu</button></section>`;
 el.querySelector('[data-module-retry]').onclick=()=>document.getElementById('refresh').click();
}
// 16/11/2026: mỗi lần mount một màn có số thế hệ riêng (data-mount-gen) để bảng dùng chung biết màn vừa được dựng lại
// sau khi SQL tải xong và khôi phục trang đang xem (shared/ui/table.mjs).
let mountGeneration=0;
function mountAll({background=false}={}){
 const fragment=document.createDocumentFragment(),next={},ready=[];
 const elements={};
 for(const [key,r] of Object.entries(routes)){
  const el=document.createElement('div');el.dataset.view=key;el.className='module-view';el.hidden=true;elements[key]=el;fragment.append(el);
 }
 views.replaceChildren(fragment);controllers=next;frameElements=elements;document.getElementById('snapshot-date').innerHTML=icon('calendar')+date(store.data.asOf);
 const vendorScope=vendorSession()?.vendorScope||null;
 if(vendorScope){
  const curHash=location.hash.slice(1);
  if(!curHash||!VENDOR_ROUTES.includes(curHash))location.replace('#vendor-overview');
  document.querySelectorAll('[data-route]').forEach(el=>{if(!VENDOR_ROUTES.includes(el.dataset.route))el.hidden=true;});
  document.querySelectorAll('[data-workspace-tab]').forEach(el=>{if(!VENDOR_ROUTES.includes(el.dataset.workspaceTab))el.hidden=true;});
  document.querySelectorAll('.nav-group[data-nav-group]').forEach(section=>{if(!section.querySelector('[data-route]:not([hidden])'))section.hidden=true;});
 }
 const mountOne=async key=>{
  if(vendorScope&&!VENDOR_ROUTES.includes(key)){if(location.hash.slice(1)===key)location.replace('#vendor-overview');return;}
  if(Object.hasOwn(next,key))return;const r=routes[key],el=frameElements[key]||elements[key];el.innerHTML='<p class="small muted module-loading">Đang nạp dữ liệu màn hình…</p>';try{const isVendorKey=key==='vendor-overview'||key==='vendor-weekly-orders'||key==='vendor-order-history';const mountOpts=isVendorKey?{api,read:(vendor,week)=>{const p=new URLSearchParams();if(vendor&&vendor!=='all')p.set('vendor',vendor);if(week)p.set('week',week);return authApi('vendor-data'+(p.size?'?'+p:''));},send:input=>authApi('vendor-orders','POST',input),writeInOut:input=>authApi('vendor-inout','POST',input),importInOut:input=>authApi('vendor-inout-import','POST',input),confirmTransfer:input=>authApi('vendor-transfer-confirm','POST',input),changeTransfer:input=>authApi('vendor-transfer-action','POST',input),session:vendorSession,getPeriod:()=>vendorPeriod,setPeriod:p=>{vendorPeriod=p;}}:{api};el.dataset.mountGen=String(++mountGeneration);const controller=r.module.mount(el,store.data,mountOpts);next[key]=controller;bindCards(el,key,store.data,controller);if(controller?.ready&&!background)await Promise.resolve(controller.ready);}catch(error){next[key]=null;moduleError(el,r.label,error);}};
 ensureRoute=mountOne;
 const order=Object.keys(routes),overviewKey=vendorScope?'vendor-overview':(order.includes('overview')?'overview':order[0]);
 return mountOne(overviewKey).then(()=>{showRoute();if(!background)void (async()=>{for(const key of order)if(key!==overviewKey)await mountOne(key);})();});
}
// 12/11/2026: SQL chạy nền trả về số khác bản đang dựng -> chỉ dựng lại đúng màn liên quan,
 // các màn khác giữ nguyên (không lật lại cả portal, không mất vị trí cuộn của người dùng).
 const screenViews={'/api/budget-oh/live':['overview','aps'],'/api/cost-saving':['overview'],'/api/stock-live':['inventory','vendor-overview'],'/api/orders-live':['orders'],'/api/orders-context':['orders'],'/api/delivery-live':['delivery'],'/api/codes-live':['codes'],'/api/tracking-live':['tracking','projects','data-tracking'],'/api/aps-live':['aps'],'/api/vendor-data':['vendor-overview','vendor-weekly-orders','vendor-order-history'],'/api/data-tracking':['data-tracking']};
 document.addEventListener(SCREEN_REFRESHED,event=>{
  const screen=String(event?.detail?.screen||'').split('?')[0];
  for(const key of screenViews[screen]||[]){
   if(!controllers[key]||!frameElements[key]?.isConnected)continue;
   // Giữ chiều cao màn trong lúc dựng lại để trang không bị co rồi cuộn nhảy lên đầu (16/11/2026).
   const frame=frameElements[key],height=frame.hidden?0:frame.offsetHeight;if(height){frame.style.minHeight=height+'px';clearTimeout(frame.__keepHeight);frame.__keepHeight=setTimeout(()=>{frame.style.minHeight='';},2500);}
   delete controllers[key];
   void Promise.resolve(ensureRoute(key)).catch(()=>{});
  }
 });
 function invalidate(keys){
  const targets=[...new Set((Array.isArray(keys)?keys:[]).filter(key=>routes[key]))];
  if(!targets.length){mountAll();return;}
  for(const key of targets){const old=frameElements[key];if(!controllers[key]||!old?.isConnected)continue;const replacement=document.createElement('div');replacement.dataset.view=key;replacement.className='module-view';replacement.hidden=old.hidden;old.replaceWith(replacement);frameElements[key]=replacement;delete controllers[key];void Promise.resolve(ensureRoute(key)).catch(()=>{});}
 }
 document.addEventListener('data-edited',event=>invalidate(event.detail?.views));
 return {mountAll,ensure(route){return routes[route]?ensureRoute(route):Promise.resolve();},invalidate,setTab(route,filter){controllers[route]?.setTab(filter);},clear(){controllers={};frameElements={};}};
}
