// Public contract Phase 6A; Phase 6B/6C nối handoff Orders → Codes và Codes → Orders.
// Không tạo event bus, API hoặc schema mới.
const contract={
 version:'legacy-phase-6a',
 ownership:{
  requests:{owner:'Orders',identity:['id'],writers:['Orders.create','Orders.confirm','Codes.ready:owner-only']},
  codes:{owner:'Codes',identity:['id'],writers:['Orders.confirm:append-if-absent','Codes.ready']},
  tracking:{owner:'Tracking',identity:['pr','sq'],writers:['Tracking.confirmSync']},
  purchaseLines:{owner:'Purchase snapshot (giả lập)',writers:[]},
  items:{owner:'Inventory snapshot',writers:[]},
  budget:{owner:'Snapshot ngân sách; ownership nghiệp vụ chưa chốt',writers:[]}
 },
 requestFields:['id','date','source','list','code','name','group','qty','unit','vendor','sop','need','status','owner','po'],
 codeExtraFields:['originalCode','purchaseCode','step','rfq','round','workDays','sla','pic'],
 actions:{
  create:{writes:['requests'],arrayOperation:'unshift-in-place',defaults:{status:'Chờ xác nhận',owner:'PIC1',po:null},effects:['dialog-close','data-edited','toast'],toast:'Đã tạo yêu cầu trong phiên mẫu.'},
  confirm:{writes:['requests','codes'],requestPatch:{status:'Đã xác nhận',owner:'PIC2'},codeDefaults:{purchaseCode:'',step:'Item Master Check',rfq:'',round:0,workDays:0,sla:12,status:'Đang xử lý',pic:'Nguyễn An'},arrayOperation:'append-code-only-if-id-absent',effects:['dialog-close','data-edited','toast'],toast:'Đã chuyển yêu cầu sang PIC2 trong phiên mẫu.'},
  ready:{writes:['codes','requests'],codeFields:['purchaseCode','reason','confirmedAt','status','step','owner'],codePatch:{status:'Ready for PR',step:'Ready for PR',owner:'PIC3'},requestFields:['owner'],requestPatch:{owner:'PIC3'},requestMatch:'first-id-or-no-op',effects:['dialog-close','data-edited','toast'],toast:'Đã xác nhận mã và bàn giao PIC3.'},
  confirmSync:{writes:['tracking'],arrayOperation:'replace-array-with-Map-merge',effects:['data-edited','toast'],toast:'Đã cập nhật PR Tracking. Đồng bộ lại không tạo dòng trùng.'}
 },
 tracking:{
  key:'`${pr}:${sq}`',requiredTruthy:['pr','sq','code'],rejectQty:'qty <= 0',mergeError:'Dòng PR không hợp lệ',
  mergeOrder:'existing Map insertion order, append new keys; last incoming value wins',
  mergeSpread:['existing-row','incoming-row'],trackingFallback:'TRK-${pr}-${sq}',
  pasteRequiredStrings:['pr','sq','code','name','vendor'],pasteQty:'finite-number > 0',
  pasteDefaults:{status:'Chờ PO',received:0},pasteEmptyError:'Cần một danh sách PR lines.',
  pasteFieldsError:'Mỗi dòng cần pr, sq, code, name, vendor và qty > 0.',
  missingPrToast:'Không tìm thấy PR mẫu. Dùng PR-1242 hoặc PR-1243.',
  previewWrites:[],cancelWrites:[],readyAutomaticallyCreatesPR:false
 },
 event:{name:'data-edited',target:'document',type:'CustomEvent',detail:'optional-views-array',bubbles:false,cancelable:false,remount:'selective-views-or-six-view-fallback',fetch:false,persistence:'RAM-only'},
 readDependencies:{Orders:['items','asOf','sopLate','ageDays'],Codes:['requests','asOf','sopLate'],Tracking:['purchaseLines','codes','budget[9]','trackingKey','mergeTracking'],cardAdapter:['codes Ready for PR','purchaseLines missing pr+sq','sopLate']}
};
function freeze(value){for(const child of Object.values(value))if(child&&typeof child==='object')freeze(child);return Object.freeze(value);}
export const procurementContract=freeze(contract);

// Integration sở hữu side effect ghi Codes; Orders chỉ xác nhận request trước khi gọi.
// Không import internal Codes, không đổi duplicate behavior hoặc defaults Phase 6A.
export function appendCodeForConfirmedRequest(data,request){
 if(!data.codes.some(c=>c.id===request.id))data.codes.push({...request,originalCode:request.code,...procurementContract.actions.confirm.codeDefaults});
}

// Phase 6C: giữ find/first-match legacy; orphan không ghi request nào.
export function handoffFirstRequestForReadyCode(data,code){
 const req=data.requests.find(q=>q.id===code.id);if(req)req.owner='PIC3';
}

