export const genAIOrigin='https://genai.sec.samsung.net';
export const observedModelGuid='01988e7d-b30e-79d1-8385-2ed7c222d532';
const guid=v=>typeof v==='string'&&/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(v);
const issue=(message,code,details={})=>Object.assign(Error(message),{code,...details});

// Stateful UTF-8/SSE parsing. Neither read() boundaries nor FINAL_ANSWER end a response.
export async function readGenAISSE(body,{onChunk=()=>{},signal,maxBytes=4*1024*1024}={}){
 if(!body?.getReader)throw issue('Phản hồi không có luồng SSE.','protocol');
 const reader=body.getReader(),decoder=new TextDecoder('utf-8',{fatal:true});let buffer='',data=[],eventName='',text='',chunks=0,bytes=0,finalSeen=false,doneSeen=false;
 const abort=()=>{void reader.cancel().catch(()=>{});};signal?.addEventListener('abort',abort,{once:true});
 function dispatch(){
  if(!data.length){eventName='';return;}
  const source=data.join('\n');data=[];const name=eventName;eventName='';
  if(source==='[DONE]'){doneSeen=true;return;}
  let event;try{event=JSON.parse(source);}catch{throw issue('Sự kiện SSE không phải JSON hợp lệ; câu trả lời chưa hoàn tất.','protocol');}
  const status=event?.event_status;
  if(status==='ERROR'||name.toLowerCase()==='error'||event?.error)throw issue('GenAI báo lỗi trong luồng; câu trả lời chưa hoàn tất.','remote');
  if(status==='FINAL_ANSWER')finalSeen=true;
  if(status==='CHUNK'&&typeof event.content==='string'){
   text+=event.content;chunks++;onChunk(event.content,text);
  }
 }
 function line(value){if(value===''){dispatch();return;}if(value.startsWith(':'))return;const i=value.indexOf(':'),field=i<0?value:value.slice(0,i);let valuePart=i<0?'':value.slice(i+1);if(valuePart.startsWith(' '))valuePart=valuePart.slice(1);if(field==='data')data.push(valuePart);else if(field==='event')eventName=valuePart;}
 function drain(eof=false){let start=0;for(let i=0;i<buffer.length;i++){if(buffer[i]!=='\n'&&buffer[i]!=='\r')continue;if(buffer[i]==='\r'&&i===buffer.length-1&&!eof)break;line(buffer.slice(start,i));if(buffer[i]==='\r'&&buffer[i+1]==='\n')i++;start=i+1;}buffer=buffer.slice(start);}
 try{
  while(true){signal?.throwIfAborted();const next=await reader.read();signal?.throwIfAborted();if(next.done)break;bytes+=next.value.byteLength;if(bytes>maxBytes)throw issue('Phản hồi vượt giới hạn 4 MB; đã dừng đọc.','limit');buffer+=decoder.decode(next.value,{stream:true});drain();}
  buffer+=decoder.decode();drain(true);
  // Read to clean HTTP EOF. FINAL_ANSWER alone never stops the reader.
  // A transport failure or an unterminated event remains incomplete.
  const partial=buffer.length>0||data.length>0;
  return {text,chunks,finalSeen,doneSeen,cleanEOF:true,complete:!partial&&chunks>0,
   warning:partial?'Luồng đóng giữa sự kiện; câu trả lời chưa hoàn tất.':!chunks?'Luồng kết thúc nhưng chưa nhận nội dung CHUNK.':!doneSeen?'Đã đọc đến cuối luồng HTTP; chưa có tín hiệu kết thúc được xác nhận từ API.':''};
 }finally{signal?.removeEventListener('abort',abort);await reader.cancel().catch(()=>{});reader.releaseLock();}
}

export function createGenAIClient({fetcher=globalThis.fetch,origin=globalThis.location?.origin}={}){
 let busy=false;
 async function ask({chatGuid,modelGuid,content,onChunk,onPhase,signal}){
  if(busy)throw issue('Đang xử lý câu hỏi trước.','busy');
  if(!guid(chatGuid)||!guid(modelGuid))throw issue('Cần chatGuid có quyền truy cập và model GUID hợp lệ.','config');
  if(typeof content!=='string'||!content.trim()||new TextEncoder().encode(content).length>1024*1024)throw issue('Nội dung trống hoặc vượt 1 MB.','config');
  busy=true;let stage='before',messageGuid=null;
  const credentials=origin===genAIOrigin?'same-origin':'include';
  async function post(path,payload,sse=false){
   const r=await fetcher(genAIOrigin+path,{method:'POST',credentials,mode:'cors',redirect:'manual',cache:'no-store',referrerPolicy:'no-referrer',headers:{'Content-Type':'application/json',...(sse?{Accept:'text/event-stream'}:{})},body:JSON.stringify(payload),signal});
   if(r.type==='opaqueredirect'||r.status===302||r.status===301||r.status===303||r.status===307||r.status===308||r.status===401)throw issue('Phiên Samsung chưa hợp lệ hoặc đã hết hạn. Đăng nhập GenAI trong cùng trình duyệt; không tự gửi lại.','session',{httpStatus:r.status||null});
   if(r.status===403)throw issue('GenAI từ chối quyền chat/model hoặc phiên xác thực. Kiểm tra quyền trên Samsung.','forbidden',{httpStatus:r.status});
   if(!r.ok)throw issue('GenAI trả HTTP '+r.status+'. Chưa tự gửi lại yêu cầu.','http',{httpStatus:r.status});
   const type=r.headers.get('content-type')||'';
   if(!(sse?type.includes('text/event-stream'):type.includes('application/json')))throw issue('Phản hồi không đúng định dạng; có thể bị chuyển tới trang đăng nhập.','protocol');
   return r;
  }
  try{
   stage='message';onPhase?.('Đang gửi câu hỏi');
   const r=await post('/api/chat/v1/messages',{chatGuid,messageType:'chat',content,attributes:{plugins:[],skills:[],mcpServers:[],knowledge:[],embeddingKnowledge:[],codeInterpreters:false},fileUuids:[]});
   const record=await r.json();if(!guid(record.guid))throw issue('Tin nhắn không có guid hợp lệ; chưa gọi sinh câu trả lời.','protocol');messageGuid=record.guid;
   stage='response';onPhase?.('Đang nhận phân tích');
   const stream=await post('/api/chat/v1/messages-response',{chatGuid,messageGuid,locale:'en',modelGuids:[modelGuid],isArtifact:false},true);
   const result=await readGenAISSE(stream.body,{onChunk,signal});return {...result,messageGuid,chatGuid};
  }catch(error){
   const cancelled=signal?.aborted||error.name==='AbortError',known=['session','forbidden','http','protocol','remote','limit','config','busy'].includes(error.code),code=cancelled?'cancelled':known?error.code:'network';
   const message=cancelled?(signal?.reason?.name==='TimeoutError'?'Hết thời gian chờ. Câu trả lời có thể chưa hoàn tất.':'Đã hủy. Câu trả lời có thể chưa hoàn tất.'):known?error.message:'Trình duyệt không đọc được phản hồi GenAI. Chưa thể phân biệt lỗi mạng, CORS, redirect đăng nhập hay cookie bị chặn chỉ từ lỗi fetch. Đã đăng nhập ở tab khác không bảo đảm localhost dùng được phiên.';
   throw Object.assign(Error(message+(stage==='before'?'':' Yêu cầu có thể đã được nhận; kiểm tra cuộc trò chuyện trước khi gửi lại.')),{code,stage,messageGuid,uncertain:stage!=='before',diagnostics:{mroOrigin:String(origin||'Không xác định'),apiOrigin:genAIOrigin,crossOrigin:origin!==genAIOrigin,endpoint:stage==='response'?'/api/chat/v1/messages-response':'/api/chat/v1/messages',stage,httpStatus:known?error.httpStatus??null:null,code,messageGuid}});
  }finally{busy=false;}
 }
 return {ask};
}
