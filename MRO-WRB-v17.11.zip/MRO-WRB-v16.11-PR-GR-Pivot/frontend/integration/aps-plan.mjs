import {esc,showDetail,toast} from '../shared/ui/index.mjs';
// Panel Monthly Plan (EQM_MRO_ServiceMonthlyPlan): integration đọc/ghi qua /api/aps/plan.
// Module aps chỉ render khung chứa [data-aps-plan-root]; mọi fetch/ghi thuộc integration này.
// Mỗi lần lưu tạo phiên bản mới (V1, V2…) — bảng hiển thị phiên bản mới nhất theo tháng,
// tooltip liệt kê lịch sử phiên bản. Không DELETE/PUT phía server (INSERT-only).
const MONTH_NAMES=['Tháng 1','Tháng 2','Tháng 3','Tháng 4','Tháng 5','Tháng 6','Tháng 7','Tháng 8','Tháng 9','Tháng 10','Tháng 11','Tháng 12'];
const fmtTime=value=>value?esc(new Date(String(value).replace(' ','T')+'Z').toLocaleString('vi-VN')):'—';
const fmtAmount=(amount,currency)=>amount==null?'—':Number(amount).toLocaleString('vi-VN',{maximumFractionDigits:2})+' '+esc(currency||'');
export function startApsPlan(api){
  let cache=null,busy=false,timer=null,lastRead=Date.now();
  const rootSel='[data-aps-plan-root]';
  const rootView=()=>document.querySelector('[data-view="aps"]');
  const schedule=()=>{clearTimeout(timer);timer=null;if(rootView()&&!rootView().hidden&&!document.hidden)timer=setTimeout(()=>{if(rootView()&&!rootView().hidden&&!document.hidden&&!document.getElementById('detail')?.open)load();else schedule();},Math.max(5000,300000-(Date.now()-lastRead)));};
  const wake=()=>{if(rootView()&&!rootView().hidden&&!document.hidden){if(Date.now()-lastRead>=300000&&!busy&&!document.getElementById('detail')?.open)load();else schedule();}else{clearTimeout(timer);timer=null;}};
  document.addEventListener('visibilitychange',wake);
  document.addEventListener('signed-out',()=>{clearTimeout(timer);timer=null;cache=null;});
  const canManage=()=>!!cache&&cache.canManage===true;
  const historyOf=(year,month)=>(cache.plan||[]).filter(r=>r.year===year&&r.month===month).sort((a,b)=>Number(b.version.slice(1))-Number(a.version.slice(1)));
  function render(error){
    const host=document.querySelector(rootSel);
    if(!host)return;
    host.dataset.ready='1';
    if(error){host.innerHTML=`<p class="small red" role="alert">${esc(error)}</p><button class="button" type="button" data-aps-plan-action="reload">Thử lại</button>`;return;}
    if(!cache){host.innerHTML='<p class="small muted" role="status">Đang tải Monthly Plan…</p>';return;}
    const latest=cache.latest||{};
    const keys=Object.keys(latest).sort((a,b)=>b.localeCompare(a));
    const rows=keys.map(key=>{
      const row=latest[key];
      const history=historyOf(row.year,row.month);
      const title=history.map(h=>`${h.version}: ${Number(h.amount).toLocaleString('vi-VN')} ${h.currency} · ${h.createdBy||'—'} · ${h.createdAt||''}`).join('\n');
      return `<tr>
        <td>${esc(row.year)}</td><td>${esc(MONTH_NAMES[row.month-1]||row.month)}</td>
        <td><strong>${fmtAmount(row.amount,row.currency)}</strong></td>
        <td><span class="badge cyan">${esc(row.version)}</span>${history.length>1?` <span class="muted small" title="${esc(title)}">(${history.length} phiên bản)</span>`:''}</td>
        <td>${esc(row.createdBy||'—')}</td><td>${fmtTime(row.createdAt)}</td>
        <td>${canManage()?`<button class="text-button" type="button" data-aps-plan-action="update" data-ym="${esc(key)}">Cập nhật</button>`:'<span class="muted small">Chỉ xem</span>'}</td>
      </tr>`;
    }).join('');
    host.innerHTML=`<div class="table-scroll"><table class="aps-plan-table"><thead><tr>
      <th>Năm</th><th>Tháng</th><th>Số tiền kế hoạch</th><th>Phiên bản</th><th>Cập nhật bởi</th><th>Lưu lúc</th><th>Hành động</th>
    </tr></thead><tbody>${rows||'<tr><td colspan="7" class="muted">Chưa có kế hoạch tháng nào trên SQL Server.</td></tr>'}</tbody></table></div>
    ${canManage()?'<button class="button primary" type="button" data-aps-plan-action="add">Nhập kế hoạch tháng</button>':''}`;
  }
  async function load(force=false){
    if(busy)return;busy=true;
    try{cache=await api('aps/plan');render();}
    catch(error){render(error&&error.message||'Không tải được Monthly Plan.');}
    finally{busy=false;lastRead=Date.now();schedule();}
  }
  function dialogForm({heading='',year='',month='',currency='USD',amount=''}){
    return `<p class="small muted">${heading}</p><form class="account-form" data-aps-plan-form>
      <label>Năm<input name="year" type="number" min="2000" max="2100" required value="${esc(year)}"></label>
      <label>Tháng<select name="month" required>${MONTH_NAMES.map((label,index)=>`<option value="${index+1}"${String(month)===String(index+1)?' selected':''}>${label}</option>`).join('')}</select></label>
      <label>Loại tiền<select name="currency"><option value="USD"${currency==='USD'?' selected':''}>USD</option><option value="VND"${currency==='VND'?' selected':''}>VND</option></select></label>
      <label>Số tiền kế hoạch<input name="amount" type="number" min="0" step="0.0001" required value="${esc(amount)}"></label>
      <button class="button primary" type="submit">Lưu phiên bản mới</button>
    </form>`;
  }
  async function submit(form){
    const data=Object.fromEntries(new FormData(form).entries()),button=form.querySelector('button[type=submit]');
    button.disabled=true;
    try{
      const result=await api('aps/plan','POST',{year:Number(data.year),month:Number(data.month),amount:Number(data.amount),currency:data.currency});
      cache={...cache,plan:result.plan,latest:result.latest,canManage:cache.canManage};
      document.getElementById('detail').close();
      render();toast(`Đã lưu Monthly Plan ${data.year}-${String(data.month).padStart(2,'0')} — phiên bản ${result.version}.`);
    }catch(error){toast(error&&error.message||'Không lưu được Monthly Plan.');button.disabled=false;}
  }
  document.addEventListener('click',event=>{
    const target=event.target instanceof Element?event.target.closest('[data-aps-plan-action]'):null;
    if(!target)return;
    const action=target.dataset.apsPlanAction;
    if(action==='reload'){load(true);return;}
    const view=rootView();
    if(!view||view.hidden)return;
    if(action==='add'){
      showDetail('Nhập kế hoạch tháng',dialogForm({heading:'Estimate tổng theo tháng, lưu trên SQL Server (EQM_MRO_ServiceMonthlyPlan). Mỗi lần lưu tạo phiên bản mới; phiên bản mới nhất là kế hoạch hiện hành của tháng.'}));
      return;
    }
    if(action==='update'){
      const [year,month]=String(target.dataset.ym).split('-');
      const row=(cache.latest||{})[target.dataset.ym];
      if(!row)return;
      showDetail('Cập nhật kế hoạch tháng '+target.dataset.ym,dialogForm({heading:'Lưu sẽ tạo phiên bản mới cho tháng này; các phiên bản cũ được giữ lại làm lịch sử.',year,month,currency:row.currency,amount:row.amount??''}));
    }
  });
  document.addEventListener('submit',event=>{
    const form=event.target instanceof Element?event.target:null;
    if(form&&form.matches('[data-aps-plan-form]')){event.preventDefault();submit(form);}
  });
  if(window.MutationObserver){
    const observer=new MutationObserver(()=>{
      if(!cache&&!busy&&rootView()&&!rootView().hidden)load();
      else if(cache&&document.querySelector(rootSel)&&!document.querySelector(rootSel).dataset.ready)render();
      if(rootView()&&!rootView().hidden&&Date.now()-lastRead>=300000&&!busy&&!document.getElementById('detail')?.open)load();
      else if(rootView()?.hidden){clearTimeout(timer);timer=null;}
      else if(!timer&&cache&&rootView()&&!rootView().hidden)schedule();
    });
    const views=document.getElementById('views');
    if(views)observer.observe(views,{attributes:true,attributeFilter:['hidden'],childList:true,subtree:true});
  }
  if(rootView()&&!rootView().hidden)load();
}
