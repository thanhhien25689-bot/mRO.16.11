import {esc,showDetail,toast} from '../shared/ui/index.mjs';
// Panel hợp đồng dịch vụ (EQM_MRO_ServiceContract): integration đọc/ghi qua /api/aps/contracts.
// Module aps chỉ render khung chứa [data-aps-contracts-root]; mọi fetch/upload thuộc integration này.
// PDF upload gửi multipart/form-data qua api() (api gắn CSRF và không tự đặt Content-Type cho FormData).
// 06/11/2026: PDF và metadata nằm trong SQL (cột PdfData/PdfName/PdfSize/...), một PDF cho mỗi Số hợp đồng;
// portal không còn giữ file hay metadata trên đĩa. Integration không import shared/auth-ui.
// 06/11/2026: cột PDF có nút "⬇ Tải về" cho MỌI phiên đã đăng nhập (viewer kèm theo), tải qua blob
// cùng route GET /api/aps/contracts/pdf để giữ đúng tên file và hiện nguyên nhân lỗi thật.
const fmtDate=value=>value?esc(String(value).slice(0,10)):'—';
const fmtSize=size=>Number(size)>=1048576?(Number(size)/1048576).toFixed(1)+' MB':Math.max(1,Math.round(Number(size)/1024))+' KB';
const fmtTime=value=>value?esc(new Date(String(value).replace(' ','T')+'Z').toLocaleString('vi-VN')):'—';
export function startApsContracts(api){
  let cache=null,busy=false,timer=null,lastRead=Date.now();
  const rootSel='[data-aps-contracts-root]';
  const rootView=()=>document.querySelector('[data-view="aps"]');
  const schedule=()=>{clearTimeout(timer);timer=null;if(rootView()&&!rootView().hidden&&!document.hidden)timer=setTimeout(()=>{if(rootView()&&!rootView().hidden&&!document.hidden&&!document.getElementById('detail')?.open)load();else schedule();},Math.max(5000,300000-(Date.now()-lastRead)));};
  const wake=()=>{if(rootView()&&!rootView().hidden&&!document.hidden){if(Date.now()-lastRead>=300000&&!busy&&!document.getElementById('detail')?.open)load();else schedule();}else{clearTimeout(timer);timer=null;}};
  document.addEventListener('visibilitychange',wake);
  document.addEventListener('signed-out',()=>{clearTimeout(timer);timer=null;cache=null;});
  const canManage=()=>!!cache&&cache.canManage===true;
  function render(error){
    const host=document.querySelector(rootSel);
    if(!host)return;
    host.dataset.ready='1';
    if(error){host.innerHTML=`<p class="small red" role="alert">${esc(error)}</p><button class="button" type="button" data-aps-contract-action="reload">Thử lại</button>`;return;}
    if(!cache){host.innerHTML='<p class="small muted" role="status">Đang tải danh sách hợp đồng…</p>';return;}
    const contracts=cache.contracts||[];
    const rows=contracts.map(c=>`<tr>
      <td>${esc(c.no)}</td><td><strong>${esc(c.contractNo)}</strong></td><td>${esc(c.vendor)}</td>
      <td>${fmtDate(c.effectiveDate)}</td><td>${fmtDate(c.expiryDate)}</td>
      <td>${esc(c.createdBy||'—')}</td><td>${fmtTime(c.createdAt)}</td><td>${fmtTime(c.updatedAt)}</td>
      <td>${c.pdf?`<button class="text-button" type="button" data-aps-contract-action="download" data-no="${esc(c.contractNo)}" data-name="${esc(c.pdf.name||'')}" title="Tải file PDF về máy · ${esc(c.pdf.name||'file.pdf')} · ${fmtSize(c.pdf.size)} · ${esc(c.pdf.uploadedBy||'')} · lưu trong SQL">⬇ Tải về</button><span class="muted small"> ${esc(c.pdf.name||'file.pdf')} · ${fmtSize(c.pdf.size)}</span>${canManage()?`<button class="text-button red" type="button" data-aps-contract-action="delete-pdf" data-no="${esc(c.contractNo)}" data-name="${esc(c.pdf.name||'file.pdf')}" title="Xóa PDF khỏi hợp đồng trong SQL (giữ nguyên bản ghi hợp đồng)">xóa</button>`:''}`:`<span class="muted small">${cache&&cache.pdfSchemaReady===false?'chưa có cột PDF':'—'}</span>`}</td>
      <td>${canManage()?`<button class="text-button" type="button" data-aps-contract-action="edit" data-no="${esc(c.contractNo)}">Sửa</button>
      <button class="text-button" type="button" data-aps-contract-action="upload" data-no="${esc(c.contractNo)}">Tải lên PDF</button>`:'<span class="muted small">Chỉ xem</span>'}</td>
    </tr>`).join('');
    host.innerHTML=`<div class="table-scroll"><table class="aps-contract-table"><thead><tr>
      <th>No</th><th>Số hợp đồng</th><th>Vendor</th><th>Hiệu lực</th><th>Hết hạn</th><th>Tạo bởi</th><th>Tạo lúc</th><th>Cập nhật</th><th>PDF</th><th>Hành động</th>
    </tr></thead><tbody>${rows||'<tr><td colspan="10" class="muted">Chưa có hợp đồng nào trên SQL Server — bấm "Thêm hợp đồng" để tạo và kèm file PDF (chỉ Admin trở lên).</td></tr>'}</tbody></table></div>
    ${canManage()?'<button class="button primary" type="button" data-aps-contract-action="add">Thêm hợp đồng</button>':''}`;
  }
  async function load(force=false){
    if(busy)return;busy=true;
    try{cache=await api('aps/contracts');render();}
    catch(error){render(error&&error.message||'Không tải được danh sách hợp đồng.');}
    finally{busy=false;lastRead=Date.now();schedule();}
  }
  function dialogForm({heading='',contractNo='',vendor='',effectiveDate='',expiryDate='',allowPdf=false}){
    return `<p class="small muted">${heading}</p><form class="account-form" data-aps-contract-form>
      <label>Số hợp đồng (ContractNo)<input name="contractNo" required maxlength="100" value="${esc(contractNo)}" ${contractNo?'readonly':''}></label>
      <label>Vendor<input name="vendor" required maxlength="200" value="${esc(vendor)}"></label>
      <label>Ngày hiệu lực<input name="effectiveDate" type="date" value="${esc(effectiveDate)}"></label>
      <label>Ngày hết hạn<input name="expiryDate" type="date" value="${esc(expiryDate)}"></label>
      ${allowPdf?'<label>File hợp đồng (tùy chọn)<input name="pdf" type="file"></label><p class="small muted">Nhận mọi định dạng (PDF, Word/Excel, ảnh, file bị DRM công ty bảo vệ), tối đa 30 MB — lưu nguyên byte trực tiếp vào hợp đồng trong SQL (cột PdfData), một file mỗi hợp đồng, upload lại sẽ ghi đè. Mã hợp đồng nhập ở request Service phải khớp đúng Số hợp đồng này.</p>':''}
      <p class="small red" data-aps-contract-error role="alert" hidden></p>
      <button class="button primary" type="submit">Lưu</button>
    </form>`;
  }
  // 06/11/2026: <dialog> showModal() nằm ở top layer nên che mất toast — lỗi phải hiện NGAY TRONG dialog.
  function showFormError(form,message){
    const button=form.querySelector('button[type=submit]');if(button)button.disabled=false;
    const box=form.querySelector('[data-aps-contract-error]');
    const text=message||'Không lưu được hợp đồng.';
    if(box){box.textContent=text;box.hidden=false;box.scrollIntoView({block:'nearest'});}
    else toast(text);
  }
  function formValues(form){const f=new FormData(form);return {contractNo:String(f.get('contractNo')||'').trim(),vendor:String(f.get('vendor')||'').trim(),effectiveDate:String(f.get('effectiveDate')||''),expiryDate:String(f.get('expiryDate')||'')};}
    // Backend là nguồn thật của giới hạn (MAX_PDF trong backend/modules/aps/contracts.cjs = 30 MB);
  // chặn trước tại đây để không phí thời gian upload một file chắc chắn bị từ chối. Lỗi mạng
  // ("Failed to fetch" do socket bị cắt giữa chừng) được đổi thành thông điệp có nguyên nhân.
  const MAX_PDF_BYTES=30*1048576;
  const pdfTooBig=file=>'File '+fmtSize(file.size)+' vượt giới hạn 30 MB. Hãy nén hoặc tách file nhỏ hơn.';
  const uploadIssue=error=>{const raw=error&&error.message||'';return /failed to fetch|networkerror|load failed|err_network|err_connection|err_incomplete|err_timed_out/i.test(raw)?'Không gửi được file lên máy chủ (mất kết nối, máy chủ khởi động lại hoặc upload quá lâu). Kiểm tra kết nối rồi thử lại; file tối đa 30 MB.':(raw||'Không tải lên được file.');};
  const pdfBody=(contractNo,file)=>{const body=new FormData();body.append('no',contractNo);body.append('file',file,file.name||'hop-dong.pdf');return body;};
  // 09/11/2026 (quyết định người dùng): server không còn chặn theo định dạng — file bị DRM hay
  // Word/Excel vẫn được lưu nguyên byte. Nút "Tải về" cũng phải nhận application/octet-stream.
  const storedToast=(result,fallback)=>fallback+(result&&result.fileKind&&result.fileKind!=='pdf'&&result.fileKindNote?' '+result.fileKindNote:'');
  async function submit(form){
    const values=formValues(form),editing=form.dataset.editing==='1';
    const button=form.querySelector('button[type=submit]');button.disabled=true;
    try{
            const pdf=form.querySelector('input[name=pdf]')?.files?.[0]||null;
      if(pdf&&pdf.size>MAX_PDF_BYTES){button.disabled=false;showFormError(form,pdfTooBig(pdf));return;}
      const data=editing?await api('aps/contracts','PUT',{no:Number(form.dataset.no),...values}):await api('aps/contracts','POST',values);
      cache={...cache,contracts:data.contracts,canManage:cache.canManage};
      document.getElementById('detail').close();
      if(!editing&&pdf){
        try{
          const uploaded=await api('aps/contracts/pdf','POST',pdfBody(values.contractNo,pdf));
          cache={...cache,contracts:uploaded.contracts,canManage:cache.canManage,pdfSchemaReady:uploaded.pdfSchemaReady!==false};
          render();toast(storedToast(uploaded,'Đã thêm hợp đồng và lưu file vào SQL.'));
        }catch(pdfError){render();toast('Hợp đồng đã lưu nhưng chưa upload được PDF: '+uploadIssue(pdfError)+'. Bấm "Tải lên PDF" để thử lại.');}
        return;
      }
      render();toast(editing?'Đã cập nhật hợp đồng.':'Đã thêm hợp đồng.');
    }catch(error){showFormError(form,error&&error.message||'Không lưu được hợp đồng.');}
  }
  async function upload(form){
    const contractNo=form.dataset.no,file=form.querySelector('input[type=file]').files[0],button=form.querySelector('button[type=submit]');
    if(!file)return;if(file.size>MAX_PDF_BYTES){showFormError(form,pdfTooBig(file));return;}button.disabled=true;
    try{
      const data=await api('aps/contracts/pdf','POST',pdfBody(contractNo,file));
      cache={...cache,contracts:data.contracts,canManage:cache.canManage,pdfSchemaReady:data.pdfSchemaReady!==false};
      document.getElementById('detail').close();
      render();toast(storedToast(data,'Đã lưu file hợp đồng vào SQL.'));
    }catch(error){showFormError(form,uploadIssue(error));}
  }
  // Nút "⬇ Tải về": cùng route GET /api/aps/contracts/pdf (mọi phiên đã đăng nhập, GET không cần CSRF token).
  // Đọc blob rồi lưu qua <a download> để giữ đúng tên file và hiện được nguyên nhân lỗi (404 chưa có PDF,
  // 502 SQL lỗi) ngay tại chỗ, thay vì mở tab trắng như window.open.
  function saveBlob(blob,name,fallbackUrl){
    if(!window.URL||!URL.createObjectURL){window.open(fallbackUrl,'_blank');return;}
    const href=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=href;link.download=name;link.hidden=true;
    document.body.appendChild(link);link.click();link.remove();
    setTimeout(()=>URL.revokeObjectURL(href),30000);
  }
  function reportError(node,message){
    const dialog=document.getElementById('detail');
    if(node&&dialog&&!dialog.closed&&dialog.contains(node)){
      const box=dialog.querySelector('[data-aps-contract-error]');
      if(box){box.textContent=message;box.hidden=false;return;}
    }
    toast(message);
  }
  async function download(button){
    const contractNo=button.dataset.no||'';
    const fileName=/\.[A-Za-z0-9]{1,8}$/i.test(button.dataset.name||'')?button.dataset.name:`hop-dong-${contractNo}.pdf`;
    const url=`/api/aps/contracts/pdf?no=${encodeURIComponent(contractNo)}`;
    const label=button.textContent;
    button.disabled=true;button.textContent='Đang tải…';
    try{
      const response=await fetch(url,{credentials:'same-origin'});
      // 09/11/2026: file trong SQL có thể không phải PDF (bản DRM, Word/Excel, ảnh) → server trả
      // application/octet-stream. Chỉ cần HTTP ok; không còn từ chối vì thiếu Content-Type PDF.
      if(!response.ok){
        let reason='';
        try{const data=await response.json();reason=String(data&&data.message||'');}catch{reason='';}
        throw Error(reason||`Không tải được file đính kèm của hợp đồng ${contractNo} (HTTP ${response.status}).`);
      }
      saveBlob(await response.blob(),fileName,url);
      toast(`Đang tải file "${fileName}".`);
    }catch(error){reportError(button,error&&error.message||`Không tải được file đính kèm của hợp đồng ${contractNo}.`);}
    finally{button.disabled=false;button.textContent=label;}
  }
  // Dialog "Tải lên file" cho xem + tải lại file hiện tại trước khi ghi đè (file có thể không phải PDF).
  function currentPdf(contractNo){
    const row=cache&&cache.contracts&&cache.contracts.find(c=>c.contractNo===contractNo);
    if(!row||!row.pdf)return '';
    return `<p class="small muted">File hiện tại: <strong>${esc(row.pdf.name||'file.pdf')}</strong> · ${fmtSize(row.pdf.size)} · <button class="text-button" type="button" data-aps-contract-action="download" data-no="${esc(contractNo)}" data-name="${esc(row.pdf.name||'')}">⬇ Tải về</button> Upload file mới sẽ ghi đè bản này trong SQL.</p>`;
  }
  document.addEventListener('click',async event=>{
    const target=event.target instanceof Element?event.target.closest('[data-aps-contract-action]'):null;
    if(!target)return;
    const action=target.dataset.apsContractAction;
    if(action==='reload'){load(true);return;}
    const view=rootView();
    if(!view||view.hidden)return;
    if(action==='add'){
      showDetail('Thêm hợp đồng dịch vụ',dialogForm({heading:'Hợp đồng lưu trên SQL Server (EQM_MRO_ServiceContract). Số hợp đồng là khóa, trùng sẽ bị chặn. Có thể chọn kèm file PDF hợp đồng.',allowPdf:true}));
      return;
    }
    if(action==='edit'){
      const row=cache&&cache.contracts&&cache.contracts.find(c=>c.contractNo===target.dataset.no);
      if(!row)return;
      showDetail('Sửa hợp đồng',dialogForm({heading:'Số hợp đồng không đổi; chỉ sửa Vendor và ngày hiệu lực/hết hạn.',contractNo:row.contractNo,vendor:row.vendor,effectiveDate:row.effectiveDate||'',expiryDate:row.expiryDate||''}));
      const form=document.querySelector('[data-aps-contract-form]');
      if(form){form.dataset.editing='1';form.dataset.no=String(row.no);}
      return;
    }
    if(action==='upload'){
      showDetail('Tải lên file hợp đồng',`<p class="small muted">Hợp đồng <strong>${esc(target.dataset.no)}</strong>. Nhận mọi định dạng file (PDF, Word/Excel, ảnh, bản bị DRM công ty bảo vệ), tối đa 30 MB — lưu nguyên byte vào chính bản ghi hợp đồng trong SQL (upload lại sẽ ghi đè).</p>${currentPdf(target.dataset.no)}
      <form class="account-form" data-aps-contract-upload data-no="${esc(target.dataset.no)}">
        <label>File hợp đồng<input type="file" name="file" required></label>
        <p class="small red" data-aps-contract-error role="alert" hidden></p>
        <button class="button primary" type="submit">Tải lên</button>
      </form>`);
      return;
    }
    if(action==='delete-pdf'){
      if(!canManage())return;
      if(!window.confirm(`Xóa PDF "${target.dataset.name}" của hợp đồng ${target.dataset.no}?\n\nHợp đồng vẫn giữ nguyên trong SQL; chỉ nội dung PDF (cột PdfData) bị xóa.`))return;
      target.disabled=true;
      try{
        const data=await api(`aps/contracts/pdf?no=${encodeURIComponent(target.dataset.no)}`,'DELETE');
        cache={...cache,contracts:data.contracts,canManage:cache.canManage,pdfSchemaReady:data.pdfSchemaReady!==false};
        render();toast('Đã xóa PDF khỏi hợp đồng trong SQL.');
      }catch(error){toast(error&&error.message||'Không xóa được PDF.');target.disabled=false;}
      return;
    }
    if(action==='download'){await download(target);return;}// tải PDF: GET kèm cookie phiên, lưu blob giữ đúng tên file, lỗi hiện nguyên nhân
  });
  document.addEventListener('submit',event=>{
    const form=event.target instanceof Element?event.target:null;
    if(!form)return;
    if(form.matches('[data-aps-contract-form]')){event.preventDefault();submit(form);}
    else if(form.matches('[data-aps-contract-upload]')){event.preventDefault();upload(form);}
  });
  if(window.MutationObserver){
    const observer=new MutationObserver(()=>{
      if(!cache&&!busy&&rootView()&&!rootView().hidden)load();
      else if(cache&&document.querySelector(rootSel)&&!document.querySelector(rootSel).dataset.ready)render();
      if(rootView()&&!rootView().hidden&&Date.now()-lastRead>=300000&&!busy&&!document.getElementById('detail')?.open)load();
      else if(rootView()?.hidden){clearTimeout(timer);timer=null;}
      else if(!timer&&cache&&rootView()&&!rootView().hidden)schedule();
    });
    const views=document.getElementById('views');
    if(views)observer.observe(views,{attributes:true,attributeFilter:['hidden'],childList:true,subtree:true});
  }
  if(rootView()&&!rootView().hidden)load();
}
