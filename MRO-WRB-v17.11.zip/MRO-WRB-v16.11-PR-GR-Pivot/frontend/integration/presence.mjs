import {esc,showDetail} from '../shared/ui/index.mjs';

// Integration duy nhất của nút "Người đang dùng Portal": đọc GET /api/presence (server/auth.cjs).
// Chỉ import frontend/shared/ui/index.mjs; không import module/core khác, không fetch trực tiếp.
const intervalMs=30000;
const peopleLimit=200;
export function startPresence(api){
 const host=document.querySelector('.top-actions');if(!host)return;
 const button=document.createElement('button');button.type='button';button.id='presence';button.className='icon-button presence-chip';button.title='Người đang dùng Portal';button.setAttribute('aria-label','Người đang dùng Portal');button.hidden=true;
 button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg><span class="presence-count" hidden>0</span>';
 const divider=host.querySelector('.top-divider');if(divider)host.insertBefore(button,divider);else host.append(button);
 const count=button.querySelector('.presence-count');
 let timer,session=null,data=null,busy=false,generation=0,failures=0;
 function paint(){
  if(!session){button.hidden=true;count.hidden=true;return;}
  button.hidden=false;
  if(!data){count.hidden=true;button.classList.add('is-stale');button.title='Đang đọc số người dùng…';return;}
  count.hidden=false;count.textContent=data.total>99?'99+':String(data.total);
  button.classList.toggle('is-stale',failures>0);
  const label=data.users+' người đăng nhập · '+data.viewers+' lượt xem Viewer';
  button.title=label+(failures?' · chưa đọc lại được từ máy chủ':'')+' · bấm để xem chi tiết';
  button.setAttribute('aria-label','Người đang dùng Portal: '+label);
 }
 function stop(){clearTimeout(timer);timer=null;}
 function schedule(){stop();if(session&&!document.hidden)timer=setTimeout(check,intervalMs);}
 async function check(){
  if(!session||busy)return;busy=true;const token=generation;
  try{const result=await api('presence');if(token!==generation)return;data=result;failures=0;}
  catch{if(token!==generation)return;failures++;}
  finally{busy=false;if(token===generation){paint();schedule();}}
 }
 function stamp(value){return new Date(value).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'});}
 function open(){
  const minutes=data&&data.windowSeconds?Math.max(1,Math.round(data.windowSeconds/60)):2;
  if(!data){showDetail('Người đang dùng Portal','<p class="red" role="alert">Chưa đọc được số liệu từ máy chủ. Kiểm tra kết nối rồi bấm thử lại.</p><button class="button" type="button" id="presence-retry">Thử lại</button>');document.getElementById('presence-retry').onclick=()=>{check();open();};return;}
  const rows=data.people?`<ul class="presence-list">${data.people.slice(0,peopleLimit).map(p=>`<li><strong>${esc(p.name)}</strong><small>${esc(p.username)} · ${esc(p.role)}</small>${p.self?'<em>bạn</em>':''}<span>${p.viewer?'Chế độ Viewer (không sửa được)':'Tài khoản'} · hoạt động ${p.idleSeconds<=5?'vừa xong':p.idleSeconds+' giây trước'}${p.since?' · vào lúc '+stamp(p.since):''}</span></li>`).join('')}</ul>${data.people.length>=peopleLimit?'<small class="muted">Danh sách hiển thị tối đa 200 phiên.</small>':''}`:'<p class="muted">Chỉ Admin trở lên xem được danh sách ai đang online. Anh chỉ thấy số lượng.</p>';
  showDetail('Người đang dùng Portal',`<p><strong>${data.users}</strong> người đăng nhập · <strong>${data.viewers}</strong> lượt xem Viewer · tổng <strong>${data.total}</strong> phiên đang hoạt động.</p><p class="muted">Một phiên tính là đang online nếu có thao tác trong ${minutes} phút gần nhất. Số liệu tự làm mới mỗi 30 giây${failures?' · lần đọc gần nhất lỗi, đang giữ số liệu cũ':''}.</p>${rows}`);
 }
 button.onclick=open;
 document.addEventListener('auth-ready',event=>{stop();generation++;session=event.detail?.id||'session';data=null;failures=0;busy=false;paint();check();});
 document.addEventListener('signed-out',()=>{stop();generation++;session=null;data=null;failures=0;busy=false;paint();});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();else if(session)check();});
 window.addEventListener('pagehide',stop);
}
