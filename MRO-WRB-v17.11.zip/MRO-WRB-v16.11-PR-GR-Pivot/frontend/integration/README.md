# Procurement integration contract — Phase 6A/6B/6C

Public contract duy nhất: `procurement.mjs`. Export `procurementContract` giữ nguyên metadata bất biến của Phase 6A. Phase 6B thêm `appendCodeForConfirmedRequest(data,request)` và nối riêng handoff Orders → Codes vào runtime. Chỉ đúng file này được static allowlist theo ngoại lệ đã duyệt; không tạo event bus/framework.

## Ownership và luồng thực tế

| Dữ liệu | Owner hiện tại | Đường ghi |
| --- | --- | --- |
| requests | Orders | Create unshift; confirm sửa status/owner; Codes ready chỉ sửa owner của request đầu tiên cùng id |
| codes | Codes | Orders confirm append bản copy nếu id chưa có; Codes ready sửa Purchase Code/reason/time/status/step/owner |
| tracking | Tracking | Confirm sync thay cả mảng bằng kết quả merge theo pr:sq |
| purchaseLines | Snapshot Purchase giả lập | Chỉ đọc; không phải dữ liệu do Codes tạo |
| items | Snapshot Inventory | Orders chỉ đọc danh mục; không trừ tồn |
| budget | Snapshot ngân sách, ownership nghiệp vụ chưa chốt | Tracking đọc budget[9]/detail; không ghi |

Orders tạo request PIC1 → xác nhận chuyển PIC2, tạo code nếu chưa tồn tại → Codes ready chuyển owner PIC3. **Ready không tự tạo PR/tracking.** Tracking hiển thị ready codes, nhưng nhập PR từ purchaseLines hoặc JSON paste riêng. Không xóa ready codes sau sync, không cập nhật request/code owner từ Tracking.

## Contract hiện trạng

- Create: giữ ID REQ/max/padStart, Number(qty), item fields, nguồn/list/vendor/SOP/need, status chờ/PIC1/null PO; thêm đầu mảng, không tạo code ngay.
- Confirm: request status Đã xác nhận, owner PIC2. Code mới copy request sau cập nhật, originalCode=request.code, purchaseCode rỗng và các defaults trong contract; thêm cuối codes. Nếu ID có sẵn, không sửa/ghi đè code, dù owner hai bản ghi khác nhau.
- Ready: purchaseCode/reason từ form; confirmedAt=new Date().toISOString(); status/step Ready for PR, owner PIC3. Chỉ owner của request đầu tiên cùng ID đổi PIC3; không có request thì bỏ qua. Không đổi originalCode/code/request status hoặc tạo PR.
- Sync preview/cancel không ghi dữ liệu. Confirm map incoming tracking fallback, merge bằng Map pr:sq; thứ tự key cũ giữ, key mới append, dòng trùng cuối thắng, spread incoming đè existing. Mảng tracking mới; mảng requests/codes giữ tham chiếu. Dòng tracking không cập nhật có thể giữ tham chiếu object cũ.
- Paste form kiểm tra array không rỗng, string pr/sq/code/name/vendor, qty finite >0; sau đó helper merge validation. Paste thêm status/received theo phép `||`, không phải `??`. Direct sync không thêm hai defaults này.
- ConfirmSync không cập nhật tồn kho, budget, purchaseLines, requests hoặc codes. Reload raw phục hồi snapshot mẫu, không persist.

## Event và dependency

Create/confirm/ready: mutation → dialog.close → CustomEvent(data-edited) trên document → toast. Sync: mutation → event → toast. Event detail có thể chứa `views[]` để invalidation chọn lọc; detail rỗng giữ fallback mount toàn bộ sáu view. bubbles/cancelable=false. Core không fetch khi remount. Navigation giữ view; reload mới fetch, auth sign-out clear store. Không thay cơ chế này.

Orders dùng sopLate/ageDays; Codes dùng sopLate; Tracking dùng trackingKey/mergeTracking qua model facade và public-model Tracking. Shared card adapter đọc ready codes và purchaseLines chưa có pr+sq để tạo nguồn bảng tạm; không tự persist. Những dependency/data write này là nợ tích hợp được khóa trước refactor, không phải hướng dẫn thêm ghi chéo mới.

## Cách dùng và giới hạn

Chạy npm test cho contract/boundary/API. `tests/procurement.browser.cjs` chạy trong sandbox với Playwright/Chrome; biến MRO_FRONTEND_BASELINE trỏ checkpoint để so sánh cùng kịch bản. Test giữ reference tới JSON response trong browser tạm, quan sát mutation/event/DOM/toast thật; không gọi implementation giả thay thế handler. Timestamp được cố định trong browser test. Fixture hiếm (trùng ID, code thiếu request) chỉ chèn vào RAM của test.

Không import internal module khác. Contract không import module và không sửa schema. Handoff Orders confirm và Codes Ready đã chuyển vào integration; Tracking sync vẫn giữ implementation hiện tại. Module hóa Tracking cần task riêng. Hạn chế hiện tại (key dấu :, validation helper yếu hơn paste, owner chỉ cập nhật first match, Codes Ready chưa tạo PR) được giữ nguyên và test; không sửa bug ở Phase 6A.

## Cập nhật Phase 6B — handoff Orders

Phần mô tả Phase 6A phía trên là baseline; metadata procurementContract vẫn giữ nguyên. Public export mới appendCodeForConfirmedRequest(data,request) đã nối vào Orders runtime: caller patch request trước, helper chỉ append code khi thiếu ID, copy originalCode và defaults contract. Không ghi requests/tracking hoặc import Codes implementation. Chỉ đúng procurement.mjs được allowlist, không public cả integration directory. Node/browser tests tiếp tục kiểm tra đường chạy thực; không event bus. Tại Phase 6B, Ready/Tracking chưa chuyển vào integration; cập nhật Phase 6C bên dưới.

## Phase 6C — Ready → request đầu tiên

Thêm public handoffFirstRequestForReadyCode(data,code). Codes cập nhật purchaseCode/reason/confirmedAt/status/step/owner trước, integration dùng requests.find(q=>q.id===code.id), chỉ đổi owner request đầu tiên thành PIC3 nếu có. Không sửa status, duplicate còn lại hoặc tạo request cho orphan. Không ghi tracking, không import Orders implementation. Metadata procurementContract và appendCodeForConfirmedRequest giữ nguyên. Không thêm integration asset/allowlist hoặc framework.

