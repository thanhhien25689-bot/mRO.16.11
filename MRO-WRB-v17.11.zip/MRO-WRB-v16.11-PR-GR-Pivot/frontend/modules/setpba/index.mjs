﻿/**
 * SET/PBA Overview — Phase 4D.3B.1
 * Displays KPIs from /api/sp/* (Mock API when SP_USE_MOCK=1).
 * Read-only overview: total SET/PBA, OK/NG breakdown, stock by holder, InTransit, NG alerts.
 */
import { esc } from '../../shared/ui/index.mjs';
import { icon } from '../../../shared/icons.mjs';
import { vendorSession } from '../../../shared/auth-ui.mjs';
import { getHolder, onHolderChange, mountHolderSelect, resolveVendorHolder } from '../../shared/utils/holder-store.mjs';

const HOLDERS = ['SEV', 'ALT', 'ALV', 'BUJEON', 'CHITWING'];
const HOLDER_LABEL = { SEV: 'SEV', ALT: 'ALT', ALV: 'ALV', BUJEON: 'Bujeon', CHITWING: 'Chitwing' };

function fmt(n) {
  return Number.isFinite(n) ? n.toLocaleString('vi-VN') : '—';
}

const HOLDER_ICON = { SEV: 'warehouse', ALT: 'layers', ALV: 'layers', BUJEON: 'cpu', CHITWING: 'cpu' };

function holderOverview(visibleHolders, setUnits, pbaRows) {
  const PLOT_H = 96; // fixed chart plotting-area height in px

  // Total donut — combined SET+PBA for the filtered scope
  const totalOK = setUnits.filter(u => u.condition === 'OK').length
    + pbaRows.filter(r => r.condition === 'OK').reduce((s, r) => s + (r.qty || 0), 0);
  const totalNG = setUnits.filter(u => u.condition === 'NG').length
    + pbaRows.filter(r => r.condition === 'NG').reduce((s, r) => s + (r.qty || 0), 0);
  const totalAll = setUnits.length + pbaRows.reduce((s, r) => s + (r.qty || 0), 0);
  const R = 36, SW = 7, C = +(2 * Math.PI * R).toFixed(1);
  const okLen = totalAll > 0 ? +((totalOK / totalAll) * C).toFixed(1) : 0;
  const ngLen = totalAll > 0 ? +((totalNG / totalAll) * C).toFixed(1) : 0;
  const okPct = totalAll > 0 ? Math.round(totalOK / totalAll * 100) : 0;
  const ngPct = totalAll > 0 ? Math.round(totalNG / totalAll * 100) : 0;
  const tipT = `Tổng SET+PBA: ${fmt(totalAll)} · OK: ${fmt(totalOK)} (${okPct}%) · NG: ${fmt(totalNG)} (${ngPct}%)`;
  const totalDonut = `<svg class="sp-total-donut" width="90" height="90" viewBox="0 0 90 90" role="img" aria-label="${esc(tipT)}">
    <title>${esc(tipT)}</title>
    <circle cx="45" cy="45" r="${R}" fill="none" stroke="var(--track)" stroke-width="${SW}"/>
    ${totalAll > 0 ? `<circle cx="45" cy="45" r="${R}" fill="none" stroke="var(--mint)" stroke-width="${SW}" stroke-dasharray="${okLen} ${C}" transform="rotate(-90 45 45)"/>` : ''}
    ${totalNG > 0 ? `<circle cx="45" cy="45" r="${R}" fill="none" stroke="var(--red)" stroke-width="${SW}" stroke-dasharray="${ngLen} ${C}" stroke-dashoffset="${-okLen}" transform="rotate(-90 45 45)"/>` : ''}
    <text x="45" y="42" text-anchor="middle" fill="currentColor" font-size="13" font-weight="700">${fmt(totalAll)}</text>
    <text x="45" y="56" text-anchor="middle" fill="var(--muted)" font-size="9">SET+PBA</text>
  </svg>`;

  // Stacked bar column — NG on top, other (non-OK/NG) in middle, OK at bottom.
  // Segments rendered ONLY when value > 0. Stack uses justify-content:flex-end (via CSS)
  // so all rendered segments are grounded at the baseline with no floating gaps.
  function barCol(total, ok, ng, localMax, holderName, type) {
    const other  = Math.max(0, total - ok - ng);
    const colH   = localMax > 0 ? (total   / localMax) * PLOT_H : 0;
    const okH    = localMax > 0 ? (ok      / localMax) * PLOT_H : 0;
    const ngH    = localMax > 0 ? (ng      / localMax) * PLOT_H : 0;
    const otherH = localMax > 0 ? (other   / localMax) * PLOT_H : 0;
    const okPct    = total > 0 ? Math.round(ok    / total * 100) : 0;
    const ngPct    = total > 0 ? Math.round(ng    / total * 100) : 0;
    const otherPct = total > 0 ? Math.round(other / total * 100) : 0;
    const tipOK    = `${holderName} ${type} OK: ${fmt(ok)} (${okPct}%)`;
    const tipNG    = `${holderName} ${type} NG: ${fmt(ng)} (${ngPct}%)`;
    const tipOther = `${holderName} ${type} Khác: ${fmt(other)} (${otherPct}%) — điều kiện ngoài OK/NG`;
    // Topmost rendered segment (in flex-end order: NG first, other second, OK last) gets top rounding.
    const topSeg = ng > 0 ? 'ng' : other > 0 ? 'other' : ok > 0 ? 'ok' : null;
    const ngR    = ng    > 0 ? (topSeg === 'ng'    ? '3px 3px 0 0' : '0') : '';
    const otherR = other > 0 ? (topSeg === 'other' ? '3px 3px 0 0' : '0') : '';
    const okR    = ok    > 0 ? (topSeg === 'ok'    ? '3px 3px 0 0' : '0') : '';
    return `<div class="sp-bc">
      <div class="sp-bc-tot">${total > 0 ? fmt(total) : '—'}</div>
      <div class="sp-bc-area" style="height:${PLOT_H}px">
        ${total > 0
          ? `<div class="sp-bc-stack" style="height:${colH.toFixed(1)}px">
              ${ng    > 0 ? `<div class="sp-bc-ng"    style="height:${ngH.toFixed(1)}px;border-radius:${ngR}"    title="${esc(tipNG)}">${ngH    >= 16 ? fmt(ng)    : ''}</div>` : ''}
              ${other > 0 ? `<div class="sp-bc-other" style="height:${otherH.toFixed(1)}px;border-radius:${otherR}" title="${esc(tipOther)}">${otherH >= 16 ? fmt(other) : ''}</div>` : ''}
              ${ok    > 0 ? `<div class="sp-bc-ok"    style="height:${okH.toFixed(1)}px;border-radius:${okR}"    title="${esc(tipOK)}">${okH    >= 16 ? fmt(ok)    : ''}</div>` : ''}
            </div>`
          : `<div class="sp-bc-empty" style="height:${PLOT_H}px"></div>`}
      </div>
      <div class="sp-bc-lbl">${type}</div>
    </div>`;
  }

  // Build per-holder panels
  const panels = visibleHolders.map(h => {
    const sets = setUnits.filter(u => u.holderCode === h);
    const pba  = pbaRows.filter(r => r.holderCode === h);
    const sT = sets.length;
    const sOK = sets.filter(u => u.condition === 'OK').length;
    const sNG = sets.filter(u => u.condition === 'NG').length;
    const pT  = pba.reduce((s, r) => s + (r.qty || 0), 0);
    const pOK = pba.filter(r => r.condition === 'OK').reduce((s, r) => s + (r.qty || 0), 0);
    const pNG = pba.filter(r => r.condition === 'NG').reduce((s, r) => s + (r.qty || 0), 0);
    const localMax = Math.max(sT, pT, 1); // per-holder scale — independent of other holders
    const name = HOLDER_LABEL[h] || h;
    const hIcon = icon(HOLDER_ICON[h] || 'layers');
    const hasNG = sNG > 0 || pNG > 0;
    const holderTotal = sT + pT;
    return `<div class="sp-hp2${hasNG ? ' sp-hp2--ng' : ''}">
      <div class="sp-hp2-head">
        <div class="sp-hp2-title">${hIcon}<strong>${esc(name)}</strong></div>
        <span class="sp-hp2-htotal">${fmt(holderTotal)}</span>
      </div>
      <div class="sp-hp2-bars">
        ${barCol(sT, sOK, sNG, localMax, name, 'SET')}
        ${barCol(pT, pOK, pNG, localMax, name, 'PBA')}
      </div>
      <div class="sp-hp2-foot">
        <div class="sp-hp2-foot-row">
          <span class="sp-hp2-foot-lbl">SET</span>
          <b class="sp-hp2-foot-ok">${fmt(sOK)} OK</b>
          ${sNG > 0 ? `<em class="sp-hp2-foot-ng">${fmt(sNG)} NG</em>` : '<em class="sp-hp2-foot-zero">0 NG</em>'}
        </div>
        <div class="sp-hp2-foot-row">
          <span class="sp-hp2-foot-lbl">PBA</span>
          <b class="sp-hp2-foot-ok">${fmt(pOK)} OK</b>
          ${pNG > 0 ? `<em class="sp-hp2-foot-ng">${fmt(pNG)} NG</em>` : '<em class="sp-hp2-foot-zero">0 NG</em>'}
        </div>
      </div>
    </div>`;
  }).join('');

  return `<div class="sp-hov">
    <div class="sp-hov-legend">
      <span class="sp-leg-ok">■ OK</span>
      <span class="sp-leg-ng">■ NG</span>
      <span class="sp-leg-note" title="Chiều cao cột tính theo max(SET,PBA) của từng Holder riêng. Không so sánh tỷ lệ giữa các Holder khác nhau.">Tỷ lệ độc lập theo Holder ⓘ</span>
    </div>
    <div class="sp-hov-row">
      <div class="sp-hov-donut">
        <div class="sp-hov-donut-title">Tổng</div>
        ${totalDonut}
        <div class="sp-hov-donut-foot">
          <span class="sp-hov-ok">${fmt(totalOK)} OK</span>
          <span class="sp-hov-ng${totalNG > 0 ? '' : ' sp-hov-ng-zero'}">${fmt(totalNG)} NG</span>
        </div>
      </div>
      ${panels}
    </div>
  </div>`;
}

function kpiCard(value, label, sub, accent) {
  return `<div class="kpi-card${accent ? ' kpi-' + accent : ''}">
    <span class="kpi-value" data-count="${value}">${fmt(value)}</span>
    <span class="kpi-label">${esc(label)}</span>
    ${sub ? `<span class="kpi-sub">${esc(sub)}</span>` : ''}
  </div>`;
}

function holderRow(h, setUnits, pbaRows) {
  const sets = setUnits.filter(u => u.holderCode === h);
  const pba  = pbaRows.filter(r => r.holderCode === h);
  const setOK = sets.filter(u => u.condition === 'OK').length;
  const setNG = sets.filter(u => u.condition === 'NG').length;
  const pbaQty = pba.reduce((s, r) => s + (r.qty || 0), 0);
  const pbaNG  = pba.filter(r => r.condition === 'NG').reduce((s, r) => s + (r.qty || 0), 0);
  return `<tr>
    <td><strong>${esc(HOLDER_LABEL[h] || h)}</strong></td>
    <td>${fmt(sets.length)}</td>
    <td class="${setOK > 0 ? 'green' : ''}">${fmt(setOK)}</td>
    <td class="${setNG > 0 ? 'red' : ''}">${fmt(setNG)}</td>
    <td>${fmt(pbaQty)}</td>
    <td class="${pbaNG > 0 ? 'red' : ''}">${fmt(pbaNG)}</td>
  </tr>`;
}

function renderAlerts(alerts) {
  if (!alerts.length) return '<p class="small muted">Không có cảnh báo NG mới.</p>';
  return `<ul class="sp-alert-list">
    ${alerts.map(a => `<li>
      <span class="amber">${icon('warn')}</span>
      <span><strong>${esc(a.holderCode)}</strong> · ${esc(a.model || a.itemType)} · ${esc(a.reason || '')}</span>
      <span class="small muted">${esc(a.reportedAt ? new Date(a.reportedAt).toLocaleDateString('vi-VN') : '')}</span>
    </li>`).join('')}
  </ul>`;
}

function renderTransfers(inTransit) {
  if (!inTransit.length) return '<p class="small muted">Không có phiếu đang InTransit.</p>';
  return `<div class="table-scroll"><table class="sp-table">
    <thead><tr><th>Phiếu</th><th>Từ</th><th>Đến</th><th>Trạng thái</th><th>Ngày tạo</th></tr></thead>
    <tbody>
    ${inTransit.map(t => `<tr>
      <td><code>${esc(t.transferNo || String(t.transferId))}</code></td>
      <td>${esc(t.fromHolder)}</td>
      <td>${esc(t.toHolder)}</td>
      <td><span class="badge badge-transit">${esc(t.status)}</span></td>
      <td class="small muted">${esc(t.requestedAt ? new Date(t.requestedAt).toLocaleDateString('vi-VN') : '')}</td>
    </tr>`).join('')}
    </tbody>
  </table></div>`;
}

export function mount(root, _data, { api }) {
  const session = vendorSession();
  const isVendor = !!session?.vendorScope;
  // Resolve display name → canonical holder code (e.g. 'Almus Tech' → 'ALT')
  const ownHolder = isVendor ? (resolveVendorHolder(session.vendorScope) || session.vendorScope) : 'SEV';

  // Phase 4D.3E: holder from shared store; vendor is locked to own scope
  let selectedHolder = isVendor ? ownHolder : getHolder();

  root.innerHTML = `
    <section class="panel sp-overview" data-sp-panel>
      <div class="panel-head">
        <h2>${icon('stock')} SET/PBA Overview
          <span class="badge badge-demo" title="Mock API · SP_USE_MOCK=1">DEMO</span>
        </h2>
        <div class="sp-overview-controls">
          <span id="sp-ov-access-badge"></span>
          <button class="icon-button" id="sp-refresh" title="Tải lại dữ liệu SET/PBA" aria-label="Tải lại">${icon('refresh')}</button>
        </div>
      </div>
      <div id="sp-status" class="small muted" role="status">Đang tải dữ liệu…</div>
      <div id="sp-body"></div>
    </section>`;

  const status      = root.querySelector('#sp-status');
  const body        = root.querySelector('#sp-body');
  const accessBadge = root.querySelector('#sp-ov-access-badge');

  function updateAccessBadge() {
    const h = selectedHolder;
    if (!h) {
      accessBadge.innerHTML = '';
      return;
    }
    const isOwn = !isVendor || h === ownHolder;
    accessBadge.innerHTML = isOwn
      ? `<span class="badge badge-editable" title="Holder của bạn — thao tác ghi được phép">Có thể chỉnh sửa</span>`
      : `<span class="badge badge-readonly" title="Holder khác — chỉ xem tham khảo">Chỉ xem</span>`;
  }

  async function load() {
    status.textContent = 'Đang tải dữ liệu…';
    body.innerHTML = '';
    updateAccessBadge();
    try {
      const h = selectedHolder;
      const holderQ = h ? `&holder=${encodeURIComponent(h)}` : '';
      const tfHolderQ = h ? `&holder=${encodeURIComponent(h)}` : '';
      const [stockRes, setRes, pbaRes, tfRes, alertRes] = await Promise.all([
        api('sp/stock?inclDemo=1'),
        api(`sp/set?inclDemo=1${holderQ}`),
        api(`sp/pba?inclDemo=1${holderQ}`),
        api(`sp/transfer?status=InTransit${tfHolderQ}`),
        isVendor ? Promise.resolve({ alerts: [] }) : api('sp/ng-alerts?onlyNew=0'),
      ]);

      const setUnits  = setRes.units    || [];
      const pbaRows   = pbaRes.rows     || [];
      const transfers = tfRes.transfers || [];
      const alerts    = alertRes.alerts || [];

      const totalSet  = setUnits.length;
      const setOK     = setUnits.filter(u => u.condition === 'OK').length;
      const setNG     = setUnits.filter(u => u.condition === 'NG').length;
      const totalPba  = pbaRows.reduce((s, r) => s + (r.qty || 0), 0);
      const pbaOK     = pbaRows.filter(r => r.condition === 'OK').reduce((s, r) => s + (r.qty || 0), 0);
      const pbaNG     = pbaRows.filter(r => r.condition === 'NG').reduce((s, r) => s + (r.qty || 0), 0);
      const inTransit = transfers.filter(t => t.status === 'InTransit');
      const newAlerts = alerts.filter(a => a.alertStatus === 'New');

      // Holder table: show filtered or all
      const visibleHolders = h ? [h] : HOLDERS;

      body.innerHTML = `
        <div class="sp-ov-kpis">
          <div class="sp-ov-kpi">
            <span class="sp-ov-kpi-val">${fmt(totalSet)}</span>
            <div><div class="sp-ov-kpi-lbl">SET tổng</div><div class="sp-ov-kpi-sub">${fmt(setOK)} OK · ${setNG > 0 ? `<span style="color:var(--red)">${fmt(setNG)} NG</span>` : '0 NG'}</div></div>
          </div>
          <div class="sp-ov-kpi">
            <span class="sp-ov-kpi-val">${fmt(totalPba)}</span>
            <div><div class="sp-ov-kpi-lbl">PBA tổng</div><div class="sp-ov-kpi-sub">${fmt(pbaOK)} OK · ${pbaNG > 0 ? `<span style="color:var(--red)">${fmt(pbaNG)} NG</span>` : '0 NG'}</div></div>
          </div>
          <div class="sp-ov-kpi${inTransit.length > 0 ? ' sp-ov-kpi--amber' : ''}">
            <span class="sp-ov-kpi-val">${fmt(inTransit.length)}</span>
            <div><div class="sp-ov-kpi-lbl">InTransit</div></div>
          </div>
          ${!isVendor ? `<div class="sp-ov-kpi${newAlerts.length > 0 ? ' sp-ov-kpi--red' : ''}">
            <span class="sp-ov-kpi-val">${fmt(newAlerts.length)}</span>
            <div><div class="sp-ov-kpi-lbl">NG Alerts</div><div class="sp-ov-kpi-sub">chưa đọc</div></div>
          </div>` : ''}
        </div>

        <div class="sp-ov-subtitle">Tổng quan theo Holder</div>
        ${holderOverview(visibleHolders, setUnits, pbaRows)}

        <h3 class="sp-section-title">Phiếu đang vận chuyển (InTransit)</h3>
        ${renderTransfers(inTransit)}

        ${!isVendor ? `
          <h3 class="sp-section-title">NG Alerts</h3>
          ${renderAlerts(alerts)}
        ` : ''}
      `;

      status.textContent = `Cập nhật lúc ${new Date().toLocaleTimeString('vi-VN')}`;
    } catch (e) {
      status.setAttribute('role', 'alert');
      status.textContent = 'Không tải được dữ liệu SET/PBA: ' + e.message;
    }
  }

  // Phase 4D.3E: mount shared holder selector in topbar slot; subscribe to changes
  mountHolderSelect('sp-holder-slot', { isVendor, vendorCode: ownHolder });
  onHolderChange(h => { selectedHolder = isVendor ? ownHolder : h; load(); });
  root.querySelector('#sp-refresh').onclick = load;
  load();
  return {};
}
