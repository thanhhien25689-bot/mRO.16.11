/**
 * SET/PBA Operations — Phase 4D.3B.2A + 4D.3B.2B-1 (NG Reporting) + 4D.3B.2B-2 (Transfer Create)
 * Tabs: SET Inventory · PBA Inventory · Transfer & Receipt · NG Management · Movement History
 * Phase 4D.3B.2B-2: SEV can create multi-line Transfers (Requested) and dispatch to InTransit.
 */
import { tableController, showDetail, detailFields } from '../../shared/ui/index.mjs';
import { esc } from '../../shared/ui/index.mjs';
import { icon } from '../../../shared/icons.mjs';
import { vendorSession } from '../../../shared/auth-ui.mjs';
import { exportWorkbook } from '../../shared/utils/csv.mjs';
import { getHolder, onHolderChange, mountHolderSelect, resolveVendorHolder } from '../../shared/utils/holder-store.mjs';

const TABS = [
  { id: 'set',      label: 'SET Inventory' },
  { id: 'pba',      label: 'PBA Inventory' },
  { id: 'transfer', label: 'Transfer & Receipt' },
  { id: 'ng',       label: 'NG Management' },
  { id: 'movement', label: 'Movement History' },
  { id: 'adjreq',   label: 'Adj. Requests' },
];

const BADGE_DEMO = `<span class="badge badge-demo" title="Mock API · SP_USE_MOCK=1">DEMO</span>`;

function fmt(n) { return n == null ? '—' : Number(n).toLocaleString('vi-VN'); }
function fmtDate(s) { return s ? new Date(s).toLocaleDateString('vi-VN') : '—'; }
function condBadge(v) {
  if (!v) return '—';
  const cls = v === 'OK' ? 'mint' : v === 'NG' ? 'red' : 'amber';
  return `<span class="badge badge-${cls}">${esc(v)}</span>`;
}
function statusBadge(v) {
  if (!v) return '—';
  const cls = /Received|Closed|OK/.test(v) ? 'mint'
    : /Rejected|NG/.test(v) ? 'red'
    : /InTransit|Partial|New/.test(v) ? 'amber' : 'muted';
  return `<span class="badge badge-${cls}">${esc(v)}</span>`;
}

/* ---- Column definitions ---- */
// Action column buttons carry data-* attributes for event delegation; no inline onclick.
// _sevMode is set after identity resolves; buttons read it at render time.
let _sevMode = false;

const SET_NG_BTN = r => {
  const isNG = r.condition === 'NG';
  const isSEVHeld = r.holderCode === 'SEV';
  const inStock = r.stockState === 'InStock';
  const destroyBtn = (_sevMode && isNG && isSEVHeld && inStock)
    ? `<button class="button sp-destroy-btn" data-sp-destroy-set
         data-sn="${esc(r.sn || '')}"
         data-model="${esc(r.model || '')}"
         style="background:var(--red,#c0392b);color:#fff;margin-left:4px">Hủy</button>`
    : '';
  if (isNG) return `<span class="badge badge-red" style="font-size:9px">NG</span>${destroyBtn}`;
  return `<button class="button sp-ng-btn" data-sp-ng-set
       data-sn="${esc(r.sn || '')}"
       data-holder="${esc(r.holderCode || '')}"
       data-model="${esc(r.model || '')}"
       data-imei1="${esc(r.imei1 || '')}">Báo NG</button>`;
};

const PBA_NG_BTN = r => {
  const isNG = r.condition === 'NG';
  const isSEVHeld = r.holderCode === 'SEV';
  const hasQty = (r.qty ?? 0) > 0;
  const destroyBtn = (_sevMode && isNG && isSEVHeld && hasQty)
    ? `<button class="button sp-destroy-btn" data-sp-destroy-pba
         data-model="${esc(r.model || '')}"
         data-rack="${esc(r.rack || '')}"
         data-cond="${esc(r.condition || '')}"
         data-qty="${r.qty ?? 0}"
         style="background:var(--red,#c0392b);color:#fff;margin-left:4px">Hủy</button>`
    : '';
  return `<button class="button sp-ng-btn" data-sp-ng-pba
     data-holder="${esc(r.holderCode || '')}"
     data-model="${esc(r.model || '')}"
     data-rack="${esc(r.rack || '')}"
     data-cond="${esc(r.condition || '')}"
     data-qty="${r.qty ?? 0}">Báo NG</button>${destroyBtn}`;
};

const SET_COLS = [
  { key: 'sn',         label: 'SN' },
  { key: 'imei1',      label: 'IMEI1' },
  { key: 'model',      label: 'Model' },
  { key: 'basicModel', label: 'Basic Model' },
  { key: 'holderCode', label: 'Holder' },
  { label: 'Condition', render: r => condBadge(r.condition), value: r => r.condition || '' },
  { key: 'stockState', label: 'State' },
  { key: 'location',   label: 'Rack/Location' },
  { label: 'Demo', render: r => r.isDemo ? `<span class="badge badge-amber">DEMO</span>` : '—', value: r => r.isDemo ? 'Demo' : '' },
  { label: 'Thao tác', render: SET_NG_BTN, value: () => '' },
];
const SET_FILTERS = [
  { key: 'holderCode', label: 'Holder' },
  { key: 'condition',  label: 'Condition' },
  { key: 'stockState', label: 'State' },
];

const PBA_COLS = [
  { key: 'model',      label: 'Model' },
  { key: 'basicModel', label: 'Basic Model' },
  { key: 'holderCode', label: 'Holder' },
  { label: 'Condition', render: r => condBadge(r.condition), value: r => r.condition || '' },
  { key: 'rack',       label: 'Rack' },
  { label: 'Qty', render: r => `<strong>${fmt(r.qty)}</strong>`, value: r => r.qty ?? 0 },
  { label: 'Thao tác', render: PBA_NG_BTN, value: () => '' },
];
const PBA_FILTERS = [
  { key: 'holderCode', label: 'Holder' },
  { key: 'condition',  label: 'Condition' },
];

function tfCols(isVendor, vendorCode) {
  const actorHolder = isVendor ? vendorCode : 'SEV';
  const canDispatch     = r => r.status === 'Requested'    && r.fromHolder === actorHolder;
  const canReceive      = r => r.status === 'InTransit'    && r.toHolder   === actorHolder;
  const canReject       = r => r.status === 'InTransit'    && r.toHolder   === actorHolder;
  const canConfirmRet   = r => ['Rejected','PartialReceived'].includes(r.status) && r.fromHolder === actorHolder;

  function actionCell(r) {
    const btns = [];
    const id = r.transferId, no = esc(r.transferNo || '');
    if (canDispatch(r))   btns.push(`<button class="button sp-dispatch-btn" data-sp-dispatch data-tf-id="${id}" data-tf-no="${no}">Dispatch</button>`);
    if (canReceive(r))    btns.push(`<button class="button sp-receive-btn"  data-sp-receive  data-tf-id="${id}">Nhận hàng</button>`);
    if (canReject(r))     btns.push(`<button class="button sp-reject-btn"   data-sp-reject   data-tf-id="${id}">Từ chối</button>`);
    if (canConfirmRet(r)) btns.push(`<button class="button sp-return-btn"   data-sp-confirm-return data-tf-id="${id}">Xác nhận trả</button>`);
    return btns.length ? btns.join(' ') : '—';
  }

  return [
    { key: 'transferNo',   label: 'Phiếu' },
    { key: 'transferType', label: 'Loại' },
    { key: 'fromHolder',   label: 'Từ' },
    { key: 'toHolder',     label: 'Đến' },
    { label: 'Trạng thái', render: r => statusBadge(r.status), value: r => r.status || '' },
    { label: 'Ngày tạo',   render: r => fmtDate(r.requestedAt), value: r => r.requestedAt || '' },
    { label: 'Ngày xác nhận', render: r => fmtDate(r.confirmedAt), value: r => r.confirmedAt || '' },
    { label: 'Thao tác', render: actionCell, value: () => '' },
  ];
}
const TF_FILTERS = [
  { key: 'fromHolder', label: 'Từ Holder' },
  { key: 'toHolder',   label: 'Đến Holder' },
  { key: 'status',     label: 'Trạng thái' },
  { key: 'transferType', label: 'Loại' },
];

const NG_COLS = [
  { key: 'reportNo',   label: 'ReportNo' },
  { key: 'holderCode', label: 'Holder' },
  { key: 'itemType',   label: 'Loại' },
  { key: 'model',      label: 'Model' },
  { key: 'sn',         label: 'SN' },
  { label: 'Qty', render: r => fmt(r.qty), value: r => r.qty ?? '' },
  { key: 'reason',     label: 'Lý do' },
  { label: 'Trạng thái', render: r => statusBadge(r.status), value: r => r.status || '' },
  { label: 'Alert',    render: r => statusBadge(r.alertStatus), value: r => r.alertStatus || '' },
  { label: 'Ngày báo', render: r => fmtDate(r.reportedAt), value: r => r.reportedAt || '' },
];
const NG_FILTERS = [
  { key: 'holderCode',  label: 'Holder' },
  { key: 'status',      label: 'Trạng thái' },
  { key: 'alertStatus', label: 'Alert' },
  { key: 'itemType',    label: 'Loại' },
];

const MV_COLS = [
  { key: 'movementType',   label: 'Loại' },
  { key: 'itemType',       label: 'Item' },
  { key: 'holderCode',     label: 'Holder' },
  { key: 'counterHolder',  label: 'Counter' },
  { key: 'model',          label: 'Model' },
  { key: 'sn',             label: 'SN' },
  { label: 'QtyDelta', render: r => {
    const v = r.qtyDelta ?? 0;
    return `<span class="${v > 0 ? 'mint' : v < 0 ? 'red' : ''}">${v > 0 ? '+' : ''}${fmt(v)}</span>`;
  }, value: r => r.qtyDelta ?? 0 },
  { label: 'Thời gian', render: r => fmtDate(r.createdAt), value: r => r.createdAt || '' },
];
const MV_FILTERS = [
  { key: 'holderCode',   label: 'Holder' },
  { key: 'movementType', label: 'Loại' },
  { key: 'itemType',     label: 'Item type' },
];

function adjReqCols(isVendor) {
  function actionCell(r) {
    if (isVendor || r.status !== 'Pending') return statusBadge(r.status);
    const id = r.adjReqId;
    return `<span style="display:flex;gap:4px;flex-wrap:wrap">
      ${statusBadge(r.status)}
      <button class="button sp-adj-approve-btn" data-sp-adj-approve data-adj-id="${id}" style="font-size:11px;padding:2px 7px">Duyệt</button>
      <button class="button sp-adj-reject-btn"  data-sp-adj-reject  data-adj-id="${id}" style="font-size:11px;padding:2px 7px;color:var(--red)">Từ chối</button>
    </span>`;
  }
  return [
    { key: 'requestNo',  label: 'Phiếu' },
    { key: 'holderCode', label: 'Holder' },
    { key: 'model',      label: 'Model' },
    { key: 'condition',  label: 'Condition' },
    { key: 'rack',       label: 'Rack' },
    { label: 'Qty', render: r => `<strong>${fmt(r.qty)}</strong>`, value: r => r.qty ?? 0 },
    { key: 'direction',  label: 'Direction' },
    { key: 'reason',     label: 'Lý do' },
    { label: 'Trạng thái / Thao tác', render: actionCell, value: r => r.status || '' },
    { label: 'Ngày gửi', render: r => fmtDate(r.requestedAt), value: r => r.requestedAt || '' },
    { key: 'reviewedBy', label: 'Reviewed By' },
    { key: 'reviewNote', label: 'Review Note' },
  ];
}
const ADJ_REQ_FILTERS = [
  { key: 'holderCode', label: 'Holder' },
  { key: 'status',     label: 'Trạng thái' },
  { key: 'direction',  label: 'Direction' },
];

/* ---- Detail dialogs ---- */
function setDetail(r) {
  showDetail(r.sn || 'SET',
    detailFields({
      SN: r.sn || '—', IMEI1: r.imei1 || '—', IMEI2: r.imei2 || '—',
      Model: r.model || '—', 'Basic Model': r.basicModel || '—',
      Holder: r.holderCode || '—', Condition: r.condition || '—',
      'Stock State': r.stockState || '—', 'Rack/Location': r.location || '—',
      Origin: r.origin || '—', Remark: r.remark || '—',
      Demo: r.isDemo ? 'Có (IsDemo=1)' : 'Không',
      'Created At': fmtDate(r.createdAt),
    })
  );
}

function transferDetail(r) {
  const lineRows = (r.lines || []).map(l =>
    `<tr><td>${esc(l.lineId)}</td><td>${esc(l.itemType)}</td><td>${esc(l.model || '')}</td><td>${esc(l.sn || '')}</td><td>${fmt(l.qty)}</td><td>${fmt(l.receivedQty)}</td><td>${esc(l.condition || '')}</td></tr>`
  ).join('');
  showDetail(r.transferNo || 'Transfer',
    `${detailFields({
      'Transfer No': r.transferNo || '—', 'Loại': r.transferType || '—',
      'Từ': r.fromHolder || '—', 'Đến': r.toHolder || '—',
      'Trạng thái': r.status || '—', 'Ngày tạo': fmtDate(r.requestedAt),
      'Xác nhận bởi': r.confirmedBy || '—', 'Ngày xác nhận': fmtDate(r.confirmedAt),
      'Lý do từ chối': r.rejectReason || '—',
    })}
    <h3 style="margin:16px 0 8px">Dòng hàng</h3>
    <div class="table-scroll"><table><thead><tr><th>LineID</th><th>Loại</th><th>Model</th><th>SN</th><th>Qty</th><th>Received</th><th>Cond.</th></tr></thead>
    <tbody>${lineRows || '<tr><td colspan="7" class="empty-state">Không có dòng hàng.</td></tr>'}</tbody></table></div>`
  );
}

function ngDetail(r) {
  showDetail(r.reportNo || 'NG Report',
    detailFields({
      'Report No': r.reportNo || '—', Holder: r.holderCode || '—',
      'Item Type': r.itemType || '—', Model: r.model || '—',
      SN: r.sn || '—', Qty: fmt(r.qty),
      Reason: r.reason || '—', Status: r.status || '—',
      'Alert Status': r.alertStatus || '—',
      'Reported By': r.reportedBy || '—', 'Reported At': fmtDate(r.reportedAt),
      'Closed At': fmtDate(r.closedAt), 'Close Note': r.closeNote || '—',
    })
  );
}

/* ---- NG Report form ---- */
function showNgForm({ itemType, sn, imei1, holderCode, model, rack, condition, maxQty, onSubmit }) {
  const isPba = itemType === 'PBA';
  const title = `Báo NG · ${itemType} · ${esc(isPba ? model : sn)}`;
  const qtyField = isPba ? `
    <label style="display:flex;flex-direction:column;gap:6px;font-size:12px;color:var(--muted);grid-column:1/-1">
      Số lượng NG (tối đa ${maxQty})
      <input id="sp-ng-qty" type="number" min="1" max="${maxQty}" value="1" required style="font-size:13px">
    </label>` : '';
  showDetail(title, `
    <div class="detail-fields" style="margin-bottom:12px">
      ${isPba
        ? `<div><dt>Model</dt><dd>${esc(model)}</dd></div>
           <div><dt>Holder</dt><dd>${esc(holderCode)}</dd></div>
           <div><dt>Rack</dt><dd>${esc(rack || '—')}</dd></div>
           <div><dt>Condition hiện tại</dt><dd>${esc(condition || '—')}</dd></div>`
        : `<div><dt>SN</dt><dd>${esc(sn)}</dd></div>
           <div><dt>Holder</dt><dd>${esc(holderCode)}</dd></div>
           <div><dt>Model</dt><dd>${esc(model)}</dd></div>`}
    </div>
    <form id="sp-ng-form" class="form-grid">
      ${qtyField}
      <label style="display:flex;flex-direction:column;gap:6px;font-size:12px;color:var(--muted);grid-column:1/-1">
        Lý do NG <span class="red">*</span>
        <textarea id="sp-ng-reason" rows="3" maxlength="500" placeholder="Mô tả lỗi, vết nứt, thiếu linh kiện…" required style="font-size:13px"></textarea>
      </label>
      <p class="red small" id="sp-ng-err" role="alert" style="grid-column:1/-1"></p>
      <div style="display:flex;gap:10px;grid-column:1/-1">
        <button type="button" class="button" id="sp-ng-cancel">Hủy</button>
        <button type="submit" class="button primary" id="sp-ng-submit">Xác nhận Báo NG</button>
      </div>
    </form>
  `);
  document.getElementById('sp-ng-cancel').onclick = () => document.getElementById('detail').close();
  document.getElementById('sp-ng-form').onsubmit = async e => {
    e.preventDefault();
    const reason = document.getElementById('sp-ng-reason').value.trim();
    const qty = isPba ? Number(document.getElementById('sp-ng-qty').value) : 1;
    const errEl = document.getElementById('sp-ng-err');
    const submit = document.getElementById('sp-ng-submit');
    if (!reason) { errEl.textContent = 'Lý do NG là bắt buộc.'; return; }
    if (isPba && (!Number.isInteger(qty) || qty < 1 || qty > maxQty)) {
      errEl.textContent = `Số lượng phải từ 1 đến ${maxQty}.`; return;
    }
    submit.disabled = true;
    errEl.textContent = '';
    try {
      await onSubmit({ reason, qty });
      document.getElementById('detail').close();
    } catch (err) {
      errEl.textContent = err.message || 'Không gửi được báo NG.';
      submit.disabled = false;
    }
  };
}

/* ---- Destroy form (Phase 4D.5B — SEV only) ---- */
function showDestroyForm({ itemType, label, maxQty, onSubmit }) {
  const isPba = itemType === 'PBA';
  const qtyField = isPba ? `
    <label style="display:flex;flex-direction:column;gap:6px;font-size:12px;color:var(--muted);grid-column:1/-1">
      Số lượng hủy (tối đa ${maxQty})
      <input id="sp-dst-qty" type="number" min="1" max="${maxQty}" value="1" required style="font-size:13px">
    </label>` : '';
  showDetail(`Hủy (Destroy) · ${esc(label)}`, `
    <p style="color:var(--red,#c0392b);font-size:12px;margin-bottom:12px">
      ⚠ Thao tác này không thể hoàn tác. Chỉ SEV mới được phép thực hiện.
    </p>
    <form id="sp-dst-form" class="form-grid">
      ${qtyField}
      <label style="display:flex;flex-direction:column;gap:6px;font-size:12px;color:var(--muted);grid-column:1/-1">
        Lý do hủy <span class="red">*</span>
        <textarea id="sp-dst-reason" rows="3" maxlength="500" placeholder="Lý do hủy: hỏng không sửa được, hết hạn sử dụng…" required style="font-size:13px"></textarea>
      </label>
      <p class="red small" id="sp-dst-err" role="alert" style="grid-column:1/-1"></p>
      <div style="display:flex;gap:10px;grid-column:1/-1">
        <button type="button" class="button" id="sp-dst-cancel">Hủy bỏ</button>
        <button type="submit" class="button" id="sp-dst-submit"
          style="background:var(--red,#c0392b);color:#fff">Xác nhận Hủy</button>
      </div>
    </form>
  `);
  document.getElementById('sp-dst-cancel').onclick = () => document.getElementById('detail').close();
  document.getElementById('sp-dst-form').onsubmit = async e => {
    e.preventDefault();
    const reason = document.getElementById('sp-dst-reason').value.trim();
    const qty = isPba ? Number(document.getElementById('sp-dst-qty').value) : 1;
    const errEl = document.getElementById('sp-dst-err');
    const submit = document.getElementById('sp-dst-submit');
    if (!reason) { errEl.textContent = 'Lý do hủy là bắt buộc.'; return; }
    if (isPba && (!Number.isInteger(qty) || qty < 1 || qty > maxQty)) {
      errEl.textContent = `Số lượng phải từ 1 đến ${maxQty}.`; return;
    }
    submit.disabled = true;
    errEl.textContent = '';
    try {
      await onSubmit({ reason, qty });
      document.getElementById('detail').close();
    } catch (err) {
      errEl.textContent = err.message || 'Không thực hiện được thao tác Hủy.';
      submit.disabled = false;
    }
  };
}

/* ---- Transfer Receipt / Return forms ---- */

function showReceiveForm(transfer, onSubmit) {
  const lines = transfer.lines || [];
  const lineRows = lines.map(l => {
    const isSET = l.itemType === 'SET';
    const maxQty = l.qty - (l.receivedQty ?? 0);  // remaining to receive
    return `<tr>
      <td style="font-size:11px">${esc(l.itemType)}</td>
      <td style="font-size:11px">${esc(l.model || l.sn || '')}</td>
      <td style="font-size:11px">${esc(l.sn || '—')}</td>
      <td style="font-size:11px">${esc(l.condition || '')}</td>
      <td style="font-size:11px">${l.qty}</td>
      <td>${isSET
        ? `<select class="sp-recv-qty" data-line-id="${l.transferLineId}" style="font-size:11px">
             <option value="1">1 (Nhận)</option>
             <option value="0">0 (Trả lại)</option>
           </select>`
        : `<input type="number" class="sp-recv-qty" data-line-id="${l.transferLineId}" min="0" max="${maxQty}" value="${maxQty}" style="font-size:11px;width:60px">`}</td>
    </tr>`;
  }).join('');

  showDetail(`Nhận hàng · ${esc(transfer.transferNo || '')}`, `
    <div style="margin-bottom:10px;font-size:12px;color:var(--muted)">Từ <strong>${esc(transfer.fromHolder)}</strong> → <strong>${esc(transfer.toHolder)}</strong></div>
    <div class="table-scroll"><table>
      <thead><tr><th>Loại</th><th>Model/SN</th><th>SN</th><th>Cond.</th><th>Qty gửi</th><th>Qty nhận</th></tr></thead>
      <tbody id="sp-recv-tbody">${lineRows}</tbody>
    </table></div>
    <p class="red small" id="sp-recv-err" role="alert" style="margin-top:10px"></p>
    <div style="display:flex;gap:10px;margin-top:12px">
      <button type="button" class="button" id="sp-recv-cancel">Hủy</button>
      <button type="button" class="button primary" id="sp-recv-submit">Xác nhận nhận hàng</button>
    </div>
  `);

  document.getElementById('sp-recv-cancel').onclick = () => document.getElementById('detail').close();
  document.getElementById('sp-recv-submit').onclick = async () => {
    const errEl = document.getElementById('sp-recv-err');
    const submit = document.getElementById('sp-recv-submit');
    const partialLines = [...document.querySelectorAll('.sp-recv-qty')].map(el => ({
      transferLineId: Number(el.dataset.lineId),
      receivedQty: Number(el.value),
    }));
    const isPartial = partialLines.some((pl, i) => pl.receivedQty < (lines[i]?.qty ?? 0));
    submit.disabled = true; errEl.textContent = '';
    try {
      await onSubmit({ partialLines: isPartial ? partialLines : null });
      document.getElementById('detail').close();
    } catch (err) {
      errEl.textContent = err.message || 'Không nhận được hàng.';
      submit.disabled = false;
    }
  };
}

function showRejectForm(transfer, onSubmit) {
  showDetail(`Từ chối Transfer · ${esc(transfer.transferNo || '')}`, `
    <div style="margin-bottom:10px;font-size:12px;color:var(--muted)">Từ <strong>${esc(transfer.fromHolder)}</strong> → <strong>${esc(transfer.toHolder)}</strong></div>
    <label style="display:flex;flex-direction:column;gap:6px;font-size:12px;color:var(--muted)">
      Lý do từ chối <span class="red">*</span>
      <textarea id="sp-rej-reason" rows="3" maxlength="300" required style="font-size:13px"></textarea>
    </label>
    <p class="red small" id="sp-rej-err" role="alert" style="margin-top:8px"></p>
    <div style="display:flex;gap:10px;margin-top:12px">
      <button type="button" class="button" id="sp-rej-cancel">Hủy</button>
      <button type="button" class="button" style="color:var(--red);border-color:color-mix(in srgb,var(--red) 30%,var(--border))" id="sp-rej-submit">Xác nhận từ chối</button>
    </div>
  `);
  document.getElementById('sp-rej-cancel').onclick = () => document.getElementById('detail').close();
  document.getElementById('sp-rej-submit').onclick = async () => {
    const errEl = document.getElementById('sp-rej-err');
    const submit = document.getElementById('sp-rej-submit');
    const reason = document.getElementById('sp-rej-reason').value.trim();
    if (!reason) { errEl.textContent = 'Lý do từ chối là bắt buộc.'; return; }
    submit.disabled = true; errEl.textContent = '';
    try {
      await onSubmit({ rejectReason: reason });
      document.getElementById('detail').close();
    } catch (err) {
      errEl.textContent = err.message || 'Không từ chối được.';
      submit.disabled = false;
    }
  };
}

function showConfirmReturnForm(transfer, onSubmit) {
  const lines = transfer.lines || [];
  // Only lines with pending return qty
  const pending = lines.filter(l => {
    const totalReturn = l.qty - (l.receivedQty ?? 0);
    return totalReturn - (l.returnConfirmedQty ?? 0) > 0;
  });

  const lineRows = pending.map(l => {
    const totalReturn = l.qty - (l.receivedQty ?? 0);
    const alreadyConf = l.returnConfirmedQty ?? 0;
    const remaining   = totalReturn - alreadyConf;
    const isSET = l.itemType === 'SET';
    return `<tr>
      <td style="font-size:11px">${esc(l.itemType)}</td>
      <td style="font-size:11px">${esc(l.model || '')}</td>
      <td style="font-size:11px">${esc(l.sn || '—')}</td>
      <td style="font-size:11px">${remaining}</td>
      <td>${isSET
        ? `<select class="sp-ret-qty" data-line-id="${l.transferLineId}" style="font-size:11px">
             <option value="${remaining}">${remaining} (Nhận về)</option>
             <option value="0">0 (Chưa về)</option>
           </select>`
        : `<input type="number" class="sp-ret-qty" data-line-id="${l.transferLineId}" min="0" max="${remaining}" value="${remaining}" style="font-size:11px;width:60px">`}</td>
    </tr>`;
  }).join('');

  showDetail(`Xác nhận trả hàng · ${esc(transfer.transferNo || '')}`, `
    <div style="margin-bottom:10px;font-size:12px;color:var(--muted)">Nguồn <strong>${esc(transfer.fromHolder)}</strong> xác nhận nhận lại hàng hoàn trả</div>
    ${pending.length === 0 ? '<p class="small muted">Không có hàng chờ trả về.</p>' : `
    <div class="table-scroll"><table>
      <thead><tr><th>Loại</th><th>Model</th><th>SN</th><th>Chờ trả</th><th>Qty xác nhận</th></tr></thead>
      <tbody>${lineRows}</tbody>
    </table></div>
    <p class="red small" id="sp-ret-err" role="alert" style="margin-top:10px"></p>
    <div style="display:flex;gap:10px;margin-top:12px">
      <button type="button" class="button" id="sp-ret-cancel">Hủy</button>
      <button type="button" class="button primary" id="sp-ret-submit">Xác nhận nhận lại</button>
    </div>`}
  `);
  if (pending.length === 0) return;
  document.getElementById('sp-ret-cancel').onclick = () => document.getElementById('detail').close();
  document.getElementById('sp-ret-submit').onclick = async () => {
    const errEl = document.getElementById('sp-ret-err');
    const submit = document.getElementById('sp-ret-submit');
    const returnLines = [...document.querySelectorAll('.sp-ret-qty')].map(el => ({
      transferLineId: Number(el.dataset.lineId),
      returnConfirmedQty: Number(el.value),
    }));
    submit.disabled = true; errEl.textContent = '';
    try {
      await onSubmit({ returnLines });
      document.getElementById('detail').close();
    } catch (err) {
      errEl.textContent = err.message || 'Không xác nhận được.';
      submit.disabled = false;
    }
  };
}

/* ---- Transfer Create form ---- */
const HOLDERS = ['SEV','ALT','ALV','BUJEON','CHITWING'];
const TRANSFER_TYPES = ['Dispatch','Return','VendorToVendor'];

function showTransferCreateForm(onSubmit, { lockedFrom = null } = {}) {
  let lineCount = 0;

  function lineHtml(idx) {
    return `
      <div class="sp-tf-line" id="sp-tf-line-${idx}">
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <select id="sp-tf-ltype-${idx}" style="font-size:12px;min-width:70px">
            <option value="SET">SET</option>
            <option value="PBA">PBA</option>
          </select>
          <input id="sp-tf-model-${idx}" placeholder="Model" style="font-size:12px;width:140px">
          <input id="sp-tf-sn-${idx}" placeholder="SN (SET only)" style="font-size:12px;width:140px">
          <select id="sp-tf-cond-${idx}" style="font-size:12px;min-width:90px">
            <option value="OK">OK</option>
            <option value="NG">NG</option>
            <option value="Checking">Checking</option>
          </select>
          <input id="sp-tf-rack-${idx}" placeholder="Rack (PBA)" style="font-size:12px;width:90px">
          <input id="sp-tf-qty-${idx}" type="number" min="1" value="1" placeholder="Qty" style="font-size:12px;width:60px">
          <button type="button" class="button sp-tf-rm" data-tf-rm="${idx}" style="padding:3px 8px;font-size:11px">✕</button>
        </div>
      </div>`;
  }

  function addLine() {
    const idx = lineCount++;
    const container = document.getElementById('sp-tf-lines');
    if (!container) return;
    const div = document.createElement('div');
    div.innerHTML = lineHtml(idx);
    container.appendChild(div.firstElementChild);
  }

  showDetail('Tạo Transfer mới', `
    <form id="sp-tf-form" class="form-grid">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;grid-column:1/-1">
        <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted)">
          Từ Holder <span class="red">*</span>
          ${lockedFrom
            ? `<input id="sp-tf-from" value="${esc(lockedFrom)}" readonly style="font-size:13px;background:var(--panel-alt);color:var(--muted)">`
            : `<select id="sp-tf-from" style="font-size:13px">${HOLDERS.map(h => `<option value="${h}">${h}</option>`).join('')}</select>`}
        </label>
        <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted)">
          Đến Holder <span class="red">*</span>
          <select id="sp-tf-to" style="font-size:13px">
            ${HOLDERS.map(h => `<option value="${h}">${h}</option>`).join('')}
          </select>
        </label>
        <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted)">
          Loại Transfer
          <select id="sp-tf-type" style="font-size:13px">
            ${TRANSFER_TYPES.map(t => `<option value="${t}">${t}</option>`).join('')}
          </select>
        </label>
        <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted)">
          Lý do / Ghi chú
          <input id="sp-tf-reason" maxlength="200" placeholder="Tùy chọn" style="font-size:13px">
        </label>
      </div>
      <div style="grid-column:1/-1;border-top:1px solid var(--border);padding-top:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <strong style="font-size:12px">Dòng hàng</strong>
          <button type="button" class="button" id="sp-tf-add-line" style="font-size:11px;padding:4px 10px">+ Thêm dòng</button>
        </div>
        <div id="sp-tf-lines"></div>
      </div>
      <p class="red small" id="sp-tf-err" role="alert" style="grid-column:1/-1"></p>
      <div style="display:flex;gap:10px;grid-column:1/-1">
        <button type="button" class="button" id="sp-tf-cancel">Hủy</button>
        <button type="submit" class="button primary" id="sp-tf-submit">Tạo (Requested)</button>
      </div>
    </form>
  `);

  addLine(); // start with one line

  document.getElementById('sp-tf-add-line').onclick = addLine;
  document.getElementById('sp-tf-cancel').onclick = () => document.getElementById('detail').close();

  // Event delegation for remove buttons inside the lines container
  document.getElementById('sp-tf-lines').addEventListener('click', e => {
    const rm = e.target.closest('[data-tf-rm]');
    if (rm) {
      const lineEl = document.getElementById(`sp-tf-line-${rm.dataset.tfRm}`);
      if (lineEl) lineEl.remove();
    }
  });

  document.getElementById('sp-tf-form').onsubmit = async e => {
    e.preventDefault();
    const errEl = document.getElementById('sp-tf-err');
    const submit = document.getElementById('sp-tf-submit');
    const from = document.getElementById('sp-tf-from').value;
    const to   = document.getElementById('sp-tf-to').value;
    if (from === to) { errEl.textContent = 'FromHolder và ToHolder phải khác nhau.'; return; }

    // Collect lines
    const lineEls = document.querySelectorAll('.sp-tf-line');
    if (!lineEls.length) { errEl.textContent = 'Cần ít nhất một dòng hàng.'; return; }
    const lines = [];
    for (const el of lineEls) {
      const id = el.id.replace('sp-tf-line-', '');
      const itemType = document.getElementById(`sp-tf-ltype-${id}`)?.value;
      const model    = document.getElementById(`sp-tf-model-${id}`)?.value?.trim();
      const sn       = document.getElementById(`sp-tf-sn-${id}`)?.value?.trim();
      const condition= document.getElementById(`sp-tf-cond-${id}`)?.value;
      const rack     = document.getElementById(`sp-tf-rack-${id}`)?.value?.trim() || '';
      const qty      = Number(document.getElementById(`sp-tf-qty-${id}`)?.value) || 1;
      if (!model && !sn) { errEl.textContent = `Dòng ${id}: cần Model hoặc SN.`; return; }
      const line = { itemType, condition, remark: null };
      if (itemType === 'SET') {
        if (!sn) { errEl.textContent = `Dòng ${id}: SET cần SN.`; return; }
        line.sn = sn;
        if (model) line.model = model;
      } else {
        if (!model) { errEl.textContent = `Dòng ${id}: PBA cần Model.`; return; }
        line.model = model; line.fromRack = rack; line.qty = qty;
      }
      lines.push(line);
    }

    submit.disabled = true; errEl.textContent = '';
    try {
      const result = await onSubmit({
        fromHolder: from, toHolder: to,
        transferType: document.getElementById('sp-tf-type').value,
        reason: document.getElementById('sp-tf-reason').value.trim() || null,
        lines,
      });
      document.getElementById('detail').close();
      return result;
    } catch (err) {
      errEl.textContent = err.message || 'Không tạo được Transfer.';
      submit.disabled = false;
    }
  };
}

/* ---- Phase 4D.3F: Stock Addition & Adjustment (Batch 2A) ---- */

// Template columns per legacy SEV Enterprise Control Tower
const ADD_PBA_COLS  = ['Model name','Basic Model','Condition','Rack','Qty','Reason'];
const ADJ_PBA_COLS  = ['Model name','Basic Model','Condition','Rack','Qty','Direction','Reason'];

function downloadAddTemplate() {
  exportWorkbook([{
    name: 'Template',
    rows: [
      { 'Model name': 'PBA-MAINBOARD-S24', 'Basic Model': 'Mainboard S24', 'Condition': 'OK', 'Rack': 'R-01', 'Qty': '10', 'Reason': 'Nhập kho mới' },
      { 'Model name': 'PBA-DISPLAY-S24',   'Basic Model': 'Display S24',   'Condition': 'OK', 'Rack': 'R-02', 'Qty': '5',  'Reason': 'Bổ sung tồn kho' },
    ],
    columns: ADD_PBA_COLS.map(k => ({ key: k, label: k })),
  }], 'Template_Stock_Add_PBA');
}

function downloadAdjustTemplate() {
  exportWorkbook([{
    name: 'Template',
    rows: [
      { 'Model name': 'PBA-MAINBOARD-S24', 'Basic Model': 'Mainboard S24', 'Condition': 'OK', 'Rack': 'R-01', 'Qty': '5', 'Direction': 'IN',  'Reason': 'Nhận thêm từ nhà máy' },
      { 'Model name': 'PBA-DISPLAY-S24',   'Basic Model': 'Display S24',   'Condition': 'OK', 'Rack': 'R-02', 'Qty': '2', 'Direction': 'OUT', 'Reason': 'Thanh lý hỏng' },
    ],
    columns: ADJ_PBA_COLS.map(k => ({ key: k, label: k })),
  }], 'Template_Stock_Adjust_PBA');
}

function parseAddRows(rawRows) {
  return rawRows.map(r => ({
    model:      pick(r, 'Model name', 'Model'),
    basicModel: pick(r, 'Basic Model') || null,
    condition:  pick(r, 'Condition') || 'OK',
    rack:       pick(r, 'Rack') || '',
    qty:        Number(pick(r, 'Qty', 'Quantity')) || 0,
    remark:     pick(r, 'Reason', 'Remark', 'Note') || null,
  })).filter(r => r.model);
}

function parseAdjustRows(rawRows) {
  return rawRows.map(r => ({
    model:      pick(r, 'Model name', 'Model'),
    basicModel: pick(r, 'Basic Model') || null,
    condition:  pick(r, 'Condition') || 'OK',
    rack:       pick(r, 'Rack') || '',
    qty:        Number(pick(r, 'Qty', 'Quantity')) || 0,
    direction:  (pick(r, 'Direction') || 'IN').toUpperCase(),
    remark:     pick(r, 'Reason', 'Remark', 'Note') || null,
  })).filter(r => r.model);
}

function validateAddRows(rows) {
  const errs = [];
  const keysSeen = new Set();
  rows.forEach((r, i) => {
    if (!r.model) { errs.push({ row: i+2, msg: 'Model trống.' }); return; }
    if (!Number.isInteger(r.qty) || r.qty <= 0) { errs.push({ row: i+2, model: r.model, msg: `Qty không hợp lệ: ${r.qty}` }); return; }
    const k = `${r.model}|${r.condition}|${r.rack}`;
    if (keysSeen.has(k)) { errs.push({ row: i+2, model: r.model, msg: `Dòng trùng: model/condition/rack đã có ở trên.` }); return; }
    keysSeen.add(k);
  });
  return errs;
}

function validateAdjustRows(rows) {
  const errs = [];
  const keysSeen = new Set();
  rows.forEach((r, i) => {
    if (!r.model) { errs.push({ row: i+2, msg: 'Model trống.' }); return; }
    if (!Number.isInteger(r.qty) || r.qty <= 0) { errs.push({ row: i+2, model: r.model, msg: `Qty không hợp lệ: ${r.qty}` }); return; }
    if (!['IN','OUT'].includes(r.direction)) { errs.push({ row: i+2, model: r.model, msg: `Direction phải là IN hoặc OUT (nhận được: ${r.direction})` }); return; }
    const k = `${r.model}|${r.condition}|${r.rack}|${r.direction}`;
    if (keysSeen.has(k)) { errs.push({ row: i+2, model: r.model, msg: 'Dòng trùng.' }); return; }
    keysSeen.add(k);
  });
  return errs;
}

function renderPbaOpPreview(parsedRows, errors, container, extraColLabel) {
  const total   = parsedRows.length;
  const invalid = errors.length;
  const valid   = total - invalid;
  let html = `<div style="margin-bottom:8px;display:flex;gap:12px;flex-wrap:wrap">`;
  html += `<span>Tổng Excel: <strong>${total}</strong></span>`;
  html += `<span class="${valid > 0 ? 'green' : ''}">Hợp lệ: <strong>${Math.max(0, valid)}</strong></span>`;
  if (invalid) html += `<span class="red">Lỗi: <strong>${invalid}</strong></span>`;
  if (total === 0) html += `<span class="red">Không đọc được dòng nào — kiểm tra sheet "Template" và tên cột.</span>`;
  html += '</div>';
  if (invalid) {
    html += `<ul class="small red" style="margin:4px 0 8px 16px">`;
    errors.slice(0, 10).forEach(e => { html += `<li>Dòng ${e.row}${e.model ? ` (${esc(e.model)})` : ''}: ${esc(e.msg)}</li>`; });
    if (errors.length > 10) html += `<li>… và ${errors.length - 10} lỗi khác</li>`;
    html += '</ul>';
  }
  const validRows = parsedRows;
  if (validRows.length) {
    const extra = extraColLabel ? `<th>${esc(extraColLabel)}</th>` : '';
    const extraVal = r => extraColLabel ? `<td>${esc(r.direction || '')}</td>` : '';
    html += `<div class="table-scroll"><table class="sp-table">
      <thead><tr><th>#</th><th>Model</th><th>Basic Model</th><th>Condition</th><th>Rack</th><th>Qty</th>${extra}<th>Reason</th></tr></thead><tbody>`;
    validRows.slice(0, 20).forEach((r, i) => {
      html += `<tr><td class="small muted">${i+2}</td><td>${esc(r.model)}</td><td>${esc(r.basicModel||'')}</td><td>${esc(r.condition)}</td><td>${esc(r.rack)}</td><td><strong>${r.qty}</strong></td>${extraVal(r)}<td class="small muted">${esc(r.remark||'')}</td></tr>`;
    });
    if (validRows.length > 20) html += `<tr><td colspan="8" class="small muted">… và ${validRows.length-20} dòng khác</td></tr>`;
    html += '</tbody></table></div>';
  }
  container.innerHTML = html;
}

function downloadAdjRequestTemplate() {
  exportWorkbook([{
    name: 'Template',
    rows: [
      { 'Model name': 'PBA-MAINBOARD-S24', 'Basic Model': 'Mainboard S24', 'Condition': 'OK', 'Rack': 'R-01', 'Qty': '5', 'Direction': 'IN',  'Reason': 'Nhận thêm từ nhà máy' },
      { 'Model name': 'PBA-DISPLAY-S24',   'Basic Model': 'Display S24',   'Condition': 'OK', 'Rack': 'R-02', 'Qty': '2', 'Direction': 'OUT', 'Reason': 'Trả lại SEV' },
    ],
    columns: ADJ_PBA_COLS.map(k => ({ key: k, label: k })),
  }], 'Template_RequestAdjust_PBA');
}

function showAdjRequestFlow(ownHolder, onDone) {
  showDetail('Yêu cầu điều chỉnh tồn kho', `
    <div class="sp-bulk-reg">
      <p class="small muted" style="margin-bottom:10px">Holder: <strong>${esc(ownHolder)}</strong> · Yêu cầu sẽ ở trạng thái <strong>Pending</strong>, không thay đổi tồn kho cho đến khi SEV phê duyệt.</p>
      <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <button class="button" id="sp-adjreq-dl-tpl">⬇ Tải Template Excel</button>
        <span class="small muted">Cột Direction: IN (tăng) hoặc OUT (giảm)</span>
      </div>
      <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center">
        <label class="button primary" for="sp-adjreq-file" style="cursor:pointer">📂 Chọn file .xlsx</label>
        <input type="file" id="sp-adjreq-file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" style="position:absolute;opacity:0;pointer-events:none">
        <span id="sp-adjreq-fname" class="small muted">Chưa chọn file</span>
      </div>
      <div id="sp-adjreq-preview"></div>
      <div id="sp-adjreq-actions" hidden style="margin-top:12px">
        <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted);max-width:280px;margin-bottom:10px">
          PIC xác nhận <span class="red">*</span>
          <input id="sp-adjreq-pic" maxlength="80" placeholder="Tên / ID người gửi yêu cầu" style="font-size:13px">
        </label>
        <div style="display:flex;gap:8px;align-items:center">
          <button class="button primary" id="sp-adjreq-submit">✓ Gửi yêu cầu (Pending)</button>
          <button class="button" id="sp-adjreq-cancel">Hủy</button>
          <span id="sp-adjreq-status" class="small muted" style="margin-left:4px"></span>
        </div>
      </div>
    </div>`);

  document.getElementById('sp-adjreq-dl-tpl').onclick = downloadAdjRequestTemplate;
  document.getElementById('sp-adjreq-cancel').onclick = () => document.getElementById('detail')?.close();
  const fileInput = document.getElementById('sp-adjreq-file');
  document.querySelector('label[for="sp-adjreq-file"]').onclick = () => fileInput.click();

  let validRows = [];

  fileInput.addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    document.getElementById('sp-adjreq-fname').textContent = file.name;
    const previewEl = document.getElementById('sp-adjreq-preview');
    previewEl.innerHTML = '<span class="small muted">Đang phân tích…</span>';
    try {
      const sheets = await parseXlsxFile(file);
      const rows = sheets['Template'] || Object.values(sheets)[0] || [];
      const parsed = parseAdjustRows(rows);
      const errs = validateAdjustRows(parsed);
      const errRows = new Set(errs.map(e => e.row - 2));
      validRows = parsed.filter((_, i) => !errRows.has(i));
      renderPbaOpPreview(parsed, errs, previewEl, 'Direction');
      const actionsEl = document.getElementById('sp-adjreq-actions');
      if (actionsEl) actionsEl.hidden = validRows.length === 0;
    } catch (err) {
      previewEl.innerHTML = `<p class="red small">Lỗi đọc file: ${esc(err.message)}</p>`;
    }
  });

  document.getElementById('sp-adjreq-submit').onclick = async () => {
    const pic = document.getElementById('sp-adjreq-pic')?.value?.trim();
    const statusEl = document.getElementById('sp-adjreq-status');
    if (!pic) { statusEl.textContent = 'Nhập tên PIC.'; return; }
    if (!validRows.length) { statusEl.textContent = 'Không có dòng hợp lệ.'; return; }
    const btn = document.getElementById('sp-adjreq-submit');
    btn.disabled = true;
    statusEl.textContent = 'Đang gửi…';
    const requestId = Array.from(crypto.getRandomValues(new Uint32Array(4)), n => n.toString(16).padStart(8,'0')).join('');
    try {
      const result = await onDone({ requestId, pbas: validRows, pic });
      statusEl.textContent = `✓ Đã gửi ${result.submitted} yêu cầu (Pending — chờ SEV phê duyệt)`;
      btn.textContent = '✓ Đã gửi';
    } catch (err) {
      statusEl.textContent = 'Lỗi: ' + (err.message || 'Không gửi được.');
      btn.disabled = false;
    }
  };
}

function showRejectAdjForm(adjReqId, onSubmit) {
  showDetail(`Từ chối yêu cầu #${adjReqId}`, `
    <label style="display:flex;flex-direction:column;gap:6px;font-size:12px;color:var(--muted)">
      Lý do từ chối <span class="red">*</span>
      <textarea id="sp-adjrej-reason" rows="3" maxlength="300" required style="font-size:13px"></textarea>
    </label>
    <p class="red small" id="sp-adjrej-err" role="alert" style="margin-top:8px"></p>
    <div style="display:flex;gap:10px;margin-top:12px">
      <button type="button" class="button" id="sp-adjrej-cancel">Hủy</button>
      <button type="button" class="button" style="color:var(--red);border-color:color-mix(in srgb,var(--red) 30%,var(--border))" id="sp-adjrej-confirm">Xác nhận từ chối</button>
    </div>`);
  document.getElementById('sp-adjrej-cancel').onclick = () => document.getElementById('detail').close();
  document.getElementById('sp-adjrej-confirm').onclick = async () => {
    const errEl = document.getElementById('sp-adjrej-err');
    const reason = document.getElementById('sp-adjrej-reason').value.trim();
    if (!reason) { errEl.textContent = 'Lý do là bắt buộc.'; return; }
    const btn = document.getElementById('sp-adjrej-confirm');
    btn.disabled = true; errEl.textContent = '';
    try {
      await onSubmit({ rejectReason: reason });
      document.getElementById('detail').close();
    } catch (err) {
      errEl.textContent = err.message || 'Không từ chối được.';
      btn.disabled = false;
    }
  };
}

function showStockAddFlow(ownHolder, onDone) {
  showDetail('Bổ sung tồn kho PBA', `
    <div class="sp-bulk-reg">
      <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <button class="button" id="sp-add-dl-tpl">⬇ Tải Template Excel</button>
        <span class="small muted">Sheet "Template" · Model name, Basic Model, Condition, Rack, Qty, Reason</span>
      </div>
      <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center">
        <label class="button primary" for="sp-add-file" style="cursor:pointer">📂 Chọn file .xlsx</label>
        <input type="file" id="sp-add-file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" style="position:absolute;opacity:0;pointer-events:none">
        <span id="sp-add-fname" class="small muted">Chưa chọn file</span>
      </div>
      <div id="sp-add-preview"></div>
      <div id="sp-add-actions" hidden style="margin-top:12px">
        <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted);max-width:280px;margin-bottom:10px">
          PIC xác nhận <span class="red">*</span>
          <input id="sp-add-pic" maxlength="80" placeholder="Tên / ID người xác nhận" style="font-size:13px">
        </label>
        <div style="display:flex;gap:8px;align-items:center">
          <button class="button primary" id="sp-add-confirm">✓ Xác nhận bổ sung</button>
          <button class="button" id="sp-add-cancel">Hủy</button>
          <span id="sp-add-status" class="small muted" style="margin-left:4px"></span>
        </div>
      </div>
    </div>`);

  document.getElementById('sp-add-dl-tpl').onclick = downloadAddTemplate;
  document.getElementById('sp-add-cancel').onclick = () => document.getElementById('detail')?.close();
  const fileInput = document.getElementById('sp-add-file');
  document.querySelector('label[for="sp-add-file"]').onclick = () => fileInput.click();

  let validRows = [];

  fileInput.addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    document.getElementById('sp-add-fname').textContent = file.name;
    const previewEl = document.getElementById('sp-add-preview');
    previewEl.innerHTML = '<span class="small muted">Đang phân tích…</span>';
    try {
      const sheets = await parseXlsxFile(file);
      const rows = sheets['Template'] || sheets['NEW_PBA'] || Object.values(sheets)[0] || [];
      const parsed = parseAddRows(rows);
      const errs = validateAddRows(parsed);
      validRows = errs.length ? [] : parsed;
      renderPbaOpPreview(parsed, errs, previewEl, null);
      const actionsEl = document.getElementById('sp-add-actions');
      if (actionsEl) actionsEl.hidden = errs.length > 0 || parsed.length === 0;
    } catch (err) {
      previewEl.innerHTML = `<p class="red small">Lỗi đọc file: ${esc(err.message)}</p>`;
    }
  });

  document.getElementById('sp-add-confirm').onclick = async () => {
    const pic = document.getElementById('sp-add-pic')?.value?.trim();
    const statusEl = document.getElementById('sp-add-status');
    if (!pic) { statusEl.textContent = 'Nhập tên PIC.'; return; }
    if (!validRows.length) { statusEl.textContent = 'Không có dòng hợp lệ.'; return; }
    const btn = document.getElementById('sp-add-confirm');
    btn.disabled = true;
    statusEl.textContent = 'Đang bổ sung…';
    const requestId = Array.from(crypto.getRandomValues(new Uint32Array(4)), n => n.toString(16).padStart(8,'0')).join('');
    try {
      const result = await onDone({ requestId, pbas: validRows, pic });
      statusEl.textContent = `✓ Đã bổ sung ${result.added} dòng PBA`;
      btn.textContent = '✓ Đã xong';
    } catch (err) {
      statusEl.textContent = 'Lỗi: ' + (err.message || 'Không bổ sung được.');
      btn.disabled = false;
    }
  };
}

function showAdjustFlow(ownHolder, onDone) {
  showDetail('Điều chỉnh tồn kho PBA', `
    <div class="sp-bulk-reg">
      <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <button class="button" id="sp-adj-dl-tpl">⬇ Tải Template Excel</button>
        <span class="small muted">Sheet "Template" · Cột Direction: IN (tăng) hoặc OUT (giảm)</span>
      </div>
      <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center">
        <label class="button primary" for="sp-adj-file" style="cursor:pointer">📂 Chọn file .xlsx</label>
        <input type="file" id="sp-adj-file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" style="position:absolute;opacity:0;pointer-events:none">
        <span id="sp-adj-fname" class="small muted">Chưa chọn file</span>
      </div>
      <div id="sp-adj-preview"></div>
      <div id="sp-adj-actions" hidden style="margin-top:12px">
        <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted);max-width:280px;margin-bottom:10px">
          PIC xác nhận <span class="red">*</span>
          <input id="sp-adj-pic" maxlength="80" placeholder="Tên / ID người xác nhận" style="font-size:13px">
        </label>
        <div style="display:flex;gap:8px;align-items:center">
          <button class="button primary" id="sp-adj-confirm">✓ Xác nhận điều chỉnh</button>
          <button class="button" id="sp-adj-cancel">Hủy</button>
          <span id="sp-adj-status" class="small muted" style="margin-left:4px"></span>
        </div>
      </div>
    </div>`);

  document.getElementById('sp-adj-dl-tpl').onclick = downloadAdjustTemplate;
  document.getElementById('sp-adj-cancel').onclick = () => document.getElementById('detail')?.close();
  const fileInput = document.getElementById('sp-adj-file');
  document.querySelector('label[for="sp-adj-file"]').onclick = () => fileInput.click();

  let validRows = [];

  fileInput.addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    document.getElementById('sp-adj-fname').textContent = file.name;
    const previewEl = document.getElementById('sp-adj-preview');
    previewEl.innerHTML = '<span class="small muted">Đang phân tích…</span>';
    try {
      const sheets = await parseXlsxFile(file);
      const rows = sheets['Template'] || Object.values(sheets)[0] || [];
      const parsed = parseAdjustRows(rows);
      const errs = validateAdjustRows(parsed);
      validRows = errs.length ? [] : parsed;
      renderPbaOpPreview(parsed, errs, previewEl, 'Direction');
      const actionsEl = document.getElementById('sp-adj-actions');
      if (actionsEl) actionsEl.hidden = errs.length > 0 || parsed.length === 0;
    } catch (err) {
      previewEl.innerHTML = `<p class="red small">Lỗi đọc file: ${esc(err.message)}</p>`;
    }
  });

  document.getElementById('sp-adj-confirm').onclick = async () => {
    const pic = document.getElementById('sp-adj-pic')?.value?.trim();
    const statusEl = document.getElementById('sp-adj-status');
    if (!pic) { statusEl.textContent = 'Nhập tên PIC.'; return; }
    if (!validRows.length) { statusEl.textContent = 'Không có dòng hợp lệ.'; return; }
    const btn = document.getElementById('sp-adj-confirm');
    btn.disabled = true;
    statusEl.textContent = 'Đang điều chỉnh…';
    const requestId = Array.from(crypto.getRandomValues(new Uint32Array(4)), n => n.toString(16).padStart(8,'0')).join('');
    try {
      const result = await onDone({ requestId, pbas: validRows, pic });
      const inCount  = result.adjusted?.filter(r => r.direction === 'IN').length  || 0;
      const outCount = result.adjusted?.filter(r => r.direction === 'OUT').length || 0;
      statusEl.textContent = `✓ IN: ${inCount} · OUT: ${outCount} dòng đã điều chỉnh`;
      btn.textContent = '✓ Đã xong';
    } catch (err) {
      statusEl.textContent = 'Lỗi: ' + (err.message || 'Không điều chỉnh được.');
      btn.disabled = false;
    }
  };
}

/* ---- Phase 4D.3F: Legacy header alias helper ---- */
// Pick first non-empty value from row using multiple header aliases (supports legacy + new column names)
function pick(row, ...keys) {
  for (const k of keys) {
    const v = row[k];
    if (v != null && String(v).trim()) return String(v).trim();
  }
  return '';
}

/* ---- Phase 4D.3D-1: Bulk Registration ---- */

// Minimal xlsx parser: reads sheet XML strings → array of row objects keyed by header row
function parseXlsxSheet(sharedStrings, sheetXml) {
  // Extract shared strings
  const ss = [];
  const siRe = /<si>([\s\S]*?)<\/si>/g;
  let m;
  while ((m = siRe.exec(sharedStrings)) !== null) {
    const tRe = /<t(?:[^>]*)>([\s\S]*?)<\/t>/g;
    let txt = '', tm;
    while ((tm = tRe.exec(m[1])) !== null) txt += tm[1];
    ss.push(txt.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&#13;/g,'\r'));
  }

  function cellVal(c) {
    const t = (c.match(/t="([^"]*)"/) || [])[1];
    if (t === 'inlineStr') {
      const isM = c.match(/<is>([\s\S]*?)<\/is>/);
      if (!isM) return '';
      const tM = isM[1].match(/<t(?:[^>]*)>([\s\S]*?)<\/t>/);
      return tM ? tM[1].replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&#13;/g,'\r') : '';
    }
    const v = (c.match(/<v>([^<]*)<\/v>/) || [])[1];
    if (v == null) return '';
    return t === 's' ? (ss[Number(v)] || '') : v;
  }

  const rows = [];
  const rowRe = /<row[^>]*>([\s\S]*?)<\/row>/g;
  while ((m = rowRe.exec(sheetXml)) !== null) {
    const cells = {};
    const cRe = /<c r="([A-Z]+)\d+"([^>]*)>([\s\S]*?)<\/c>/g;
    let cm;
    while ((cm = cRe.exec(m[1])) !== null) {
      const col = cm[1];
      cells[col] = cellVal(cm[2] + cm[3]);
    }
    rows.push(cells);
  }
  return rows;
}

function colIndex(letter) {
  let n = 0;
  for (const ch of letter) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

function mapRowsToObjects(rawRows) {
  if (rawRows.length < 1) return [];
  // First row = headers
  const headerRow = rawRows[0];
  const cols = Object.keys(headerRow).sort((a, b) => colIndex(a) - colIndex(b));
  const headers = cols.map(c => headerRow[c]);
  return rawRows.slice(1).map(row => {
    const obj = {};
    cols.forEach((c, i) => { if (headers[i]) obj[headers[i]] = row[c] || ''; });
    return obj;
  }).filter(row => Object.values(row).some(v => v.trim && v.trim()));
}

async function parseXlsxFile(file) {
  // v4D.3F — inlineStr + DEFLATE support
  const buf = await file.arrayBuffer();
  const bytes = new Uint8Array(buf);

  async function inflate(compData) {
    // DecompressionStream('deflate-raw') is available in all modern browsers and Node.js 18+
    const ds = new DecompressionStream('deflate-raw');
    const writer = ds.writable.getWriter();
    const reader = ds.readable.getReader();
    writer.write(compData);
    writer.close();
    const chunks = [];
    let done, value;
    while (({ done, value } = await reader.read()), !done) chunks.push(value);
    const totalLen = chunks.reduce((s, c) => s + c.length, 0);
    const result = new Uint8Array(totalLen);
    let pos = 0;
    for (const chunk of chunks) { result.set(chunk, pos); pos += chunk.length; }
    return result;
  }

  async function readZip(bytes) {
    // Read from Central Directory (end of ZIP) so compSize is always correct,
    // even when Excel sets the data-descriptor flag (bit 3) and writes compSize=0
    // in the local file header.
    const files = {};
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const u16 = at => dv.getUint16(at, true);
    const u32 = at => dv.getUint32(at, true);

    // Locate End of Central Directory (EOCD) by scanning backwards from end
    let eocdOff = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65558); i--) {
      if (bytes[i]===0x50&&bytes[i+1]===0x4B&&bytes[i+2]===0x05&&bytes[i+3]===0x06) {
        eocdOff = i; break;
      }
    }
    if (eocdOff < 0) return files;

    const cdCount = u16(eocdOff + 10);
    const cdOff   = u32(eocdOff + 16);

    let cdPos = cdOff;
    for (let e = 0; e < cdCount; e++) {
      if (u32(cdPos) !== 0x02014b50) break;
      const method     = u16(cdPos + 10);
      const compSize   = u32(cdPos + 20);
      const fnLen      = u16(cdPos + 28);
      const extraLen   = u16(cdPos + 30);
      const cmtLen     = u16(cdPos + 32);
      const lhOff      = u32(cdPos + 42);
      const name       = new TextDecoder().decode(bytes.slice(cdPos + 46, cdPos + 46 + fnLen));
      // Data starts after local file header (30 bytes) + local fn + local extra
      const lhFnLen    = u16(lhOff + 26);
      const lhExtraLen = u16(lhOff + 28);
      const dataStart  = lhOff + 30 + lhFnLen + lhExtraLen;
      const compData   = bytes.slice(dataStart, dataStart + compSize);
      if (method === 0) {
        files[name] = new TextDecoder().decode(compData);
      } else if (method === 8) {
        try { files[name] = new TextDecoder().decode(await inflate(compData)); } catch (e) {
          console.error('[SP-ZIP] inflate error for', name, e.message);
        }
      }
      cdPos += 46 + fnLen + extraLen + cmtLen;
    }
    return files;
  }

  const files = await readZip(bytes);
  const ss = files['xl/sharedStrings.xml'] || '';
  const wbXml = files['xl/workbook.xml'] || '';

  const sheetNames = [];
  const sheetRe = /<sheet name="([^"]*)"[^/]*/g;
  let sm;
  while ((sm = sheetRe.exec(wbXml)) !== null)
    sheetNames.push(sm[1].replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"'));

  const result = {};
  sheetNames.forEach((name, idx) => {
    const xml = files[`xl/worksheets/sheet${idx+1}.xml`] || '';
    result[name] = mapRowsToObjects(parseXlsxSheet(ss, xml));
  });
  if (!sheetNames.length)
    console.error('[parseXlsxFile] No sheets. ZIP entries:', Object.keys(files));
  return result;
}

// Legacy column names per SEV Enterprise Control Tower (formTemplateExcel / downloadTemplate).
// SN, IMEI, UN columns are marked TEXT (z='@') in exportWorkbook to prevent leading-zero loss.
const NEW_SET_COLS  = ['SN','Model name','Basic Model','IMEI','IMEI2','UN','Origin','Mode','CRO No','Remark'];
const NEW_PBA_COLS  = ['Model name','Basic Model','Condition','Rack','Qty','Origin','Remark'];
const SEV_INV_COLS  = ['No.','Model name','Basic model','Serial','UN','IMEI','IMEI2','S/N','Type','Origin','Qty','Dept.','Status','Location','CRO no.','Remark'];

function downloadRegisterTemplate() {
  const setRows = [
    { 'SN': 'SN-001-EXAMPLE', 'Model name': 'SM-S928U', 'Basic Model': 'Galaxy S24 Ultra', 'IMEI': '352999001234567', 'IMEI2': '', 'UN': '', 'Origin': 'Vietnam', 'Mode': 'Lot', 'CRO No': '', 'Remark': '' },
    { 'SN': 'SN-002-EXAMPLE', 'Model name': 'SM-S928U', 'Basic Model': 'Galaxy S24 Ultra', 'IMEI': '', 'IMEI2': '', 'UN': '', 'Origin': 'Vietnam', 'Mode': 'Lot', 'CRO No': '', 'Remark': '' },
  ];
  const pbaRows = [
    { 'Model name': 'PBA-MAINBOARD-S24', 'Basic Model': 'Mainboard S24', 'Condition': 'OK', 'Rack': 'R-01', 'Qty': '10', 'Origin': 'Vietnam', 'Remark': '' },
    { 'Model name': 'PBA-DISPLAY-S24',   'Basic Model': 'Display S24',   'Condition': 'OK', 'Rack': 'R-02', 'Qty': '5',  'Origin': 'Vietnam', 'Remark': '' },
  ];
  exportWorkbook([
    { name: 'NEW_SET', rows: setRows, columns: NEW_SET_COLS.map(k => ({ key: k, label: k })), textCols: ['SN','IMEI','IMEI2','UN'] },
    { name: 'NEW_PBA', rows: pbaRows, columns: NEW_PBA_COLS.map(k => ({ key: k, label: k })) },
  ], 'Template_Register_SET_PBA');
}

function downloadSevInventoryTemplate() {
  const sampleRow = {
    'No.': '1', 'Model name': 'SM-S928U', 'Basic model': 'Galaxy S24 Ultra',
    'Serial': 'SER-001', 'UN': '', 'IMEI': '352999001234567', 'IMEI2': '',
    'S/N': 'SN-001-EXAMPLE', 'Type': 'SET', 'Origin': 'Vietnam',
    'Qty': '1', 'Dept.': 'SEV', 'Status': 'OK', 'Location': 'R-01',
    'CRO no.': '', 'Remark': '',
  };
  exportWorkbook([
    { name: 'Template', rows: [sampleRow], columns: SEV_INV_COLS.map(k => ({ key: k, label: k })), textCols: ['Serial','UN','IMEI','IMEI2','S/N'] },
  ], 'Template_SEV_Inventory');
}

function showBulkRegisterFlow(onRegistered, currentSets = []) {
  showDetail('Ghi nhận SET/PBA mới', `
    <div class="sp-bulk-reg">
      <div style="margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <button class="button" id="sp-bulk-dl-tpl">⬇ Template Ghi nhận (NEW_SET / NEW_PBA)</button>
        <button class="button" id="sp-bulk-dl-inv-tpl">⬇ Template Kiểm kê SEV</button>
        <span class="small muted">File .xlsx — dùng header tiếng Anh theo chuẩn SEV Enterprise</span>
      </div>
      <div style="margin-bottom:12px">
        <label class="button" for="sp-bulk-file" style="cursor:pointer">📂 Chọn file Excel (.xlsx)</label>
        <input type="file" id="sp-bulk-file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" style="position:absolute;opacity:0;pointer-events:none">
        <span id="sp-bulk-filename" class="small muted" style="margin-left:10px">Chưa chọn file</span>
      </div>
      <div id="sp-bulk-preview"></div>
      <div id="sp-bulk-actions" hidden style="margin-top:12px">
        <button class="button primary" id="sp-bulk-confirm">✓ Xác nhận đăng ký</button>
        <button class="button" id="sp-bulk-cancel">Hủy</button>
        <span id="sp-bulk-status" class="small muted" style="margin-left:10px"></span>
      </div>
    </div>
  `);

  document.getElementById('sp-bulk-dl-tpl').onclick = downloadRegisterTemplate;
  document.getElementById('sp-bulk-dl-inv-tpl').onclick = downloadSevInventoryTemplate;

  let parsedSets = [], parsedPbas = [], validSets = [], validPbas = [];

  document.getElementById('sp-bulk-file').addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    document.getElementById('sp-bulk-filename').textContent = file.name;
    const preview = document.getElementById('sp-bulk-preview');
    preview.innerHTML = '<p class="small muted">Đang phân tích file…</p>';
    try {
      const sheets = await parseXlsxFile(file);
      parsedSets = sheets['NEW_SET'] || [];
      parsedPbas = sheets['NEW_PBA'] || [];
      renderPreview(parsedSets, parsedPbas, preview);
    } catch (err) {
      preview.innerHTML = `<p class="red small">Lỗi đọc file: ${esc(err.message)}</p>`;
    }
  });

  document.getElementById('sp-bulk-file').parentElement.querySelector('label').onclick = () =>
    document.getElementById('sp-bulk-file').click();

  function validateRows(sets, pbas) {
    const errs = [];
    const snSeen = new Set();
    sets.forEach((row, i) => {
      const sn = pick(row, 'SN', 'S/N', 'Serial');
      if (!sn) errs.push({ sheet: 'NEW_SET', row: i+2, msg: 'SN trống' });
      else if (snSeen.has(sn)) errs.push({ sheet: 'NEW_SET', row: i+2, msg: `SN trùng trong file: ${sn}` });
      else snSeen.add(sn);
    });
    pbas.forEach((row, i) => {
      const model = pick(row, 'Model name', 'Model');
      if (!model) errs.push({ sheet: 'NEW_PBA', row: i+2, msg: 'Model trống' });
      const qty = Number(pick(row, 'Qty', 'Quantity'));
      if (!Number.isInteger(qty) || qty <= 0) errs.push({ sheet: 'NEW_PBA', row: i+2, msg: `Qty không hợp lệ: ${pick(row,'Qty','Quantity')}` });
    });
    return errs;
  }

  function renderPreview(sets, pbas, container) {
    // Map rows using both legacy headers (Model name, Basic Model, IMEI, S/N, UN, …) and new headers
    validSets = sets.map(r => ({
      sn:         pick(r, 'SN', 'S/N', 'Serial'),
      model:      pick(r, 'Model name', 'Model') || null,
      basicModel: pick(r, 'Basic Model') || null,
      imei1:      pick(r, 'IMEI', 'IMEI1') || null,
      imei2:      pick(r, 'IMEI2') || null,
      un:         pick(r, 'UN') || null,
      origin:     pick(r, 'Origin') || null,
      mode:       pick(r, 'Mode') || null,
      location:   pick(r, 'Rack', 'Location') || null,
      cro:        pick(r, 'CRO No', 'CRO') || null,
      remark:     pick(r, 'Remark', 'Note') || null,
      condition:  pick(r, 'Condition') || 'OK',
    })).filter(r => r.sn);
    validPbas = pbas.map(r => ({
      model:      pick(r, 'Model name', 'Model'),
      basicModel: pick(r, 'Basic Model') || null,
      condition:  pick(r, 'Condition') || 'OK',
      rack:       pick(r, 'Rack') || '',
      qty:        Number(pick(r, 'Qty', 'Quantity')) || 0,
      origin:     pick(r, 'Origin') || null,
      remark:     pick(r, 'Remark', 'Note') || null,
    })).filter(r => r.model);
    const errs = validateRows(sets, pbas);

    let html = `<div style="margin-bottom:8px"><strong>${validSets.length}</strong> SET · <strong>${validPbas.length}</strong> PBA`;
    if (errs.length) html += ` · <span class="red">${errs.length} lỗi</span>`;
    html += '</div>';

    if (validSets.length) {
      html += `<p class="small muted sp-section-title">NEW_SET (${validSets.length} dòng)</p>
        <div class="table-scroll"><table class="sp-table"><thead><tr><th>#</th><th>SN</th><th>Model</th><th>Basic Model</th><th>IMEI</th><th>UN</th><th>Origin</th></tr></thead><tbody>`;
      validSets.slice(0,20).forEach((r,i) => {
        html += `<tr><td class="small muted">${i+2}</td><td><code>${esc(r.sn)}</code></td><td>${esc(r.model||'')}</td><td>${esc(r.basicModel||'')}</td><td class="small">${esc(r.imei1||'')}</td><td class="small">${esc(r.un||'')}</td><td class="small">${esc(r.origin||'')}</td></tr>`;
      });
      if (validSets.length > 20) html += `<tr><td colspan="7" class="small muted">… và ${validSets.length-20} SET khác</td></tr>`;
      html += '</tbody></table></div>';
    }

    if (validPbas.length) {
      html += `<p class="small muted sp-section-title">NEW_PBA (${validPbas.length} dòng)</p>
        <div class="table-scroll"><table class="sp-table"><thead><tr><th>#</th><th>Model</th><th>Basic Model</th><th>Condition</th><th>Rack</th><th>Qty</th></tr></thead><tbody>`;
      validPbas.forEach((r,i) => {
        html += `<tr><td class="small muted">${i+2}</td><td>${esc(r.model)}</td><td>${esc(r.basicModel||'')}</td><td>${esc(r.condition)}</td><td>${esc(r.rack)}</td><td>${esc(String(r.qty))}</td></tr>`;
      });
      html += '</tbody></table></div>';
    }

    if (errs.length) {
      html += `<p class="small red sp-section-title">Lỗi validation (${errs.length})</p><ul class="small red" style="margin:4px 0 0 16px">`;
      errs.slice(0,10).forEach(e => { html += `<li>${esc(e.sheet)} dòng ${e.row}: ${esc(e.msg)}</li>`; });
      if (errs.length > 10) html += `<li>… và ${errs.length-10} lỗi khác</li>`;
      html += '</ul>';
    }

    container.innerHTML = html;
    const actions = document.getElementById('sp-bulk-actions');
    if (actions) {
      actions.hidden = errs.length > 0 || (validSets.length + validPbas.length === 0);
    }
  }

  const confirmBtn = document.getElementById('sp-bulk-confirm');
  const cancelBtn  = document.getElementById('sp-bulk-cancel');
  const statusEl   = document.getElementById('sp-bulk-status');

  if (cancelBtn) cancelBtn.onclick = () => document.getElementById('detail')?.close();

  if (confirmBtn) confirmBtn.onclick = async () => {
    confirmBtn.disabled = true;
    statusEl.textContent = 'Đang đăng ký…';
    const requestId = Array.from(crypto.getRandomValues(new Uint32Array(4)), n => n.toString(16).padStart(8,'0')).join('');
    try {
      const result = await onRegistered({ requestId, sets: validSets, pbas: validPbas });
      statusEl.textContent = `✓ Đã đăng ký ${result.registered.sets} SET + ${result.registered.pbas} PBA`;
      confirmBtn.textContent = '✓ Đã xong';
    } catch (err) {
      statusEl.textContent = 'Lỗi: ' + (err.message || 'Không đăng ký được.');
      confirmBtn.disabled = false;
    }
  };
}

/* ---- Transfer Import Wizard (Phase 4D.3D-2B) ---- */

// SET: required SN; optional Model, IMEI1, IMEI2
const TI_SET_FIELDS = [
  { key: 'sn',    label: 'SN',    required: true  },
  { key: 'model', label: 'Model', required: false },
  { key: 'imei1', label: 'IMEI1', required: false },
  { key: 'imei2', label: 'IMEI2', required: false },
];
// PBA: required Model, Qty; optional Condition, Rack
const TI_PBA_FIELDS = [
  { key: 'model',     label: 'Model',     required: true  },
  { key: 'qty',       label: 'Qty',       required: true  },
  { key: 'condition', label: 'Condition', required: false },
  { key: 'rack',      label: 'Rack',      required: false },
];

function downloadTransferTemplate() {
  exportWorkbook([
    {
      name: 'SET_TRANSFER',
      rows: [
        { SN: 'SN-001-EXAMPLE', Model: 'SM-S928U', IMEI1: '352999001234567', IMEI2: '' },
        { SN: 'SN-002-EXAMPLE', Model: 'SM-S928U', IMEI1: '', IMEI2: '' },
      ],
      columns: TI_SET_FIELDS.map(f => ({ key: f.key === 'sn' ? 'SN' : f.key === 'imei1' ? 'IMEI1' : f.key === 'imei2' ? 'IMEI2' : f.label, label: f.label + (f.required ? ' *' : '') })),
    },
    {
      name: 'PBA_TRANSFER',
      rows: [
        { Model: 'PBA-MAINBOARD-S24', Qty: '10', Condition: 'OK', Rack: 'R-01' },
        { Model: 'PBA-DISPLAY-S24',   Qty: '5',  Condition: 'OK', Rack: 'R-02' },
      ],
      columns: TI_PBA_FIELDS.map(f => ({ key: f.label, label: f.label + (f.required ? ' *' : '') })),
    },
  ], 'Template_Transfer_SET_PBA');
}

function autoMapColumns(sourceHeaders, fields) {
  // Returns { fieldKey: sourceHeader | '' }
  const mapping = {};
  const used = new Set();
  for (const f of fields) {
    const target = f.label.toLowerCase();
    const best = sourceHeaders.find(h => {
      const hn = h.toLowerCase().replace(/[^a-z0-9]/g, '');
      const tn = target.replace(/[^a-z0-9]/g, '');
      return hn === tn || hn.includes(tn) || tn.includes(hn);
    });
    if (best && !used.has(best)) { mapping[f.key] = best; used.add(best); }
    else mapping[f.key] = '';
  }
  return mapping;
}

function applyMapping(rawRows, mapping) {
  return rawRows.map(row => {
    const out = {};
    for (const [fieldKey, srcHeader] of Object.entries(mapping)) {
      out[fieldKey] = srcHeader ? String(row[srcHeader] ?? '').trim() : '';
    }
    return out;
  }).filter(row => Object.values(row).some(v => v));
}

function showBulkTransferImportFlow(ownHolder, onDone) {
  // Wizard state
  const ws = {
    step: 1,
    file: null,
    rawSheets: {},        // { sheetName: rawRows[] }
    sheetNames: [],
    setSheet: '',
    pbaSheet: '',
    setHeaderRow: 0,      // 0-based index of header row in raw sheet data
    pbaHeaderRow: 0,
    setMapping: {},       // { sn:'', model:'', imei1:'', imei2:'' }
    pbaMapping: {},       // { model:'', qty:'', condition:'', rack:'' }
    setRows: [],          // mapped rows after applying mapping
    pbaRows: [],
    validationResult: null,
    toHolder: '',
    transferType: 'Dispatch',
  };

  const detailBody = () => document.getElementById('detail-body');
  const detailTitle = () => document.getElementById('detail-title');

  function setTitle(t) { const el = detailTitle(); if (el) el.textContent = t; }

  function renderStep() {
    switch (ws.step) {
      case 1: renderStep1(); break;
      case 2: renderStep2(); break;
      case 3: renderStep3(); break;
      case 4: renderStep4(); break;
    }
  }

  // ── Step 1: Upload ─────────────────────────────────────────────────────────
  function renderStep1() {
    setTitle('Import Transfer · Bước 1/4 — Tải file Excel');
    detailBody().innerHTML = `
      <div class="sp-bulk-reg">
        <p class="small muted" style="margin-bottom:12px">Sender: <strong>${esc(ownHolder)}</strong> · File .xlsx cần có sheet <code>SET_TRANSFER</code> và/hoặc <code>PBA_TRANSFER</code> (hoặc bất kỳ tên sheet nào — bạn sẽ chọn ở bước sau).</p>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:16px">
          <button class="button" id="tiw-dl-tpl">⬇ Tải Template mẫu</button>
          <label class="button primary" for="tiw-file" style="cursor:pointer">📂 Chọn file .xlsx</label>
          <input type="file" id="tiw-file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" style="position:absolute;opacity:0;pointer-events:none">
          <span id="tiw-filename" class="small muted">Chưa chọn file</span>
        </div>
        <div id="tiw-step1-status" class="small"></div>
        <div style="margin-top:16px;display:flex;gap:8px">
          <button class="button" id="tiw-cancel">Hủy</button>
        </div>
      </div>`;
    document.getElementById('tiw-dl-tpl').onclick = downloadTransferTemplate;
    document.getElementById('tiw-cancel').onclick = () => document.getElementById('detail')?.close();
    const fileInput = document.getElementById('tiw-file');
    document.querySelector('label[for="tiw-file"]').onclick = () => fileInput.click();
    fileInput.addEventListener('change', async e => {
      const file = e.target.files[0];
      if (!file) return;
      ws.file = file;
      document.getElementById('tiw-filename').textContent = file.name;
      document.getElementById('tiw-step1-status').innerHTML = '<span class="muted">Đang phân tích…</span>';
      try {
        const allSheets = await parseXlsxFile(file);
        ws.rawSheets = allSheets;
        ws.sheetNames = Object.keys(allSheets);
        if (!ws.sheetNames.length) { document.getElementById('tiw-step1-status').innerHTML = '<span class="red">File không có sheet nào.</span>'; return; }
        // Auto-select SET_TRANSFER / PBA_TRANSFER if present
        ws.setSheet = ws.sheetNames.find(n => /set/i.test(n)) || ws.sheetNames[0] || '';
        ws.pbaSheet = ws.sheetNames.find(n => /pba/i.test(n)) || '';
        document.getElementById('tiw-step1-status').innerHTML = `<span class="mint">✓ ${ws.sheetNames.length} sheet: ${ws.sheetNames.map(esc).join(', ')}</span>`;
        setTimeout(() => { ws.step = 2; renderStep(); }, 400);
      } catch (err) {
        document.getElementById('tiw-step1-status').innerHTML = `<span class="red">Lỗi đọc file: ${esc(err.message)}</span>`;
      }
    });
  }

  // ── Step 2: Sheet selection + column mapping ───────────────────────────────
  function getHeadersFromSheet(sheetName, headerRow) {
    const raw = ws.rawSheets[sheetName] || [];
    if (!raw.length) return [];
    const row = raw[headerRow] || {};
    return Object.keys(row).sort((a, b) => colIndex(a) - colIndex(b)).map(c => String(row[c] || '').trim()).filter(Boolean);
  }

  function mappingSelectsHtml(id, fields, mapping, headers) {
    const opts = [`<option value="">— Bỏ qua —</option>`, ...headers.map(h => `<option value="${esc(h)}">${esc(h)}</option>`)].join('');
    return fields.map(f => `
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
        <span style="width:90px;font-size:12px;color:var(--muted)">${esc(f.label)}${f.required ? ' <span class="red">*</span>' : ''}</span>
        <select id="${id}-${f.key}" style="font-size:12px;min-width:160px">${opts.replace(`value="${esc(mapping[f.key] || '')}"`, `value="${esc(mapping[f.key] || '')}" selected`)}</select>
      </div>`).join('');
  }

  function renderStep2() {
    setTitle('Import Transfer · Bước 2/4 — Chọn sheet & ánh xạ cột');
    const sheetOpts = [`<option value="">— Không dùng —</option>`, ...ws.sheetNames.map(n => `<option value="${esc(n)}">${esc(n)}</option>`)].join('');
    const headerRowOpts = (sheetName) => {
      const raw = ws.rawSheets[sheetName] || [];
      return raw.slice(0, 10).map((_, i) => `<option value="${i}">Dòng ${i + 1}</option>`).join('');
    };
    detailBody().innerHTML = `
      <div class="sp-bulk-reg" style="max-height:70vh;overflow-y:auto">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <div>
            <p class="small" style="font-weight:600;margin-bottom:6px">Sheet SET</p>
            <select id="tiw-set-sheet" style="width:100%;margin-bottom:4px">${sheetOpts.replace(`"${esc(ws.setSheet)}"`, `"${esc(ws.setSheet)}" selected`)}</select>
            <label class="small muted">Dòng header: <select id="tiw-set-hrow" style="font-size:12px">${headerRowOpts(ws.setSheet)}</select></label>
            <div id="tiw-set-mapping" style="margin-top:8px"></div>
          </div>
          <div>
            <p class="small" style="font-weight:600;margin-bottom:6px">Sheet PBA</p>
            <select id="tiw-pba-sheet" style="width:100%;margin-bottom:4px">${sheetOpts.replace(`"${esc(ws.pbaSheet)}"`, `"${esc(ws.pbaSheet)}" selected`)}</select>
            <label class="small muted">Dòng header: <select id="tiw-pba-hrow" style="font-size:12px">${headerRowOpts(ws.pbaSheet)}</select></label>
            <div id="tiw-pba-mapping" style="margin-top:8px"></div>
          </div>
        </div>
        <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
          <button class="button" id="tiw-step2-back">← Trở lại</button>
          <button class="button primary" id="tiw-step2-next">Xác nhận ánh xạ →</button>
          <span id="tiw-step2-err" class="red small"></span>
        </div>
      </div>`;

    function refreshMappingUI() {
      const setSheet = document.getElementById('tiw-set-sheet')?.value || '';
      const pbaSheet = document.getElementById('tiw-pba-sheet')?.value || '';
      const setHRow  = Number(document.getElementById('tiw-set-hrow')?.value || 0);
      const pbaHRow  = Number(document.getElementById('tiw-pba-hrow')?.value || 0);
      const setH = getHeadersFromSheet(setSheet, setHRow);
      const pbaH = getHeadersFromSheet(pbaSheet, pbaHRow);
      ws.setMapping = autoMapColumns(setH, TI_SET_FIELDS);
      ws.pbaMapping = autoMapColumns(pbaH, TI_PBA_FIELDS);
      const smEl = document.getElementById('tiw-set-mapping');
      const pmEl = document.getElementById('tiw-pba-mapping');
      if (smEl) smEl.innerHTML = setSheet ? mappingSelectsHtml('tiw-sm', TI_SET_FIELDS, ws.setMapping, setH) : '<span class="small muted">Không dùng SET</span>';
      if (pmEl) pmEl.innerHTML = pbaSheet ? mappingSelectsHtml('tiw-pm', TI_PBA_FIELDS, ws.pbaMapping, pbaH) : '<span class="small muted">Không dùng PBA</span>';
      // After rendering, set selected values
      TI_SET_FIELDS.forEach(f => { const el = document.getElementById(`tiw-sm-${f.key}`); if (el && ws.setMapping[f.key]) el.value = ws.setMapping[f.key]; });
      TI_PBA_FIELDS.forEach(f => { const el = document.getElementById(`tiw-pm-${f.key}`); if (el && ws.pbaMapping[f.key]) el.value = ws.pbaMapping[f.key]; });
    }

    ['tiw-set-sheet','tiw-pba-sheet','tiw-set-hrow','tiw-pba-hrow'].forEach(id => {
      document.getElementById(id)?.addEventListener('change', refreshMappingUI);
    });
    refreshMappingUI();

    document.getElementById('tiw-step2-back').onclick = () => { ws.step = 1; renderStep(); };
    document.getElementById('tiw-step2-next').onclick = () => {
      // Read current mapping from selects
      const setSheet = document.getElementById('tiw-set-sheet')?.value || '';
      const pbaSheet = document.getElementById('tiw-pba-sheet')?.value || '';
      ws.setSheet = setSheet;
      ws.pbaSheet = pbaSheet;
      ws.setHeaderRow = Number(document.getElementById('tiw-set-hrow')?.value || 0);
      ws.pbaHeaderRow = Number(document.getElementById('tiw-pba-hrow')?.value || 0);
      TI_SET_FIELDS.forEach(f => { const el = document.getElementById(`tiw-sm-${f.key}`); if (el) ws.setMapping[f.key] = el.value; });
      TI_PBA_FIELDS.forEach(f => { const el = document.getElementById(`tiw-pm-${f.key}`); if (el) ws.pbaMapping[f.key] = el.value; });
      // Validate required fields
      const errEl = document.getElementById('tiw-step2-err');
      if (!setSheet && !pbaSheet) { errEl.textContent = 'Chọn ít nhất một sheet SET hoặc PBA.'; return; }
      if (setSheet && !ws.setMapping['sn']) { errEl.textContent = 'Sheet SET cần ánh xạ cột SN.'; return; }
      if (pbaSheet && !ws.setMapping['model'] && !ws.pbaMapping['model']) { /* skip */ }
      if (pbaSheet && !ws.pbaMapping['model']) { errEl.textContent = 'Sheet PBA cần ánh xạ cột Model.'; return; }
      if (pbaSheet && !ws.pbaMapping['qty'])   { errEl.textContent = 'Sheet PBA cần ánh xạ cột Qty.'; return; }
      // Apply mapping
      const setRaw = ws.rawSheets[setSheet] || [];
      const pbaRaw = ws.rawSheets[pbaSheet] || [];
      const setData = applyMapping(setRaw.slice(ws.setHeaderRow + 1), ws.setMapping);
      const pbaData = applyMapping(pbaRaw.slice(ws.pbaHeaderRow + 1), ws.pbaMapping);
      ws.setRows = setData.filter(r => r.sn);
      ws.pbaRows = pbaData.map(r => ({ ...r, qty: Number(r.qty) || 0 })).filter(r => r.model);
      if (!ws.setRows.length && !ws.pbaRows.length) { errEl.textContent = 'Không có dữ liệu sau khi ánh xạ. Kiểm tra lại header row và cột.'; return; }
      ws.step = 3; renderStep();
    };
  }

  // ── Step 3: Server-side validation ────────────────────────────────────────
  async function renderStep3() {
    setTitle('Import Transfer · Bước 3/4 — Kiểm tra tồn kho');
    detailBody().innerHTML = `
      <div class="sp-bulk-reg">
        <p class="small muted">Đang kiểm tra với server… <strong>${ws.setRows.length}</strong> SET, <strong>${ws.pbaRows.length}</strong> PBA từ holder <strong>${esc(ownHolder)}</strong></p>
        <div id="tiw-step3-body"><span class="small muted">Đang xác thực…</span></div>
        <div style="margin-top:12px;display:flex;gap:8px" id="tiw-step3-actions">
          <button class="button" id="tiw-step3-back">← Trở lại ánh xạ</button>
        </div>
      </div>`;
    document.getElementById('tiw-step3-back').onclick = () => { ws.step = 2; renderStep(); };
    try {
      const result = await onDone({ _preview: true, fromHolder: ownHolder, sets: ws.setRows, pbas: ws.pbaRows });
      ws.validationResult = result;
      renderStep3Results(result);
    } catch (err) {
      document.getElementById('tiw-step3-body').innerHTML = `<p class="red small">Lỗi xác thực: ${esc(err.message)}</p>`;
    }
  }

  function renderStep3Results(r) {
    const { errors = [], warnings = [], valid = { sets: [], pbas: [] } } = r;
    const hasErrors = errors.length > 0;
    let html = `<div style="display:flex;gap:12px;margin-bottom:10px;flex-wrap:wrap">
      <span class="badge badge-${valid.sets.length+valid.pbas.length>0?'mint':'muted'}">✓ Hợp lệ: ${valid.sets.length} SET + ${valid.pbas.length} PBA</span>
      ${errors.length ? `<span class="badge badge-red">✗ Lỗi: ${errors.length}</span>` : ''}
      ${warnings.length ? `<span class="badge badge-amber">⚠ Cảnh báo: ${warnings.length}</span>` : ''}
    </div>`;

    if (errors.length) {
      html += `<p class="small red" style="font-weight:600;margin-bottom:4px">Lỗi (${errors.length}) — Phải sửa trước khi tạo Transfer:</p>
        <div class="table-scroll"><table class="sp-table"><thead><tr><th>Dòng</th><th>Loại</th><th>Field</th><th>SN/Model</th><th>Mô tả lỗi</th></tr></thead><tbody>`;
      errors.forEach(e => {
        html += `<tr><td class="small muted">${e.row}</td><td>${esc(e.type)}</td><td>${esc(e.field||'')}</td><td><code>${esc(e.sn||e.model||'')}</code></td><td class="red small">${esc(e.msg)}</td></tr>`;
      });
      html += '</tbody></table></div>';
    }

    if (warnings.length) {
      html += `<p class="small amber" style="font-weight:600;margin:8px 0 4px">Cảnh báo (${warnings.length}) — Transfer vẫn được tạo nhưng cần xem lại:</p>
        <div class="table-scroll"><table class="sp-table"><thead><tr><th>Dòng</th><th>Loại</th><th>Field</th><th>SN/Model</th><th>Giá trị file</th><th>Giá trị hệ thống</th></tr></thead><tbody>`;
      warnings.forEach(w => {
        html += `<tr><td class="small muted">${w.row}</td><td>${esc(w.type)}</td><td>${esc(w.field||'')}</td><td><code>${esc(w.sn||w.model||'')}</code></td><td class="amber small">${esc(w.fileValue||'')}</td><td class="small">${esc(w.systemValue||'')}</td></tr>`;
      });
      html += '</tbody></table></div>';
    }

    if (!hasErrors && (valid.sets.length || valid.pbas.length)) {
      html += `<p class="small mint" style="font-weight:600;margin:8px 0 4px">Danh sách hợp lệ:</p>`;
      if (valid.sets.length) {
        html += `<div class="table-scroll"><table class="sp-table"><thead><tr><th>SN</th><th>Model (HT)</th><th>Holder</th><th>Trạng thái</th><th>Condition</th></tr></thead><tbody>`;
        valid.sets.slice(0, 20).forEach(s => {
          html += `<tr><td><code>${esc(s.sn)}</code></td><td>${esc(s.model||'')}</td><td>${esc(s.holderCode)}</td><td>${esc(s.stockState||'')}</td><td>${esc(s.condition||'')}</td></tr>`;
        });
        if (valid.sets.length > 20) html += `<tr><td colspan="5" class="small muted">… và ${valid.sets.length - 20} SET khác</td></tr>`;
        html += '</tbody></table></div>';
      }
      if (valid.pbas.length) {
        html += `<div class="table-scroll"><table class="sp-table"><thead><tr><th>Model</th><th>Condition</th><th>Rack</th><th>Qty yêu cầu</th><th>Tồn kho</th></tr></thead><tbody>`;
        valid.pbas.forEach(p => {
          html += `<tr><td>${esc(p.model)}</td><td>${esc(p.condition)}</td><td>${esc(p.rack)}</td><td><strong>${p.qty}</strong></td><td class="muted">${p.availableQty}</td></tr>`;
        });
        html += '</tbody></table></div>';
      }
    }

    document.getElementById('tiw-step3-body').innerHTML = html;

    const actionsEl = document.getElementById('tiw-step3-actions');
    if (!hasErrors && (valid.sets.length || valid.pbas.length)) {
      actionsEl.innerHTML += `
        <button class="button primary" id="tiw-step3-next">Tiếp tục tạo Transfer →</button>
        ${warnings.length ? `<span class="amber small" style="margin-left:8px">⚠ Có ${warnings.length} cảnh báo — xem lại trước khi tạo</span>` : ''}`;
      document.getElementById('tiw-step3-next').onclick = () => { ws.step = 4; renderStep4(); };
    } else if (hasErrors) {
      actionsEl.innerHTML = `<button class="button" id="tiw-step3-back">← Trở lại ánh xạ</button><span class="red small" style="margin-left:8px">Sửa ${errors.length} lỗi trước khi tiếp tục.</span>`;
      document.getElementById('tiw-step3-back').onclick = () => { ws.step = 2; renderStep(); };
    }
  }

  // ── Step 4: Confirm & Create ───────────────────────────────────────────────
  function renderStep4() {
    setTitle('Import Transfer · Bước 4/4 — Xác nhận tạo Transfer');
    const r = ws.validationResult?.valid || { sets: [], pbas: [] };
    const destOpts = ['SEV','ALT','ALV','BUJEON','CHITWING'].filter(h => h !== ownHolder).map(h => `<option value="${h}">${h}</option>`).join('');
    detailBody().innerHTML = `
      <div class="sp-bulk-reg">
        <p class="small muted" style="margin-bottom:12px">Sender: <strong>${esc(ownHolder)}</strong> · <strong>${r.sets.length} SET</strong> + <strong>${r.pbas.length} PBA</strong> · Transfer sẽ ở trạng thái <strong>Requested</strong>. Dispatch riêng từ tab Transfer & Receipt.</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
          <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted)">
            Đến Holder <span class="red">*</span>
            <select id="tiw-to" style="font-size:13px">${destOpts}</select>
          </label>
          <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted)">
            Loại Transfer
            <select id="tiw-type" style="font-size:13px">
              <option value="Dispatch">Dispatch</option>
              <option value="Return">Return</option>
              <option value="VendorToVendor">VendorToVendor</option>
            </select>
          </label>
          <label style="display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--muted);grid-column:1/-1">
            Lý do / Ghi chú
            <input id="tiw-reason" maxlength="200" placeholder="Tùy chọn" style="font-size:13px">
          </label>
        </div>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          <button class="button" id="tiw-step4-back">← Trở lại</button>
          <button class="button primary" id="tiw-step4-confirm">✓ Tạo Transfer ngay</button>
          <span id="tiw-step4-status" class="small muted" style="margin-left:4px"></span>
        </div>
      </div>`;
    document.getElementById('tiw-step4-back').onclick = () => { ws.step = 3; renderStep3(); };
    document.getElementById('tiw-step4-confirm').onclick = async () => {
      const btn = document.getElementById('tiw-step4-confirm');
      const statusEl3 = document.getElementById('tiw-step4-status');
      const toHolder    = document.getElementById('tiw-to').value;
      const transferType = document.getElementById('tiw-type').value;
      const reason = document.getElementById('tiw-reason').value.trim() || null;
      if (!toHolder) { statusEl3.textContent = 'Chọn Đến Holder.'; return; }
      btn.disabled = true;
      statusEl3.textContent = 'Đang tạo Transfer…';
      const lines = [
        ...r.sets.map(s => ({ itemType: 'SET', sn: s.sn, model: s.model || undefined, condition: s.condition || 'OK' })),
        ...r.pbas.map(p => ({ itemType: 'PBA', model: p.model, condition: p.condition, fromRack: p.rack, qty: p.qty })),
      ];
      try {
        const result = await onDone({ fromHolder: ownHolder, toHolder, transferType, reason, lines });
        const tfNo = result?.transfer?.transferNo || result?.transferNo || '';
        statusEl3.textContent = '';
        detailBody().innerHTML = `<div style="text-align:center;padding:24px">
          <p class="mint" style="font-size:18px;font-weight:600">✓ Transfer đã được tạo</p>
          <p style="margin:8px 0"><strong>${esc(tfNo)}</strong> · Requested</p>
          <p class="small muted">Chuyển sang tab Transfer & Receipt để Dispatch.</p>
          <button class="button primary" onclick="document.getElementById('detail').close()" style="margin-top:16px">Đóng</button>
        </div>`;
        setTitle('Transfer đã tạo thành công');
      } catch (err) {
        statusEl3.textContent = 'Lỗi: ' + (err.message || 'Không tạo được.');
        btn.disabled = false;
      }
    };
  }

  // Open dialog and start
  showDetail('Import Transfer · Bước 1/4 — Tải file Excel', '');
  renderStep1();
}

/* ---- Main mount ---- */
const HOLDERS_OPS = ['SEV', 'ALT', 'ALV', 'BUJEON', 'CHITWING'];
const HOLDER_LABEL_OPS = { SEV: 'SEV', ALT: 'ALT', ALV: 'ALV', BUJEON: 'Bujeon', CHITWING: 'Chitwing' };

export function mount(root, _data, { api }) {
  const session = vendorSession();
  const isVendor = !!session?.vendorScope;
  // Resolve display name → canonical holder code (e.g. 'Almus Tech' → 'ALT')
  const vendorCode = isVendor ? (resolveVendorHolder(session.vendorScope) || session.vendorScope) : '';
  const ownHolder = isVendor ? vendorCode : 'SEV';
  _sevMode = !isVendor; // controls Destroy button visibility in action columns

  // Phase 4D.3E: holder from shared store; vendor is locked to own scope
  let selectedHolder = isVendor ? vendorCode : getHolder();

  // State preservation: save tableController state per tab
  const savedState = {};
  let tables = {}; // tabId → tableController
  let activeTab = 'set';
  let allData = {};

  root.innerHTML = `
    <div class="sp-ops-header">
      <div class="sp-ops-title">${icon('stock')} SET/PBA Operations ${BADGE_DEMO}</div>
      <div class="sp-ops-actions">
        <span id="sp-ops-access-badge"></span>
        ${isVendor ? `<span class="badge badge-vendor" title="Vendor view">${esc(vendorCode)}</span>` : ''}
        ${!isVendor ? `<button class="button primary" id="sp-ops-bulk-reg" title="Ghi nhận hàng loạt SET/PBA mới vào kho SEV">+ Ghi nhận SET/PBA mới</button>` : ''}
        <button class="icon-button" id="sp-ops-refresh" title="Tải lại" aria-label="Tải lại">${icon('refresh')}</button>
      </div>
    </div>
    <div id="sp-ops-status" class="small muted sp-ops-status" role="status">Đang tải dữ liệu…</div>
    <div class="table-tabs sp-ops-tabs" role="tablist">
      ${TABS.map((t, i) => `<button role="tab" data-sp-tab="${t.id}" aria-selected="${i === 0}" aria-controls="sp-panel-${t.id}">${t.label}<span data-sp-tab-count="${t.id}">…</span></button>`).join('')}
    </div>
    <div id="sp-toolbar-set" class="sp-panel-toolbar sp-tf-toolbar" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;align-items:center"></div>
    <div id="sp-panel-set" role="tabpanel" data-sp-panel="set" class="panel table-panel sp-panel"></div>
    <div id="sp-toolbar-pba" class="sp-panel-toolbar sp-tf-toolbar" hidden style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;align-items:center"></div>
    <div id="sp-panel-pba" role="tabpanel" data-sp-panel="pba" hidden class="panel table-panel sp-panel"></div>
    <div id="sp-toolbar-transfer" class="sp-panel-toolbar sp-tf-toolbar" hidden style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;align-items:center">
      <button class="button primary" data-sp-create-tf>+ Tạo Transfer</button>
      <button class="button" data-sp-import-tf>📂 Import Excel Transfer</button>
      <button class="button" data-sp-dl-tf-tpl>⬇ Template</button>
    </div>
    <div id="sp-panel-transfer" role="tabpanel" data-sp-panel="transfer" hidden class="panel table-panel sp-panel"></div>
    <div id="sp-toolbar-ng" class="sp-panel-toolbar" hidden></div>
    <div id="sp-panel-ng" role="tabpanel" data-sp-panel="ng" hidden class="panel table-panel sp-panel"></div>
    <div id="sp-toolbar-movement" class="sp-panel-toolbar" hidden></div>
    <div id="sp-panel-movement" role="tabpanel" data-sp-panel="movement" hidden class="panel table-panel sp-panel"></div>
    <div id="sp-toolbar-adjreq" class="sp-panel-toolbar sp-tf-toolbar" hidden style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;align-items:center"></div>
    <div id="sp-panel-adjreq" role="tabpanel" data-sp-panel="adjreq" hidden class="panel table-panel sp-panel"></div>
  `;

  // Inject SET and PBA toolbars (Transfer toolbar is baked into template above)
  const setTb = root.querySelector('#sp-toolbar-set');
  if (setTb) setTb.innerHTML = `<button class="button" data-sp-create-tf>+ Tạo Transfer từ SET</button>`;
  const pbaTb = root.querySelector('#sp-toolbar-pba');
  if (pbaTb) pbaTb.innerHTML = `
    <button class="button" data-sp-create-tf>+ Tạo Transfer từ PBA</button>
    ${!isVendor ? `<button class="button" data-sp-stock-add>+ Bổ sung tồn kho</button>
    <button class="button" data-sp-adjust>Điều chỉnh tồn kho</button>` : ''}`;

  const adjreqTb = root.querySelector('#sp-toolbar-adjreq');
  if (adjreqTb) adjreqTb.innerHTML = isVendor
    ? `<button class="button primary" data-sp-adj-req-create>+ Yêu cầu điều chỉnh</button>
       <button class="button" data-sp-adj-req-dl-tpl>⬇ Template</button>`
    : `<span class="small muted">SEV: xem và phê duyệt yêu cầu điều chỉnh từ Vendor bên dưới.</span>`;

  const statusEl = root.querySelector('#sp-ops-status');

  function setStatus(msg, isError = false) {
    statusEl.textContent = msg;
    statusEl.classList.toggle('red', isError);
  }

  function setCount(tabId, n) {
    const el = root.querySelector(`[data-sp-tab-count="${tabId}"]`);
    if (el) el.textContent = n;
  }

  function switchTab(tabId) {
    // Save current table state
    if (tables[activeTab]) savedState[activeTab] = tables[activeTab].getState();

    // Show/hide panels and toolbars
    root.querySelectorAll('[data-sp-panel]').forEach(p => { p.hidden = p.dataset.spPanel !== tabId; });
    TABS.forEach(t => {
      const tb = root.querySelector(`#sp-toolbar-${t.id}`);
      if (tb) tb.hidden = t.id !== tabId;
    });
    root.querySelectorAll('[data-sp-tab]').forEach(b => {
      const active = b.dataset.spTab === tabId;
      b.setAttribute('aria-selected', String(active));
      b.classList.toggle('active', active);
    });
    activeTab = tabId;

    // Restore state if already built
    if (tables[tabId] && savedState[tabId]) {
      tables[tabId].restoreState(savedState[tabId]);
    }
  }

  root.querySelectorAll('[data-sp-tab]').forEach(b => {
    b.onclick = () => switchTab(b.dataset.spTab);
  });

  function buildTable(tabId, panel, rows, columns, filters, name, onDetail) {
    if (tables[tabId]) {
      // Update existing
      tables[tabId].update(rows);
      setCount(tabId, rows.length);
    } else {
      tables[tabId] = tableController(panel, { rows, columns, filters, name, onDetail, pageSize: 10 });
      setCount(tabId, rows.length);
    }
    if (savedState[tabId]) tables[tabId].restoreState(savedState[tabId]);
  }

  function renderAll(data) {
    allData = data;
    const { setUnits = [], pbaRows = [], transfers = [], ngReports = [], movements = [], adjRequests = [] } = data;

    const setPanel = root.querySelector('[data-sp-panel="set"]');
    buildTable('set', setPanel, setUnits, SET_COLS, SET_FILTERS, 'SET-Inventory', setDetail);

    const pbaPanel = root.querySelector('[data-sp-panel="pba"]');
    buildTable('pba', pbaPanel, pbaRows, PBA_COLS, PBA_FILTERS, 'PBA-Inventory', null);

    const tfPanel = root.querySelector('[data-sp-panel="transfer"]');
    buildTable('transfer', tfPanel, transfers, tfCols(isVendor, vendorCode), TF_FILTERS, 'Transfer', transferDetail);

    if (!isVendor) {
      const ngPanel = root.querySelector('[data-sp-panel="ng"]');
      buildTable('ng', ngPanel, ngReports, NG_COLS, NG_FILTERS, 'NG-Management', ngDetail);
    } else {
      const ngPanel = root.querySelector('[data-sp-panel="ng"]');
      ngPanel.innerHTML = '<p class="small muted" style="padding:16px">Vendor không có quyền xem NG Management.</p>';
    }

    const mvPanel = root.querySelector('[data-sp-panel="movement"]');
    buildTable('movement', mvPanel, movements, MV_COLS, MV_FILTERS, 'Movement-History', null);

    const adjreqPanel = root.querySelector('[data-sp-panel="adjreq"]');
    buildTable('adjreq', adjreqPanel, adjRequests, adjReqCols(isVendor), ADJ_REQ_FILTERS, 'Adj-Requests', null);
  }

  function updateAccessBadge() {
    const accessBadge = root.querySelector('#sp-ops-access-badge');
    if (!accessBadge) return;
    const h = selectedHolder;
    if (!h) { accessBadge.innerHTML = ''; return; }
    const isOwn = !isVendor || h === ownHolder;
    accessBadge.innerHTML = isOwn
      ? `<span class="badge badge-editable" title="Holder của bạn — thao tác ghi được phép">Có thể chỉnh sửa</span>`
      : `<span class="badge badge-readonly" title="Holder khác — chỉ xem tham khảo">Chỉ xem</span>`;
  }

  async function load() {
    setStatus('Đang tải dữ liệu…');
    updateAccessBadge();
    try {
      const h = selectedHolder;
      const holderParam = h ? `&holder=${encodeURIComponent(h)}` : '';
      const tfHolderParam = h ? `?holder=${encodeURIComponent(h)}` : '';
      const [setRes, pbaRes, tfRes, ngRes, mvRes, adjReqRes] = await Promise.all([
        api(`sp/set?inclDemo=1${holderParam}`),
        api(`sp/pba?inclDemo=1${holderParam}`),
        api(`sp/transfer${tfHolderParam}`),
        isVendor ? Promise.resolve({ alerts: [] }) : api('sp/ng-alerts?onlyNew=0'),
        api('sp/movement?limit=300'),
        api('sp/adj-request'),
      ]);

      const movements = (mvRes.movements || []).map(m => ({
        ...m,
        holderCode:    m.holderCode    || m.holder    || '',
        counterHolder: m.counterHolder || m.counter   || '',
        movementType:  m.movementType  || m.type      || '',
        itemType:      m.itemType      || '',
        qtyDelta:      m.qtyDelta      ?? m.qty       ?? 0,
        createdAt:     m.createdAt     || m.at        || '',
      }));

      renderAll({
        setUnits:   setRes.units    || [],
        pbaRows:    pbaRes.rows     || [],
        transfers:  tfRes.transfers || [],
        ngReports:  ngRes.alerts    || [],
        movements,
        adjRequests: adjReqRes.requests || [],
      });

      const total = (setRes.units?.length || 0) + (pbaRes.rows?.length || 0);
      setStatus(`Đã tải · ${new Date().toLocaleTimeString('vi-VN')} · ${total} mục`);
    } catch (e) {
      setStatus('Lỗi tải dữ liệu: ' + e.message, true);
    }
  }

  root.querySelector('#sp-ops-refresh').onclick = load;

  const bulkRegBtn = root.querySelector('#sp-ops-bulk-reg');
  if (bulkRegBtn) {
    bulkRegBtn.onclick = () => {
      showBulkRegisterFlow(async (payload) => {
        const result = await api('sp/register-batch', 'POST', payload);
        await load();
        return result;
      });
    };
  }

  // Phase 4D.3E: mount shared holder selector in topbar slot; subscribe to changes
  mountHolderSelect('sp-holder-slot', { isVendor, vendorCode });
  onHolderChange(h => { selectedHolder = isVendor ? vendorCode : h; load(); });

  // Event delegation for Transfer Create + Dispatch + Báo NG buttons
  root.addEventListener('click', e => {
    // Stock Add (SEV only)
    if (e.target.closest('[data-sp-stock-add]')) {
      showStockAddFlow(ownHolder, async payload => {
        const result = await api('sp/stock-add', 'POST', payload);
        await load();
        return result;
      });
      return;
    }

    // Adjust (SEV only)
    if (e.target.closest('[data-sp-adjust]')) {
      showAdjustFlow(ownHolder, async payload => {
        const result = await api('sp/adjust', 'POST', payload);
        await load();
        return result;
      });
      return;
    }

    // Create Transfer (SEV + Vendor)
    const createBtn = e.target.closest('[data-sp-create-tf]');
    if (createBtn) {
      showTransferCreateForm(async (payload) => {
        await api('sp/transfer', 'POST', payload);
        await load();
      }, { lockedFrom: ownHolder });
      return;
    }

    // Import Excel Transfer (wizard)
    const importTfBtn = e.target.closest('[data-sp-import-tf]');
    if (importTfBtn) {
      showBulkTransferImportFlow(ownHolder, async (payload) => {
        if (payload._preview) {
          // Server-side stock validation — no write
          return api('sp/transfer/preview', 'POST', {
            fromHolder: payload.fromHolder,
            sets: payload.sets,
            pbas: payload.pbas,
          });
        }
        // Actual commit
        const result = await api('sp/transfer', 'POST', payload);
        await load();
        return result;
      });
      return;
    }

    // Download Transfer Template
    const dlTfBtn = e.target.closest('[data-sp-dl-tf-tpl]');
    if (dlTfBtn) { downloadTransferTemplate(); return; }

    // Dispatch Transfer
    const dispatchBtn = e.target.closest('[data-sp-dispatch]');
    if (dispatchBtn) {
      const transferId = Number(dispatchBtn.dataset.tfId);
      const transferNo = dispatchBtn.dataset.tfNo || `#${transferId}`;
      if (!confirm(`Dispatch Transfer ${transferNo}?\nSẽ chuyển sang InTransit và khóa tồn kho.`)) return;
      dispatchBtn.disabled = true;
      api('sp/transfer/dispatch', 'POST', { transferId })
        .then(() => load())
        .catch(err => { alert('Dispatch lỗi: ' + err.message); dispatchBtn.disabled = false; });
      return;
    }

    // Receive Transfer
    const receiveBtn = e.target.closest('[data-sp-receive]');
    if (receiveBtn) {
      const transferId = Number(receiveBtn.dataset.tfId);
      const tf = (allData.transfers || []).find(t => t.transferId === transferId);
      if (!tf) return;
      showReceiveForm(tf, async ({ partialLines }) => {
        await api('sp/transfer/receive', 'POST', { transferId, partialLines });
        await load();
      });
      return;
    }

    // Reject Transfer
    const rejectBtn = e.target.closest('[data-sp-reject]');
    if (rejectBtn) {
      const transferId = Number(rejectBtn.dataset.tfId);
      const tf = (allData.transfers || []).find(t => t.transferId === transferId);
      if (!tf) return;
      showRejectForm(tf, async ({ rejectReason }) => {
        await api('sp/transfer/reject', 'POST', { transferId, rejectReason });
        await load();
      });
      return;
    }

    // Confirm Return
    const retBtn = e.target.closest('[data-sp-confirm-return]');
    if (retBtn) {
      const transferId = Number(retBtn.dataset.tfId);
      const tf = (allData.transfers || []).find(t => t.transferId === transferId);
      if (!tf) return;
      showConfirmReturnForm(tf, async ({ returnLines }) => {
        await api('sp/transfer/return-confirm', 'POST', { transferId, returnLines });
        await load();
      });
      return;
    }

    // Adj. Request: Vendor submit
    if (e.target.closest('[data-sp-adj-req-create]')) {
      showAdjRequestFlow(ownHolder, async payload => {
        const result = await api('sp/adj-request', 'POST', payload);
        await load();
        return result;
      });
      return;
    }

    // Adj. Request: template download
    if (e.target.closest('[data-sp-adj-req-dl-tpl]')) {
      downloadAdjRequestTemplate();
      return;
    }

    // Adj. Request: SEV approve
    const approveBtn = e.target.closest('[data-sp-adj-approve]');
    if (approveBtn) {
      const adjReqId = Number(approveBtn.dataset.adjId);
      if (!confirm(`Phê duyệt yêu cầu #${adjReqId}?\nSẽ áp dụng thay đổi tồn kho ngay lập tức.`)) return;
      approveBtn.disabled = true;
      api('sp/adj-request/approve', 'POST', { adjReqId })
        .then(() => load())
        .catch(err => { alert('Phê duyệt lỗi: ' + err.message); approveBtn.disabled = false; });
      return;
    }

    // Adj. Request: SEV reject
    const rejectAdjBtn = e.target.closest('[data-sp-adj-reject]');
    if (rejectAdjBtn) {
      const adjReqId = Number(rejectAdjBtn.dataset.adjId);
      showRejectAdjForm(adjReqId, async ({ rejectReason }) => {
        await api('sp/adj-request/reject', 'POST', { adjReqId, rejectReason });
        await load();
      });
      return;
    }

    const setBtn = e.target.closest('[data-sp-ng-set]');
    if (setBtn) {
      const { sn, holder, model, imei1 } = setBtn.dataset;
      showNgForm({
        itemType: 'SET', sn, holderCode: holder, model, imei1,
        onSubmit: async ({ reason }) => {
          await api('sp/ng-report', 'POST', { itemType: 'SET', sn, holderCode: holder, model, imei1, reason });
          await load();
        },
      });
      return;
    }
    const pbaBtn = e.target.closest('[data-sp-ng-pba]');
    if (pbaBtn) {
      const { holder, model, rack, cond, qty } = pbaBtn.dataset;
      showNgForm({
        itemType: 'PBA', holderCode: holder, model, rack, condition: cond, maxQty: Number(qty) || 1,
        onSubmit: async ({ reason, qty: reportQty }) => {
          await api('sp/ng-report', 'POST', { itemType: 'PBA', holderCode: holder, model, rack, condition: cond, qty: reportQty, reason });
          await load();
        },
      });
      return;
    }

    // ---- Destroy (Phase 4D.5B — SEV only) ----
    const destroySetBtn = e.target.closest('[data-sp-destroy-set]');
    if (destroySetBtn) {
      const { sn, model } = destroySetBtn.dataset;
      showDestroyForm({ itemType: 'SET', label: `SET · SN ${sn}`, onSubmit: async ({ reason }) => {
        await api('sp/destroy', 'POST', { itemType: 'SET', sn, reason });
        await load();
      }});
      return;
    }
    const destroyPbaBtn = e.target.closest('[data-sp-destroy-pba]');
    if (destroyPbaBtn) {
      const { model, rack, cond, qty } = destroyPbaBtn.dataset;
      showDestroyForm({ itemType: 'PBA', label: `PBA · ${model} · ${cond}`, maxQty: Number(qty) || 1, onSubmit: async ({ reason, qty: destroyQty }) => {
        await api('sp/destroy', 'POST', { itemType: 'PBA', model, holderCode: 'SEV', condition: cond, rack, qty: destroyQty, reason });
        await load();
      }});
      return;
    }
  });

  load();

  return {};
}
