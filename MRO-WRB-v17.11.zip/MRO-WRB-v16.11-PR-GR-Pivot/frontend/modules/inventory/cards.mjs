// Public descriptor của module; thứ tự giữ tương thích KPI legacy.
import {stockStatus,isAging} from '../../../shared/model.mjs';
export function cardFilters(data){
 const all=()=>true,stock=s=>r=>stockStatus(r)===s;
 return [
  {key:'all',filter:all},
  {key:'sufficient',filter:stock('Đủ tồn')},
  {key:'not-sufficient',filter:r=>r.sqlStock?stockStatus(r)==='Theo dõi':stockStatus(r)!=='Đủ tồn'},
  {key:'discrepancy',filter:r=>r.sqlStock?['Nguy cơ thiếu','Hết hàng'].includes(stockStatus(r)):r.physical!==r.gmro},
  {key:'aging',filter:r=>isAging(r,data.asOf)}
 ];
}
export function locationFilter(index){return r=>index===0?r.physical>0:r.vendors['ABCD'[index-1]]>0;}

export function kpiDescriptors(rows,asOf,source){
 if(source||rows.some(r=>r.sqlStock))return [
 {key:'all',args:['Mã vật tư',rows.length,'WRBG + 4 vendor','stock']},
 {key:'sufficient',args:['Đủ tồn',rows.filter(r=>stockStatus(r)==='Đủ tồn').length,'Coverage hoặc Safety stock','check','mint']},
 {key:'not-sufficient',args:['Theo dõi',rows.filter(r=>stockStatus(r)==='Theo dõi').length,'Theo nhu cầu từng tuần','warn','amber']},
 {key:'discrepancy',args:['Thiếu',rows.filter(r=>['Nguy cơ thiếu','Hết hàng'].includes(stockStatus(r))).length,'Nguy cơ thiếu / Hết hàng','layers','violet']},
 {key:'aging',args:['Aging > 30 ngày',rows.filter(r=>isAging(r,asOf)).length,'Còn tồn · chưa xuất từ lần nhập','clock','amber']}];
 return [
 {key:'all',args:['Mã vật tư',rows.length,'SEV + 4 vendor','stock']},
 {key:'sufficient',args:['Đủ tồn',rows.filter(r=>stockStatus(r)==='Đủ tồn').length,'Coverage trên 4 tuần','check','mint']},
 {key:'not-sufficient',args:['Cần theo dõi',rows.filter(r=>stockStatus(r)!=='Đủ tồn').length,'Theo mức bao phủ tồn','warn','amber']},
 {key:'discrepancy',args:['Chênh lệch SEV / GMRO',rows.filter(r=>r.physical!==r.gmro).length,'Hai nguồn lưu độc lập','layers','violet']},
 {key:'aging',args:['Aging > 30 ngày',rows.filter(r=>isAging(r,asOf)).length,'Có tồn · không xuất dùng','clock','amber']}
 ];
}
