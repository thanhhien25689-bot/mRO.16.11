// Các phép tính cross-screen vẫn dùng facade model hiện tại.
import {stockTotal,coverage} from '../../../shared/model.mjs';
export const discrepancies=rows=>rows.filter(r=>r.physical!==r.gmro);
export const atLocation=(rows,location)=>rows.filter(r=>location==='SEV'?r.physical>0:r.vendors[location]>0);
export const lowestCoverage=rows=>rows.filter(r=>stockTotal(r)>0).sort((a,b)=>coverage(a)-coverage(b)).slice(0,3);
