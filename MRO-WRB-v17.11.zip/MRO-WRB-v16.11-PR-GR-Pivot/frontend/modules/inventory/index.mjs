// Public interface duy nhất, cùng pattern Delivery.
import {toast} from '../../shared/ui/index.mjs';
import {render} from './view.mjs';
import {showReconciliation} from './actions.mjs';
import {cardFilters,locationFilter} from './cards.mjs';
export {cardFilters,locationFilter};
export function mount(root,data,presentation){
 const controller=render(root,data,presentation);
 root.querySelector('#reconcile').onclick=()=>showReconciliation(controller);
 const banner=root.querySelector('.inventory-banner');
 const syncStatus=document.createElement('p');syncStatus.className='small';syncStatus.setAttribute('role','status');syncStatus.dataset.stockSyncStatus='';banner.after(syncStatus);if(data.stockError){syncStatus.setAttribute('role','alert');syncStatus.textContent='Không tải được SQL: '+data.stockError+(data.stockSource==='sql-cache'?' Đang hiển thị lần đồng bộ trước.':' Không hiển thị dữ liệu mẫu.');}
 else if(Array.isArray(data.stockProblems)&&data.stockProblems.length){syncStatus.className='small amber';syncStatus.textContent='Cảnh báo: đang bỏ qua '+data.stockProblems.length+' dòng lỗi dữ liệu — '+data.stockProblems.slice(0,3).join(' · ')+(data.stockProblems.length>3?' … (xem /api/stock-live để biết đủ danh sách).':'.');}
 if(!data.stockSource){const note=document.createElement('p');note.className='small amber';note.textContent='Dữ liệu mẫu · Chưa đồng bộ tồn kho SQL. Kiểm tra kết nối chưa tải dữ liệu; nhấn Cập nhật từ SQL để tải.';banner.append(note);}
 if(presentation.canUpdateBudget?.()){const button=document.createElement('button');button.className='button';button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M20 7v5h-5M4 17v-5h5M6.1 7a7 7 0 0 1 11.6-2L20 8M4 16l2.3 3A7 7 0 0 0 18 17"/></svg>';button.title='Cập nhật từ SQL';button.setAttribute('aria-label',button.title);banner.append(button);button.onclick=async()=>{button.disabled=true;button.classList.add('is-loading');syncStatus.textContent='Đang đọc tồn WRBG, tồn đầu kỳ Vendor, InOut Vendor, MasterData và Production…';try{const result=await presentation.api('stock-sync','POST',{});Object.assign(data,result);document.dispatchEvent(new CustomEvent('data-edited',{detail:{views:['inventory','vendor-overview','overview']}}));toast('Đã cập nhật tồn kho và sản lượng từ SQL.');}catch(e){syncStatus.setAttribute('role','alert');syncStatus.textContent='Đồng bộ chưa thành công: '+e.message+' Dữ liệu đang xem chưa thay đổi.';toast(e.message);button.disabled=false;button.classList.remove('is-loading');button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M20 7v5h-5M4 17v-5h5M6.1 7a7 7 0 0 1 11.6-2L20 8M4 16l2.3 3A7 7 0 0 0 18 17"/></svg>';button.title='Cập nhật từ SQL';button.setAttribute('aria-label',button.title);}};}
 if(presentation.api){let timer,stopped=false,busy=false,last=Date.now(),settings={stockEnabled:true,stockSeconds:300};
 const stop=()=>{stopped=true;clearTimeout(timer);document.removeEventListener('refresh-settings-changed',changed);document.removeEventListener('visibilitychange',wake);observer.disconnect();};
 const schedule=()=>{clearTimeout(timer);if(!stopped)timer=setTimeout(tick,settings.stockEnabled&&!root.hidden&&!document.hidden?Math.min(30000,Math.max(5000,settings.stockSeconds*1000-(Date.now()-last))):30000);};
 const changed=e=>{settings=e.detail;last=Date.now();schedule();};
 const wake=()=>{if(!root.hidden&&!document.hidden&&settings.stockEnabled&&Date.now()-last>=settings.stockSeconds*1000)tick();else schedule();};
 async function tick(){if(stopped||!root.isConnected){stop();return;}if(busy)return;busy=true;try{settings=await presentation.api('refresh-settings');if(settings.stockEnabled&&Date.now()-last>=settings.stockSeconds*1000&&!root.hidden&&!document.hidden&&!document.getElementById('detail')?.open&&!root.contains(document.activeElement)){const result=await presentation.api('stock-live');last=Date.now();if(!root.isConnected)return;Object.assign(data,result);document.dispatchEvent(new CustomEvent('data-edited',{detail:{views:['inventory','vendor-overview','overview']}}));stop();}}catch(e){last=Date.now();syncStatus.textContent=e.message;}finally{busy=false;schedule();}}
 const observer=new MutationObserver(()=>{if(!root.isConnected){stop();return;}wake();});observer.observe(root,{attributes:true,attributeFilter:['hidden']});observer.observe(document.getElementById('views'),{childList:true});
 document.addEventListener('refresh-settings-changed',changed);document.addEventListener('visibilitychange',wake);presentation.api('refresh-settings').then(value=>{settings=value;schedule();}).catch(schedule);
 }
 return Object.assign(controller,{cardFilters:cardFilters(data),locationFilter});
}

