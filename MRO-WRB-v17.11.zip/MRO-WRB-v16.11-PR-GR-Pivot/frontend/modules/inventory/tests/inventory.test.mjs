import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import * as api from '../index.mjs';
import {cardFilters,locationFilter,kpiDescriptors} from '../cards.mjs';
import {discrepancies,atLocation,lowestCoverage} from '../selectors.mjs';
import {showReconciliation} from '../actions.mjs';
import {stockTotal,stockStatus,coverage,isAging} from '../../../../shared/model.mjs';
const data=JSON.parse(readFileSync(new URL('../../../../tests/fixtures/legacy-raw.json',import.meta.url)));
test('Inventory public interface and KPI/filter mapping preserve current thresholds',()=>{
 assert.deepEqual(Object.keys(api).sort(),['cardFilters','locationFilter','mount']);
 const rows=data.items,cards=cardFilters(data),kpis=kpiDescriptors(rows,data.asOf);
 assert.deepEqual(cards.map(c=>c.key),['all','sufficient','not-sufficient','discrepancy','aging']);assert.deepEqual(kpis.map(c=>c.key),cards.map(c=>c.key));
 const expected=[rows,rows.filter(r=>stockStatus(r)==='Đủ tồn'),rows.filter(r=>stockStatus(r)!=='Đủ tồn'),rows.filter(r=>r.physical!==r.gmro),rows.filter(r=>isAging(r,data.asOf))];
 assert.deepEqual(cards.map(c=>rows.filter(c.filter)),expected);assert.deepEqual(kpis.map(c=>c.args[1]),expected.map(r=>r.length));
 const edge={...data,items:[0,0.5,1,4,5].map(n=>({physical:n,gmro:0,vendors:{A:0,B:0,C:0,D:0},demand:1,lastIssue:'2026-09-05'}))};
 assert.deepEqual(cardFilters(edge).map(c=>edge.items.filter(c.filter).length),[5,1,4,4,4]);
});
test('Inventory selectors and location filters match legacy without sorting or modifying source',()=>{
 const before=JSON.stringify(data),rows=data.items;
 assert.deepEqual(discrepancies(rows),rows.filter(r=>r.physical!==r.gmro));
 for(const [i,v] of ['SEV','A','B','C','D'].entries()){
  const expected=rows.filter(r=>v==='SEV'?r.physical>0:r.vendors[v]>0);
  assert.deepEqual(atLocation(rows,v),expected);assert.deepEqual(rows.filter(locationFilter(i)),expected);
 }
 assert.deepEqual(lowestCoverage(rows),rows.filter(r=>stockTotal(r)>0).sort((a,b)=>coverage(a)-coverage(b)).slice(0,3));
 assert.equal(JSON.stringify(data),before);
});
test('Inventory reconciliation delegates existing diff tab; no data writes or new workflow',()=>{
 const calls=[];showReconciliation({setTab:id=>calls.push(id)});assert.deepEqual(calls,['diff']);
 const noDemand={physical:1,gmro:1,vendors:{A:0,B:0,C:0,D:0},demand:0,lastIssue:data.asOf};
 assert.equal(coverage(noDemand),null);assert.deepEqual(lowestCoverage([noDemand]),[noDemand]); // Không sửa renderer toFixed(null) trong phase này.
});
