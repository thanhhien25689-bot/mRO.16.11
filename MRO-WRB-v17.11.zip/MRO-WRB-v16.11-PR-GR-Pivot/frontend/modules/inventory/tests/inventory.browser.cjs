const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const source=process.env.MRO_FRONTEND_BASELINE||path.resolve(__dirname,'../../../..');
const {createServer}=require(path.join(source,'server.cjs'));
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
(async()=>{
 const runtime=fs.mkdtempSync(path.join(os.tmpdir(),'mro-inventory-browser-'));let server,browser;
 try{
  server=createServer({runtime});await new Promise(r=>server.listen(0,'127.0.0.1',r));
  browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({viewport:{width:1920,height:1080}});
  await require('../../../../tests/fixtures/legacy-data.cjs').install(page,path.resolve(__dirname,'../../../..'));
  const errors=[],states=[],csv=[];let rawRequests=0;
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(new URL(r.url()).pathname==='/data/raw.json')rawRequests++;});
  await page.goto('http://127.0.0.1:'+server.address().port);
  for(const [name,value] of Object.entries({username:'inventorytest',name:'Inventory Test',password:'Inventory-test-password-2026!',confirm:'Inventory-test-password-2026!'}))await page.locator(`#login-form [name=${name}]`).fill(value);
  await page.locator('#login-form button[type=submit]').click();
  // Overview no longer exposes the legacy `.kpi` primitive; wait for the
  // route itself and the shared loader instead of coupling Inventory coverage
  // to Overview's card markup.
  await page.locator('[data-view=overview]').waitFor({state:'visible'});await page.locator('#loading').waitFor({state:'hidden'});
  const raw=JSON.parse(fs.readFileSync(path.join(source,'tests/fixtures/legacy-raw.json'))),rows=raw.items;
  const total=r=>r.physical+Object.values(r.vendors).reduce((a,b)=>a+b,0),status=r=>total(r)===0?'Hết hàng':!r.demand?'Chưa có nhu cầu':total(r)/r.demand<1?'Nguy cơ thiếu':total(r)/r.demand<=4?'Theo dõi':'Đủ tồn';
  const expected=[rows,rows.filter(r=>status(r)==='Đủ tồn'),rows.filter(r=>status(r)!=='Đủ tồn'),rows.filter(r=>r.physical!==r.gmro),rows.filter(r=>total(r)>0&&(Date.parse(raw.asOf)-Date.parse(r.lastIssue))/86400000>30)];
  await page.evaluate(()=>{window.inventoryEvents=0;document.addEventListener('data-edited',()=>window.inventoryEvents++);});
  for(const theme of ['dark','light']){
   if(await page.locator('html').getAttribute('data-theme')!==theme)await page.locator('#theme').click();
   await page.locator('[data-route=inventory]').click();const view=page.locator('[data-view=inventory]');await view.waitFor({state:'visible'});const table=view.locator('#inventory-table');
   async function record(name){states.push({name:theme+'/'+name,sha256:hash(await view.innerHTML())});}
   async function reset(){await table.locator('.filter-reset').click();assert.equal(await table.locator('.result-count').textContent(),rows.length+' kết quả');}
   await record('initial');
   for(let i=0;i<5;i++){const card=view.locator('.kpi').nth(i);await card.click();assert.equal(await card.getAttribute('data-card-id'),'inventory-'+i);assert.equal(await table.locator('.result-count').textContent(),expected[i].length+' kết quả');await record('card-'+i);await reset();}
   for(let i=0;i<5;i++){await view.locator('.location').nth(i).click();const n=rows.filter(r=>i===0?r.physical>0:r.vendors['ABCD'[i-1]]>0).length;assert.equal(await table.locator('.result-count').textContent(),n+' kết quả');await record('location-'+i);await reset();}
   for(const tab of ['risk','aging','diff']){await table.locator(`[data-tab=${tab}]`).click();await record('tab-'+tab);await reset();}
   await view.locator('#reconcile').click();assert.equal(await table.locator('[data-tab=diff]').getAttribute('class'),'active');assert.equal(await table.locator('.result-count').textContent(),expected[3].length+' kết quả');await record('reconcile');await reset();
   await table.locator('.page-size').selectOption('5');await table.locator('[data-page=next]').click();await record('page-next');await table.locator('[data-page=prev]').click();await record('page-prev');
   await table.locator('[data-sort="3"]').click();await record('sort');await reset();
   await table.locator('[data-key=group]').selectOption(rows[0].group);await record('group');await reset();
   await table.locator('input[type=search]').fill(rows[0].code);await record('search');
   await table.locator('.row-open').first().click();await page.locator('#detail').waitFor({state:'visible'});assert.ok((await page.locator('#detail-body').textContent()).includes(rows[0].code));states.push({name:theme+'/detail',sha256:hash(await page.locator('#detail-body').innerHTML())});await page.locator('#close-detail').click();
   const downloadPromise=page.waitForEvent('download');await table.locator('.export').click();const download=await downloadPromise;const bytes=fs.readFileSync(await download.path());assert.equal(download.suggestedFilename(),'Ton-kho.xlsx');assert.ok(bytes.toString('utf8').includes(rows[0].code));csv.push({theme,sha256:hash(bytes)});
   await page.evaluate(()=>window.inventoryView=document.querySelector('[data-view=inventory]'));
   await page.locator('[data-route=delivery]').click();await page.locator('[data-view=delivery]').waitFor({state:'visible'});await page.locator('[data-route=inventory]').click();await view.waitFor({state:'visible'});assert.equal(await page.evaluate(()=>window.inventoryView===document.querySelector('[data-view=inventory]')),true);assert.equal(await table.locator('input[type=search]').inputValue(),rows[0].code);await reset();await record('reset');
  }
  assert.equal(await page.evaluate(()=>window.inventoryEvents),0);assert.equal(rawRequests,1);assert.deepEqual(errors,[]);console.log(JSON.stringify({passed:true,rawRequests,states,csv,pageErrors:errors},null,2));
 }finally{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));assert.equal(path.dirname(runtime),os.tmpdir());assert.ok(path.basename(runtime).startsWith('mro-inventory-browser-'));fs.rmSync(runtime,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
