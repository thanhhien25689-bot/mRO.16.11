// Action duy nhất hiện có: đổi tab đối chiếu, không ghi dữ liệu.
export function showReconciliation(controller){controller.setTab('diff');}
