# Inventory — public contract

Cùng pattern Delivery: index/view/cards/selectors/actions và tests riêng. `index.mjs` là điểm vào duy nhất cho code ngoài module; không import internal. Hai file ở `modules/inventory/` giữ facade tương thích.

- `mount(root,data,presentation)`: đọc `data.items`, `data.asOf`; `presentation.badge` do host truyền đúng helper legacy. Không ghi dữ liệu, không fetch.
- Trả controller table hiện tại cùng `cardFilters` và `locationFilter`. Binder host dùng descriptor, giữ ID `inventory-0`…`inventory-4` và `location-0`…`location-4`.
- `cardFilters(data)` và `locationFilter(index)` giữ public export cũ qua facade.
- `view.mjs` giữ layout/table/detail; `cards.mjs` sở hữu KPI/filter; `selectors.mjs` sở hữu danh sách chênh lệch, vị trí và ba mã coverage thấp; `actions.mjs` chỉ chuyển tab `diff` cho nút đối chiếu.

Module chỉ dùng nội bộ, public Shared UI và facade `shared/model.mjs`. Các phép tính stockTotal/stockStatus/coverage/isAging/ageDays đang dùng xuyên màn nên không chuyển implementation hoặc sửa behavior. Badge là presentation adapter như Delivery, không refactor Shared UI.

Không có API ghi hoặc action sửa tồn kho. Giữ lỗi/hạn chế renderer coverage null và mọi threshold/ngày/CSV hiện tại. Không refactor module khác. Dữ liệu host, dialog toàn cục và controller table vẫn là contract shell; chưa deploy riêng.

Chạy `npm test` từ root để chạy unit và boundary/static test. Browser wrapper: `node tests/inventory.browser.cjs` trong sandbox có Playwright/Chrome. `MRO_FRONTEND_BASELINE` cho phép cùng script chạy trên checkpoint trước phase. Không chạy seed hoặc dùng runtime vận hành.

Static allowlist chỉ năm file production index/view/cards/selectors/actions. README/tests/private file không được public HTTP. Mọi thay đổi core/shared/public contract cần review và regression toàn hệ thống.
