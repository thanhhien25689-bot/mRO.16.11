import {appendCodeForConfirmedRequest} from '../../integration/procurement.mjs';
export function createRequest(rows,items,asOf,f){
 const item=items.find(r=>r.code===f.get('code'));rows.unshift({id:`REQ-${String(Math.max(0,...rows.map(r=>Number(r.id.split('-')[1])))+1).padStart(4,'0')}`,date:asOf,source:f.get('source'),list:f.get('list'),code:item.code,name:item.name,group:item.group,qty:Number(f.get('qty')),unit:item.unit,vendor:f.get('vendor'),sop:f.has('sop'),need:f.get('need'),status:'Chờ xác nhận',owner:'PIC1',po:null});
}
export function confirmRequest(data,request){
 request.status='Đã xác nhận';request.owner='PIC2';
 appendCodeForConfirmedRequest(data,request);
}
