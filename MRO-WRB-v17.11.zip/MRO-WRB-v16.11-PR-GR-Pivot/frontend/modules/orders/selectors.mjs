export const countStatus=(rows,status)=>rows.filter(r=>r.status===status).length;
export const sourceCount=rows=>new Set(rows.map(r=>r.source)).size;
export const remarkFormatHint='Type - Project - Model - Process';
const remarkText=v=>String(v??'').trim();
// 12/11/2026: bản sao phía trình duyệt của backend/modules/orders/index.cjs — Type chỉ có ba giá
// trị SETUP / SOP / Spare Part, sửa cùng lúc cả hai bản.
const remarkTypes={SETUP:'SETUP',SOP:'SOP',SPARE:'Spare Part','SPARE PART':'Spare Part'};
const remarkDashes=raw=>[...raw.matchAll(/(?:^|\s)-(?=\s|$)/g)].map(m=>m.index+m[0].length-1);
export function standardRemark(value){const raw=remarkText(value).replace(/\[non-minimum item\]/gi,'').trim();if(!raw)return{ok:false,error:'Remark trống; phải theo form Type - Project - Model - Process.'};const dashes=remarkDashes(raw);if(dashes.length<3)return{ok:false,error:'Remark phải đủ bốn phần Type - Project - Model - Process; Project, Model và Process được để trống nhưng vẫn phải giữ dấu " - " giữa các phần.'};const parts=[raw.slice(0,dashes[0]).trim(),raw.slice(dashes[0]+1,dashes[1]).trim(),raw.slice(dashes[1]+1,dashes[2]).trim(),raw.slice(dashes[2]+1).trim()],type=remarkTypes[parts[0].replace(/\s+/g,' ').toUpperCase()];if(!type)return{ok:false,error:'Remark phải bắt đầu bằng Type hợp lệ (SETUP, SOP hoặc Spare Part) và các phần cách nhau bằng " - ".'};return{ok:true,type,project:parts[1],model:parts[2],process:parts[3]};}
