# Orders — public contract (Phase 6B)

Cùng pattern Delivery/Inventory/Overview: index/view/cards/selectors/actions và test riêng. `index.mjs` là public entry duy nhất; code ngoài không import internal.

- `mount(root,data,presentation)` dựng UI cũ. `presentation.badge/icon` do host truyền từ helper legacy. Trả table controller hiện tại cùng `cardFilters` cho binder của host.
- `cardFilters(data)` giữ năm key legacy: all/confirmed/pending-confirmation/sop-late/purchase-plan. Thẻ cuối vẫn lọc toàn bộ rows, KPI vẫn đếm nguồn nhu cầu, không sửa khác biệt này.
- Hai file `modules/orders/index.mjs` và `modules/orders/public-card-filters.mjs` chỉ facade; mount(root,data) cũ được giữ.

## Ownership và handoff

Orders sở hữu requests: create unshift và confirm sửa status/owner. items/asOf chỉ đọc. Khi confirm, actions gọi public `frontend/integration/procurement.mjs::appendCodeForConfirmedRequest(data,request)` **sau** khi cập nhật request.

Integration giữ side effect legacy: nếu codes chưa có ID thì append bản copy request đã xác nhận, originalCode và defaults Phase 6A. Nếu đã có thì không ghi đè. Ownership codes vẫn Codes, tracking vẫn Tracking; Orders không truy cập internal Codes/Tracking hoặc trực tiếp ghi các mảng đó. Helper integration không thêm validation/status gate để tránh sửa behavior.

Index giữ thứ tự mutation → dialog.close → data-edited → toast. Core remount các view trong `data-edited.detail.views`; event không có detail mới fallback remount sáu view, không fetch. Không thêm event bus hoặc API/persist. SOP/ageDays giữ model facade; Codes Ready/Tracking preview/merge vẫn legacy, chưa module hóa.

## Phân chia file

- view: HTML/table/detail/form, callback onConfirm.
- cards: KPI/filter descriptor.
- selectors: đếm status/source riêng Orders.
- actions: createRequest và confirmRequest; handoff qua public integration.
- index: mount, event handler/lifecycle, controller.
- tests: unit ownership/shape/duplicate/edge và browser filter/detail/cancel/CSV; workflow xuyên module tiếp tục dùng procurement.browser.cjs.

Chạy npm test từ root. Browser chạy bản sao sandbox bằng tests/orders.browser.cjs và tests/procurement.browser.cjs (Playwright/Chrome); MRO_FRONTEND_BASELINE trỏ checkpoint để so sánh cùng script. Không seed hoặc dùng account/runtime thật.

Static allowlist chỉ năm file production Orders và đúng frontend/integration/procurement.mjs. README/tests/private/nested hoặc integration khác không được phục vụ. Khởi động lại server để nhận asset list mới.
