import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import * as api from '../index.mjs';
import {createRequest,confirmRequest} from '../actions.mjs';
import {cardFilters,kpiDescriptors} from '../cards.mjs';
import {sopLate} from '../../../../shared/model.mjs';
import {standardRemark,remarkFormatHint} from '../selectors.mjs';
import {procurementContract as c,appendCodeForConfirmedRequest} from '../../../integration/procurement.mjs';
const data=JSON.parse(readFileSync(new URL('../../../../tests/fixtures/legacy-raw.json',import.meta.url)));
test('Orders public API and KPI/filter mapping retain legacy semantics',()=>{
 assert.deepEqual(Object.keys(api).sort(),['cardFilters','mount']);const rows=data.requests,cards=cardFilters(data),kpis=kpiDescriptors(rows,data.asOf);
 assert.deepEqual(cards.map(c=>c.key),['all','confirmed','pending-confirmation','sop-late','purchase-plan']);assert.deepEqual(kpis.map(k=>k.key),cards.map(c=>c.key));
 const expected=[rows,rows.filter(r=>r.status==='Đã xác nhận'),rows.filter(r=>r.status==='Chờ xác nhận'),rows.filter(r=>sopLate(r,data.asOf)),rows];assert.deepEqual(cards.map(c=>rows.filter(c.filter)),expected);
 assert.deepEqual(kpis.map(k=>k.args[1]),[...expected.slice(0,4).map(r=>r.length),new Set(rows.map(r=>r.source)).size]);
});
test('Orders create owns requests only: unshift, exact fields/order, conversion and identity',()=>{
 const d=structuredClone(data),old=structuredClone(d),rows=d.requests,item=d.items[0];const id=`REQ-${String(Math.max(0,...rows.map(r=>Number(r.id.split('-')[1])))+1).padStart(4,'0')}`;
 const f=new Map(Object.entries({code:item.code,list:'Test <&',qty:'7',source:'Vendor C',vendor:'Vendor B',need:'2026-10-20',sop:'on'}));createRequest(rows,d.items,d.asOf,f);
 assert.equal(d.requests,rows);assert.deepEqual(Object.keys(rows[0]),c.requestFields);assert.deepEqual(rows[0],{id,date:d.asOf,source:'Vendor C',list:'Test <&',code:item.code,name:item.name,group:item.group,qty:7,unit:item.unit,vendor:'Vendor B',sop:true,need:'2026-10-20',...c.actions.create.defaults});assert.deepEqual(rows.slice(1),old.requests);assert.deepEqual({...d,requests:null},{...old,requests:null});
});
test('Orders confirmation delegates Codes write through integration, preserves append/defaults and duplicate row',()=>{
 const d=structuredClone(data),old=structuredClone(d),request={...d.requests[0],id:'REQ-CONTRACT',owner:'PIC1',status:'Chờ xác nhận'};d.requests.unshift(request);const codes=d.codes;
 confirmRequest(d,request);assert.equal(request.owner,'PIC2');assert.equal(request.status,'Đã xác nhận');assert.equal(d.codes,codes);assert.deepEqual(codes.slice(0,-1),old.codes);assert.deepEqual(codes.at(-1),{...request,originalCode:request.code,...c.actions.confirm.codeDefaults});assert.deepEqual(d.tracking,old.tracking);
 const existing=codes.at(-1);existing.owner='PIC3';existing.purchaseCode='EXISTING';const saved=structuredClone(existing);confirmRequest(d,request);assert.equal(codes.at(-1),existing);assert.deepEqual(existing,saved);assert.equal(codes.length,old.codes.length+1);
});
test('integration handoff does not mutate request or tracking and retains no-op for existing ID',()=>{
 const request=Object.freeze({...data.requests[0],status:'Đã xác nhận',owner:'PIC2'}),tracking=Object.freeze([]),d={codes:[],tracking};appendCodeForConfirmedRequest(d,request);assert.equal(d.tracking,tracking);assert.equal(request.owner,'PIC2');assert.notEqual(d.codes[0],request);const first=d.codes[0];appendCodeForConfirmedRequest(d,request);assert.equal(d.codes.length,1);assert.equal(d.codes[0],first);
});
test('Orders legacy edge behavior stays unchanged instead of adding validation',()=>{
 const rows=[],item=data.items[0],f=new Map(Object.entries({code:item.code,list:'',qty:'0',source:'SEV',vendor:'Vendor A',need:'2026-10-20'}));createRequest(rows,[item],data.asOf,f);assert.equal(rows[0].id,'REQ-0001');assert.equal(rows[0].qty,0);assert.equal(rows[0].sop,false);assert.throws(()=>createRequest([],[],data.asOf,f),TypeError);
});
test('Order Remark must follow the standard Type - Project - Model - Process form',()=>{
 const accepted=[['SETUP','Bud3FE','','Mass Line','SETUP - Bud3FE - - Mass Line'],['SETUP','Bud4','','Mass Line','SETUP - Bud4 - - Mass Line'],['SETUP','Tabs11','','Mass Line','SETUP - Tabs11 - - Mass Line'],['SOP','Improver Shuttle Output_Unload Aging 6h','','','SOP - Improver Shuttle Output_Unload Aging 6h - -'],['SOP','Improve auto attach label','','','SOP - Improve auto attach label - -'],['SOP','','','W48','SOP - - - W48'],['SOP','Rubber Item','','','SOP - Rubber Item - -'],['SOP','Silicon Cap','','','SOP - Silicon Cap - -']];
 assert.equal(remarkFormatHint,'Type - Project - Model - Process');
 for(const [type,project,model,process,remark]of accepted){const result=standardRemark(remark);assert.ok(result.ok,remark);assert.equal(result.type,type,remark);assert.equal(result.project,project,remark);assert.equal(result.model,model,remark);assert.equal(result.process,process,remark);}
 assert.equal(standardRemark('  setup - bud4 - - mass line  ').ok,true);
 assert.equal(standardRemark('SPARE PART - Rubber - -').type,'Spare Part','Type chỉ có SETUP / SOP / Spare Part');
 assert.equal(standardRemark('SOP - Alpha - M1 - Mass Line - Line 2').process,'Mass Line - Line 2');
 for(const wrong of ['','   ','Ghi chú','Mua mới','SETUP - Bud3FE','SETUP - Bud3FE - Mass Line','SETUP-Bud3FE-Mass Line','SETUP - Bud3FE - -Mass Line','Bud3FE - SETUP - - Mass Line','KHAC - A - B - C'])assert.equal(standardRemark(wrong).ok,false,wrong);
 const view=readFileSync(new URL('../view.mjs',import.meta.url),'utf8');
  assert.ok(view.includes('const issues=checkRemarks();if(issues.length){'));assert.ok(view.includes('[data-order-input="remark"].is-invalid'));assert.ok(view.includes('bắt buộc theo form <strong>Type - Project - Model - Process</strong>'));
});
test('Order bulk dialog: reject nhiều dòng đang Chờ duyệt đi cùng approve qua cùng orders-decision từng dòng',()=>{
 const view=readFileSync(new URL('../view.mjs',import.meta.url),'utf8');
 // Nút hàng loạt và nút từng dòng cho cả hai quyết định; cùng apply() tuần tự với partial success.
 assert.ok(view.includes('data-bulk-reject>Từ chối đã chọn'),'nút từ chối đã chọn');
 assert.ok(view.includes('data-bulk-reject-one="'),'nút từ chối từng dòng');
 assert.ok(view.includes("apply(picked(),'approve')")&&view.includes("apply(picked(),'reject')"),'cả hai quyết định đi qua apply()');
 assert.ok(view.includes('revision:row.revision,decision,comment'),'decision tham số hóa, không cứng approve');
 assert.ok(!/decision:'approve'/.test(view),'không còn approve cứng trong bulk');
  assert.ok(view.includes("if(!row||row.status!=='Chờ duyệt'||row.deleted)throw Error('Order đã thay đổi. Tải lại dữ liệu.')"),'pre-check: chỉ dòng Chờ duyệt được gửi');
  assert.ok((view.match(/timeKey:(?:row|r)\.timeKey/g)||[]).length===3,'cả quyết định từng dòng (r) lẫn hàng loạt (row) đều gửi timeKey để nhắm đúng dòng trùng khóa');
 assert.ok(view.includes('Đang ${doing} ${ok+failed+1}/${indices.length}…')&&view.includes('`${done} ${ok}/${indices.length} · Lỗi ${failed}. Các dòng đã lưu được giữ nguyên.`'),'trạng thái và kết quả báo theo quyết định, partial success');
});
