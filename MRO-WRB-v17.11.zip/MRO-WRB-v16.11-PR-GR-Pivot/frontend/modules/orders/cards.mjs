// Public descriptor của module; thứ tự giữ tương thích KPI legacy.
import {sopLate} from '../../../shared/model.mjs';
export function cardFilters(data){
 const all=()=>true,status=s=>r=>r.status===s;
 return [
  {key:'all',filter:all},
  {key:'confirmed',filter:status('Đã xác nhận')},
  {key:'pending-confirmation',filter:status('Chờ xác nhận')},
  {key:'sop-late',filter:r=>sopLate(r,data.asOf)},
  {key:'purchase-plan',filter:all}
 ];
}

import {countStatus,sourceCount} from './selectors.mjs';
export function kpiDescriptors(rows,asOf){return [
 {key:'all',args:['Tổng yêu cầu',rows.length,'Tất cả nguồn nhu cầu','order']},
 {key:'confirmed',args:['Đã xác nhận',countStatus(rows,'Đã xác nhận'),'Sẵn sàng chuyển PIC2','check','mint']},
 {key:'pending-confirmation',args:['Chờ xác nhận',countStatus(rows,'Chờ xác nhận'),'PIC1 cần kiểm tra','clock','amber']},
 {key:'sop-late',args:['SOP chưa có PO',rows.filter(r=>sopLate(r,asOf)).length,'Từ 21 ngày · theo owner','warn','red']},
 {key:'purchase-plan',args:['Nguồn nhu cầu',sourceCount(rows),'SEV & Vendor','layers','violet']}
 ];}
