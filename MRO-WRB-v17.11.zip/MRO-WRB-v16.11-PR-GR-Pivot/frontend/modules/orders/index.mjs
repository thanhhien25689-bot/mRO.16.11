import {toast} from '../../shared/ui/index.mjs';
import {render,renderSqlOrders,showCreateForm} from './view.mjs';
import {createRequest,confirmRequest} from './actions.mjs';
import {cardFilters} from './cards.mjs';
export {cardFilters};
export function mount(root,data,presentation){
 if(data.ordersSource)return renderSqlOrders(root,data,async()=>{const result=await presentation.api('orders-live');Object.assign(data,result);return result;},{canAdd:presentation.canEditBusiness,canDelete:presentation.canDeleteOrders,context:input=>presentation.api('orders-context?'+new URLSearchParams(input)),add:async input=>{const result=await presentation.api('orders-add','POST',input);Object.assign(data,result);return result;},canApprove:presentation.canApproveOrders,decide:async input=>{const result=await presentation.api('orders-decision','POST',input);Object.assign(data,result);return result;}});
 const rows=data.requests;
 const controller=render(root,data,presentation,r=>{
  confirmRequest(data,r);
  document.getElementById('detail').close();
  document.dispatchEvent(new CustomEvent('data-edited',{detail:{views:['orders','codes','tracking','projects','overview']}}));
  toast('Đã chuyển yêu cầu sang PIC2 trong phiên mẫu.');
 });
 root.querySelector('#new-request').onclick=()=>{
  showCreateForm(data);
  document.getElementById('request-form').onsubmit=e=>{
   e.preventDefault();createRequest(rows,data.items,data.asOf,new FormData(e.target));
   document.getElementById('detail').close();
   document.dispatchEvent(new CustomEvent('data-edited',{detail:{views:['orders','codes','tracking','projects','overview']}}));
   toast('Đã tạo yêu cầu trong phiên mẫu.');
  };
 };
 return Object.assign(controller,{cardFilters:cardFilters(data)});
}

