import {stockStatus,coverage,ohValue} from '../../../shared/model.mjs';
import {tableController,esc,toast} from '../../shared/ui/index.mjs';
import {cardFilters} from './cards.mjs';
import {repairSummary,savingSummary,cumulative} from './selectors.mjs';
export function bindChartActions(root,data){
 const chart=root.querySelector('.ov-finance .ov-chart'),cards=[...chart.closest('section').querySelectorAll('[data-oh-series]')];
 let selected=null;
 const toggle=card=>{selected=selected===card.dataset.ohSeries?null:card.dataset.ohSeries;cards.forEach(c=>c.setAttribute('aria-pressed',String(c.dataset.ohSeries===selected)));chart.querySelectorAll('.ov-bar').forEach(bar=>{const match=!selected||selected==='annual'&&!bar.classList.contains('ov-plan')||bar.classList.contains('ov-'+selected);bar.classList.toggle('ov-bar-muted',!match);bar.classList.toggle('ov-bar-highlight',!!selected&&match);});};
 cards.forEach(card=>{card.onclick=()=>toggle(card);card.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggle(card);}};});
 const tip=document.createElement('div');tip.id='oh-chart-tooltip';tip.className='ov-chart-tooltip';tip.role='tooltip';tip.hidden=true;chart.append(tip);
 const format=n=>new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(n);
 const hide=()=>{tip.hidden=true;};
 root.querySelectorAll('[data-oh-month]').forEach(month=>{
  const show=()=>{const row=data.budget.find(r=>r.month===Number(month.dataset.ohMonth));if(!row)return;const gr=ohValue(row),forecast=row.rawGR===null;tip.innerHTML=`<strong>${esc(month.querySelector('strong').textContent)} <small>· K USD</small></strong><div><span class="cyan">● P03 kế hoạch</span><b>${format(row.p03)}</b></div><div><span class="${forecast?'amber':'mint'}">● ${forecast?'GR dự kiến':'GR thực tế'}</span><b>${format(gr)}</b></div><div class="ov-tooltip-ratio"><span>GR / P03</span><b class="${row.p03>0&&gr>row.p03?'red':'cyan'}">${row.p03?format(gr/row.p03*100)+'%':'—'}</b></div>`;tip.hidden=false;const rect=month.getBoundingClientRect(),box=tip.getBoundingClientRect();tip.style.left=Math.max(8,Math.min(rect.left+rect.width/2-box.width/2,window.innerWidth-box.width-8))+'px';tip.style.top=Math.max(8,rect.top>box.height+12?rect.top-box.height-10:Math.min(rect.bottom+10,window.innerHeight-box.height-8))+'px';};
  month.onpointerenter=show;month.onpointerleave=hide;month.onfocus=show;month.onblur=hide;month.onkeydown=e=>{if(e.key==='Escape')hide();};
 });
 chart.addEventListener('scroll',hide,{passive:true});
}
// Giữ cùng lifecycle tạo/xóa bảng chi tiết và reset khi click thẻ.
export function bindCardActions(root,data,{badge},{cards,activate,selected}){
 let detail=null;
  const descriptors=[...cardFilters(data),{key:'codes-open',rows:()=>(data.codesSQL||data.codes).filter(r=>r.status!=='Ready for PR').map(r=>({...r,name:r.itemName||r.name}))}];
  const columns=[{key:'code',details:true,label:'Mã vật tư',secondary:r=>r.stockCalculation?.itemCodes?.join(', ')||r.itemCode||''},{key:'name',label:'Vật tư'},{label:'Coverage',value:r=>r.sqlStock?(coverage(r)===null?'—':(r.stockCalculation.exact?'':'≥ ')+coverage(r).toFixed(2)+' tuần'):coverage(r)?.toFixed(1)+' tuần',...(data.stockSource?{explain:r=>[r.stockCalculation.explanation,...r.stockCalculation.steps,...r.stockCalculation.problems].join('\n')}:{})},{label:'Trạng thái',value:stockStatus,render:r=>badge(stockStatus(r))}];
  const statuses=['Đủ tồn','Theo dõi','Nguy cơ thiếu','Hết hàng',...(data.stockSource?['Chưa đủ dữ liệu']:[])];
  const segments=[...root.querySelectorAll('.ov-stock svg g circle')],legends=[...root.querySelectorAll('.ov-stock .donut-legend>div')];
  let activeStatus=null;
  const clearStock=()=>{activeStatus=null;[...segments,...legends].forEach(el=>el.setAttribute('aria-pressed','false'));if(detail){detail.remove();detail=null;}};
  statuses.forEach((status,i)=>[segments[i],legends[i]].filter(Boolean).forEach(el=>{
   el.setAttribute('role','button');el.setAttribute('tabindex','0');el.setAttribute('aria-label',status+' · Xem dữ liệu');el.setAttribute('aria-pressed','false');el.dataset.stockStatus=status;
   const open=()=>{if(activeStatus===status){clearStock();return;}clearStock();selected(null);activeStatus=status;[segments[i],legends[i]].forEach(x=>x?.setAttribute('aria-pressed','true'));
    detail=document.createElement('section');detail.className='panel overview-card-details';detail.dataset.allowScroll='true';detail.innerHTML=`<div class="panel-head"><h2>${esc(status)} · Chi tiết</h2><button class="button" data-reset-stock>Reset</button></div><div class="table-panel"></div>`;
    root.querySelector('.ov-operations').after(detail);tableController(detail.querySelector('.table-panel'),{rows:data.items.filter(r=>stockStatus(r)===status),name:'Ton-kho-'+status,pageSize:5,columns});detail.querySelector('[data-reset-stock]').onclick=clearStock;
   };el.onclick=open;el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open();}};
  }));
  root.querySelectorAll('.ov-operations [data-overview-key]').forEach(el=>{const i=descriptors.findIndex(d=>d.key===el.dataset.overviewKey);if(i<0)return;el.dataset.cardId='overview-'+i;activate(el,()=>{clearStock();if(detail)detail.remove();detail=document.createElement('section');detail.className='panel overview-card-details';detail.dataset.allowScroll='true';const label=el.querySelector('.kpi-top>span').textContent;detail.innerHTML=`<div class="panel-head"><h2>${esc(label)} · Chi tiết</h2><button class="button" data-reset-overview>Reset</button></div><div class="table-panel"></div>`;root.querySelector('.ov-operations').after(detail);const rows=descriptors[i].rows().map(r=>i===4&&r.pr&&typeof r.pr==='object'?{...r,pr:r.pr.PR_NO,sq:r.pr.PR_SEQ,name:r.itemName}:r);tableController(detail.querySelector('.table-panel'),{rows,name:label,pageSize:5,columns:i===5?[{key:'id',label:'Yêu cầu'},{key:'originalCode',label:'Mã gốc',secondary:r=>data.items.find(item=>item.code===r.originalCode)?.stockCalculation?.itemCodes?.join(', ')||''},{key:'name',label:'Vật tư'},{key:'step',label:'Bước hiện tại'},{key:'status',label:'Trạng thái',render:r=>badge(r.status)}]:i===4?[{key:'pr',label:'PR'},{key:'sq',label:'PR Sq'},{key:'name',label:'Vật tư'},{key:'vendor',label:'Vendor'},{key:'status',label:'Trạng thái',render:r=>badge(r.status)}]:columns});selected(el.dataset.cardId);detail.querySelector('[data-reset-overview]').onclick=()=>{detail.remove();detail=null;selected(null);};});});return;
 }
// Cost Saving: tooltip cho biểu đồ đường, binding tách riêng (id ov-saving-tooltip) để không
// đụng chart OH và chart Repair.
const savingMonths=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
export function bindSavingChart(root,data){
 const chart=root.querySelector('.ov-line');
 if(!chart)return;
 const sav=savingSummary(data);
 // Biểu đồ Cost Saving vẽ lũy kế nên tooltip dùng cùng chuỗi lũy kế cho Plan và Actual.
 const planCum=cumulative(sav.plan),actualCum=cumulative(sav.actual);
 const tip=document.createElement('div');tip.id='ov-saving-tooltip';tip.className='ov-chart-tooltip';tip.role='tooltip';tip.hidden=true;chart.append(tip);
 const format=n=>new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(n);
 const hide=()=>{tip.hidden=true;};
 chart.querySelectorAll('[data-saving-month]').forEach(slot=>{
  const show=()=>{
   const index=Number(slot.dataset.savingMonth)-1;
   const point=sav.points[index];
   if(!point)return;
   // Giá trị so sánh là lũy kế: chênh lệch = (lũy kế Actual - lũy kế Plan) / lũy kế Plan.
   const target=planCum[index],value=actualCum[index];
   const ratio=target?((value??0)-target)/target*100:null;
   tip.innerHTML=`<strong>${esc(savingMonths[point.month-1])} <small>· K USD lũy kế</small></strong><div><span class="amber">● Kế hoạch lũy kế (Plan)</span><b>${target===null?'—':format(target)}</b></div><div><span class="cyan">● Thực hiện lũy kế (Actual)</span><b>${value===null?'—':format(value)}</b></div><div class="ov-tooltip-ratio"><span>${point.isPlan?'Tháng dự kiến':'Chênh lệch lũy kế / Plan'}</span><b class="${ratio!==null&&ratio<0?'red':'cyan'}">${point.isPlan?'—':ratio===null?'—':(ratio>0?'+':'')+ratio.toFixed(1)+'%'}</b></div>`;
   tip.hidden=false;
   const rect=slot.getBoundingClientRect(),box=tip.getBoundingClientRect();
   tip.style.left=Math.max(8,Math.min(rect.left+rect.width/2-box.width/2,window.innerWidth-box.width-8))+'px';
   tip.style.top=Math.max(8,rect.top>box.height+12?rect.top-box.height-10:Math.min(rect.bottom+10,window.innerHeight-box.height-8))+'px';
  };
  slot.onpointerenter=show;slot.onpointerleave=hide;slot.onfocus=show;slot.onblur=hide;slot.onkeydown=e=>{if(e.key==='Escape')hide();};
 });
 chart.addEventListener('scroll',hide,{passive:true});
}
export function bindRepairChart(root,data){
 const chart=root.querySelector('[data-oh-chart=repair]');
 if(!chart)return;
 const rep=repairSummary(data),rows=rep.rows;
 const tip=document.createElement('div');tip.id=chart.dataset.ohTip||'oh-repair-tooltip';tip.className='ov-chart-tooltip';tip.role='tooltip';tip.hidden=true;chart.append(tip);
 const format=n=>new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(n);
 const hide=()=>{tip.hidden=true;};
 chart.querySelectorAll('[data-oh-month]').forEach(month=>{
  const show=()=>{
   const row=rows.find(r=>r.month===Number(month.dataset.ohMonth));if(!row)return;
   const gr=ohValue(row),forecast=row.rawGR===null;
   tip.innerHTML=`<strong>${esc(month.querySelector('strong').textContent)} <small>· K USD</small></strong><div><span class="cyan">● P03 kế hoạch</span><b>${format(row.p03)}</b></div><div><span class="${forecast?'amber':'mint'}">● ${forecast?'GR dự kiến':'GR thực tế'}</span><b>${format(gr)}</b></div><div class="ov-tooltip-ratio"><span>GR / P03</span><b class="${row.p03>0&&gr>row.p03?'red':'cyan'}">${row.p03?format(gr/row.p03*100)+'%':'—'}</b></div>${row.reason?`<div class="ov-tooltip-reason"><span>Lý do vượt P03</span>${esc(row.reason)}</div>`:''}`;
   tip.hidden=false;const rect=month.getBoundingClientRect(),box=tip.getBoundingClientRect();tip.style.left=Math.max(8,Math.min(rect.left+rect.width/2-box.width/2,window.innerWidth-box.width-8))+'px';tip.style.top=Math.max(8,rect.top>box.height+12?rect.top-box.height-10:Math.min(rect.bottom+10,window.innerHeight-box.height-8))+'px';
  };
  month.onpointerenter=show;month.onpointerleave=hide;month.onfocus=show;month.onblur=hide;month.onkeydown=e=>{if(e.key==='Escape')hide();};
 });
 chart.addEventListener('scroll',hide,{passive:true});
}
// Nguồn Actual của OH Repair (WRB Data ↔ Tax confirm AdJ): ghi trường `source` vào budget doc portal APS
// qua cầu /api/aps-app (đã qua session/CSRF/role WRB, revision chống ghi đè). Không đủ quyền thì không đổi.
export function bindRepairSource(root,data,{repairApi,canUpdateBudget,onSaved}){
 const select=root.querySelector('[data-repair-source]');
 if(!select||!repairApi)return;
 select.onchange=async()=>{
  const rep=repairSummary(data),value=select.value==='manual'?'manual':'payments';
  if(!canUpdateBudget?.()||value===rep.docSource){select.value=rep.docSource||'payments';return;}
  select.disabled=true;
  try{
   const state=await repairApi('aps-app/api/data?year='+encodeURIComponent(rep.year));
   const doc=state.budget||{year:Number(rep.year),closed:0,months:Array.from({length:12},()=>({p03:0,actual:0,plan:0,reason:''}))};
   const months=(Array.isArray(doc.months)&&doc.months.length===12?doc.months:Array.from({length:12},()=>({}))).map(m=>({p03:Number(m.p03)||0,actual:Number(m.actual)||0,plan:Number(m.plan)||0,reason:String(m.reason||'').slice(0,1000)}));
   await repairApi('aps-app/api/budget','PUT',{year:Number(doc.year)||Number(rep.year),closed:Number(doc.closed)||0,source:value,revision:Number(state.revision)||0,months});
   onSaved?.({source:value});
  }catch(e){select.value=rep.docSource||'payments';toast(e.message||'Không đổi được nguồn ngân sách Repair.');}
  finally{select.disabled=!canUpdateBudget?.();}
 };
}

