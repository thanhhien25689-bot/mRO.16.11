# Overview — public contract

Cùng pattern Delivery/Inventory: index/view/cards/selectors/actions, test riêng và facade host. `index.mjs` là entry duy nhất; code bên ngoài không import internal.

- `mount(root,data,presentation)` dựng Overview, chỉ đọc snapshot. Host cung cấp `presentation.badge` và `presentation.link` bằng helper legacy.
- `cardFilters(data)` trả năm descriptor rows lazy: all/sufficient/shortage/out-of-stock/pending-po. KPI sản lượng thứ sáu vẫn không clickable.
- mount trả `{bindCards(context)}`; binder host truyền `{cards,activate,selected}` sau render. Đây là callback controller để module sở hữu action mở/reset detail riêng của Overview; không tạo router/store/event framework mới.
- `view.mjs` giữ layout/chart/links. `cards.mjs` giữ KPI descriptors và row selectors của thẻ. `selectors.mjs` tổng hợp snapshot cho màn Overview. `actions.mjs` giữ nguyên lifecycle/template bảng chi tiết, reset và export thông qua public tableController.

Khác Delivery/Inventory ở chỗ Overview không có một bảng chính: chọn một trong năm thẻ tạo bảng chi tiết tạm. Callback bindCards giữ timing cũ sau mount. Shared không biết implementation này và không import Overview. Navigation data-go/data-filter vẫn do core xử lý; không thêm fetch, data write hoặc event data-edited.

Giữ toàn bộ implementation shared/model: stockStatus/coverage/isAging/sopLate/ohValue/sum vẫn là facade hợp lệ dùng nhiều màn hoặc chưa rõ ownership. Overview chỉ sở hữu tổ hợp/tập con dùng để hiển thị, không sở hữu lại công thức tồn kho/SOP/budget. Không import internal module khác.

`modules/overview/index.mjs` giữ mount(root,data), truyền badge/link. `modules/overview/public-card-filters.mjs` re-export public contract. DOM ID/thứ tự KPI, lỗi/edge behavior, labels và công thức legacy không tối ưu/sửa trong phase này.

Unit chạy qua npm test; browser qua tests/overview.browser.cjs trong sandbox có Playwright/Chrome. Biến MRO_FRONTEND_BASELINE trỏ checkpoint để chạy cùng test trên source cũ. Runtime tạm, không seed hoặc dùng account thật. Static allowlist chỉ năm file production, không tests/README/private. Module chưa là app deploy riêng; vẫn dùng shell/theme/shared table và snapshot host.


## Layout hai khoang (28/10/2026)

`index.mjs` set `root.dataset.fitViewport=''` (bật lại 12/11/2026): core `scheduleFit` zoom Overview vừa khít chiều cao `#main`, chỉ từ 1100px bề ngang và bỏ qua khi view có `[data-allow-scroll]`; khối nén CSS cuối `assets/readability.css` giữ hệ số zoom gần 1 trên màn 24 inch. `view.mjs` bọc
`section.ov-finance` (Ngân sách OH) và `section.ov-duo` (OH Repair và COST Saving) trong
`div.ov-fold`; từ 12/11/2026 không còn `section.ov-materials` (bảng "Vận hành & vật tư" đã gỡ khỏi
tab Tổng quan) nên fold chứa đúng hai bảng, mỗi bảng một dòng và lấp đầy chiều ngang cửa sổ. `selectors.mjs` thêm
`repairSummary` (đổi đơn vị `data.aps.budget` sang K$, dùng `ohValue` của shared/model, không tính
lại nghiệp vụ APS) và `savingSummary` (đọc `data.costSaving` per-year). `actions.mjs` tách
`bindRepairChart` cho chart Repair (tooltip id riêng `oh-repair-tooltip`), còn `bindChartActions`
giới hạn trong `.ov-finance .ov-chart`. `budget.mjs` thêm `bindSavingChart` (tooltip chart Cost
Saving; dialog nhập Cost Saving đã bị thay bằng nguồn SQL). Host `modules/overview/index.mjs`
truyền thêm `savingApi:api, canUpdateBudget`. Section mới dùng `.ov-duo-card`, không dùng class
`.kpi`. Chi tiết và kết quả test: `docs/cost-saving-overview.md`.

## Ngân sách Repair về Overview (28/10/2026)

Sau khi panel P03/GR rời portal `aps-app`, thẻ OH Repair ở Overview sở hữu:

- `selectors.mjs`: `repairSummary` theo logic tab Repair & Service (grVal từ requests, grSplit
  theo tháng hiện hành trong `data.aps.asOf`, nguồn `payments|manual`, cap "tháng vừa qua" theo
  `closed`). `data.repairSource` chỉ đổi cách đọc, không ghi dữ liệu.
- `view.mjs`: select nguồn `data-repair-source`, nút `data-repair-detail`, nút `data-repair-update`
  (chỉ admin trở lên), 4 KPI `.ov-finance-stat`, dải period theo `grSplit`, aside "KẾT QUẢ THÁNG
  VỪA QUA" kèm "Lý do vượt P03".
- `actions.mjs`: `bindRepairChart` (tooltip + lý do vượt P03) và `bindRepairSource` (đổi nguồn qua
  PUT cầu APS, hoàn tác về giá trị cũ khi lỗi).
- `budget.mjs`: `bindRepairBudget` — dialog chi tiết chỉ đọc và dialog cập nhật 12 tháng (P03,
  Actual thủ công, Payment Plan, Lý do vượt P03, Chốt đến tháng, Nguồn Actual) ghi qua
  `presentation.repairApi` = `api` của host (`GET /api/aps-app/api/data`, `PUT /api/aps-app/api/budget`,
  revision chống ghi đè); sau lưu đọc lại và merge vào `state.repairOverride` để vẽ ngay.
- Host `modules/overview/index.mjs` truyền thêm `repairApi:api`. Test: unit trong module và
  `tests/aps-panel-removed.test.mjs`, `tests/repair-budget-api.test.mjs`.

## Nén chiều cao cho màn 24 inch (12/11/2026)

Hai bảng full-width nên biểu đồ cao theo bề ngang; tổng chiều cao vượt vùng nhìn thấy của
màn 1920×1080. `assets/readability.css` thêm khối cuối file
`@media(min-width:1250px) and (max-height:1015px)` chỉ chỉnh padding/chiều cao
(`.ov-plot`, `.ov-columns`, `.ov-duo .ov-line svg` dùng `clamp(...vh...)`), không đổi cỡ chữ;
nhờ đó hệ số zoom mà `data-fit-viewport` áp lên Overview gần bằng 1 trên màn 24 inch.
`tests/workspace-responsive.browser.cjs` bổ sung viewport 1920×990 và khoá
`duoBottom <= mainBottom + 14`, in dòng `OVERVIEW-FIT` để hiệu chỉnh.
