import {stockStatus,isAging,sopLate,ohValue,sum} from '../../../shared/model.mjs';
// Chỉ chọn/tổng hợp dữ liệu cho Overview; không di chuyển phép tính cross-screen.
export function summary(data){
const {items,requests,budget,production}=data;const tracking=data.trackingSQL||data.tracking;const count=s=>items.filter(r=>stockStatus(r)===s).length;const critical=items.filter(r=>['Hết hàng','Nguy cơ thiếu'].includes(stockStatus(r)));const late=requests.filter(r=>sopLate(r,data.asOf));const aging=items.filter(r=>isAging(r,data.asOf));const annual=data.budgetOH?data.budgetOH.totals.annual/1000:sum(budget,ohValue),p03=data.budgetOH?data.budgetOH.totals.p03/1000:sum(budget,'p03');
const max=Math.max(...budget.map(r=>Math.max(r.p03,ohValue(r))))*1.15;
return {items,requests,tracking,budget,production,count,critical,late,aging,annual,p03,max};
}

export function budgetSummary(data){
 const actual=data.budget.filter(r=>r.rawGR!==null),forecast=data.budget.filter(r=>r.rawGR===null);
 const latest=actual.reduce((a,r)=>!a||r.month>a.month?r:a,null);
 return {actual:data.budgetOH?data.budgetOH.totals.actual/1000:sum(actual,ohValue),forecast:data.budgetOH?data.budgetOH.totals.forecast/1000:sum(forecast,'forecast'),latest,year:String(data.ohYear||data.budgetOH?.document.year||data.asOf).slice(0,4),actualMonths:actual.map(r=>r.month),forecastMonths:forecast.map(r=>r.month)};
}


// OH Repair: đọc snapshot APS do host merge (data.aps), chuyển sang logic của tab Repair & Service
// (biểu đồ P03/GR nay chỉ còn ở đây): GR (nguồn WRB Data) tính theo paymentMonth/Year của requests,
// bỏ Service loại "Setup new MC"; Actual thủ công (Tax confirm AdJ) và Payment Plan lấy từ budget doc
// portal APS. Actual/Dự kiến tách theo tháng hiện tại (data.asOf, Asia/Ho_Chi_Minh), "tháng vừa qua"
// bị chặn theo tháng chốt (closed). data.repairSource chỉ đổi cách đọc, không ghi dữ liệu.
export function repairSummary(data){
 const aps=data.aps||{},budget=aps.budget||null;
 const round=n=>Math.round(n*100)/100,k=n=>round((Number(n)||0)/1000);
 const months=budget&&Array.isArray(budget.months)?budget.months:[];
 const stamp=/^(\d{4})-(\d{1,2})/.exec(String(aps.asOf||data.asOf||''));
 const clock=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'numeric'}).formatToParts(new Date());
 const nowYear=stamp?Number(stamp[1]):Number(clock.find(p=>p.type==='year').value);
 const nowMonth=stamp?Number(stamp[2]):Number(clock.find(p=>p.type==='month').value);
 const year=Number(budget?budget.year:String(data.ohYear||data.asOf).slice(0,4))||nowYear;
 const grSplit=!budget?0:year<nowYear?12:year>nowYear?0:nowMonth-1;
 const docSource=budget?.source==='manual'?'manual':'payments';
 // Nguồn GR khi Overview đang ở "WRB Data": ưu tiên SQL Server (EQM_MRO_REPAIR + EQM_MRO_SERVICE,
 // SUM [Amount 2 (USD)] theo Month/Year Payment) do aps.sql mang về; SQL chưa đọc được hoặc chưa có
 // dữ liệu năm đó thì mới fallback SQLite portal. "Tax confirm (AdJ)" (manual) luôn theo budget.
 const sql=aps.sql&&aps.sql.available?aps.sql:null;
 const sqlReady=!!(sql&&sql.connected!==false);
 const sqlHasYear=list=>sqlReady&&Array.isArray(list)&&list.some(row=>String(row.year)===String(year));
 const sqlGRValue=(y,month)=>{const hit=(sql.gr||[]).find(row=>String(row.year)===String(y)&&Number(row.month)===Number(month));return hit?Number(hit.amountUSD)||0:0;};
 const sqlPlanValue=(y,month)=>{const hit=(sql.plan||[]).find(row=>String(row.year)===String(y)&&Number(row.month)===Number(month));return hit?Number(hit.amountUSD)||0:null;};
 const hasSQLGR=sqlReady&&sqlHasYear(sql.gr),hasSQLPlan=sqlReady&&sqlHasYear(sql.plan);
 const override=data.repairSource==='manual'||data.repairSource==='payments'||data.repairSource==='sql'?data.repairSource:null;
 const source=override||(docSource==='manual'?'manual':hasSQLGR?'sql':'payments');
 const skipGR=r=>r.type==='Service'&&String(r.serviceType||'').trim().toLowerCase().replace(/\s+/g,' ')==='setup new mc';
 const grVal=month=>(Array.isArray(aps.requests)?aps.requests:[]).reduce((acc,r)=>{
  if(skipGR(r)||String(r.paymentYear||year)!==String(year))return acc;
  if((r.paymentMonth?Number(r.paymentMonth):0)!==month)return acc;
  return acc+(r.type==='Repair'?(r.lines||[]).reduce((t,l)=>t+(Number(l.amount2USD)||0),0):(Number(r.amount2USD)||0));
 },0);
 const rows=months.map((m,i)=>{
  const month=m.month||i+1;
  const p03=k(m.p03),actualWRB=k(grVal(month)),actualTax=k(m.actual),plan=k(m.plan),isActual=i<grSplit;
  const sqlGR=isActual&&hasSQLGR?k(sqlGRValue(year,month)):null;
  const planAt=hasSQLPlan?sqlPlanValue(year,month):null;
  const sqlPlan=planAt===null?null:k(planAt);
  const value=source==='manual'?(isActual?actualTax:plan||actualTax||actualWRB)
   :source==='sql'?(isActual?(sqlGR===null?actualWRB:sqlGR):(sqlPlan!==null?sqlPlan:(plan||actualTax||actualWRB)))
   :actualWRB;
  return {month,p03,rawGR:isActual?value:null,forecast:isActual?null:value,adjustment:0,actualWRB,actualTax,plan,sqlGR,sqlPlan,isActual,reason:m.reason||''};
 });
 const actual=rows.filter(r=>r.rawGR!==null),forecast=rows.filter(r=>r.rawGR===null);
 const closedCap=budget?Math.min(Math.max(Number(budget.closed)||0,0),12):0;
 let lastMonthNum=!budget?0:year<nowYear?12:year>nowYear?0:nowMonth-1;
 if(lastMonthNum>0)lastMonthNum=Math.min(lastMonthNum,closedCap||12);
 const latest=lastMonthNum>0?rows.find(r=>r.month===lastMonthNum)||null:null;
 const delta=latest?ohValue(latest)-latest.p03:0;
 const actualTotal=round(actual.reduce((t,r)=>t+ohValue(r),0)),forecastTotal=round(forecast.reduce((t,r)=>t+ohValue(r),0)),p03Total=round(rows.reduce((t,r)=>t+r.p03,0));
 return {
  connected:aps.connected!==false,warning:aps.warning||'',source,docSource,
  sqlConnected:sqlReady,sqlGR:hasSQLGR,sqlPlan:hasSQLPlan,sqlWarning:(sql&&sql.warning)||'',
  closed:closedCap,grSplit,year:String(budget?budget.year:String(data.ohYear||data.asOf).slice(0,4)),
  rows,max:rows.length?Math.max(...rows.map(r=>Math.max(r.p03,ohValue(r))))*1.15:1,
  actual,forecast,latest,delta,percent:latest&&latest.p03?delta/latest.p03*100:null,
  actualMonths:actual.map(r=>r.month),forecastMonths:forecast.map(r=>r.month),
  total:round(actualTotal+forecastTotal),p03Total,actualTotal,forecastTotal,
  variancePct:p03Total?round((actualTotal+forecastTotal-p03Total)/p03Total*100):null
 };
}

// Lũy kế Cost Saving: giá trị tháng N = tổng T1..TN cho cả Plan và Actual. Tháng trống (null)
// không tạo điểm trên đường nhưng không chặn tổng; làm tròn 2 số lẻ (đơn vị K$) để không tích sai số.
export function cumulative(values){
 let total=0;
 return (Array.isArray(values)?values:[]).map(value=>{
  if(value===null||value===undefined||value==='')return null;
  const number=Number(value);
  if(!Number.isFinite(number))return null;
  total+=number;
  return Math.round(total*100)/100;
 });
}

// Cost Saving đọc từ dbo.EQM_CostSavingActivity (USD). months = Actual các tháng đã/đang diễn ra,
// Plan cho các tháng còn lại; K$ chỉ là cách hiển thị, không đổi số liệu nguồn.
export function savingSummary(data){
 const record=data.costSaving||null;
 const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'numeric'}).formatToParts(new Date()).map(p=>[p.type,p.value]));
 const currentYear=Number(parts.year),currentMonth=Number(parts.month);
 const year=Number(data.ohYear||String(data.asOf).slice(0,4))||currentYear;
 const series=record||{};
 const k=key=>{const source=Array.isArray(series[key])?series[key]:[];return Array.from({length:12},(_,index)=>{const value=source[index];return value===null||value===undefined||value===''?null:Math.round(Number(value)*100/1000)/100;});};
 const plan=k('plan'),actual=k('actual'),months=k('months');
 const viewMonth=currentYear===year?currentMonth:12;
 const points=months.map((value,index)=>({month:index+1,target:plan[index],value,actual:actual[index],isPlan:index+1>viewMonth}));
 const max=Math.max(0,...plan,...actual,...months);
 return {
  year,viewMonth,currentMonth:year===currentYear?currentMonth:(year<currentYear?12:0),
  plan,actual,months,points,maxK:max?Math.ceil(max/4)*4||max:0,
  total:months.reduce((total,value)=>total+(value??0),0),
  planTotal:plan.reduce((total,value)=>total+(value??0),0),
  actualTotal:actual.reduce((total,value)=>total+(value??0),0),
  actualMonths:actual.filter(value=>value!==null).length,planMonths:plan.filter(value=>value!==null).length,
  viewValue:months[viewMonth-1],items:record?.items||0,source:record?.source||'',
  warning:record?.warning||'',updatedAt:record?.updatedAt||'',loading:record?.source==='empty'&&!record?.warning
 };
}
