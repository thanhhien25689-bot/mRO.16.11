// Public descriptor của module; thứ tự giữ tương thích KPI legacy.
import {stockStatus} from '../../../shared/model.mjs';
export function cardFilters(data){
 const all=()=>true,stock=s=>r=>stockStatus(r)===s;
 return [
  {key:'all',rows:()=>data.items.filter(all)},
  {key:'sufficient',rows:()=>data.items.filter(stock('Đủ tồn'))},
  {key:'shortage',rows:()=>data.items.filter(stock('Nguy cơ thiếu'))},
  {key:'out-of-stock',rows:()=>data.items.filter(stock('Hết hàng'))},
  {key:'pending-po',rows:()=>(data.trackingSQL||data.tracking).filter(r=>data.trackingSQL?r.pr?.PR_NO&&!r.pr?.PO_NO:!r.po)}
 ];
}

import {fmt} from '../../shared/ui/index.mjs';
export function kpiDescriptors(data,count){
 const {items,tracking,production}=data;
 return [
 {key:'all',args:['Tổng mã vật tư',fmt(items.length),'SEV & 4 vendor','stock']},
 {key:'sufficient',args:['Đủ tồn',count('Đủ tồn'),`${(items.length?Math.round(count('Đủ tồn')/items.length*100):0)}% danh mục vật tư`,'check','mint']},
 {key:'shortage',args:['Nguy cơ thiếu',count('Nguy cơ thiếu'),data.stockSource?'Coverage < 2 tuần / Safety stock':'Coverage dưới 1 tuần','warn','amber']},
 {key:'out-of-stock',args:['Hết hàng',count('Hết hàng'),'Cần bổ sung vật tư','stock','red']},
 {key:'pending-po',args:['PR chờ PO',(data.trackingSQL||tracking).filter(r=>data.trackingSQL?r.pr?.PR_NO&&!r.pr?.PO_NO:!r.po).length,'Theo dõi cùng PIC3','tracking','violet']},
 {key:'codes-open',args:['Code chưa Ready',(data.codesSQL||data.codes).filter(r=>r.status!=='Ready for PR').length,'Chưa sẵn sàng bàn giao PIC3','code','cyan']}
 ];
}
