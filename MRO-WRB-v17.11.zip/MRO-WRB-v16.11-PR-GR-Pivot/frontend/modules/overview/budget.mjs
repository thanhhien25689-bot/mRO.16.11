import {showDetail,esc,toast} from '../../shared/ui/index.mjs';
import {repairSummary} from './selectors.mjs';

const money = value => value === null ? '—' : new Intl.NumberFormat('en-US',{maximumFractionDigits:0}).format(value);
const precise=n=>n===null?'—':new Intl.NumberFormat('en-US',{maximumFractionDigits:4}).format(n);
const monthName=n=>['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][n-1];
const series=[['total','oldTotal','P03'],['actualPR','oldPR','PR'],['actualGR','oldGR','GR']];
const inputSeries=[...series,['other',null,'Other']];
const combined=r=>({...r,actualGR:r.actualGR+(r.other||0)});
const kind = actual => actual?'Thực tế':'Dự kiến';
const period = actual => actual?'oh-gr-actual':'oh-gr-forecast';
const legend = '<div class="oh-period-legend"><span class="oh-gr-actual">GR thực tế</span><span class="oh-gr-forecast">GR dự kiến</span><small>GR và PR: trước tháng hiện tại là Actual, còn lại là Plan.</small></div>';
const rowTable = (rows, preview=false, details=false) => legend+`<div class="table-scroll"><table class="oh-import-table oh-month-grid"><thead><tr><th>Chỉ tiêu · USD</th>${rows.map(r=>`<th scope="col" class="${period(r.actual)}" title="GR ${monthName(r.month)}: ${kind(r.actual)}">${monthName(r.month)}</th>`).join('')}</tr></thead><tbody>${(details?[...series,['diffPR',null,'Diff PR'],['diffGR',null,'Diff GR']]:series).map(([key,old,label])=>`<tr><th scope="row">${label}</th>${rows.map(r=>`<td class="${key.startsWith('diff')?(r[key]<0?'red':'mint'):['actualGR','actualPR'].includes(key)?period(r.actual):''}" data-calculation="${esc(key==='diffPR'?'Diff PR = P03 − PR: '+precise(r.total)+' − '+precise(r.actualPR)+' = '+precise(r.diffPR):key==='diffGR'?'Diff GR = P03 − GR: '+precise(r.total)+' − '+precise(r.actualGR)+' = '+precise(r.diffGR):label+' · '+monthName(r.month))}" tabindex="0" title="${['actualGR','actualPR'].includes(key)?(key==='actualGR'?'GR ':'PR ')+monthName(r.month)+': '+kind(r.actual):label+' '+monthName(r.month)}">${money(r[key])}${preview?`<small>Trước: ${money(r[old])}</small>`:''}${preview&&key==='actualGR'&&r.oldActual!==r.actual?'<small>Đổi phân loại GR</small>':''}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
const entryTable = document => legend+`<div class="table-scroll"><table class="oh-entry-table oh-month-grid"><thead><tr><th>Chỉ tiêu · USD</th>${document.months.map(r=>`<th scope="col" data-oh-period-month="${r.month}" class="${period(r.month<=document.actualThroughMonth)}" title="GR ${monthName(r.month)}: ${kind(r.month<=document.actualThroughMonth)}">${monthName(r.month)}</th>`).join('')}</tr></thead><tbody>${inputSeries.map(([key,,label])=>`<tr><th scope="row">${label}</th>${document.months.map(r=>`<td data-oh-month="${r.month}" class="${['actualGR','actualPR'].includes(key)?period(r.month<=document.actualThroughMonth):''}"><input type="number" inputmode="decimal" ${key==='other'?'min="-10000000000"':'min="0"'} max="10000000000" step="0.0001" required data-oh-field="${key}" aria-label="${monthName(r.month)} ${key}" title="${['actualGR','actualPR'].includes(key)?(key==='actualGR'?'GR ':'PR ')+monthName(r.month)+': '+kind(r.month<=document.actualThroughMonth):label+' '+monthName(r.month)}" value="${esc(r[key]??(key==='other'?0:''))}"></td>`).join('')}</tr>`).join('')}</tbody></table></div>`;


export function bindBudget(root,data,{budgetApi,canUpdateBudget,onSaved}) {
  if (!budgetApi) return;
  root.querySelector('[data-oh-detail]').onclick = () => {
    const saved=data.budgetOH,doc=saved?.document;if(data.ohMissing){showDetail('Ngân sách OH','<p>Chưa có dữ liệu cho năm đã chọn.</p>');return;}
    const rows=doc?doc.months.map(r=>({...combined(r),actual:r.month<=doc.actualThroughMonth})):data.budget.map(r=>({month:r.month,total:r.p03*1000,actualPR:null,actualGR:(r.rawGR===null?r.forecast:r.rawGR+r.adjustment)*1000,actual:r.rawGR!==null}));
    showDetail(`Ngân sách OH · ${doc?.year||String(data.ohYear||data.asOf).slice(0,4)}`,`<p class="small muted">Đơn vị USD; hiển thị số nguyên làm tròn, dấu phẩy phân cách hàng nghìn. Diff PR = P03 − PR; Diff GR = P03 − GR. Số gốc khi lưu giữ nguyên độ chính xác.</p>${saved?`<p class="small">${doc.actualThroughMonth?'Actual đến hết '+monthName(doc.actualThroughMonth):'Toàn bộ Plan'}. Cập nhật: ${esc(new Date(saved.updatedAt).toLocaleString('vi-VN'))} · ${esc(saved.updatedBy.name)}</p>`:'<p class="small">Dữ liệu mẫu hiện tại, chưa nhập JSON ngân sách.</p>'}${rowTable(rows.map(r=>({...r,diffPR:r.actualPR===null?null:r.total-r.actualPR,diffGR:r.total-r.actualGR})),false,true)}`);
  };
  const update=root.querySelector('[data-oh-update]');
  if (!update || !canUpdateBudget?.()) return;
  update.onclick=async()=>{
    update.disabled=true;
    try {
      const year=Number(String(data.ohYear||data.asOf).slice(0,4)),state=await budgetApi(`budget-oh?year=${year}`);
      const initial=(data.budgetOH?.source==='sql'?data.budgetOH.document:state.document) || {year,currency:'USD',actualThroughMonth:state.actualThroughMonth,months:Array.from({length:12},(_,i)=>({month:i+1,total:'',actualPR:'',actualGR:''}))};
      if(!root.isConnected)return;
      showDetail(`Cập nhật ngân sách OH · ${year}`,`<form id="oh-import" class="account-form"><p>Điền số liệu trực tiếp vào bảng, đơn vị <strong>USD</strong>. P03 = kế hoạch; GR và PR trước tháng hiện tại là Actual, từ tháng hiện tại là Plan. Năm trước: toàn bộ Actual; năm sau: toàn bộ Plan. Other được lưu riêng và cộng vào GR khi hiển thị; không cộng trước vào ô GR nhập.</p><p class="small muted" data-oh-source>${state.document?'Bảng đang dùng số liệu đã lưu trên máy chủ.':'Chưa có ngân sách. Điền đủ 12 tháng hoặc tải từ SQL Server.'}</p><div class="account-actions"><button type="button" class="button" data-oh-sql>Tải từ SQL Server</button><span class="small muted">Hoặc nhập/paste vào bảng bên dưới · Xác nhận bảng nhập sẽ ghi P03/GR/PR/Other lên SQL và cập nhật JSON</span></div><div data-oh-editor><div class="oh-entry-tools"><label>Actual tự động đến hết<select data-oh-cutoff disabled>${Array.from({length:13},(_,i)=>`<option value="${i}" ${i===initial.actualThroughMonth?'selected':''}>${i?monthName(i):'Toàn bộ Plan'}</option>`).join('')}</select></label><label>Số khi dán Excel<select data-oh-paste-format><option value="en">1,234.56 (dấu chấm thập phân)</option><option value="vi">1.234,56 (dấu phẩy thập phân)</option></select></label><button type="button" class="button" data-oh-template>Tải file mẫu ${year}</button></div>${entryTable(initial)}<p class="small muted">Copy vùng số từ Excel, chọn ô bắt đầu rồi Ctrl+V (không copy tiêu đề). Chọn đúng định dạng số ở trên. Tối đa 4 chữ số thập phân; ô trống không được tự tính là 0.</p><details class="oh-file-option"><summary>Hoặc nhập từ file JSON</summary><input type="file" accept=".json,application/json" data-oh-file aria-label="File ngân sách JSON"></details></div><p role="alert" class="red"></p><div data-oh-preview></div><div class="account-actions oh-entry-actions"><button type="button" class="button" data-oh-cancel>Hủy</button><button type="button" class="button" data-oh-back hidden>Sửa số liệu</button><button type="button" class="button primary" data-oh-check>Xem trước</button><button type="submit" class="button primary" disabled hidden data-oh-save>Xác nhận cập nhật</button></div></form>`);
      const form=document.getElementById('oh-import'),dialog=document.getElementById('detail'),error=form.querySelector('[role=alert]'),save=form.querySelector('[data-oh-save]'),fileInput=form.querySelector('[data-oh-file]'),preview=form.querySelector('[data-oh-preview]'),editor=form.querySelector('[data-oh-editor]'),check=form.querySelector('[data-oh-check]'),back=form.querySelector('[data-oh-back]'),cutoff=form.querySelector('[data-oh-cutoff]');
      dialog.scrollTop=0;
      let candidate=null,sqlToken=null,revision=state.revision,sequence=0,saving=false;
      const sqlButton=form.querySelector('[data-oh-sql]');
      const active=()=>form.isConnected&&dialog.open;
      const inputs=[...form.querySelectorAll('[data-oh-field]')];
      function invalidate(){sequence++;candidate=null;sqlToken=null;save.disabled=true;save.hidden=true;back.hidden=true;check.hidden=false;check.disabled=false;editor.hidden=false;error.textContent='';preview.innerHTML='';}
      function kinds(){form.querySelectorAll('[data-oh-period-month]').forEach(header=>{const month=Number(header.dataset.ohPeriodMonth),actual=month<=Number(cutoff.value),text='GR '+monthName(month)+': '+kind(actual);header.className=period(actual);header.title=text;for(const key of ['actualGR','actualPR']){const input=form.querySelector(`[data-oh-month="${month}"] [data-oh-field="${key}"]`);input.parentElement.className=period(actual);input.title=(key==='actualGR'?'GR ':'PR ')+monthName(month)+': '+kind(actual);input.setAttribute('aria-label',`${monthName(month)} ${key} · ${kind(actual)}`);}});}
      editor.addEventListener('input',()=>{if(!saving){invalidate();kinds();}});
      editor.addEventListener('paste',e=>{
        const target=e.target.closest('[data-oh-field]');if(!target||saving)return;
        e.preventDefault();
        try{
          const text=e.clipboardData?.getData('text/plain');
          if(!text||text.length>20000)throw Error('Vùng dán trống hoặc quá lớn.');
          const lines=text.replace(/\r\n?/g,'\n').replace(/\n$/,'').split('\n').map(line=>line.split('\t'));
          const startRow=inputSeries.findIndex(([key])=>key===target.dataset.ohField),startCol=Number(target.closest('[data-oh-month]').dataset.ohMonth)-1,width=lines[0].length;
          if(lines.some(row=>row.length!==width))throw Error('Vùng Excel cần có số cột bằng nhau ở mọi hàng.');
          if(startRow+lines.length>4||startCol+width>12)throw Error('Vùng dán vượt bảng 4 hàng × 12 tháng. Chọn lại ô bắt đầu hoặc vùng Excel.');
          const vi=form.querySelector('[data-oh-paste-format]').value==='vi',changes=[];
          lines.forEach((row,y)=>row.forEach((cell,x)=>{
            let raw=cell.trim().replace(/^"(.*)"$/,'$1').trim();
            const allowNegative=inputSeries[startRow+y][0]==='other',sign=allowNegative?'-?':'';
            const valid=vi?new RegExp(`^${sign}(?:\\d+|\\d{1,3}(?:\\.\\d{3})+)(?:,\\d{1,4})?$`):new RegExp(`^${sign}(?:\\d+|\\d{1,3}(?:,\\d{3})+)(?:\\.\\d{1,4})?$`);
            if(!valid.test(raw))throw Error(`Ô Excel hàng ${y+1}, cột ${x+1}: cần ${allowNegative?'số':'số không âm'}, tối đa 4 chữ số thập phân. Kiểm tra định dạng số đã chọn; không để trống hoặc copy tiêu đề.`);
            const normalized=vi?raw.replaceAll('.','').replace(',','.'):raw.replaceAll(',','');
            if(Math.abs(Number(normalized))>10000000000)throw Error(`Ô Excel hàng ${y+1}, cột ${x+1}: vượt giá trị tối đa.`);
            changes.push([form.querySelector(`[data-oh-month="${startCol+x+1}"] [data-oh-field="${inputSeries[startRow+y][0]}"]`),normalized]);
          }));
          invalidate();changes.forEach(([input,value])=>input.value=value);kinds();
          form.querySelector('[data-oh-source]').textContent=`Đã dán ${lines.length} hàng × ${width} cột. Chưa lưu; kiểm tra và chọn Xem trước.`;
        }catch(err){error.textContent=err.message+' Chưa thay đổi ô nào.';}
      });
      cutoff.onchange=()=>{invalidate();kinds();};
      back.onclick=()=>{invalidate();dialog.scrollTop=0;};
      function fill(document){cutoff.value=String(document.actualThroughMonth);for(const r of document.months)for(const key of ['total','actualPR','actualGR','other'])form.querySelector(`[data-oh-month="${r.month}"] [data-oh-field="${key}"]`).value=String(r[key]??0);kinds();}
      async function verify(document,token,fromSql=false){
        preview.textContent='Đang kiểm tra dữ liệu…';check.disabled=true;
        try{
          const checked=await budgetApi(`budget-oh/${fromSql?'sql-preview':'preview'}?year=${year}`,'POST',fromSql?{expectedRevision:revision}:{document,expectedRevision:revision});
          if(!active()||token!==sequence)return;
          candidate=checked.document;sqlToken=checked.sqlToken||null;fill(candidate);
          preview.innerHTML=`<p><strong>Xem trước · ${year} · ${candidate.actualThroughMonth?'Thực tế đến hết '+monthName(candidate.actualThroughMonth):'Chưa chốt thực tế'}</strong></p><p class="small">P03 cả năm: ${money(checked.totals.p03)} USD · GR thực tế: ${money(checked.totals.actual)} USD · GR dự kiến: ${money(checked.totals.forecast)} USD</p>${rowTable(checked.rows.map(combined),true)}<p class="small muted">Chưa lưu. Xác nhận sẽ thay toàn bộ ngân sách OH của năm ${year}; dữ liệu nghiệp vụ khác được giữ nguyên.</p>`;
          editor.hidden=true;check.hidden=true;back.hidden=false;save.hidden=false;save.disabled=false;dialog.scrollTop=0;
        }catch(e){if(active()&&token===sequence){preview.innerHTML='';error.textContent=e.message;check.disabled=false;}}
      }
      sqlButton.onclick=async()=>{invalidate();sqlButton.disabled=true;try{await verify(null,sequence,true);}finally{if(active())sqlButton.disabled=false;}};
      check.onclick=()=>{
        invalidate();if(!form.reportValidity())return;
        const months=Array.from({length:12},(_,i)=>({month:i+1,...Object.fromEntries(inputSeries.map(([key])=>[key,Number(form.querySelector(`[data-oh-month="${i+1}"] [data-oh-field="${key}"]`).value)]))}));
        verify({year,currency:'USD',actualThroughMonth:Number(cutoff.value),months},sequence);
      };
      form.querySelector('[data-oh-cancel]').onclick=()=>dialog.close();
      form.querySelector('[data-oh-template]').onclick=async()=>{
        try {const template=await budgetApi(`budget-oh/template?year=${year}`);if(!active())return;const url=URL.createObjectURL(new Blob([JSON.stringify(template,null,2)+'\n'],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=`oh-budget-${year}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
        catch(e){if(active())error.textContent=e.message;}
      };
      fileInput.onchange=async()=>{
        invalidate();const token=sequence;
        const file=fileInput.files[0];if(!file)return;
        try {
          if(!file.name.toLowerCase().endsWith('.json')||file.size>100000)throw Error('Chọn file .json không quá 100 KB.');
          let document;try{document=JSON.parse((await file.text()).replace(/^\uFEFF/,''));}catch{throw Error('File JSON không hợp lệ. Anh kiểm tra lại dấu ngoặc, dấu phẩy và số.');}
          if(!active()||token!==sequence)return;
          await verify(document,token);
        }catch(e){if(active()&&token===sequence){preview.innerHTML='';error.textContent=e.message;}}
      };
      form.onsubmit=async e=>{
        e.preventDefault();if(saving)return;if(!candidate){check.click();return;}saving=true;sqlButton.disabled=true;save.disabled=true;back.disabled=true;fileInput.disabled=true;cutoff.disabled=true;inputs.forEach(i=>i.disabled=true);error.textContent='';
        try {
          const saved=await budgetApi(`budget-oh?year=${year}`,'PUT',{document:candidate,expectedRevision:revision,...(sqlToken?{sqlToken}:{})});
          if(!root.isConnected)return;
          if(active())dialog.close();
          onSaved?.(saved);
          toast(sqlToken?'Đã cập nhật JSON từ SQL.':'Đã cập nhật SQL và JSON ngân sách OH.');
        }catch(e){if(active()){error.textContent=e.message;save.disabled=false;back.disabled=false;fileInput.disabled=false;cutoff.disabled=true;sqlButton.disabled=false;inputs.forEach(i=>i.disabled=false);saving=false;}}
      };
    }catch(e){toast(e.message);}finally{update.disabled=false;}
  };
}

// ===== Ngân sách Repair (portal APS) — sau khi panel P03/GR bị bỏ khỏi portal /aps-app, Overview
// là nơi duy nhất xem chi tiết và nhập. Ghi qua cầu /api/aps-app (session/CSRF/role WRB, revision
// chống ghi đè); không fetch trực tiếp trong module, mọi lời gọi đi qua repairApi host-injected.
const REPAIR_ROWS=[['p03','P03 gốc'],['actual','Actual thủ công'],['plan','Payment Plan'],['reason','Lý do vượt P03']];
const repairMoney=n=>new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(n);
const repairMonths=budget=>{
 const list=Array.isArray(budget?.months)&&budget.months.length===12?budget.months:Array.from({length:12},()=>({p03:0,actual:0,plan:0,reason:''}));
 return list.map((m,i)=>({month:m.month||i+1,p03:m.p03,actual:m.actual,plan:m.plan,reason:m.reason||''}));
};
function repairGrid(months,editable){
 const cells=(m,key)=>{const raw=key==='reason'?String(m.reason||''):String(Number(m[key])||0);
  return `<td data-oh-month="${m.month}">${editable?(key==='reason'?`<textarea data-repair-field="${key}" rows="2" maxlength="1000">${esc(raw)}</textarea>`:`<input type="number" min="0" step="0.0001" data-repair-field="${key}" value="${esc(raw)}">`):(key==='reason'?(raw?esc(raw):'—'):esc(repairMoney(Number(raw)||0)))}</td>`;};
 return `<div class="table-scroll"><table class="oh-entry-table oh-month-grid repair-entry-grid"><thead><tr><th scope="col">Chỉ tiêu · USD</th>${months.map(m=>`<th scope="col">T${String(m.month).padStart(2,'0')}</th>`).join('')}</tr></thead><tbody>${REPAIR_ROWS.map(([key,label])=>`<tr><th scope="row">${label}</th>${months.map(m=>cells(m,key)).join('')}</tr>`).join('')}</tbody></table></div>`;
}
// Đổi phản hồi GET /api/aps-app/api/data về đúng shape budget của snapshot WRB (data.aps.budget).
function repairMerged(fresh){
 const doc=fresh?.budget,sum=fresh?.summary;if(!doc)return null;
 return {year:doc.year,closed:Number(doc.closed)||0,source:doc.source==='manual'?'manual':'payments',
  months:Array.isArray(sum?.months)&&sum.months.length===12?sum.months.map(m=>({month:m.month,p03:m.p03,actual:m.actual,plan:m.plan,reason:m.reason||''})):repairMonths(doc)};
}
export function bindRepairBudget(root,data,{repairApi,canUpdateBudget,onSaved}){
 if(!repairApi)return;
 const budget=(data.aps&&data.aps.budget)||null;
 const year=String(budget?budget.year:String(data.ohYear||data.asOf).slice(0,4));
 const detail=root.querySelector('[data-repair-detail]');
 if(detail)detail.onclick=()=>{
  if(!budget){showDetail('Ngân sách Repair · '+year,'<p class="small muted">Chưa có ngân sách Repair trong portal APS cho năm này.</p>');return;}
  const doc=repairMonths(budget),rep=repairSummary(data),source=rep.source==='manual'?'manual':'payments';
  const used=`<div class="table-scroll"><table class="oh-entry-table repair-used-table"><tbody><tr><th scope="row">Actual đang dùng</th>${rep.rows.map(r=>`<td>${esc(repairMoney((r.rawGR===null?r.forecast:r.rawGR+r.adjustment)*1000))}</td>`).join('')}</tr></tbody></table></div>`;
  showDetail('Ngân sách Repair · '+year+' · Nguồn '+(source==='manual'?'Tax confirm (AdJ)':'WRB Data'),
   `<p class="small muted">Đơn vị USD. Annual Outlook = Actual của tháng đã chốt + Payment Plan của tháng chưa chốt. Nguồn “manual” chỉ dùng số nhập Actual thủ công; nguồn “payments” chỉ dùng giao dịch WRB — không cộng hai nguồn.${canUpdateBudget?.()?'':' Chỉ Admin trở lên được chỉnh sửa.'}</p>${repairGrid(doc,false)}${used}`);
 };
 const update=root.querySelector('[data-repair-update]');
 if(!update||!canUpdateBudget?.())return;
 update.onclick=async()=>{
  update.disabled=true;
  try{
   const state=await repairApi('aps-app/api/data?year='+encodeURIComponent(year));
   const doc=state.budget||{year:Number(year),closed:0,source:'payments'};
   const revision=Number(state.revision)||0,months=repairMonths(doc);
   if(!root.isConnected)return;
   showDetail('Cập nhật ngân sách Repair · '+(doc.year||year),
    `<form id="repair-budget-form" class="account-form"><p class="small muted">Điền trực tiếp vào bảng, đơn vị <strong>USD</strong>. Annual Outlook = Actual của tháng đã chốt + Payment Plan của tháng chưa chốt. Nguồn “manual” chỉ dùng Actual thủ công; nguồn “payments” chỉ dùng giao dịch WRB — không cộng hai nguồn.</p>
     <div class="repair-entry-config"><label>Chốt đến tháng <select data-repair-closed aria-label="Chốt đến tháng">${Array.from({length:13},(_,i)=>`<option value="${i}"${i===(Number(doc.closed)||0)?' selected':''}>${i===0?'Chưa chốt':'T'+String(i).padStart(2,'0')}</option>`).join('')}</select></label><label>Nguồn Actual <select data-repair-form-source aria-label="Nguồn Actual"><option value="payments"${doc.source!=='manual'?' selected':''}>WRB Data</option><option value="manual"${doc.source==='manual'?' selected':''}>Tax confirm (AdJ)</option></select></label></div>
     ${repairGrid(months,true)}
     <p class="small red" role="alert"></p>
     <div class="actions"><button type="button" class="button" data-repair-cancel>Đóng</button><button type="submit" class="button primary">Lưu ngân sách</button></div></form>`);
   const dialog=document.getElementById('detail'),form=document.getElementById('repair-budget-form'),error=form.querySelector('[role=alert]');
   const payload=()=>({year:Number(doc.year)||Number(year),closed:Number(form.querySelector('[data-repair-closed]').value)||0,
    source:form.querySelector('[data-repair-form-source]').value==='manual'?'manual':'payments',revision,
    months:months.map((m,i)=>({p03:Number(form.querySelector(`[data-oh-month="${i+1}"] [data-repair-field="p03"]`).value)||0,
     actual:Number(form.querySelector(`[data-oh-month="${i+1}"] [data-repair-field="actual"]`).value)||0,
     plan:Number(form.querySelector(`[data-oh-month="${i+1}"] [data-repair-field="plan"]`).value)||0,
     reason:String(form.querySelector(`[data-oh-month="${i+1}"] [data-repair-field="reason"]`).value||'').trim().slice(0,1000)}))});
   form.querySelector('[data-repair-cancel]').onclick=()=>dialog.close();
   form.onsubmit=async e=>{
    e.preventDefault();
    const save=form.querySelector('[type=submit]');save.disabled=true;error.textContent='';
    try{
     const input=payload();
     await repairApi('aps-app/api/budget','PUT',input);
     if(!root.isConnected)return;
     dialog.close();
     toast('Đã cập nhật ngân sách Repair năm '+(doc.year||year)+'.');
     const fresh=await repairApi('aps-app/api/data?year='+encodeURIComponent(doc.year||year)).catch(()=>null);
     onSaved?.({source:input.source,merged:fresh?repairMerged(fresh):null});
    }catch(err){error.textContent=err.message;save.disabled=false;}
   };
  }catch(e){toast(e.message);}finally{update.disabled=false;}
 };
}
// Ô nhập Plan/Actual Cost Saving (05/11/2026): dialog bảng hoạt động theo khóa No của
// EQM_CostSavingActivity; chỉ ô thay đổi mới gửi POST /api/cost-saving (server UPDATE từng ô
// bằng tham số). Không fetch trực tiếp trong module — mọi lời gọi qua savingApi host-injected.
export function bindSavingBudget(root,data,{savingApi,canUpdateBudget,onSaved,offline}={}){
 if(!savingApi||offline)return;
 const update=root.querySelector('[data-saving-update]');
 if(!update)return;
 if(!canUpdateBudget?.()){update.hidden=true;return;}
 update.onclick=async()=>{
  update.disabled=true;
  try{
   const year=Number(data.costSaving?.year||String(data.ohYear||data.asOf||'').slice(0,4));
   const record=await savingApi(`cost-saving?year=${year}`);
   const activities=(record?.activities||[]).filter(a=>a&&String(a.no||'').trim());
   if(!record?.editable||!activities.length){toast('Bảng EQM_CostSavingActivity không có cột No khóa dòng nên không nhập từ Portal được.');return;}
   openDialog(activities,Number(record.year)||year);
  }catch(e){toast(e.message);}finally{update.disabled=false;}
 };
 function openDialog(activities,year){
  const monthHead=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const rows=activities.map(a=>`<tr><td>${esc(a.no)}</td><td>${esc(a.label||'—')}</td><td class="${a.status==='Actual'?'cyan':'amber'}">${esc(a.status)}</td>${(a.values||[]).map((v,i)=>`<td><input type="text" inputmode="decimal" data-saving-cell data-no="${esc(a.no)}" data-month="${i+1}" data-origin="${v===null||v===undefined?'':esc(String(v))}" value="${v===null||v===undefined?'':esc(String(v))}" aria-label="Ô ${esc(a.no)} tháng ${monthHead[i]} USD" style="width:76px"></td>`).join('')}</tr>`).join('');
  showDetail(`Cost Saving · ${year}`,`<form id="saving-edit" class="account-form"><p class="small muted">Số USD gốc của từng dòng hoạt động trong EQM_CostSavingActivity. Chỉ các ô thay đổi được ghi (UPDATE theo No); ô trống nghĩa là chưa có số liệu.</p><p class="small red" role="alert" hidden></p><div style="overflow:auto"><table><thead><tr><th>No</th><th>Project / Item</th><th>Loại</th>${monthHead.map(m=>`<th>${m}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div><div class="form-actions"><button class="button small" type="submit" data-saving-save disabled>Lưu thay đổi</button><button class="ghost small" type="button" data-saving-close>Đóng</button></div></form>`);
  const dialog=document.getElementById('detail'),form=document.getElementById('saving-edit'),error=form.querySelector('[role=alert]'),save=form.querySelector('[data-saving-save]'),cells=[...form.querySelectorAll('[data-saving-cell]')];
  const numberText=/^-?\d+(?:\.\d{1,6})?$/;
  function collect(){
   const changes=[];let invalid=null;
   for(const cell of cells){
    const text=cell.value.trim();
    cell.classList.remove('is-invalid');
    if(text===cell.dataset.origin)continue;
    if(text!==''&&(!numberText.test(text)||Math.abs(Number(text))>10000000000)){cell.classList.add('is-invalid');invalid=cell;continue;}
    changes.push({no:cell.dataset.no,month:Number(cell.dataset.month),value:text===''?null:text});
   }
   if(invalid){error.hidden=false;error.textContent=`Ô ${invalid.dataset.no} · tháng ${invalid.dataset.month}: cần số USD hợp lệ (vd. 1200.50).`;return null;}
   error.hidden=true;error.textContent='';
   return changes;
  }
  const refresh=()=>{const changes=collect();save.disabled=changes===null||!changes.length;};
  cells.forEach(cell=>{cell.oninput=refresh;});
  form.querySelector('[data-saving-close]').onclick=()=>dialog.close();
  let saving=false;
  form.onsubmit=async e=>{
   e.preventDefault();if(saving)return;
   const changes=collect();
   if(!changes)return;
   if(!changes.length){toast('Không có ô nào thay đổi.');return;}
   saving=true;save.disabled=true;cells.forEach(c=>{c.disabled=true;});
   try{
    const saved=await savingApi('cost-saving','POST',{year,changes});
    toast(`Đã lưu ${saved?.saved?.count??changes.length} ô Cost Saving vào EQM_CostSavingActivity.`);
    onSaved?.(saved);
    if(form.isConnected)dialog.close();
   }catch(err){
    saving=false;cells.forEach(c=>{c.disabled=false;});save.disabled=false;
    error.hidden=false;error.textContent=err.message;
   }
  };
 }
}


