import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import * as api from '../index.mjs';
import {summary,budgetSummary,repairSummary,savingSummary,cumulative} from '../selectors.mjs';
import {render} from '../view.mjs';
import {cardFilters,kpiDescriptors} from '../cards.mjs';
import {stockStatus,coverage,isAging,sopLate,ohValue,sum} from '../../../../shared/model.mjs';
const data=JSON.parse(readFileSync(new URL('../../../../tests/fixtures/legacy-raw.json',import.meta.url)));
test('Overview public interface and six KPI/five detail descriptors retain mapping',()=>{
 assert.deepEqual(Object.keys(api).sort(),['cardFilters','mount']);
 const s=summary(data),cards=cardFilters(data),kpis=kpiDescriptors(data,s.count);
 assert.deepEqual(cards.map(c=>c.key),['all','sufficient','shortage','out-of-stock','pending-po']);assert.deepEqual(kpis.map(c=>c.key),[...cards.map(c=>c.key),'codes-open']);
 const expected=[data.items,data.items.filter(r=>stockStatus(r)==='Đủ tồn'),data.items.filter(r=>stockStatus(r)==='Nguy cơ thiếu'),data.items.filter(r=>stockStatus(r)==='Hết hàng'),data.tracking.filter(r=>!r.po)];
 assert.deepEqual(cards.map(c=>c.rows()),expected);
 assert.deepEqual(kpis.slice(1,5).map(k=>k.args[1]),expected.slice(1).map(r=>r.length));
});
test('Overview aggregation preserves cross-screen model, budget/SOP/aging calculations and source immutability',()=>{
 const before=JSON.stringify(data),s=summary(data);
 assert.deepEqual(s.critical,data.items.filter(r=>['Hết hàng','Nguy cơ thiếu'].includes(stockStatus(r))));
 assert.deepEqual(s.late,data.requests.filter(r=>sopLate(r,data.asOf)));assert.deepEqual(s.aging,data.items.filter(r=>isAging(r,data.asOf)));
 assert.equal(s.annual,sum(data.budget,ohValue));assert.equal(s.p03,sum(data.budget,'p03'));assert.equal(s.max,Math.max(...data.budget.map(r=>Math.max(r.p03,ohValue(r))))*1.15);
 assert.equal(JSON.stringify(data),before);
 const edge={...data,budget:[{p03:10,rawGR:0,adjustment:2,forecast:99},{p03:20,rawGR:null,adjustment:5,forecast:30}]};
 assert.equal(summary(edge).annual,32);assert.equal(summary(edge).p03,30);assert.equal(summary(edge).max,34.5);
});
test('Overview detail rows stay lazy and preserve no-demand/stock status boundary',()=>{
 const snapshot=structuredClone(data),cards=cardFilters(snapshot);
 const item={physical:1,vendors:{A:0},demand:0,lastIssue:data.asOf};assert.equal(coverage(item),null);
 snapshot.items=[item];snapshot.tracking=[];assert.deepEqual(cards[0].rows(),[item]);assert.deepEqual(cards[1].rows(),[]);assert.deepEqual(cards[4].rows(),[]);
});

test('Overview financial summary separates actual/forecast, finds latest month and keeps zero GR',()=>{
 const snapshot=JSON.stringify(data),b=budgetSummary(data);assert.equal(b.latest.month,9);assert.equal(b.actual,sum(data.budget.filter(r=>r.rawGR!==null),ohValue));assert.equal(b.actual+b.forecast,summary(data).annual);assert.equal(JSON.stringify(data),snapshot);
 const edge={asOf:'2027-01-01',budget:[{month:3,rawGR:0,adjustment:2,forecast:99},{month:1,rawGR:10,adjustment:-1,forecast:99},{month:4,rawGR:null,forecast:5}]};assert.equal(budgetSummary(edge).latest.month,3);assert.equal(budgetSummary(edge).actual,11);assert.equal(budgetSummary(edge).forecast,5);assert.equal(budgetSummary(edge).year,'2027');assert.equal(budgetSummary({...edge,budget:[]}).latest,null);
 assert.equal(kpiDescriptors(data,summary(data).count).at(-1).args[1],data.codes.filter(r=>r.status!=='Ready for PR').length);
});
test('Overview Repair đọc snapshot APS cùng logic tab Repair & Service (grVal/grSplit/nguồn), Cost Saving đọc Actual/Plan từ SQL, không sửa dữ liệu',()=>{
 const apsMonths=Array.from({length:12},(_,i)=>({month:i+1,p03:(i+1)*1000,actual:i<3?(i+1)*900:0,plan:(i+1)*1100,reason:i===2?'Vượt do thay jig':''}));
 const apsRequests=[
  {type:'Repair',paymentYear:2026,paymentMonth:1,lines:[{amount2USD:400},{amount2USD:500}]},
  {type:'Repair',paymentYear:2026,paymentMonth:2,lines:[{amount2USD:300}]},
  {type:'Service',serviceType:'Setup new MC',paymentYear:2026,paymentMonth:2,amount2USD:999},
  {type:'Service',serviceType:'Other',paymentYear:2026,paymentMonth:3,amount2USD:200},
  {type:'Repair',paymentYear:2025,paymentMonth:1,lines:[{amount2USD:7000}]}
 ];
 const plan=Array.from({length:12},(_,i)=>(i+1)*100),actual=Array.from({length:12},(_,i)=>i<7?(i+1)*90:null);
 const savingMonths=Array.from({length:12},(_,i)=>i<7?actual[i]:plan[i]);
 const source={...data,asOf:'2026-10-06',aps:{connected:true,asOf:'2026-10-06',budget:{year:2026,closed:3,source:'payments',months:apsMonths},requests:apsRequests},costSaving:{year:2026,currentMonth:8,plan,actual,months:savingMonths,items:4,source:'sql',warning:'',updatedAt:'2026-10-01T02:00:00.000Z'}};
 const before=JSON.stringify(source),r=repairSummary(source),s=savingSummary(source);
 // grSplit theo tháng hiện hành trong asOf (2026-10 → T01–T09 actual), chặn theo closed=3.
 assert.equal(r.year,'2026');assert.equal(r.docSource,'payments');assert.equal(r.source,'payments');assert.equal(r.closed,3);assert.equal(r.grSplit,9);
 assert.equal(r.rows.length,12);
 // GR nguồn WRB Data: cộng amount2USD theo tháng payment, bỏ Service "Setup new MC", bỏ năm khác.
 assert.equal(r.rows[0].rawGR,.9);assert.equal(r.rows[1].rawGR,.3);assert.equal(r.rows[2].rawGR,.2);
 assert.equal(r.rows[3].rawGR,0,'payments: tháng actual chưa có giao dịch thì GR=0 như tab APS');assert.equal(ohValue(r.rows[3]),0);
 assert.equal(r.rows[11].rawGR,null);assert.equal(ohValue(r.rows[11]),0);
 assert.equal(r.actualTotal,1.4);assert.equal(r.forecastTotal,0);assert.equal(r.total,1.4);assert.equal(r.p03Total,78);
 assert.equal(r.latest.month,3,'tháng vừa qua bị chặn theo tháng chốt');assert.equal(r.latest.reason,'Vượt do thay jig');
 assert.ok(Math.abs(r.delta-(0.2-3))<1e-9);assert.ok(Math.abs(r.percent-((0.2-3)/3*100))<1e-9);
 assert.ok(Math.abs(r.max-Math.max(...r.rows.map(x=>Math.max(x.p03,ohValue(x))))*1.15)<1e-9);
 assert.ok(Math.abs(r.variancePct-((1.4-78)/78*100))<0.01,'variancePct làm tròn 2 số thập phân');
 // Nguồn manual (Tax confirm AdJ): Actual thủ công của tháng đã chốt, Payment Plan của tháng chưa chốt.
 const man=repairSummary({...source,repairSource:'manual'});
 assert.equal(man.source,'manual');assert.equal(man.docSource,'payments');
 assert.deepEqual(man.actualMonths,[1,2,3,4,5,6,7,8,9]);
 assert.equal(ohValue(man.rows[0]),.9);assert.equal(ohValue(man.rows[1]),1.8);assert.equal(ohValue(man.rows[2]),2.7);
 assert.equal(ohValue(man.rows[3]),0,'tháng đã chốt nhưng chưa nhập Actual thì là 0, không lấy Plan');
 assert.equal(man.actualTotal,5.4);
 assert.ok(Math.abs(man.forecastTotal-36.3)<1e-9);assert.ok(Math.abs(man.total-(5.4+36.3))<1e-9);
 // Cost Saving: nguồn USD, selector quy đổi K$ và giữ luật Actual trước / Plan sau tháng hiện tại.
 assert.equal(s.year,2026);assert.equal(s.source,'sql');assert.equal(s.items,4);
 assert.equal(s.plan[0],.1);assert.equal(s.actual[0],.09);assert.equal(s.actual[11],null);
 assert.deepEqual(s.months,savingMonths.map(v=>v===null?null:v/1000));
 assert.equal(s.points.length,12);
 assert.ok(s.points.slice(0,s.viewMonth).every(p=>!p.isPlan)&&s.points.slice(s.viewMonth).every(p=>p.isPlan),'tháng sau tháng hiện tại là dự kiến theo Plan');
 assert.ok(Math.abs(s.total-savingMonths.reduce((total,v)=>total+(v??0),0)/1000)<1e-9);
 assert.ok(Math.abs(s.planTotal-7800/1000)<1e-9);assert.ok(Math.abs(s.actualTotal-2520/1000)<1e-9);
 assert.equal(s.actualMonths,7);assert.equal(s.planMonths,12);
 assert.deepEqual(Object.keys(s).sort(),['actual','actualMonths','actualTotal','currentMonth','items','loading','maxK','months','plan','planMonths','planTotal','points','source','total','updatedAt','viewMonth','viewValue','warning','year']);
 // Năm khác năm hiện hành: khối kết quả chốt về T12 thay vì suy diễn tháng hiện tại.
 const other=savingSummary({asOf:'2025-03-15',ohYear:2025,costSaving:{year:2025,plan:Array(12).fill(0),actual:[...Array(11).fill(null),700],months:[...Array(11).fill(null),700],source:'sql'}});
 assert.equal(other.viewMonth,12);assert.equal(other.viewValue,.7);
 // Mất kết nối APS hoặc thiếu bản ghi: không bịa số liệu, không ném lỗi.
 const offline=repairSummary({...data,aps:{connected:false,warning:'Không đọc được dữ liệu portal APS: timeout',budget:null}});
 assert.equal(offline.connected,false);assert.deepEqual(offline.rows,[]);assert.equal(offline.latest,null);assert.equal(offline.delta,0);
 assert.equal(offline.source,'payments');assert.equal(offline.grSplit,0);assert.equal(offline.variancePct,null);
 const blank=savingSummary({asOf:data.asOf});
 assert.deepEqual(blank.months,Array(12).fill(null));assert.equal(blank.actualMonths,0);assert.equal(blank.total,0);assert.equal(blank.source,'');
 assert.equal(JSON.stringify(source),before,'selector không được sửa dữ liệu nguồn');
});
test('Overview render chỉ còn hai bảng Ngân sách OH và OH Repair/COST Saving trong khung fold',()=>{
 const apsMonths=Array.from({length:12},(_,i)=>({month:i+1,p03:(i+1)*1000,actual:i<3?(i+1)*900:0,plan:(i+1)*1100,reason:i===2?'Vượt do thay jig':''}));
 const source={...data,asOf:'2026-10-06',aps:{connected:true,asOf:'2026-10-06',budget:{year:2026,closed:3,source:'payments',months:apsMonths},requests:[]},costSaving:{year:2026,currentMonth:8,plan:Array.from({length:12},(_,i)=>(i+1)*100),actual:Array.from({length:12},(_,i)=>i<7?(i+1)*90:null),months:Array.from({length:12},(_,i)=>i<7?(i+1)*90:(i+1)*100),items:4,source:'sql',warning:'',updatedAt:'2026-10-01T02:00:00.000Z'}};
 const presentation={link:(label,route,filter='')=>`<button class="text-button" data-go="${route}"${filter?` data-filter="${filter}"`:''}>${label}</button>`,badge:value=>`<span class="badge">${value}</span>`,icon:()=>'',canUpdateBudget:()=>true};
 const root={innerHTML:''};render(root,source,presentation);const html=root.innerHTML;
 const positions=['class="ov-fold"','ov-finance"','ov-duo"'].map(marker=>html.indexOf(marker));
 assert.ok(positions.every((value,index)=>value>=0&&(index===0||value>positions[index-1])),'thứ tự section phải là fold → Ngân sách OH → OH Repair/COST Saving');
 assert.equal(html.indexOf('ov-materials')===-1,true,'đã gỡ bảng Vận hành & vật tư khỏi tab Tổng quan');assert.equal((html.match(/class="panel /g)||[]).length,2,'khung fold chứa đúng hai bảng');assert.equal(html.includes('class="kpi"'),false,'tab Tổng quan không còn thẻ .kpi');
 assert.equal((html.match(/class="ov-chart"/g)||[]).length,2,'có đúng hai biểu đồ cột');
 assert.equal((html.match(/aria-describedby="oh-repair-tooltip"/g)||[]).length,12,'biểu đồ Repair đủ 12 tháng');
 assert.equal(html.includes('aria-describedby="oh-chart-tooltip"'),true,'tooltip biểu đồ OH giữ nguyên id cũ');
 assert.equal(html.includes('KẾT QUẢ THÁNG VỪA QUA'),true,'Repair có khối kết quả tháng vừa qua');
 assert.equal(html.includes('data-go="aps"'),true,'có lối mở tab Repair & Service');
 // Công cụ ngân sách Repair: chọn nguồn, chi tiết và cập nhật (admin) ngay trên thẻ Overview.
 assert.equal(html.includes('data-repair-source'),true,'có ô chọn nguồn Actual');
 assert.equal(html.includes('data-repair-detail'),true,'có nút Chi tiết ngân sách');
 assert.equal(html.includes('data-repair-update'),true,'admin có nút Cập nhật');
 assert.equal(html.includes('Lý do vượt P03'),true,'hiện lý do vượt P03 của tháng vừa qua');
 assert.equal((html.match(/<option value="(payments|manual)"/g)||[]).length,2,'đúng hai nguồn WRB Data / Tax confirm (AdJ)');
 const repairCard=html.slice(html.indexOf('class="ov-duo-card ov-repair"'),html.indexOf('class="ov-duo-card ov-saving"'));
 assert.equal(repairCard.includes('ov-finance-stat'),false,'OH Repair không còn thẻ KPI lớn phía trên biểu đồ');
 assert.ok(repairCard.includes('Tổng P03')&&repairCard.includes('Tổng Actual')&&repairCard.includes('GR dự kiến')&&repairCard.includes('Tổng cả năm'),'OH Repair vẫn đủ bốn chỉ số P03/Actual/GR dự kiến/tổng cả năm');
 assert.ok(repairCard.indexOf('ov-repair-strip')>repairCard.indexOf('class="ov-plot"')&&repairCard.indexOf('ov-repair-strip')>repairCard.indexOf('ov-chart-foot'),'bốn thẻ KPI OH Repair nằm dưới biểu đồ cột');
 assert.equal((repairCard.match(/ov-stat-chip/g)||[]).length,4,'OH Repair có bốn thẻ KPI gọn dưới biểu đồ');
 const savingCard=html.slice(html.indexOf('class="ov-duo-card ov-saving"'));
 assert.equal(savingCard.includes('ov-line-foot'),false,'Cost Saving dùng cùng dải thẻ KPI gọn');
 assert.ok(savingCard.indexOf('ov-saving-strip')>savingCard.indexOf('data-saving-month="12"'),'ba thẻ KPI Cost Saving nằm dưới biểu đồ lũy kế');
 assert.equal((savingCard.match(/ov-stat-chip/g)||[]).length,3,'Cost Saving có ba thẻ KPI gọn dưới biểu đồ');
 assert.equal((html.match(/data-saving-month="/g)||[]).length,12,'biểu đồ Cost Saving có 12 điểm tháng');
 assert.equal(html.includes('class="ov-line-target"')&&html.includes('class="ov-line-result"'),true,'biểu đồ Cost Saving có đủ đường Plan và Actual');
 assert.equal(html.includes('ov-line-stamp'),true,'biểu đồ Cost Saving ghi ngày hiện hành giữa biểu đồ như ảnh chuẩn');
 assert.equal(html.includes('data-saving-update'),false,'nguồn SQL nên card không còn ô nhập tay');
 assert.equal(html.slice(positions[2],positions[3]).includes('class="kpi"'),false,'section mới không tạo .kpi thứ sáu');
 const viewer={innerHTML:''};render(viewer,source,{...presentation,canUpdateBudget:()=>false});
 assert.equal(viewer.innerHTML.includes('data-repair-update'),false,'viewer không thấy nút Cập nhật');
 assert.equal(viewer.innerHTML.includes(' disabled title="Chỉ Admin trở lên được đổi nguồn ngân sách Repair"'),true,'viewer bị khóa ô chọn nguồn');
 const offline={innerHTML:''};render(offline,{...source,aps:{connected:false,warning:'Không đọc được dữ liệu portal APS: timeout',budget:null},costSaving:undefined},presentation);
 assert.equal(offline.innerHTML.includes('Không đọc được dữ liệu portal APS'),true,'thiếu APS chỉ cảnh báo, không sụp màn');
 assert.equal(offline.innerHTML.includes('Chưa có ngân sách Repair cho năm'),true,'thiếu ngân sách APS báo trống thay vì bịa số');
 assert.equal(offline.innerHTML.includes('Chưa có dữ liệu Cost Saving trong EQM_CostSavingActivity'),true,'chưa có Cost Saving thì báo trống, không bịa số');
});
test('Overview CSS khóa dải KPI gọn dưới biểu đồ, giữ nguyên bảng lớn Ngân sách OH và số liệu selector',()=>{
 const css=readFileSync(new URL('../../../../assets/readability.css',import.meta.url),'utf8');
 assert.ok(css.includes('[data-view=overview] .ov-stat-strip{display:grid'),'có style dải KPI gọn scope [data-view=overview]');
 assert.ok(css.includes('[data-view=overview] .ov-repair-strip{grid-template-columns:repeat(4,minmax(0,1fr))}'),'OH Repair bốn thẻ một hàng trên card rộng');
 assert.ok(css.includes('[data-view=overview] .ov-saving-strip{grid-template-columns:repeat(3,minmax(0,1fr))}'),'Cost Saving ba thẻ một hàng');
 assert.ok(css.includes('[data-view=overview] .ov-stat-chip>strong{font-size:22px'),'số của thẻ gọn 22px, nhỏ hơn thẻ KPI lớn 28px');
 assert.ok(css.includes('[data-view=overview] .ov-stat-chip{')&&css.includes('border-top:3px solid var(--cyan)'),'mỗi thẻ có viền màu trên đầu như ảnh chuẩn');
 assert.ok(css.includes('[data-view=overview] .ov-stat-chip>span{font-size:11px'),'nhãn thẻ in hoa nhỏ 11px');
 assert.equal(css.includes('.ov-line-foot'),false,'đã gỡ style dải footer cũ của Cost Saving');
 assert.equal(css.includes('.ov-repair-stats'),false,'đã gỡ style dải thẻ lớn cũ của OH Repair');
 assert.ok(css.includes('[data-view=overview] .ov-finance-stat>strong{font-size:28px}'),'bảng Ngân sách OH vẫn dùng thẻ KPI lớn như trước');
 const apsMonths=Array.from({length:12},(_,i)=>({month:i+1,p03:(i+1)*1000,actual:i<3?(i+1)*900:0,plan:(i+1)*1100,reason:''}));
 const source={...data,asOf:'2026-10-06',aps:{connected:true,asOf:'2026-10-06',budget:{year:2026,closed:3,source:'payments',months:apsMonths},requests:[]},costSaving:undefined};
 const presentation={link:()=>`<button></button>`,badge:value=>`<span class="badge">${value}</span>`,icon:()=>'',canUpdateBudget:()=>false};
 const root={innerHTML:''};render(root,source,presentation);const html=root.innerHTML;
 const repair=html.slice(html.indexOf('class="ov-duo-card ov-repair"'),html.indexOf('class="ov-duo-card ov-saving"'));
 const rep=repairSummary(source),fmt=n=>new Intl.NumberFormat('en-US',{maximumFractionDigits:0}).format(n);
 const values=[...repair.matchAll(/<strong class="[a-z]+">([^<]*?) <small>K\$<\/small>/g)].map(m=>m[1]);
 assert.deepEqual(values,[fmt(rep.p03Total),fmt(rep.actualTotal),fmt(rep.forecastTotal),fmt(rep.total)],'bốn thẻ mới giữ đúng số liệu selector của dải cũ');
 const saving=html.slice(html.indexOf('class="ov-duo-card ov-saving"'));
 assert.equal((saving.match(/>— <small>K\$/g)||[]).length,3,'chưa có Cost Saving thì ba thẻ hiện dấu gạch, không bịa số');
});

test('Overview Cost Saving vẽ lũy kế: tháng N = tổng T1..TN cho cả Plan và Actual, trục tung theo giá trị lũy kế',()=>{

 assert.deepEqual(cumulative([100,200,null,300]),[100,300,null,600],'tháng null không tạo điểm nhưng không chặn tổng các tháng sau');
 assert.deepEqual(cumulative([null,null]),[null,null],'chưa có tháng nào thì đường vẫn trống');
 const plan=Array.from({length:12},(_,i)=>(i+1)*100),actual=Array.from({length:12},(_,i)=>i<7?(i+1)*90:null);
 const months=Array.from({length:12},(_,i)=>i<7?actual[i]:plan[i]);
 const source={...data,asOf:'2026-10-06',aps:{connected:false,warning:'Không đọc được dữ liệu portal APS',budget:null},costSaving:{year:2026,currentMonth:8,plan,actual,months,items:1,source:'sql',warning:'',updatedAt:''}};
 const before=JSON.stringify(source),sav=savingSummary(source);
 assert.deepEqual(sav.plan.slice(0,3),[0.1,0.2,0.3],'selector vẫn trả giá trị từng tháng, không đổi contract KPI');
 assert.deepEqual(cumulative(sav.actual),[0.09,0.27,0.54,0.9,1.35,1.89,2.52,null,null,null,null,null],'lũy kế Actual = T1+T2+…+TN');
 const presentation={link:(label,route,filter='')=>`<button class="text-button" data-go="${route}"${filter?` data-filter="${filter}"`:''}>${label}</button>`,badge:value=>`<span class="badge">${value}</span>`,icon:()=>'',canUpdateBudget:()=>true};
 const root={innerHTML:''};render(root,source,presentation);const html=root.innerHTML;
 // Giải mã tung độ SVG về K$ theo đúng hình học biểu đồ (top 26, height 188, max làm tròn ceil(cumMax/4)*4 = 8).
 const decode=selector=>{const match=html.match(new RegExp('class="'+selector+'" points="([^"]+)"'));if(!match)return [];const top=26,h=248-26-34,max=Math.ceil(7.8/4)*4;return match[1].split(' ').map(pair=>(top+h-Number(pair.split(',')[1]))*max/h);};
 const planSeries=decode('ov-line-target').map(value=>Math.round(value*100)/100),actualSeries=decode('ov-line-result').map(value=>Math.round(value*100)/100);
 assert.equal(planSeries.length,12,'đường Plan lũy kế đủ 12 tháng');
 assert.deepEqual(planSeries,[0.1,0.3,0.6,1,1.5,2.1,2.8,3.6,4.5,5.5,6.6,7.8],'Plan vẽ bằng giá trị lũy kế, không phải từng tháng');
 assert.deepEqual(actualSeries,[0.09,0.27,0.54,0.9,1.35,1.89,2.52],'Actual lũy kế dừng ở tháng hiện tại');
 assert.equal(html.includes('(K$ · lũy kế)'),true,'đơn vị trục tung ghi rõ lũy kế');
 assert.equal(html.includes('Kế hoạch lũy kế (Plan)')&&html.includes('Thực hiện lũy kế (Actual)'),true,'chú giải ghi rõ hai chuỗi là lũy kế');
 assert.equal(html.includes('kế hoạch lũy kế 2.8 K$, thực hiện lũy kế 2.5 K$'),true,'aria-label tháng 7 đọc theo giá trị lũy kế');
 assert.equal(JSON.stringify(source),before,'vẽ lũy kế không sửa dữ liệu nguồn');
});


