const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const source=process.env.MRO_FRONTEND_BASELINE||path.resolve(__dirname,'../../../..');
const {createServer}=require(path.join(source,'server.cjs'));
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
(async()=>{
 const runtime=fs.mkdtempSync(path.join(os.tmpdir(),'mro-overview-browser-'));let server,browser;
 try{
  server=createServer({runtime});await new Promise(r=>server.listen(0,'127.0.0.1',r));
  browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({viewport:{width:1920,height:1080}});
  await require('../../../../tests/fixtures/legacy-data.cjs').install(page,path.resolve(__dirname,'../../../..'));
  const states=[],csv=[],errors=[];let rawRequests=0;
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(new URL(r.url()).pathname==='/data/raw.json')rawRequests++;});
  await page.goto('http://127.0.0.1:'+server.address().port);
  for(const [name,value] of Object.entries({username:'overviewtest',name:'Overview Test',password:'Overview-test-password-2026!',confirm:'Overview-test-password-2026!'}))await page.locator(`#login-form [name=${name}]`).fill(value);
  await page.locator('#login-form button[type=submit]').click();await page.locator('[data-view=overview] .ov-fold>.panel').first().waitFor();await page.locator('#loading').waitFor({state:'hidden'});
  const raw=JSON.parse(fs.readFileSync(path.join(source,'tests/fixtures/legacy-raw.json'))),total=r=>r.physical+Object.values(r.vendors).reduce((a,b)=>a+b,0);
  const removedCardKeys=['all','sufficient','shortage','out-of-stock','pending-po','codes-open'];
  for(const theme of ['dark','light']){
   if(await page.locator('html').getAttribute('data-theme')!==theme)await page.locator('#theme').click();
   const view=page.locator('[data-view=overview]');await view.waitFor({state:'visible'});
   async function record(name){states.push({name:theme+'/'+name,sha256:hash(await view.innerHTML())});}
   assert.equal(await view.locator('.kpi').count(),0,'đã gỡ dải thẻ KPI của bảng Vận hành & vật tư khỏi tab Tổng quan');await record('initial');
   assert.equal(await view.locator('.ov-fold>.panel').count(),2,'khung fold chỉ chứa Ngân sách OH và OH Repair/COST Saving');
   assert.deepEqual(await view.locator('.ov-duo .ov-duo-card').evaluateAll(nodes=>nodes.map(n=>n.className)),['ov-duo-card ov-repair','ov-duo-card ov-saving'],'section mới có đúng hai thẻ Repair và Cost Saving');
   assert.equal(await view.locator('.ov-saving .ov-line').count(),0,'chưa đọc được SQL thì thẻ Cost Saving không vẽ đường giả');
   assert.equal(await view.locator('.ov-duo .kpi').count(),0,'section mới không tạo thẻ .kpi thứ bảy');
   const duoBoxes=await view.evaluate(e=>{const f=e.querySelector('.ov-finance'),d=e.querySelector('.ov-duo');return {financeBottom:Math.round(f.getBoundingClientRect().bottom),duoTop:Math.round(d.getBoundingClientRect().top),financeWidth:Math.round(f.getBoundingClientRect().width),duoWidth:Math.round(d.getBoundingClientRect().width)};});
   assert.ok(duoBoxes.duoTop>=duoBoxes.financeBottom-1,'thứ tự Ngân sách OH → OH Repair/COST Saving giữ nguyên');assert.equal(duoBoxes.financeWidth,duoBoxes.duoWidth,'hai bảng phải cùng chiều ngang và lấp đầy khung Tổng quan');
   const repairEmpty=await view.locator('.ov-repair .ov-duo-empty').count();
   assert.ok(repairEmpty===1?(await view.locator('.ov-repair .ov-month').count())===0:(await view.locator('.ov-repair .ov-month').count())===12,'Repair chart có đủ 12 cột hoặc ô trống kèm giải thích');
    // Công cụ ngân sách Repair trên thẻ Overview: chọn nguồn, chi tiết và Cập nhật (admin trở lên).
    assert.equal(await view.locator('.ov-repair [data-repair-source]').count(),1,'thẻ OH Repair có ô chọn nguồn Actual');
    assert.equal(await view.locator('.ov-repair [data-repair-source]').isDisabled(),false,'developer được đổi nguồn ngân sách Repair');
    assert.equal(await view.locator('.ov-repair [data-repair-source]').inputValue(),'payments','nguồn ban đầu theo budget doc (WRB Data)');
    assert.equal(await view.locator('.ov-repair [data-repair-detail]').count(),1,'thẻ OH Repair có nút Chi tiết ngân sách');
    assert.equal(await view.locator('.ov-repair [data-repair-update]').count(),1,'admin có nút Cập nhật ngân sách Repair');
   {
    
    
    
    
    
    
   }
   for(const key of removedCardKeys)assert.equal(await view.locator('[data-overview-key="'+key+'"]').count(),0,'đã gỡ thẻ KPI "'+key+'" khỏi tab Tổng quan');
   for(const [route,filter,selector] of [['aps',null,'[data-go=aps]']]){
    await page.evaluate(()=>window.overviewView=document.querySelector('[data-view=overview]'));
    await view.locator(selector).first().click();const target=page.locator(`[data-view=${route}]`);await target.waitFor({state:'visible'});if(filter)assert.equal(await target.locator(`[data-tab=${filter}]`).getAttribute('class'),'active');
    await page.locator('[data-route=overview]').click();await view.waitFor({state:'visible'});assert.equal(await page.evaluate(()=>window.overviewView===document.querySelector('[data-view=overview]')),true);await record('return-'+route+'-'+filter);
   }
   await view.locator('.ov-finance [data-oh-series]').first().click();await page.evaluate(()=>{window.overviewBeforeRemount=document.querySelector('[data-view=overview]');document.dispatchEvent(new CustomEvent('data-edited'));});assert.equal(await page.evaluate(()=>window.overviewBeforeRemount.isConnected),false);assert.equal(await view.locator('.overview-card-details').count(),0);await record('remount');
  }
  // Cost Saving đọc thẳng dbo.EQM_CostSavingActivity: máy test chưa cấu hình SQL thì thẻ báo thật, không còn ô nhập tay.
  const overview=page.locator('[data-view=overview]');
  await page.locator('[data-route=overview]').click();await overview.waitFor({state:'visible'});
  assert.equal(await overview.locator('[data-saving-update]').count(),0,'card Cost Saving không còn nút nhập tay');
  await overview.locator('.ov-saving .ov-duo-empty').waitFor();
  assert.match(await overview.locator('.ov-saving .ov-duo-empty').textContent(),/Cost Saving/,'chưa đọc được SQL thì thẻ báo trống, không bịa số liệu');
  assert.equal(await overview.locator('.ov-materials').count(),0,'tab Tổng quan không còn khối Vận hành & vật tư');assert.equal(await overview.locator('.ov-duo').isVisible(),true,'OH Repair/COST Saving vẫn render khi Cost Saving chưa có dữ liệu');
  assert.equal(rawRequests,1);assert.deepEqual(errors,[]);console.log(JSON.stringify({passed:true,rawRequests,states,csv,pageErrors:errors},null,2));
 }finally{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));assert.equal(path.dirname(runtime),os.tmpdir());assert.ok(path.basename(runtime).startsWith('mro-overview-browser-'));fs.rmSync(runtime,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
