// Public entry duy nhất, cùng pattern Delivery/Inventory.
import {render} from './view.mjs';
import {bindCardActions,bindChartActions,bindRepairChart,bindRepairSource,bindSavingChart} from './actions.mjs';
import {bindBudget,bindRepairBudget,bindSavingBudget} from './budget.mjs';
export {cardFilters} from './cards.mjs';
const states=new WeakMap();
export function mount(root,data,presentation){
 // Tổng quan chỉ còn hai bảng: Ngân sách OH + OH Repair/COST Saving trong khung .ov-fold, tự cân đối lấp đầy chiều ngang (đã gỡ bảng "Vận hành & vật tư" ngày 12/11/2026).
 // Overview tự bó gọn theo chiều cao màn hình: core (frontend/core/bootstrap.mjs, scheduleFit) chỉ zoom view có data-fit-viewport, áp dụng từ 1100px bề ngang.
 root.dataset.fitViewport='';
 let state=states.get(data);
 if(!state){const initial=presentation.budgetApi&&!presentation.offline?null:data.budgetOH,year=data.budgetOH?.document?.year||data.budgetOH?.year||Number(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric'}).format(new Date()));state={year,saving:new Map(data.costSaving?.months?[[Number(data.costSaving.year)||year,data.costSaving]]:[]),records:new Map(presentation.offline?(presentation.budgetRecords||[]).filter(r=>r.document).map(r=>[r.document.year,r]):initial?[[year,initial]]:[]),...(presentation.offline?{years:(presentation.budgetRecords||[]).filter(r=>r.document).map(r=>r.document.year).sort((a,b)=>b-a)}:{}),repairSource:null,repairOverride:null};states.set(data,state);}
 let resolveReady;const ready=new Promise(resolve=>resolveReady=resolve);if(!presentation.budgetApi||presentation.offline||state.records.has(state.year))resolveReady();
 let context,sequence=0,timer,busy=false,stopped=false,offline=false,settings={ohSeconds:60,retrySeconds:5};
 async function refreshSaving(){
  if(!presentation.savingApi||presentation.offline||state.saving.has(state.year))return;
  try{const record=await presentation.savingApi('cost-saving?year='+state.year);if(stopped||!root.isConnected)return;state.saving.set(record?.year||state.year,record);draw();}catch{}
 }
 function draw(){
  const record=state.records.get(state.year),hasRecord=!!record?.document;
  const apsLive=state.repairOverride?{...(data.aps||{}),budget:state.repairOverride}:data.aps;
  const viewData={...data,aps:apsLive,repairSource:state.repairSource||(apsLive&&apsLive.budget?apsLive.budget.source:'payments'),ohYear:state.year,ohYears:state.years,ohMissing:!!presentation.budgetApi&&!hasRecord,budgetOH:hasRecord?record:undefined,budget:hasRecord?record.budget:(data.budgetOH?[]:data.budget),costSaving:state.saving.get(state.year)};
  const repairSaved=record=>{if(record.merged)state.repairOverride=record.merged;if(record.source)state.repairSource=record.source;draw();};
  render(root,viewData,presentation);
  bindBudget(root,viewData,{...presentation,onSaved:record=>{state.years=[...new Set([...(state.years||[]),record.document.year])].sort((a,b)=>b-a);state.records.set(record.document.year,record);draw();}});
  bindChartActions(root,viewData);
  bindRepairBudget(root,viewData,{...presentation,onSaved:repairSaved});
  bindRepairSource(root,viewData,presentation,{onSaved:repairSaved});
  bindRepairChart(root,viewData);
  bindSavingChart(root,viewData);
  bindSavingBudget(root,viewData,{...presentation,onSaved:record=>{if(record?.year)state.saving.set(Number(record.year),record);draw();}});
  if(context)bindCardActions(root,viewData,presentation,context);
  const select=root.querySelector('[data-oh-year]');
  select.onchange=()=>{state.year=Number(select.value);state.explicit=true;sequence++;if(presentation.offline)draw();else refresh();refreshSaving();};
  root.querySelector('[data-oh-status]').textContent=state.warning||(!record?(presentation.offline?'Bản xem độc lập không có dữ liệu OH cho năm này.':'Đang tải OH từ SQL…'):'');
 }
 async function refresh(){
  if(stopped)return;
  if(!root.isConnected){stop();return;}
  if(busy)return;busy=true;clearTimeout(timer);const token=sequence;
  try{try{settings={...settings,...await presentation.budgetApi('refresh-settings')};}catch{}const record=await presentation.budgetApi('budget-oh/live'+(state.explicit?'?year='+state.year:''));if(stopped||!root.isConnected||token!==sequence)return;
   offline=!!record.offline;
   const year=record.document?.year||record.year,stateKey=JSON.stringify([record.document,record.source,record.years,record.warning]);
   state.year=year;state.records.set(year,record);state.years=record.years;state.warning=record.warning;refreshSaving();
   if(state.key!==stateKey){state.key=stateKey;draw();}
  }catch(e){offline=true;if(root.isConnected)root.querySelector('[data-oh-status]').textContent=e.message;}
  finally{resolveReady();busy=false;if(!stopped)timer=setTimeout(refresh,token!==sequence?0:(offline?settings.retrySeconds:settings.ohSeconds)*1000);}
 }
 function stop(){resolveReady();stopped=true;clearTimeout(timer);delete root.dataset.fitViewport;window.removeEventListener('online',wake);document.removeEventListener('visibilitychange',wake);document.removeEventListener('refresh-settings-changed',changed);}
 function changed(e){settings=e.detail;clearTimeout(timer);if(!busy)timer=setTimeout(refresh,(offline?settings.retrySeconds:settings.ohSeconds)*1000);}
 function wake(){if(!document.hidden)refresh();}
 const updated=()=>{if(!root.isConnected){document.removeEventListener('procurement-updated',updated);return;}draw();};document.addEventListener('procurement-updated',updated);
 draw();
 if(presentation.budgetApi&&!presentation.offline){window.addEventListener('online',wake);document.addEventListener('visibilitychange',wake);document.addEventListener('refresh-settings-changed',changed);presentation.budgetApi('refresh-settings').then(value=>{settings=value;}).catch(()=>{}).finally(()=>{timer=setTimeout(refresh,0);});}

 return {ready,bindCards(next){context=next;bindCardActions(root,data,presentation,context);}};
}

