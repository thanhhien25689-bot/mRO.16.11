import {esc} from '../../shared/ui/index.mjs';

import {summary,budgetSummary,repairSummary,savingSummary,cumulative} from './selectors.mjs';
import {ohValue,stockStatus,sopLate} from '../../../shared/model.mjs';

// Phase 5B — Operational alert bar (compact, non-zero alerts only, direct navigation)
function ovAlertBar(data) {
 const items = data.items || [], tracking = data.trackingSQL || data.tracking || [];
 const codes = data.codesSQL || data.codes || [], deliveries = data.deliveries || [];
 const outOfStock = items.filter(r => stockStatus(r) === 'Hết hàng').length;
 const shortage   = items.filter(r => stockStatus(r) === 'Nguy cơ thiếu').length;
 const watch      = items.filter(r => stockStatus(r) === 'Theo dõi').length;
 const pendingPO  = tracking.filter(r => data.trackingSQL ? (r.pr?.PR_NO && !r.pr?.PO_NO) : !r.po).length;
 const openCodes  = codes.filter(r => r.status !== 'Ready for PR').length;
 const lateSOP    = (data.requests || []).filter(r => sopLate(r, data.asOf)).length;
 const unconfirmed= deliveries.filter(r => r.status === 'Đang chuẩn bị').length;
 const chips = [
  outOfStock ? `<a href="#inventory" class="ov-alert-chip red" title="Mã vật tư hết hàng hoàn toàn"><strong>${outOfStock}</strong> Hết hàng</a>` : '',
  shortage   ? `<a href="#inventory" class="ov-alert-chip amber" title="Coverage dưới 1 tuần"><strong>${shortage}</strong> Nguy cơ thiếu</a>` : '',
  watch      ? `<a href="#inventory" class="ov-alert-chip amber-soft" title="Coverage dưới 4 tuần"><strong>${watch}</strong> Cần theo dõi</a>` : '',
  pendingPO  ? `<a href="#tracking" class="ov-alert-chip violet" title="PR chưa có PO"><strong>${pendingPO}</strong> PR chờ PO</a>` : '',
  openCodes  ? `<a href="#codes" class="ov-alert-chip cyan" title="Mã chưa sẵn sàng bàn giao PIC3"><strong>${openCodes}</strong> Code chưa Ready</a>` : '',
  lateSOP    ? `<a href="#orders" class="ov-alert-chip red" title="Yêu cầu SOP trễ trên 21 ngày"><strong>${lateSOP}</strong> SOP trễ</a>` : '',
  unconfirmed? `<a href="#delivery" class="ov-alert-chip muted" title="Phiếu giao chưa xác nhận"><strong>${unconfirmed}</strong> Giao chưa xác nhận</a>` : '',
 ].filter(Boolean);
 if (!chips.length) return '';
 return `<div class="ov-alert-bar" role="region" aria-label="Cảnh báo vận hành"><span class="ov-alert-label">Cảnh báo</span>${chips.join('')}</div>`;
}
// Biểu đồ đường Cost Saving theo ảnh chuẩn, dạng LŨY KẾ: mỗi điểm tháng N = tổng T1..TN.
// Áp dụng cho cả Target = Plan (nét đứt, đủ 12 tháng) và Result = Actual (nét liền, chỉ tới
// tháng hiện tại) kèm vùng tô. Số liệu USD, trục tung K$; tháng trống không tạo điểm nhưng
// không chặn tổng lũy kế.
const SAVING_VIEW = {width:720, height:248, left:58, right:22, top:26, bottom:34};
const savingK = value => new Intl.NumberFormat('en-US', {maximumFractionDigits:1}).format(value);
function savingChart(sav, monthName, stamp) {
  if (!sav.planMonths && !sav.actualMonths) return `<div class="ov-duo-empty">${esc(sav.warning || `Chưa có dữ liệu Cost Saving trong EQM_CostSavingActivity cho năm ${sav.year}.`)}</div>`;
  const plan = cumulative(sav.plan), actual = cumulative(sav.actual);
  const cumMax = Math.max(0, ...plan, ...actual);
  const {width, height, left, right, top, bottom} = SAVING_VIEW, w = width - left - right, h = height - top - bottom;
  const max = Math.max(cumMax ? Math.ceil(cumMax / 4) * 4 || cumMax : 0, 1), x = i => left + i * w / 11, y = value => top + h - (Math.max(0, value) / max) * h;
  const path = values => values.map((value, i) => value === null ? null : `${x(i).toFixed(1)},${y(value).toFixed(1)}`).filter(Boolean).join(' ');
  const lastActual = actual.reduce((last, value, i) => value === null ? last : i, -1);
  const area = lastActual >= 0 ? `<polygon class="ov-line-area" points="${path(actual.slice(0, lastActual + 1))} ${x(lastActual).toFixed(1)},${top + h} ${left},${top + h}"/>` : '';
  const target = plan.map((value, i) => value === null ? '' : `<path class="ov-line-diamond" d="M${x(i)},${(y(value)-5).toFixed(1)}L${(x(i)+5).toFixed(1)},${y(value).toFixed(1)}L${x(i)},${(y(value)+5).toFixed(1)}L${(x(i)-5).toFixed(1)},${y(value).toFixed(1)}Z"/>`).join('');
  const result = actual.map((value, i) => value === null ? '' : `<circle class="ov-line-dot" cx="${x(i).toFixed(1)}" cy="${y(value).toFixed(1)}" r="4.5"/>`).join('');
  const step = w / 11;
  const slots = sav.months.map((value, i) => `<g class="ov-line-slot" data-saving-month="${i+1}" role="button" tabindex="0" aria-label="${monthName(i+1)}: kế hoạch lũy kế ${plan[i]===null?'chưa có':savingK(plan[i])+' K$'}, thực hiện lũy kế ${actual[i]===null?'chưa có':savingK(actual[i])+' K$'}"><rect x="${(x(i)-step/2).toFixed(1)}" y="${top}" width="${step.toFixed(1)}" height="${h}"/><text class="ov-line-x" x="${x(i).toFixed(1)}" y="${height-12}">${monthName(i+1)}</text></g>`).join('');
  const grid = [0,1,2,3,4].map(i => {const value = max*i/4;return `<line class="ov-line-grid" x1="${left}" y1="${y(value).toFixed(1)}" x2="${width-right}" y2="${value?y(value).toFixed(1):top+h}"/><text class="ov-line-y" x="${left-8}" y="${(y(value)+4).toFixed(1)}">${savingK(value)}</text>`;}).join('');
  const targetPath = path(plan), resultPath = path(actual.slice(0, Math.max(lastActual + 1, 0)));
  const now = sav.currentMonth >= 1 && sav.currentMonth <= 12 ? `<line class="ov-line-now" x1="${x(sav.currentMonth-1).toFixed(1)}" y1="${top}" x2="${x(sav.currentMonth-1).toFixed(1)}" y2="${top+h}"/>` : '';
  return `<div class="ov-line"><span class="ov-line-unit">(K$ · lũy kế)</span><span class="ov-line-stamp">${esc(stamp)}</span>
   <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Biểu đồ đường Cost Saving lũy kế ${sav.year}: kế hoạch và thực hiện lũy kế theo tháng (tháng N = tổng T1..TN), đơn vị K USD"><title>Cost Saving lũy kế ${sav.year} · K USD</title>
    ${grid}${now}${area}
    ${targetPath?`<polyline class="ov-line-target" points="${targetPath}"/>`:''}${target}
    ${resultPath?`<polyline class="ov-line-result" points="${resultPath}"/>`:''}${result}
    ${slots}
   </svg></div>`;
}
export function render(root,data,{link,icon,canUpdateBudget}){
 const {budget,annual,p03,max}=summary(data),b=budgetSummary(data),latest=b.latest;
 const delta=latest?ohValue(latest)-latest.p03:0,percent=latest?.p03?delta/latest.p03*100:null;
 const monthName=n=>['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][n-1];
 const amount=n=>data.ohMissing?'—':new Intl.NumberFormat('en-US',{maximumFractionDigits:0}).format(n);
 const months=arr=>arr.length?monthName(Math.min(...arr))+'–'+monthName(Math.max(...arr)):'Chưa có dữ liệu';
 const stat=(label,value,note,color)=>`<div class="ov-finance-stat ov-stat-${color}" role="button" tabindex="0" aria-pressed="false" data-oh-series="${({cyan:'plan',mint:'actual',amber:'forecast',violet:'annual'})[color]}"><span class="ov-finance-icon ${color}">${icon(({cyan:'money',mint:'stock',amber:'calendar',violet:'layers'})[color])}</span><span class="ov-finance-label">${label}</span><strong class="${color}">${amount(value)} <small>K$</small></strong><small>${note}</small></div>`;
 // Dải thẻ KPI gọn đặt DƯỚI biểu đồ (ảnh chuẩn: nhãn in hoa nhỏ, số lớn màu, ghi chú một dòng).
 const statChip=s=>`<div class="ov-stat-chip ov-stat-${s.color}" title="${esc(`${s.label} · ${s.note}`)}"><span>${esc(s.label)}</span><strong class="${s.color}">${s.value} <small>K$</small></strong><small>${esc(s.note)}</small></div>`;
 const statStrip=(chips,cls)=>`<div class="ov-stat-strip${cls?` ${cls}`:''}">${chips.map(statChip).join('')}</div>`;
 const rep=repairSummary(data),sav=savingSummary(data);
 const duoBars=rep.rows.map(r=>`<div class="ov-month" tabindex="0" data-oh-month="${r.month}" aria-label="${monthName(r.month)} · Xem ngân sách Repair" aria-describedby="oh-repair-tooltip"><div class="ov-columns"><div style="--target-height:${rep.max?r.p03/rep.max*100:0}%" class="ov-bar ov-plan ov-bar-grow"><span>${amount(r.p03)}</span></div><div style="--target-height:${rep.max?ohValue(r)/rep.max*100:0}%" class="ov-bar ${r.rawGR===null?'ov-forecast':'ov-actual'} ov-bar-grow"><span>${amount(ohValue(r))}</span></div></div><strong>${monthName(r.month)}</strong><small class="${r.p03>0&&ohValue(r)>r.p03?'ov-over-budget':''}">${r.p03?(ohValue(r)/r.p03*100).toFixed(0)+'%':'—'}</small></div>`).join('');
 const repPeriod=(type,from,to)=>type==='actual'?`<div class="ov-period ov-period-actual" style="grid-column:${from}/span ${to-from+1}">Đã có GR thực tế <span>T${String(from).padStart(2,'0')}–T${String(to).padStart(2,'0')}</span></div>`:`<div class="ov-period ov-period-forecast" style="grid-column:${from}/span ${to-from+1}">Dự kiến theo budget <span>T${String(from).padStart(2,'0')}–T${String(to).padStart(2,'0')}</span></div>`;
 const repPeriods=rep.grSplit>=12?repPeriod('actual',1,12):(rep.grSplit>0?repPeriod('actual',1,rep.grSplit):'')+(rep.grSplit<12?repPeriod('forecast',Math.max(rep.grSplit+1,1),12):'');
 const duoMonths=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
 const repairCan=canUpdateBudget?.();
 const repSource=rep.source==='manual'?'manual':'payments';
 const repStats=[
  {label:'Tổng P03 năm '+rep.year,value:amount(rep.p03Total),note:'Ngân sách kế hoạch',color:'cyan'},
  {label:'Tổng Actual'+(rep.grSplit>0?' (T01 – T'+String(rep.grSplit).padStart(2,'0')+')':''),value:amount(rep.actualTotal),note:rep.source==='sql'?'từ SQL Server (Repair + Service)':repSource==='payments'?'theo WRB Data (thanh toán)':'theo Tax confirm (AdJ)',color:'mint'},
  {label:'GR dự kiến'+(rep.grSplit<12?' (T'+String(rep.grSplit+1).padStart(2,'0')+' – T12)':' (đã hết năm)'),value:amount(rep.forecastTotal),note:rep.source==='sql'&&rep.sqlPlan?'theo Monthly Plan (SQL)':'theo budget đã cập nhật',color:'amber'},
  {label:'Tổng cả năm (Actual + Dự kiến)',value:amount(rep.total),note:'so với P03 '+(rep.variancePct===null?'—':(rep.variancePct>0?'+':'')+rep.variancePct.toFixed(0)+'%'),color:'violet'}
 ];
 const repStatStrip=statStrip(repStats,'ov-repair-strip');
 const savStatStrip=statStrip([
  {label:'Kế hoạch năm (lũy kế T12)',value:sav.planMonths?savingK(sav.planTotal):'—',note:'Plan '+sav.planMonths+'/12 tháng',color:'amber'},
  {label:'Thực hiện lũy kế',value:sav.actualMonths?savingK(sav.actualTotal):'—',note:'Actual '+sav.actualMonths+'/12 tháng',color:'cyan'},
  {label:'Dự kiến cả năm',value:sav.planMonths||sav.actualMonths?savingK(sav.total):'—',note:'Theo Plan và Actual hiện có',color:'violet'}
 ],'ov-saving-strip');

 const duo=`<section class="panel ov-duo"><div class="panel-head ov-duo-head"><h2>OH Repair và COST Saving</h2><span>${esc(rep.sqlWarning||(rep.connected?'Cùng năm '+rep.year+' đang xem ở Ngân sách OH':rep.warning))}</span></div><div class="ov-duo-grid">
  <article class="ov-duo-card ov-repair"><div class="ov-duo-head-row"><h3>OH Repair</h3><label class="ov-repair-source">Nguồn <select data-repair-source aria-label="Nguồn Actual OH Repair"${repairCan?'':' disabled title="Chỉ Admin trở lên được đổi nguồn ngân sách Repair"'}><option value="payments"${repSource==='payments'?' selected':''}>WRB Data${rep.source==='sql'?' (SQL Server)':''}</option><option value="manual"${repSource==='manual'?' selected':''}>Tax confirm (AdJ)</option></select></label><button class="text-button" data-repair-detail>Chi tiết ngân sách →</button>${link('Mở tab Repair & Service','aps')}${repairCan?'<button class="button small" data-repair-update>Cập nhật</button>':''}</div><div class="ov-duo-repair-body"><div class="ov-chart" data-oh-chart="repair" data-oh-tip="oh-repair-tooltip"><div class="ov-chart-heading"><strong>P03 và GR Repair theo tháng</strong><div class="chart-legend"><span><i class="cyan-bg"></i>P03</span><span><i class="mint-bg"></i>GR thực tế</span><span><i class="amber-bg"></i>Dự kiến</span></div></div>${rep.rows.length?`<div class="ov-plot">${duoBars}</div><div class="ov-periods" style="grid-template-columns:repeat(${rep.rows.length},minmax(0,1fr))">${repPeriods}</div>`:`<div class="ov-duo-empty">Chưa có ngân sách Repair cho năm ${esc(rep.year)} trong portal APS.</div>`}<div class="ov-chart-foot"><span>Tỷ lệ GR / P03 · Đơn vị K USD</span><span>${esc(rep.connected?'Nguồn '+(rep.source==='sql'?'SQL Server (Repair + Service)':repSource==='manual'?'Tax confirm (AdJ)':'WRB Data (thanh toán)')+(rep.closed?' · Chốt hết '+monthName(rep.closed):''):(rep.warning||'Không đọc được dữ liệu portal APS.'))}</span></div></div>
   <aside class="ov-latest ov-duo-latest"><div class="eyebrow">KẾT QUẢ THÁNG VỪA QUA</div><h3>${rep.latest?monthName(rep.latest.month)+' / '+esc(rep.year):'Chưa có GR thực tế'}</h3><div class="ov-latest-values"><div><span>${rep.latest&&!rep.latest.isActual?'GR dự kiến (theo budget)':repSource==='manual'?'Actual (Tax confirm)':'GR thực tế (đã điều chỉnh)'}</span><strong>${rep.latest?amount(ohValue(rep.latest)):'—'} <small>K$</small></strong></div><div><span>P03 kế hoạch</span><strong>${rep.latest?amount(rep.latest.p03):'—'} <small>K$</small></strong></div></div><div class="ov-variance ${rep.delta>0?'red':'mint'}">${rep.latest?(rep.delta>0?'+':'')+amount(rep.delta)+' K$'+(rep.percent===null?'':` (${rep.delta>0?'+':''}${rep.percent.toFixed(1)}%)`):'—'}<span>${rep.delta>0?'Cao hơn kế hoạch':'Trong kế hoạch'}</span></div><p><strong>Lý do vượt P03</strong><br>${rep.latest&&rep.latest.reason?esc(rep.latest.reason):(rep.connected?'<span class="muted">Chưa có ghi chú nguyên nhân cho tháng này.</span>':'<span class="red">'+esc(rep.warning||'Không đọc được dữ liệu portal APS.')+'</span>')}</p></aside></div>${repStatStrip}</article>
  <article class="ov-duo-card ov-saving"><div class="ov-duo-head-row"><h3>Cost Saving</h3><span class="muted">EQM_CostSavingActivity · USD · năm ${esc(sav.year)} · lũy kế theo tháng</span><span class="ov-line-legend"><i class="ov-line-key ov-line-key-target"></i>Kế hoạch lũy kế (Plan)<i class="ov-line-key ov-line-key-result"></i>Thực hiện lũy kế (Actual)</span></div>
   ${savingChart(sav,monthName,`${String(data.asOf||'').slice(8,10)}/${String(data.asOf||'').slice(5,7)}/${String(data.asOf||'').slice(0,4)}`)}
   ${savStatStrip}
   ${data.costSaving?.editable&&(data.costSaving.activities||[]).length?`<div class="ov-saving-actions"><button type="button" class="button small" data-saving-update${canUpdateBudget?.()?'':' disabled title="Chỉ Admin trở lên được cập nhật Cost Saving."'}>Nhập Plan / Actual</button><span class="small muted">Lưu trực tiếp các ô USD vào EQM_CostSavingActivity theo số thứ tự dòng (No)</span></div>`:''}
   ${sav.warning?`<p class="small red">${esc(sav.warning)}</p>`:`<p class="small muted">Actual ${sav.actualMonths}/12 tháng, Plan ${sav.planMonths}/12 tháng${sav.updatedAt?' · đọc lúc '+esc(new Date(sav.updatedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'})):''}</p>`}</article>
 </div></section>`;

 root.innerHTML=`${ovAlertBar(data)}<div class="ov-fold"><section class="panel ov-finance"><div class="panel-head"><div><div class="eyebrow">FINANCIAL OVERVIEW</div><h2>Ngân sách OH · P03 & GR</h2></div><div class="ov-finance-tools"><label class="ov-year">Năm <select data-oh-year aria-label="Năm ngân sách OH">${(data.ohYears||[Number(b.year)]).map(year=>`<option value="${year}" ${year===Number(b.year)?'selected':''}>${year}</option>`).join('')}</select></label><button class="text-button" data-oh-detail>Chi tiết ngân sách →</button>${canUpdateBudget?.()?'<button class="button small" data-oh-update>Cập nhật</button>':''}</div></div><p data-oh-status role="status" class="small muted">${data.ohMissing?'Chưa có dữ liệu OH cho năm này. Chọn Cập nhật để tải SQL hoặc nhập bảng.':''}</p><div class="ov-finance-stats">${stat('P03 cả năm',p03,'Ngân sách kế hoạch','cyan')}${stat('GR thực tế',b.actual,months(b.actualMonths)+(data.budgetOH?' · '+(data.budgetOH.source==='sql'?'SQL Server':data.budgetOH.source==='sample'?'Dữ liệu mẫu':'JSON đã lưu'):' · Đã gồm điều chỉnh'),'mint')}${stat('GR dự kiến',b.forecast,months(b.forecastMonths)+' · Forecast hiện tại','amber')}${stat('Tổng dự kiến cả năm',annual,(p03?(annual/p03*100).toFixed(1)+'% P03':'Chưa có P03'),'violet')}</div>
 <div class="ov-finance-body"><div class="ov-chart"><div class="ov-chart-heading"><strong>P03 và GR theo tháng</strong><div class="chart-legend"><span><i class="cyan-bg"></i>P03</span><span><i class="mint-bg"></i>GR thực tế</span><span><i class="amber-bg"></i>Dự kiến</span></div></div><div class="ov-plot">${budget.map(r=>`<div class="ov-month" tabindex="0" data-oh-month="${r.month}" aria-label="${monthName(r.month)} · Xem ngân sách" aria-describedby="oh-chart-tooltip"><div class="ov-columns"><div style="--target-height:${r.p03/max*100}%" class="ov-bar ov-plan ov-bar-grow"><span>${amount(r.p03)}</span></div><div style="--target-height:${ohValue(r)/max*100}%" class="ov-bar ${r.rawGR===null?'ov-forecast':'ov-actual'} ov-bar-grow"><span>${amount(ohValue(r))}</span></div></div><strong>${monthName(r.month)}</strong><small class="${r.p03>0&&ohValue(r)>r.p03?'ov-over-budget':''}">${r.p03?(ohValue(r)/r.p03*100).toFixed(0)+'%':'—'}</small></div>`).join('')}</div><div class="ov-periods" style="grid-template-columns:repeat(${budget.length||12},minmax(0,1fr))">${budget.map((r,i)=>{const type=r.rawGR===null?'forecast':'actual';if(i&&((budget[i-1].rawGR===null)=== (r.rawGR===null)))return '';let end=i;while(end+1<budget.length&&((budget[end+1].rawGR===null)===(r.rawGR===null)))end++;return `<div class="ov-period ov-period-${type}" style="grid-column:${i+1}/span ${end-i+1}">${type==='actual'?'Đã có GR thực tế':'Còn lại · Dự kiến'} <span>${monthName(r.month)}–${monthName(budget[end].month)}</span></div>`;}).join('')}</div><div class="ov-chart-foot"><span>Tỷ lệ GR / P03 · Đơn vị K USD</span><span>Thực tế ${months(b.actualMonths)} · Dự kiến ${months(b.forecastMonths)}</span></div></div>
 <aside class="ov-latest"><div class="eyebrow">KẾT QUẢ THÁNG GẦN NHẤT</div><h3>${latest?monthName(latest.month)+' / '+b.year:'Chưa có GR thực tế'}</h3><div class="ov-latest-values"><div><span>${data.budgetOH?'GR thực tế':'GR đã điều chỉnh'}</span><strong>${latest?amount(ohValue(latest)):'—'} <small>K$</small></strong></div><div><span>P03 kế hoạch</span><strong>${latest?amount(latest.p03):'—'} <small>K$</small></strong></div></div><div class="ov-variance ${delta>0?'red':'mint'}">${latest?(delta>0?'+':'')+amount(delta)+' K$'+(percent===null?'':` (${delta>0?'+':''}${percent.toFixed(1)}%)`):'—'}<span>${delta>0?'Cao hơn kế hoạch':'Trong kế hoạch'}</span></div><p><strong>Ghi chú dữ liệu</strong><br>${data.budgetOH?'Thời gian: '+esc(new Date(data.budgetOH.updatedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'})):'Chưa có thời gian cập nhật SQL.'}</p></aside></div></section>${duo}</div>`;
}
