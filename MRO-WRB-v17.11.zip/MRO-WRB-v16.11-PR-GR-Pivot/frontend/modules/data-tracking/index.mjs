import {esc,showDetail,toast,exportWorkbook} from '../../shared/ui/index.mjs';
import {createPrPivot} from './pr-pivot.mjs';
import {createGrPivot,grSummary,grMatchesFocus,grSourceLines,grProblemReasons} from './gr-pivot.mjs';
const text=value=>value===null||value===undefined?'Null':String(value);
const identity=value=>JSON.stringify([typeof value,value]);
// ERP đính kèm nhãn "[non-minimum item]" vào đầu/trong PURCHASE_REQ_INFO. Bảng PR phải xóa nhãn này
// NGAY KHI NẠP sheet, tức trước khi bảng kiểm tra "CHECK PR" sắp xếp và gộp ô, để hai dòng chỉ khác
// nhau mỗi nhãn được tổng hợp chung một ô và không lọt vào bảng, bộ lọc hay file Excel. Cùng quy tắc
// bỏ nhãn mà Project Status (parseDescription) và Remark Order dùng. Giá trị ngoài chuỗi giữ nguyên
// để Null/số không biến thành chuỗi rỗng. Export phục vụ test Node; registry vẫn chỉ dùng mount.
export const cleanPurchaseReqInfo=value=>typeof value==='string'?value.replace(/\s*\[non-minimum item\]\s*/gi,' ').trim():value;
// Cột được gộp ô ("do not repeat item data"): chấp nhận cả bản cũ một cột (chuỗi) và bản mới nhiều cột
// (mảng), luôn trả về theo thứ tự hiển thị để phần gộp lồng đúng — cột trái là nhóm ngoài,
// cột phải chỉ gộp khi trùng cả nhóm của các cột gộp bên trái.
const mergeOrder=(value,columns)=>{const wanted=new Set(Array.isArray(value)?value:(typeof value==='string'&&value?[value]:[]));return columns.filter(c=>c.visible!==false&&wanted.has(c.key)).map(c=>c.key);};
// Sắp xếp theo bộ cột gộp (trái → phải) để các dòng trùng nhau nằm kề nhau, dùng chung cho bảng và Excel.
const mergeSort=(rows,merge)=>{if(!merge.length)return rows;return rows.sort((a,b)=>{for(const key of merge){const x=identity(a[key]),y=identity(b[key]);if(x!==y)return text(a[key]).localeCompare(text(b[key]),'vi',{numeric:true})||(x<y?-1:x>y?1:0);}return 0;});};
// Vùng gộp cho Excel, cùng quy tắc lồng nhau với bảng: cột gộp thứ m chỉ gộp khi trùng cả m cột gộp đầu.
// row là chỉ số 0-based của lưới đã gồm dòng tiêu đề (dữ liệu dòng đầu = 1) theo hợp đồng của exportWorkbook.
const mergeRanges=(rows,merge,columnKeys)=>{if(!merge.length||!rows.length)return [];const ranges=[];merge.forEach((key,index)=>{const col=columnKeys.indexOf(key);if(col<0)return;const prefix=merge.slice(0,index+1);for(let i=0;i<rows.length;){const same=j=>prefix.every(name=>identity(rows[i][name])===identity(rows[j][name]));let end=i+1;while(end<rows.length&&same(end))end++;if(end-i>1)ranges.push({col,row:i+1,rows:end-i});i=end;}});return ranges;};
// Ưu tiên ngày mới nhất (yêu cầu 03/11/2026 cho REQUEST_DATE của bảng RFQ): SQL trả chuỗi
// "YYYY-MM-DD…" hoặc giá trị Date đọc được. Giá trị rỗng/không đọc được coi là CŨ NHẤT và xếp
// cuối — không đoán ngày, không loại dòng; chỉ đổi thứ tự hiển thị/xuất, không đổi SQL/dữ liệu.
const dateValue=value=>{if(value===null||value===undefined)return null;const raw=String(value).trim();if(!raw||/^null$/i.test(raw))return null;
 const iso=raw.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);if(iso)return Date.UTC(+iso[1],+iso[2]-1,+iso[3],+(iso[4]||0),+(iso[5]||0),+(iso[6]||0));
 const parsed=Date.parse(raw);return Number.isNaN(parsed)?null:parsed;};
const newerFirst=(x,y)=>x===y?0:x===null?1:y===null?-1:y-x;
// Sắp xếp dùng chung cho bảng và Excel khi bảng có "cột ngày ưu tiên":
//  - không gộp cột: dòng có ngày gần nhất lên đầu, ngày không đọc được xuống cuối;
//  - có gộp cột: ngày chỉ quyết định THỨ TỰ NHÓM ở từng cấp gộp (nhóm có ngày gần nhất đứng trước,
//    trong cùng nhóm cũng mới → cũ). Dòng trùng nhóm vẫn kề nhau nên rowspan, quy tắc gộp lồng và
//    vùng <mergeCell> không đổi; hai nhóm cùng ngày giữ đúng thứ tự giá trị như mergeSort.
const prioritySort=(rows,merge,key)=>{if(!key)return merge.length?mergeSort(rows,merge):rows;
 if(!merge.length)return rows.sort((a,b)=>newerFirst(dateValue(a[key]),dateValue(b[key])));
 const info=new WeakMap(),of=row=>{let value=info.get(row);if(!value){let group='';const keys=[];for(const name of merge){group+='\u0000'+identity(row[name]);keys.push(group);}value={date:dateValue(row[key]),keys};info.set(row,value);}return value;};
 const best=merge.map((_,level)=>{const map=new Map();for(const row of rows){const value=of(row),group=value.keys[level];if(!map.has(group)||(value.date!==null&&(map.get(group)===null||value.date>map.get(group))))map.set(group,value.date);}return map;});
 return rows.sort((a,b)=>{const x=of(a),y=of(b);for(let level=0;level<merge.length;level++){const by=newerFirst(best[level].get(x.keys[level]),best[level].get(y.keys[level]));if(by)return by;
  if(x.keys[level]!==y.keys[level]){const compare=text(a[merge[level]]).localeCompare(text(b[merge[level]]),'vi',{numeric:true});return compare||(x.keys[level]<y.keys[level]?-1:1);}}
  return newerFirst(x.date,y.date);});};
const reportKind=value=>value==='REPORT'||value==='GR_REPORT';


 // 16/11/2026 (người dùng chốt): khi SQL tải xong, host dựng lại màn (SCREEN_REFRESHED) nhưng Portal KHÔNG được nhảy
 // trang/tab (ví dụ đang ở trang 2/7 không được về 1/7). Trạng thái xem được giữ ở cấp module, sống qua các lần mount.
const remembered={state:null};
export function mount(root,data,{identity:session,load}){
 // 16/11/2026 (người dùng chốt): vào tab PR & Tracking thì mở PR Report Form trước.
 let kind='REPORT',user='',username='',busy=false,requestSequence=0,page=1,pageSize=20,query='',error='',applied=null,timer,lastRead=Date.now();const records=new Map(),loadedAt=new Map(),settings=new Map(),choices=new WeakMap(),checksCache=new Map(),removedChecks=new Map(),presetVersions=new Map(),selected=new Set();
 const memory=remembered.state;let restorePage=0,restoreScroll=0;
 if(memory){kind=memory.kind;pageSize=memory.pageSize;applied=memory.applied;for(const name of memory.selected)selected.add(name);restorePage=memory.page;restoreScroll=memory.scrollTop||0;}
 const today=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric'}).formatToParts(new Date()).map(part=>[part.type,part.value])),currentYear=Number(today.year),reportYears={REPORT:currentYear,GR_REPORT:currentYear};let reportYear=currentYear;
 if(memory){Object.assign(reportYears,memory.reportYears);reportYear=memory.reportYear;}
 const icon={settings:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="10" cy="18" r="2"/>',reload:'<path d="M20 7v5h-5M4 17v-5h5M6 7a7 7 0 0 1 12-2l2 3M4 16l2 3a7 7 0 0 0 12-2"/>',download:'<path d="M12 3v12m-4-4 4 4 4-4M4 16v5h16v-5"/>'};
 const svg=key=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true">${icon[key]}</svg>`;
 const storageKey=()=>`mro-data-tracking-${reportKind(kind)?'v2':'v1'}:${user}:${kind}`;
 const dataCacheKey=(targetKind=kind,targetYear=reportYear)=>`mro-data-tracking-data-v1:${user}:${targetKind}${reportKind(targetKind)?':'+targetYear:''}`;
 function readCachedData(){if(!user||records.has(kind))return false;try{const saved=JSON.parse(localStorage.getItem(dataCacheKey()));if(!saved?.sheet?.columns||!Array.isArray(saved.sheet.rows))return false;records.set(kind,saved);loadedAt.set(kind,Number(saved.cachedAt)||0);settings.delete(kind);return true;}catch{return false;}}
 function saveCachedData(value,targetKind,targetYear){if(!user||!value?.sheet?.columns||!Array.isArray(value.sheet.rows))return;try{const key=dataCacheKey(targetKind,targetYear),payload={...value,cachedAt:Date.now(),source:'browser-cache'},raw=JSON.stringify(payload);if(raw.length>4500000){localStorage.removeItem(key);return;}localStorage.setItem(key,raw);}catch{/* localStorage có thể đầy. */}}
 // 16/11/2026 (người dùng chốt): bộ lọc Cost Center bên ngoài bảng chọn/loại phạm vi dữ liệu của PR/GR Report Form.
 // COST_CENTER vẫn là một thẻ trong "Trường nhóm" (bản 16/11 chiều): mặc định KHÔNG tích (không hiện thành cột),
 // người dùng tích thì bảng tách dòng theo Cost Center. Xem costCenterGroupDefault trong prefs().
 const costCenterOf=row=>String(row?.COST_CENTER??'').trim();
 let costCenterOpen=false,reportControlsOpen=false,reportAuditOpen=false,grIssueFilter='all';
 function costCenterAllowed(){if(!reportKind(kind))return ()=>true;const excluded=new Set(prefs().excludedCostCenters||[]);return excluded.size?row=>!excluded.has(costCenterOf(row)):()=>true;}
 function prefs(){const columns=(records.get(kind)?.sheet.columns||[]).filter(c=>kind!=='REPORT'||c.name!=='Thiếu Type');if(settings.has(kind))return settings.get(kind);let saved;try{saved=JSON.parse(localStorage.getItem(storageKey()));}catch{}const names=new Set(columns.map(c=>c.name)),seen=new Set(),list=[];
  for(const c of Array.isArray(saved?.columns)?saved.columns:[]){if(!names.has(c.key)||seen.has(c.key))continue;seen.add(c.key);list.push({key:c.key,label:typeof c.label==='string'&&c.label.trim()?c.label.trim().slice(0,80):c.key,visible:c.visible!==false});}
  for(const c of columns)if(!seen.has(c.name)){const entry={key:c.name,label:c.name,visible:true},after=c.name==='COST_CENTER'?list.findIndex(x=>x.key==='PR_NO'):-1;if(after>=0)list.splice(after+1,0,entry);else list.push(entry);}
  // Một lần cho mỗi người dùng/bảng: thẻ COST_CENTER bắt đầu ở trạng thái bỏ tích; sau đó tôn trọng lựa chọn đã lưu.
  if(reportKind(kind)&&saved?.costCenterGroupDefault!==true){const cc=list.find(c=>c.key==='COST_CENTER');if(cc)cc.visible=false;}
  const filters=Object.fromEntries(list.filter(c=>typeof saved?.filters?.[c.key]==='string').map(c=>[c.key,saved.filters[c.key].slice(0,500)]));const usedLabels=new Set();for(const c of list){let label=c.label,suffix=1;while(usedLabels.has(label))label=c.key+' ('+(suffix++)+')';c.label=label;usedLabels.add(label);}
  const value={columns:list,filters,search:typeof saved?.search==='string'?saved.search.slice(0,500):'',merge:mergeOrder(saved?.merge,list),showEmptyMonth:saved?.showEmptyMonth===true,noRepeatLabels:saved?.noRepeatLabels===true,hideSlicers:saved?.hideSlicers===true,costCenterGroupDefault:true,excludedCostCenters:Array.isArray(saved?.excludedCostCenters)?[...new Set(saved.excludedCostCenters.filter(x=>typeof x==='string').map(x=>x.slice(0,120)))]:[]};settings.set(kind,value);return value;
 }
 function persist(){try{localStorage.setItem(storageKey(),JSON.stringify(prefs()));}catch{toast('Không lưu được cài đặt trên trình duyệt.');}}
 const checksKey=()=>`mro-data-tracking-checks-v1:${user}:${kind}`;
 function checks(){const cacheKey=user+'\n'+kind;if(!checksCache.has(cacheKey)){let saved;try{saved=JSON.parse(localStorage.getItem(checksKey()));}catch{}const box={};
  removedChecks.set(cacheKey,new Set(Array.isArray(saved?.__removed)?saved.__removed.filter(x=>typeof x==='string'):[]));
  presetVersions.set(cacheKey,Number.isFinite(saved?.__preset)?Number(saved.__preset):1);
  if(saved&&typeof saved==='object')for(const[name,c]of Object.entries(saved)){if(!c||typeof c!=='object'||typeof c.name!=='string'||!c.name.trim())continue;const key=c.name.trim().slice(0,120);box[key]={name:key,columns:Array.isArray(c.columns)?c.columns.filter(x=>x&&typeof x.key==='string').map(x=>({key:x.key,label:typeof x.label==='string'&&x.label.trim()?x.label.trim().slice(0,80):x.key,visible:x.visible!==false})):[],filters:c.filters&&typeof c.filters==='object'?Object.fromEntries(Object.entries(c.filters).filter(([,v])=>typeof v==='string').map(([k,v])=>[k,String(v).slice(0,500)])):{},search:typeof c.search==='string'?c.search.slice(0,500):'',merge:Array.isArray(c.merge)?c.merge.filter(x=>typeof x==='string'):typeof c.merge==='string'&&c.merge?[c.merge]:[]};}
  checksCache.set(cacheKey,box);}return checksCache.get(cacheKey);}
 // Preset dựng sẵn theo từng bảng (key = đúng tên tab). Tự tạo lần đầu cho mỗi tài khoản;
 // đã xóa thì ghi dấu xóa (__removed) để không quay lại. Cột khớp theo tên chuẩn hóa
 // (bỏ khoảng trắng/dấu chấm câu, không phân biệt hoa thường) nên vẫn đúng khi tên cột SQL
 // khác nhẹ; cột SQL không có trong bảng thật bị bỏ qua. "__preset" trong cùng key
 // localStorage là phiên bản preset RIÊNG của từng bảng: đổi danh sách cột thì tăng số để
 // cập nhật lại preset cho người dùng cũ (kể cả khi họ đã lưu preset từ phiên bản trước).
 // Cột "PR Amount ( USD )" do portal tự tính: PR_BUYING_AMOUNT chia tỷ giá cố định theo BUYING_CURRENCY.
 // VND dùng USD_RATE 26.000 theo quy tắc dự án; JPY 180 do anh HIEN chốt ngày 02/11/2026 (không đọc từ SQL).
 // USD giữ nguyên; tiền tệ khác/thiếu hoặc số không parse được thì để trống, không đoán và không ép 0.
 const fxColumn='PR Amount ( USD )';
 const fxRates={USD:1,VND:26000,JPY:180};
 const fxNote='PR Amount ( USD ) = PR_BUYING_AMOUNT ÷ tỷ giá cố định (VND 26.000 · JPY 180 · USD giữ nguyên; tiền tệ khác hoặc số không đọc được thì để trống)';
 // Mỗi bảng một preset riêng (key = đúng tên tab): "name" là tên bảng kiểm tra hiển thị,
 // "version" là phiên bản preset lưu trong "__preset" của key localStorage theo bảng đó,
 // "columns" là thứ tự cột chốt, "merge" là các cột mặc định gộp ô trùng (theo thứ tự hiển thị),
 // "legacyNames" là các tên cũ của chính preset này: khi version tăng, bản mang tên cũ bị xóa
 // khỏi danh sách của người dùng cũ để không còn hai dòng trùng nhau sau khi đổi tên.
 // Bảng PR: "CHECK PR" 9 cột chốt 02/11/2026, gồm BUYING_CURRENCY từ SQL và cột USD tự tính;
 // ba cột định danh phiếu lặp lại trên nhiều dòng hàng => mặc định gộp ("do not repeat item data").
 const checkPresets={
  REPORT:{name:'PR report',version:2,columns:['PR_NO','COST_CENTER','Class','Type','Project','Model','Process',...Array.from({length:12},(_,i)=>String(i+1)),'Amount','PURCHASE_REQ_INFO'],merge:[]},
  GR_REPORT:{name:'GR report',version:2,columns:['PR_NO','COST_CENTER','Class','Type','Thiếu Type','Project','Model','Process','Reason Source','Match Status',...Array.from({length:12},(_,i)=>String(i+1)),'Amount','PURCHASE_REQ_INFO'],merge:[]},
  PR:{name:'CHECK PR',version:3,
   columns:['RECEIVER_NAME','PR_NO','PURCHASE_REQ_INFO','ITEM_CODE','DESCRIPTION','PR_QTY','PR_BUYING_AMOUNT','BUYING_CURRENCY',fxColumn],
   merge:['RECEIVER_NAME','PR_NO','PURCHASE_REQ_INFO']},
  // Bảng RFQ: "Tracking RFQ" 15 cột anh cung cấp 02-03/11/2026 — tên cũ "Tracking PR" đổi thành
  // "Tracking RFQ" và REQ_COMMENTS (ghi chú yêu cầu mua) được thêm vào đầu danh sách.
  // Bốn cột RFQ_COMMENTS/REQUESTER_NAME/SUPPLIER_NAME/CONTRACT_NAME là thông tin cấp RFQ lặp lại
  // trên mọi dòng hàng của cùng RFQ nên mặc định gộp ô; REQ_COMMENTS là ghi chú theo từng yêu cầu
  // nên giữ riêng theo dòng (muốn gộp thì tích thêm trong Column Setting). Cột mặt hàng/trạng thái/
  // số PR/TORD/ngày vẫn giữ riêng theo từng dòng.
  RFQ:{name:'Tracking RFQ',version:2,legacyNames:['Tracking PR'],
   columns:['REQ_COMMENTS','RFQ_COMMENTS','REQUESTER_NAME','SUPPLIER_NAME','CONTRACT_NAME','ITEM_CODE','ITEM_NAME','SPEC','RFQ_STATUS_NAME','QT_REQ_NO','QT_REQ_SEQ','REQ_EPR','REQUEST_DATE','RECEIPT_DATE','SUBMISSION_DATE'],
   merge:['RFQ_COMMENTS','REQUESTER_NAME','SUPPLIER_NAME','CONTRACT_NAME']}
 };
 const canDeleteCheck=()=>kind!=='REPORT'||username.trim().toLowerCase()==='hien.thanh';
 const presetFor=key=>checkPresets[key]||null;
 const presetVersion=()=>presetFor(kind)?.version||1;
 const normName=value=>String(value??'').toUpperCase().replace(/[^0-9A-Z]/g,'');
 // Bảng RFQ luôn ưu tiên REQUEST_DATE gần nhất lên đầu (chỉ thứ tự hiển thị/xuất, không đổi SQL).
 // Tìm cột theo tên chuẩn hóa nên vẫn đúng khi SQL đổi hoa thường/dấu cách; bảng chưa đặt ưu tiên
 // (PR/GMRO) giữ nguyên thứ tự dữ liệu. Thêm bảng khác thì bổ sung đúng map này.
 const priorityDate=()=>{const wanted={RFQ:'REQUEST_DATE'}[kind];if(!wanted)return '';return (records.get(kind)?.sheet.columns||[]).find(c=>normName(c.name)===normName(wanted))?.name||'';};
 // Thu gọn cột định danh/số/tiền tệ (ngắn, lặp lại) và mở rộng cột mô tả yêu cầu mua theo yêu cầu 02/11/2026.
 // Khớp theo tên chuẩn hóa nên vẫn đúng khi SQL đổi hoa thường/dấu cách; tự đổi cột chỉ cần sửa hai tập này.
 const tightColumns=new Set(['RECEIVER_NAME','PR_NO','ITEM_CODE','PR_QTY','BUYING_CURRENCY',fxColumn].map(normName));
 const wideColumns=new Set(['PURCHASE_REQ_INFO'].map(normName));
 const widthClass=key=>{const name=normName(key);return tightColumns.has(name)?'dt-col-tight':wideColumns.has(name)?'dt-col-wide':'';};
 function fxAmount(value){if(typeof value==='number')return Number.isFinite(value)?value:null;if(typeof value!=='string')return null;
  let raw=value.trim();if(!raw||/^null$/i.test(raw))return null;let negative=false;if(/^\(.*\)$/.test(raw)){negative=true;raw=raw.slice(1,-1).trim();}
  raw=raw.replace(/[\u00a0\u202f]/g,' ').trim();if(/^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$/.test(raw))raw=raw.replace(/,/g,'');
  if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(raw))return null;const n=Number(raw)*(negative?-1:1);return Number.isFinite(n)?n:null;}
 // View riêng của sheet PR (view-only, không ghi SQL): xóa nhãn "[non-minimum item]" trong
 // PURCHASE_REQ_INFO và nối cột "PR Amount ( USD )" — thay cột trùng tên nếu SQL đã có, giữ mọi cột
 // gốc và đủ dòng; thiếu số hoặc tiền tệ thì ô USD để trống. Xóa nhãn ở đây nên bảng thường, bảng
 // kiểm tra, gộp ô, bộ lọc và hai đường xuất Excel đều nhận cùng một giá trị đã sạch.
 function withPRViewSheet(result){const sheet=result?.sheet;if(!sheet||!Array.isArray(sheet.columns)||!Array.isArray(sheet.rows))return result;
  const column=name=>sheet.columns.find(c=>normName(c.name)===normName(name));
  const info=column('PURCHASE_REQ_INFO'),amount=column('PR_BUYING_AMOUNT'),currency=column('BUYING_CURRENCY');if(!info&&!amount&&!currency)return result;
  const fx=Boolean(amount&&currency),name=column(fxColumn)?.name||fxColumn;
  const columns=fx?[...sheet.columns.filter(c=>normName(c.name)!==normName(fxColumn)),{name,type:'decimal'}]:sheet.columns;
  const rows=sheet.rows.map(row=>{let next=row;
   if(info)next={...next,[info.name]:cleanPurchaseReqInfo(next[info.name])};
   if(fx){const rate=fxRates[String(next[currency.name]??'').trim().toUpperCase()]||null;const value=fxAmount(next[amount.name]);next={...next,[name]:rate&&value!==null?Math.round(value/rate*100)/100:''};}
   return next;});
  return {...result,sheet:{...sheet,columns,rows}};}
 // Dựng preset cho bảng đang xem từ checkPresets[kind]: lấy đúng cột thật có trong sheet
 // (khớp tên chuẩn hóa), bỏ cột không tồn tại; chỉ tạo khi tìm được tối thiểu 3 cột.
 function defaultCheck(){if(reportKind(kind)){const p=prefs();return {name:kind==='GR_REPORT'?'GR report':'PR report',columns:p.columns.map(c=>({...c})),filters:{...p.filters},search:p.search,merge:[...p.merge]};}const preset=presetFor(kind),columns=records.get(kind)?.sheet.columns||[],byName=new Map(columns.map(c=>[normName(c.name),c.name])),keys=[];if(!preset)return null;
  for(const wanted of preset.columns){const found=byName.get(normName(wanted));if(found&&!keys.includes(found))keys.push(found);}
  if(keys.length<3)return null;const merge=new Set(preset.merge.map(normName));
  return {name:preset.name,columns:keys.map(key=>({key,label:key,visible:true})),filters:{},search:'',merge:keys.filter(key=>merge.has(normName(key)))};}
 function ensureDefaultCheck(){const preset=presetFor(kind);if(!preset||!records.has(kind))return;const cacheKey=user+'\n'+kind,box=checks(),gone=removedChecks.get(cacheKey)||new Set(),stored=presetVersions.get(cacheKey)||1,has=!!box[preset.name];
  // Wait for the new SQL schema before migrating an older cached report check.
  if(reportKind(kind)&&!records.get(kind)?.sheet.columns.some(c=>c.name==='COST_CENTER'))return;
  // Preset có thể đổi tên (legacyNames). Chỉ khi người dùng đang giữ phiên bản preset cũ mới xóa
  // bản mang tên cũ để không còn hai dòng trùng nhau, rồi dựng lại theo danh sách cột mới;
  // bảng kiểm tra người dùng tự tạo mang tên khác không bị đụng tới.
  let renamed=false;if(stored<preset.version)for(const name of preset.legacyNames||[])if(name!==preset.name&&Object.prototype.hasOwnProperty.call(box,name)&&delete box[name])renamed=true;
  if(gone.has(preset.name)){if(renamed){presetVersions.set(cacheKey,preset.version);saveChecks();}return;}
  // Add the new report dimension to the built-in check without replacing its
  // saved filters, renamed labels, hidden columns or merge order. Custom checks stay intact.
  if(has&&stored<preset.version&&reportKind(kind)&&records.get(kind)?.sheet.columns.some(c=>c.name==='COST_CENTER')){
   const existing=box[preset.name];if(!existing.columns.some(c=>c.key==='COST_CENTER')){const at=existing.columns.findIndex(c=>c.key==='PR_NO');existing.columns.splice(at<0?0:at+1,0,{key:'COST_CENTER',label:'COST_CENTER',visible:true});}
   presetVersions.set(cacheKey,preset.version);saveChecks();return;
  }
  if(has&&stored>=preset.version)return;
  const value=defaultCheck();if(!value){if(renamed){presetVersions.set(cacheKey,preset.version);saveChecks();}return;}
  box[preset.name]=value;presetVersions.set(cacheKey,preset.version);saveChecks();}
 function saveChecks(){const cacheKey=user+'\n'+kind,gone=[...(removedChecks.get(cacheKey)||[])];try{localStorage.setItem(checksKey(),JSON.stringify({...checks(),__preset:presetVersion(),...(gone.length?{__removed:gone}:{})}));}catch{toast('Không lưu được bảng kiểm tra trên trình duyệt.');}}

 function resolveCheck(c){const value=records.get(kind),names=new Set((value?.sheet.columns||[]).filter(m=>kind!=='REPORT'||m.name!=='Thiếu Type').map(m=>m.name)),columns=(Array.isArray(c?.columns)?c.columns:[]).filter(x=>names.has(x.key)&&x.visible!==false).map(x=>({key:x.key,label:typeof x.label==='string'&&x.label.trim()?x.label.trim().slice(0,80):x.key,visible:true}));
  if(!columns.length)return null;const filters={};for(const col of columns)if(typeof c.filters?.[col.key]==='string')filters[col.key]=c.filters[col.key];
  return {columns,filters,search:c.search||'',merge:mergeOrder(c.merge,columns)};}
 function view(){const p=applied||prefs();if(!Array.isArray(p.merge))p.merge=mergeOrder(p.merge,p.columns);return p;}
 function applyCheck(name){const v=resolveCheck(checks()[name]);if(!v){toast('Bảng kiểm tra "'+name+'" không còn cột hợp lệ trong dữ liệu hiện tại.');selected.delete(name);if(applied?.name===name){applied=null;query=prefs().search;}return;}applied={name,...v};query=applied.search;page=1;restorePage=0;}
 function unapply(){applied=null;query=prefs().search;page=1;restorePage=0;}
 function exportChecks(){const value=records.get(kind);if(!value)return;const list=[...selected].filter(n=>checks()[n]);if(!list.length){toast('Chưa tích chọn bảng kiểm tra nào.');return;}
  const used=new Set(),sheets=[];
  for(const name of list){const v=resolveCheck(checks()[name]);if(!v){toast('Bảng kiểm tra "'+name+'" không còn cột hợp lệ trong dữ liệu hiện tại.');continue;}
   const q=v.search.toLocaleLowerCase(),allowCostCenter=costCenterAllowed(),rows=value.sheet.rows.filter(row=>allowCostCenter(row)&&(!q||Object.values(row).some(x=>text(x).toLocaleLowerCase().includes(q)))&&v.columns.every(c=>{const f=v.filters[c.key];return !f||text(row[c.key]).toLocaleLowerCase().includes(f.toLocaleLowerCase());}));
   let sheetName=name.replace(/[\\/?*:[\]]/g,'_').slice(0,31)||kind;const base=sheetName;let n=1;while(used.has(sheetName))sheetName=base.slice(0,28)+'-'+(++n);used.add(sheetName);
   const ordered=reportAggregate(prioritySort(rows,v.merge,priorityDate()),v.columns,v.columns.filter(c=>c.visible),v.showEmptyMonth===true);sheets.push({name:sheetName,columns:v.columns.map(c=>({key:c.key,label:esc(c.label)})),rows:ordered.map(row=>Object.fromEntries(v.columns.map(c=>[c.key,row[c.key]]))),merges:mergeRanges(ordered,v.merge,v.columns.map(c=>c.key))});}
  if(!sheets.length)return;try{exportWorkbook(sheets,'Data-Tracking-'+kind+'-BangKiemTra');}catch(e){toast(e.message);}}
 function saveCheckDialog(){if(!records.get(kind))return;const p=view();
  showDetail('Lưu bảng kiểm tra · '+kind,`<form data-dt-check-form><label>Tên bảng kiểm tra<input name="name" required maxlength="120" placeholder="Ví dụ: PR chờ đối chiếu"></label><p class="small muted">Lưu ${p.columns.filter(c=>c.visible).length} cột đang hiện, ${Object.values(p.filters).filter(Boolean).length} bộ lọc cột${query?', tìm chung':''} hiện tại${p.merge.length?', gộp ô '+p.merge.length+' cột ('+esc(p.merge.join(', '))+')':''}. Bảng kiểm tra chỉ lưu trên trình duyệt này theo tài khoản.</p><p class="small amber" role="alert"></p><div class="dt-config-controls"><button class="button primary" type="submit">Lưu bảng kiểm tra</button><button class="button" type="button" data-dt-check-cancel>Hủy</button></div></form>`);
  const form=document.querySelector('[data-dt-check-form]');form.querySelector('[data-dt-check-cancel]').onclick=()=>document.getElementById('detail').close();
  form.onsubmit=e=>{e.preventDefault();const name=form.elements.name.value.trim();if(!name)return;const box=checks();
   if(kind==='REPORT'&&name==='PR report'&&box[name]&&!canDeleteCheck()){form.querySelector('[role=alert]').textContent='Chỉ Hien.thanh được thay thế bảng PR report. Hãy lưu bằng tên khác.';return;}
   if(box[name]&&!confirm('Đã có bảng kiểm tra "'+name+'". Ghi đè?'))return;
   box[name]={name,columns:p.columns.map(c=>({key:c.key,label:c.label,visible:c.visible})),filters:{...p.filters},search:query,merge:[...(p.merge||[])]};
   saveChecks();selected.clear();selected.add(name);applyCheck(name);document.getElementById('detail').close();toast('Đã lưu và áp dụng bảng kiểm tra "'+name+'".');draw();};}
 function checksBox(){ensureDefaultCheck();const list=Object.values(checks());
  return `<div class="dt-checks"><div class="dt-checks-head"><b>Danh sách các bảng kiểm tra</b><span class="dt-check-meta">${list.length} bảng đã lưu${applied?' · Đang áp dụng: '+esc(applied.name):''}</span>${document.documentElement.dataset.downloads==='denied'?'':`<button type="button" class="button" data-dt-check-export ${busy||!selected.size?'disabled':''}>Xuất Excel đã tích</button>`}<button type="button" class="button" data-dt-check-save ${busy?'disabled':''}>Lưu view hiện tại</button></div><div class="dt-checks-list">${list.length?list.map(c=>`<div class="dt-check-row ${applied?.name===c.name?'is-applied':''}"><label class="dt-check-pick"><input type="checkbox" data-dt-check-toggle="${esc(c.name)}" ${selected.has(c.name)?'checked':''}><span class="dt-check-name">${esc(c.name)}</span></label><span class="dt-check-meta">${c.columns.filter(x=>x.visible!==false).length} cột · ${Object.values(c.filters).filter(Boolean).length} lọc${c.search?' · tìm chung':''}</span><span class="dt-check-actions"><button type="button" class="button" data-dt-check-apply="${esc(c.name)}">${applied?.name===c.name?'Bỏ áp dụng':'Áp dụng'}</button>${canDeleteCheck()?`<button type="button" class="button" data-dt-check-delete="${esc(c.name)}" title="Xóa bảng kiểm tra" aria-label="Xóa ${esc(c.name)}">✕</button>`:''}</span></div>`).join(''):`<p class="small muted dt-check-empty">Chưa có bảng kiểm tra. Đặt bộ lọc và cột rồi bấm "Lưu view hiện tại"; mỗi lần cần, tích chọn tên bảng để lọc lấy danh sách rồi xuất Excel.</p>`}</div></div>`;}
 // 12/11/2026 (người dùng chốt): Report Form là bảng TỔNG HỢP nên phải "gộp theo cột đang nhìn" —
// chọn cột nào thì nhóm lại theo đúng cột chữ ĐANG HIỆN và cộng các cột số (1…12, Amount). Chọn ba
 // cột Type + 11 + Amount thì mọi dòng Type="Spare Part" dồn thành MỘT dòng, ô tháng 11 là tổng tiền
 // các PR tháng 11; ẩn hết cột chữ thì còn đúng một dòng tổng. Trước đây bảng vẽ mỗi PR một dòng nên
 // vừa chọn cột "11" là gần như mọi ô trống => người dùng tưởng cột tháng không có Amount.
 // Bảng PR/RFQ/GMRO là danh sách chứng từ nên giữ nguyên từng dòng (chỉ REPORT mới gộp).
 // lastAmountTotal + lastMergedFrom tính TRƯỚC khi gộp: dòng trạng thái vẫn đúng khi ẩn cột Amount,
 // và phân trang nói rõ "đã gộp từ N dòng" để không hiểu nhầm là mất dòng.
let lastMergedFrom=0,lastAmountTotal=0,lastHiddenEmpty=0,keepEmptyRows=false;
 // 12/11/2026 (người dùng chốt tiếp): cột "Amount" phải là tổng ĐÚNG các cột tháng ĐANG HIỆN. Bật riêng
 // cột "11" thì Amount = tiền tháng 11 (nhóm SETUP = 11.365,63), bật đủ 12 cột thì vẫn = tổng cả năm
 // (1.997.410,10). Trước đây Amount luôn là tổng 12 tháng nên đứng cạnh cột "11" ra hai số lệch nhau
 // hàng trăm lần, người dùng tưởng số liệu sai. Không bật cột tháng nào thì Amount giữ tổng cả năm của
 // nguồn (không có tháng nào để mà lọc). rowAmount trả null khi mọi ô tháng đang hiện đều trống.
 const monthKeyRe=/^(?:1[0-2]|[1-9])$/;
 function visibleMonthColumns(columns){const numeric=new Map((records.get(kind)?.sheet.columns||[]).map(c=>[c.name,!!c.numeric]));return columns.filter(c=>monthKeyRe.test(c.key)&&numeric.get(c.key));}
 function rowAmount(row,monthColumns){if(!monthColumns.length)return typeof row.Amount==='number'?row.Amount:null;let total=null;for(const c of monthColumns){const raw=row[c.key];if(raw===''||raw===null||raw===undefined)continue;const n=Number(raw);if(!Number.isFinite(n))continue;total=Number(((total??0)+n).toFixed(2));}return total;}
 function reportAggregate(rows,outColumns,dimColumns=outColumns,keepEmpty=false){
 if(!['REPORT','GR_REPORT'].includes(kind)||!rows.length)return rows;
 const meta=new Map((records.get(kind)?.sheet.columns||[]).map(c=>[c.name,c]));
 const sums=outColumns.filter(c=>meta.get(c.key)?.numeric),dims=dimColumns.filter(c=>!meta.get(c.key)?.numeric),groups=new Map();
 const monthColumns=sums.filter(c=>monthKeyRe.test(c.key));
 for(const row of rows){const key=JSON.stringify(dims.map(c=>row[c.key]??''));let group=groups.get(key);
  if(!group){group={};for(const c of outColumns)group[c.key]=sums.includes(c)?'':row[c.key]??'';if(kind==='REPORT'&&Array.isArray(row.__detailIds))group.__detailIds=[];if(kind==='GR_REPORT'){group.__detailIds=[];group.__unconverted=false;}groups.set(key,group);}
  for(const c of sums){const raw=row[c.key];if(raw===''||raw===null||raw===undefined)continue;const n=Number(raw);if(!Number.isFinite(n))continue;group[c.key]=Number(((typeof group[c.key]==='number'?group[c.key]:0)+n).toFixed(2));}
  if(kind==='REPORT'&&Array.isArray(row.__detailIds)){if(!Array.isArray(group.__detailIds))group.__detailIds=[];for(const id of row.__detailIds)if(!group.__detailIds.includes(id))group.__detailIds.push(id);}
  if(kind==='GR_REPORT'){if(row.__unconverted)group.__unconverted=true;if(Array.isArray(row.__detailIds))for(const id of row.__detailIds)if(!group.__detailIds.includes(id))group.__detailIds.push(id);}}
 // Amount của dòng đã gộp = tổng các cột tháng ĐANG HIỆN (bật cột 11 → ra tiền tháng 11); không bật
 // cột tháng nào thì giữ tổng cả năm vừa cộng ở trên.
 const merged=[...groups.values()];
 if(monthColumns.length&&outColumns.some(c=>c.key==='Amount'))for(const group of merged)group.Amount=rowAmount(group,monthColumns)??'';
 // 12/11/2026 (người dùng chốt): đang xem cột tháng nào thì CHỈ lấy số của cột tháng đó. Dòng nào
 // không có đồng nào trong các cột tháng đang hiện bị loại khỏi bảng (PR 1012962453 chỉ có 6,66 USD
 // tháng 2 không được hiện khi đang xem cột 11). Nút "Hiện dòng chưa có tiền ở cột tháng" bật lại.
 if(monthColumns.length&&!keepEmpty)return merged.filter(group=>rowAmount(group,monthColumns)!==null||(kind==='GR_REPORT'&&group.__unconverted));
 return merged;
 }
// ===== Trình bày phân cấp kiểu Pivot Table cho Report Form (12/11/2026, người dùng chốt) =====
 // Cột chữ đang hiện là các mức nhóm theo thứ tự hiển thị. Tabular Form giữ mỗi
 // trường trong một cột riêng và lặp nhãn trên các dòng chi tiết, không thụt lề.
 // Các dòng tổng nhóm vẫn cho phép thu/mở; cột số giữ đúng vị trí đã chọn.
 const pivotCollapsed=new Set();                              // phần tử: kind + "\0" + chuỗi giá trị các mức
 const columnMeta=()=>new Map((records.get(kind)?.sheet.columns||[]).map(c=>[c.name,!!c.numeric]));
 // Badge trạng thái: cùng một chữ nhưng màu khác nhau, nhìn lướt là ra nhóm ngay không cần đọc kỹ.
 const badgeClass=(key,value)=>key==='Type'?({'SETUP':'dt-b-setup','SOP':'dt-b-sop','Spare Part':'dt-b-spare'})[value]||'':key==='Match Status'?({'Matched':'dt-b-setup','Ambiguous Match':'dt-b-warn','Unmatched PR':'dt-b-bad'})[value]||'':key==='Reason Source'?({'Override':'dt-b-spare','ERP':'dt-b-sop','Missing':'dt-b-bad','Ambiguous':'dt-b-warn'})[value]||'':key==='Thiếu Type'&&value?'dt-b-warn':'';
 const cellSpan=(c,value)=>{const badge=badgeClass(c.key,value);return badge?`<span class="dt-badge ${badge}">${esc(value)}</span>`:`<span>${esc(value)}</span>`;};
 // dt-num/dt-txt quyết định căn chỉnh, dt-col-* vẫn quyết định bề rộng như quy tắc cũ.
 const dataCell=(c,value,meta,extra,attrs='')=>{const formatted=reportKind(kind)&&meta.get(c.key)&&value!==''&&value!==null&&value!==undefined&&Number.isFinite(Number(value))?Number(value).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):value;return `<td${attrs} class="${[widthClass(c.key),meta.get(c.key)?'dt-num':'dt-txt',...(extra||[])].filter(Boolean).join(' ')}" title="${esc(value)}">${cellSpan(c,formatted)}</td>`;};
 // PR và GR có hai namespace cho trạng thái thu gọn; GR không sửa công thức Amount.
 function buildPivot(rows,columns,meta){
  if(kind==='REPORT')return createPrPivot(rows,columns,meta,pivotCollapsed);
  if(kind==='GR_REPORT')return createGrPivot(rows,columns,meta,pivotCollapsed);
  return {on:false,rows,texts:[],nums:[],groups:0,groupLevels:new Set(),grand:null};
 }
 // Không lặp nhãn chỉ trên dòng dữ liệu; khi qua subtotal/header phải reset.
 const pivotDisplayRows=(current,pivot,columns,noRepeat=false)=>{
  let previous=[];
  return current.map(entry=>{
   if(entry.type!=='row'){
    previous=[];
    return Object.fromEntries(columns.map(c=>[c.key,
     c.key===entry.groupKey?(entry.type==='group'?(entry.collapsed?'▸ ':'▾ ')+entry.label:entry.label):
     (!pivot.nums.some(n=>n.key===c.key)||entry.type==='group'&&!entry.collapsed)?'':entry.row[c.key]]));
   }
   const path=pivot.texts.map(c=>text(entry.row[c.key]));
   const blank=new Set(noRepeat?pivot.texts.filter((c,i)=>path.slice(0,i+1).every((v,j)=>v===previous[j])).map(c=>c.key):[]);
   previous=path;
   return Object.fromEntries(columns.map(c=>[c.key,blank.has(c.key)?'':entry.row[c.key]]));
  });
 };
 const detailAttr=row=>kind==='GR_REPORT'&&Array.isArray(row?.__detailIds)&&row.__detailIds.length?` data-dt-detail="${encodeURIComponent(row.__detailIds.join(','))}" tabindex="0" role="button" title="Bấm để xem các dòng GR nguồn"`:'';
 const pivotBody=(current,pivot,columns,meta,noRepeat=false,cellAttrs=()=>'' )=>{
  const display=pivotDisplayRows(current,pivot,columns,noRepeat);
  return display.map((row,i)=>{
   const entry=current[i];
   if(entry.type==='group')return `<tr class="dt-pv dt-pv-${Math.min(entry.level+1,2)}">${columns.map(c=>{
    if(c.key===entry.groupKey)return `<td class="dt-pv-label"><button type="button" class="dt-pivot-control" data-dt-pivot="${encodeURIComponent(entry.id)}" aria-expanded="${!entry.collapsed}" title="Thu/mở nhóm ${esc(entry.label)}">${entry.collapsed?'▸':'▾'} ${esc(entry.label)}</button><span class="dt-pv-count">${entry.count} dòng</span></td>`;
    return dataCell(c,text(row[c.key]),meta,[],entry.collapsed?cellAttrs(entry.row,c):'');
   }).join('')}</tr>`;
   const cls=entry.type==='subtotal'?'dt-pv-subtotal':entry.type==='grand'?'dt-pv-grand':`dt-leaf${entry.odd?' dt-odd':''}`;
   return `<tr class="${cls}"${entry.type==='row'?detailAttr(entry.row):''}>${columns.map(c=>dataCell(c,text(row[c.key]),meta,[],cellAttrs(entry.row,c))).join('')}</tr>`;
  }).join('');
 };
 // Định dạng Excel riêng à Report Form; les autres exports gardent leur format existant.
 // 16/11/2026 (người dùng chốt): sheet thứ hai của Excel PR/GR Report = các dòng PR không có Type (Reason trống /
 // không đúng mẫu) để PIC cập nhật Reason. Theo phạm vi bộ lọc Cost Center bên ngoài, không theo slicer của bảng.
 function reasonIssueSheet(value,first){if(!Array.isArray(value?.reasonIssues))return null;const excluded=new Set(prefs().excludedCostCenters||[]),keep=row=>!excluded.size||(Array.isArray(row.COST_CENTERS)&&row.COST_CENTERS.length?row.COST_CENTERS:['']).some(cc=>!excluded.has(String(cc??'').trim()));
  const columns=[['ITEM_CODE','Item code'],['PR_NO','PR_No'],['PR_SEQ','PR_SEQ'],['PURCHASE_REQ_INFO','Purchase_Req_Infor'],['RECEIVER','Receiver'],['Issue','Lỗi']].map(([key,label])=>({key,label}));
  const index=first?.presentation?.styleIndex,presentation=index?{widths:[16,16,10,60,18,38],cellStyle:i=>i===0?index.header:index.normal[(i-1)%2][0],rowHeight:i=>i?20:24}:undefined;
  return {name:'Reason can cap nhat',columns,rows:value.reasonIssues.filter(keep).map(row=>Object.fromEntries(columns.map(c=>[c.key,row[c.key]??'']))),presentation};}
 function reportExcelSheet(rows,columns,meta,tree=buildPivot(rows,columns,meta)){
  const entries=tree.on?[...tree.entries,...(tree.grand?[tree.grand]:[])]:rows.map(row=>({type:'row',row}));
  const output=pivotDisplayRows(entries,tree,columns,prefs().noRepeatLabels);
  const table=root.querySelector('.dt-table'),headers=[...table.querySelectorAll('thead tr:first-child th')];
  const cell=table.querySelector('tbody td')||headers[0],css=getComputedStyle(cell),head=getComputedStyle(headers[0]);
  const rgb=value=>{value=value.trim();if(/^#[0-9a-f]{6}$/i.test(value))return 'FF'+value.slice(1).toUpperCase();if(/^#[0-9a-f]{3}$/i.test(value))return 'FF'+[...value.slice(1)].map(c=>c+c).join('').toUpperCase();const n=value.match(/[\d.]+/g);return n?.length>=3?'FF'+n.slice(0,3).map(x=>Math.round(Number(x)).toString(16).padStart(2,'0')).join('').toUpperCase():'FF101C26';};
  const scope=getComputedStyle(root.querySelector('.dt-scope'));
  const base=rgb(scope.getPropertyValue('--panel')),stripe=rgb(scope.getPropertyValue('--stripe'));
  const font=Math.max(7,parseFloat(css.fontSize)*.75),fontName=css.fontFamily.split(',')[0].replace(/["']/g,'');
  const palettes={'dt-b-setup':['FFDFF1FB','FF0A5F80'],'dt-b-sop':['FFDDF3EA','FF0D6A52'],'dt-b-spare':['FFEFEAFA','FF4A3390'],'dt-b-bad':['FFFBE3E6','FF93262F'],'dt-b-warn':['FFFDF0D3','FF8A5A12']};
  const fonts=[],fills=['<fill><patternFill patternType="none"/></fill>','<fill><patternFill patternType="gray125"/></fill>'],styles=[];
  const style=(fill,color,bold,numeric)=>{
   const fontId=fonts.length,fillId=fills.length,index=styles.length;
   fonts.push(`<font>${bold?'<b/>':''}<sz val="${font.toFixed(2)}"/><name val="${esc(fontName)}"/><color rgb="${color}"/></font>`);
   fills.push(`<fill><patternFill patternType="solid"><fgColor rgb="${fill}"/><bgColor indexed="64"/></patternFill></fill>`);
   styles.push(`<xf numFmtId="${numeric?164:0}" fontId="${fontId}" fillId="${fillId}" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1" applyNumberFormat="1"><alignment horizontal="${numeric?'right':'left'}" vertical="center" wrapText="1"/></xf>`);
   return index;
  };
  const headerStyle=reportKind(kind)?style('FF163D58','FFFFFFFF',true,false):style(rgb(head.backgroundColor),rgb(head.color),true,false);
  const groupStyles=[style('FFE5EFF7','FF234662',true,false),style('FFF1F6FB','FF234662',true,false)];
  const subtotalStyles=[style('FFDCECF6','FF173B55',true,false),style('FFDCECF6','FF173B55',true,true)];
  const grandStyles=[style('FF17405E','FFFFFFFF',true,false),style('FF17405E','FFFFFFFF',true,true)];
  const normal=[base,stripe].map(fill=>[style(fill,rgb(css.color),false,false),style(fill,rgb(css.color),false,true)]);
  const badges=Object.fromEntries(Object.entries(palettes).map(([key,[fill,color]])=>[key,style(fill,color,true,false)]));
  const pixels=headers.map(h=>h.getBoundingClientRect().width);
  const widths=pixels.map(width=>Math.max(2,(width-5)/(font/.75*.55)));
  const presentation={styleIndex:{header:headerStyle,normal},widths,freezeCols:reportKind(kind)?Math.min(2,tree.texts.length):0,autoFilter:reportKind(kind)?false:true,
   cellStyle:(i,j,value)=>{if(i===0)return headerStyle;const item=entries[i-1],numeric=meta.get(columns[j].key)?1:0;
    if(item?.type==='grand')return grandStyles[numeric];
    if(item?.type==='subtotal')return subtotalStyles[numeric];
    if(item?.type==='group')return groupStyles[Math.min(1,item.level)];
    return badges[badgeClass(columns[j].key,String(value??''))]??normal[(i-1)%2][numeric];},
   rowHeight:i=>{const row=i?output[i-1]:Object.fromEntries(columns.map(c=>[c.key,c.label]));const lines=Math.max(1,...columns.map((c,j)=>Math.ceil(Array.from(String(row[c.key]??'')).length/Math.max(1,(pixels[j]-6)/(parseFloat(css.fontSize)*.55)))));return Math.min(409,Math.max(15,lines*font*1.4+6));}};
  const border=rgb(getComputedStyle(cell).borderBottomColor);
  presentation.stylesXML=`<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts><fonts count="${fonts.length}">${fonts.join('')}</fonts><fills count="${fills.length}">${fills.join('')}</fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border>${['left','right','top','bottom'].map(side=>`<${side} style="thin"><color rgb="${border}"/></${side}>`).join('')}<diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${styles.length}">${styles.join('')}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  return {name:kind==='GR_REPORT'?'GR report':'PR report',columns:columns.map(c=>({key:c.key,label:esc(c.label)})),rows:output,merges:[],presentation};
 }

 // Dòng PR nguồn trong đúng bộ lọc và tháng đang hiện, lấy từ details của server.
 function prRawDetailSheet(reportRows,shownColumns){
  const value=records.get('REPORT');if(!Array.isArray(value?.details))return null;
  const ids=new Set(reportRows.flatMap(row=>Array.isArray(row.__detailIds)?row.__detailIds.map(String):[]));
  const months=new Set(visibleMonthColumns(shownColumns).map(c=>Number(c.key)));
  const rows=value.details.filter(row=>ids.has(String(row.id))&&(!months.size||months.has(Number(row.PR_Month))));
  const fields=[['Receiver','Receiver'],['PR_no','PR_NO'],['PR_SEQ','PR_SEQ'],['ITEM_CODE','Item code'],['PO_no','PO_NO'],['COST_CENTER','Cost Center'],['PR_Month','PR Month'],['MonthAmountUSD','Month Amount USD'],['AmountUSD','Amount USD'],['Purchase_req_infor','PURCHASE_REQ_INFO']];
  const columns=fields.map(([key,label])=>({key,label}));
  return {name:'PR detail',columns,rows:rows.map(row=>Object.fromEntries(columns.map(c=>[c.key,row[c.key]??''])))};
 }
 // Dòng GMRO gốc: cùng bộ lọc và tháng của bảng Pivot; không nhân bản tiền hoặc tự đổi tỷ giá.
 function grRawDetailSheet(reportRows,shownColumns,issuesOnly=false){
  const value=records.get('GR_REPORT');if(!Array.isArray(value?.details))return null;
  const months=visibleMonthColumns(shownColumns).map(c=>Number(c.key));
  const detailRows=grSourceLines(reportRows,value.details,months);
  const chosen=issuesOnly?detailRows.filter(row=>grProblemReasons(row).length):detailRows;
  const fields=[['GR_NO','GR_NO'],['GR_DATE','GR_DATE'],['COST_CENTER','Cost Center'],['PO_NO','PO_NO'],['PO_SEQ','PO_SEQ'],['PR_NO','PR_NO'],['PR_SEQ','PR_SEQ'],['ITEM_CODE','Item Code'],['GR_QTY','GR_QTY'],['GR_AMOUNT','GR_AMOUNT'],['CURRENCY','Currency'],['Amount USD','Amount USD'],['Match Status','Match Status'],['Class','GL Class'],['Reason Source','Reason Source'],['PURCHASE_REQ_INFO','PURCHASE_REQ_INFO']];
  if(issuesOnly)fields.unshift(['__issues','Lỗi cần xử lý']);
  const exportColumns=fields.map(([key,label])=>({key,label}));
  return {name:issuesOnly?'Loi doi soat':'GR detail',columns:exportColumns,rows:chosen.map(row=>Object.fromEntries(exportColumns.map(c=>[c.key,c.key==='__issues'?grProblemReasons(row).join(' | '):row[c.key]??''])))};
 }
 // Khi bấm ô tiền, chỉ lấy GR nguồn thuộc tháng đó; tổng popup không bị cộng cả năm.
 function openGRAmount(context){
  const value=records.get('GR_REPORT'),wanted=new Set(context.detailIds.map(String));
  const lines=grSourceLines([{__detailIds:[...wanted]}],value?.details||[],context.months);
  if(!lines.length){toast('Không tìm thấy GR nguồn trong tháng này. Hãy tải lại dữ liệu.');return;}
  const number=value=>new Intl.NumberFormat('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(value)||0);
  const amount=Number(lines.reduce((sum,row)=>sum+(typeof row['Amount USD']==='number'?row['Amount USD']:0),0).toFixed(2));
  const mismatch=Math.abs(amount-context.amount)>0.01;
  const cols=['GR_NO','GR_DATE','PO_NO','PR_NO','ITEM_CODE','GR_QTY','GR_AMOUNT','CURRENCY','Amount USD','Match Status'];
  showDetail('GR Detail · '+(context.months.length?'Tháng '+context.months.join(', '):'Cả năm'),`<div class="dt-gr-detail"><p class="small muted">${lines.length} dòng GMRO nguồn · ${esc(context.scope.join(' · '))} · Tổng đã quy đổi: <b>${number(amount)} USD</b></p>${mismatch?`<p class="small amber" role="alert">Cần kiểm tra: chi tiết ${number(amount)} USD khác ô Pivot ${number(context.amount)} USD. Không tự điều chỉnh số tiền.</p>`:''}${lines.some(r=>r['Amount USD']==null)?'<p class="small amber">Có GR chưa quy đổi USD (ô tiền nguồn được để trống).</p>':''}<div class="dt-scroll"><table class="dt-table"><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${lines.map(r=>`<tr>${cols.map(c=>`<td>${esc(r[c]??'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div>`);
 }

 function openPRDetails(context){const value=records.get('REPORT'),wanted=new Set(context.detailIds.map(String)),months=new Set(context.months.map(Number));let source=(value?.details||[]).filter(row=>wanted.has(String(row.id))&&(context.allYear||months.has(Number(row.PR_Month))));if(!source.length){toast('Không tìm thấy dòng PR nguồn của ô đã chọn. Hãy bấm Tải lại để cập nhật dữ liệu chi tiết.');return;}
  const amountKey=context.allYear?'AmountUSD':'MonthAmountUSD',groups=new Map();
  for(const row of source){const key=[row.lineKey,row.Receiver,row.PR_no,row.Purchase_req_infor].map(value=>String(value??'')).join('\u0000');let group=groups.get(key);if(!group){group={Receiver:String(row.Receiver??'').trim(),PR_NO:String(row.PR_no??'').trim(),POs:new Set(),PR_Amount:0,PURCHASE_REQ_INFO:String(row.Purchase_req_infor??'').trim(),sourceCount:0};groups.set(key,group);}const po=String(row.PO_no??'').trim();if(po)group.POs.add(po);group.sourceCount++;const amount=Number(row[amountKey]);if(Number.isFinite(amount))group.PR_Amount=Number((group.PR_Amount+amount).toFixed(2));}
  const rows=[...groups.values()].map(group=>({...group,PO_NO:[...group.POs].sort((a,b)=>a.localeCompare(b,'vi',{numeric:true})).join(' · ')})),total=Number(rows.reduce((sum,row)=>sum+row.PR_Amount,0).toFixed(2)),multiPO=rows.filter(row=>row.POs.size>1),mismatch=Math.abs(total-Number(context.amount))>.01;
  const display=value=>String(value??'').trim()||'—',money=value=>new Intl.NumberFormat('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(value)||0),scope=[`Năm ${reportYear}`,context.allYear?'Cả năm':`Tháng ${context.months.join(', ')}`,...context.scope].join(' · ');
  showDetail('PR Detail',`<div class="dt-pr-detail"><div class="dt-pr-detail-meta"><span>${esc(scope)}</span><label>Tìm kiếm<input type="search" data-dt-pr-detail-search placeholder="Receiver, PR, PO, Reason…" autocomplete="off"></label></div>${multiPO.length?`<p class="small amber" role="alert">${multiPO.length} PR line liên kết nhiều PO. Popup gom theo ITEM_CODE + PR_NO + PR_SEQ, liệt kê các PO trong cùng một ô và giữ đúng phần tiền đang cấu thành PR Report; không tự chia tiền cho từng PO.</p>`:''}${mismatch?`<p class="small amber" role="alert">Không thể đối soát tuyệt đối ô đã chọn: chi tiết ${money(total)} USD, ô báo cáo ${money(context.amount)} USD. Dữ liệu được giữ nguyên, không tự phân bổ.</p>`:''}<div class="dt-pr-detail-count small muted" data-dt-pr-detail-count></div><div class="dt-pr-detail-scroll"><table class="dt-pr-detail-table"><colgroup><col><col><col><col><col></colgroup><thead><tr><th>Receiver</th><th>PR_NO</th><th>PO_NO</th><th>PR_Amount</th><th>PURCHASE_REQ_INFO</th></tr></thead><tbody data-dt-pr-detail-body></tbody><tfoot><tr><th colspan="3">Total PR Amount</th><td>${money(total)} USD</td><td></td></tr></tfoot></table></div></div>`);
  const dialog=document.getElementById('detail'),input=dialog.querySelector('[data-dt-pr-detail-search]'),body=dialog.querySelector('[data-dt-pr-detail-body]'),count=dialog.querySelector('[data-dt-pr-detail-count]'),closeOnEscape=event=>{if(event.key==='Escape'&&dialog.open){event.preventDefault();dialog.close();}};dialog.addEventListener('keydown',closeOnEscape);dialog.addEventListener('close',()=>dialog.removeEventListener('keydown',closeOnEscape),{once:true});
  const render=()=>{const q=input.value.trim().toLocaleLowerCase(),visible=rows.filter(row=>!q||[row.Receiver,row.PR_NO,row.PO_NO,row.PURCHASE_REQ_INFO].some(value=>String(value??'').toLocaleLowerCase().includes(q)));count.textContent=`${visible.length} / ${rows.length} dòng PR`;body.innerHTML=visible.map(row=>`<tr><td>${esc(display(row.Receiver))}</td><td>${esc(display(row.PR_NO))}</td><td>${esc(display(row.PO_NO))}</td><td class="dt-num">${money(row.PR_Amount)} USD</td><td><div class="dt-pr-reason">${esc(display(row.PURCHASE_REQ_INFO))}</div></td></tr>`).join('')||'<tr><td colspan="5" class="empty-state">Không có PR phù hợp.</td></tr>';};
  input.addEventListener('input',render);render();input.focus();
 }

 function grAuditPanel(value,scopeRows,columns){
  if(kind!=='GR_REPORT'||!value?.audit)return '';
  const months=visibleMonthColumns(columns).map(c=>Number(c.key));
  const scoped=grSummary(scopeRows,value.details||[],months);
  const num=n=>new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(Number(n)||0);
  const cards=[['all','GR Amount',num(scoped.amount)+' USD','Dữ liệu nhận hàng trong phạm vi lọc'],['matched','Matched',num(scoped.matched),'GR ghép đúng một dòng PR'],['problem-pr','Unmatched / Ambiguous',num(scoped.unmatched+scoped.ambiguous),'GR chưa ghép PR hoặc ghép nhiều PR'],['data-issues','Data Issues',num(scoped.issues),'Thiếu Reason, GL Class hoặc chưa đổi USD']];
  const a=value.audit,all=[['Dòng GR nguồn',a.sourceRows],['Ghép PR thành công',a.matchedRows],['Unmatched PR',a.unmatchedRows],['Ambiguous Match',a.ambiguousRows],['Reason thiếu/sai',a.missingReasonRows],['Thiếu GL Class',a.missingClassRows],['Chưa đổi USD',a.unconvertedRows],['GR đã quy đổi',num(a.convertedUSD)+' USD'],['Chênh lệch',num(a.differenceUSD)+' USD']];
  return `<section class="dt-gr-smart-overview" aria-label="GR KPI trong bộ lọc"><div class="dt-gr-kpi-grid">${cards.map(([key,label,number,title])=>`<button type="button" class="dt-gr-kpi ${grIssueFilter===key?'is-active':''}" data-dt-gr-focus="${key}" aria-pressed="${grIssueFilter===key}" title="${esc(title)}"><span>${esc(label)}</span><b>${esc(number)}</b><small>${esc(title)}</small></button>`).join('')}</div><p class="small muted dt-gr-kpi-hint">${months.length?'Tháng '+months.join(', ')+' · ':''}KPI lấy theo năm, Cost Center, tìm kiếm và bộ lọc cột đang chọn. Nhấn thẻ để lọc bảng; Data Issues có thể trùng với Unmatched.</p><details class="dt-report-audit" data-dt-report-audit ${reportAuditOpen?'open':''}><summary>Đối soát toàn bộ nguồn GR năm ${reportYear} (mở khi cần)</summary><div class="dt-gr-audit" aria-label="Đối soát nguồn GR"><div class="dt-gr-audit-grid">${all.map(([label,v])=>`<article><span>${esc(label)}</span><b>${esc(v)}</b></article>`).join('')}</div>${a.sourceByCurrency?.length?`<p class="small muted">Tổng nguồn theo nguyên tệ: ${a.sourceByCurrency.map(x=>`${esc(x.currency)} ${num(x.amount)} (${x.rows} dòng)`).join(' · ')}. Không cộng trực tiếp các nguyên tệ khác nhau.</p>`:''}<p class="small muted">Số liệu đối soát nguồn do SQL trả về là toàn năm, chưa áp dụng bộ lọc Cost Center hoặc tìm kiếm ở màn hình. KPI phía trên mới là số liệu theo phạm vi lọc.</p></div></details></section>`;
 }
 // 15/11/2026: Đối soát dữ liệu PR — cùng bố cục/CSS với khung GR; số do backend reportForm tính (value.audit).
 function prAuditPanel(value){if(kind!=='REPORT'||!value?.audit)return '';const a=value.audit,number=n=>new Intl.NumberFormat('vi-VN',{maximumFractionDigits:2}).format(Number(n)||0),cards=[['Dòng PR nguồn',a.sourceRows],['Loại theo trạng thái PR',a.excludedStatusRows],['Lên báo cáo',a.reportedRows],['PR_Month sai/trống',a.missingMonthRows],['Chưa đổi USD',a.unconvertedRows],['Reason thiếu/sai',a.missingReasonRows],['Thiếu GL Class',a.missingClassRows],['Lí do từ Override',a.overrideRows],['PR đã quy đổi',number(a.convertedUSD)+' USD'],['Chênh lệch',number(a.differenceUSD)+' USD']];
  return `<section class="dt-gr-audit dt-pr-audit" aria-label="Đối soát PR Report"><div class="dt-gr-audit-head"><strong>Đối soát dữ liệu PR</strong><span class="small muted">Cùng phạm vi năm và lọc trạng thái PR của báo cáo</span></div><div class="dt-gr-audit-grid">${cards.map(([label,value])=>`<article><span>${esc(label)}</span><b>${esc(value)}</b></article>`).join('')}</div>${a.sourceByCurrency?.length?`<p class="small muted">Tổng nguồn theo nguyên tệ: ${a.sourceByCurrency.map(item=>`${esc(item.currency)} ${number(item.amount)} (${item.rows} dòng)`).join(' · ')}. Không so trực tiếp nguyên tệ khác nhau với USD.</p>`:''}</section>`;}
 function openGRDetails(encoded){const value=records.get('GR_REPORT'),wanted=new Set(decodeURIComponent(encoded).split(',').filter(Boolean)),rows=(value?.details||[]).filter(row=>wanted.has(String(row.id)));if(!rows.length){toast('Không tìm thấy dòng GR nguồn của bản ghi này.');return;}const columns=['GR_NO','COST_CENTER','GR_DATE','PO_NO','PO_SEQ','PR_NO','PR_SEQ','ITEM_CODE','GR_QTY','GR_AMOUNT','CURRENCY','PURCHASE_REQ_INFO','Reason Source','Match Status','Amount USD'];showDetail(`Chi tiết GR nguồn · ${rows.length} dòng`,`<div class="dt-gr-detail"><p class="small muted">Dữ liệu dưới đây là từng dòng GMRO nguồn, không phải số tiền được tạo lại từ Pivot.</p><div class="dt-scroll"><table class="dt-table"><thead><tr>${columns.map(name=>`<th>${esc(name)}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${columns.map(name=>`<td title="${esc(text(row[name]))}">${esc(text(row[name]))}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div>`);}

 function reportSourceRows(){const value=records.get(kind),p=view(),allowCostCenter=costCenterAllowed();return (value?.sheet.rows||[]).filter(row=>allowCostCenter(row)&&(!query||Object.values(row).some(v=>text(v).toLocaleLowerCase().includes(query.toLocaleLowerCase())))&&p.columns.filter(c=>c.visible).every(c=>!p.filters[c.key]||text(row[c.key]).toLocaleLowerCase().includes(p.filters[c.key].toLocaleLowerCase())));}
 function filtered(){const value=records.get(kind),p=view(),allowCostCenter=costCenterAllowed();let rows=(value?.sheet.rows||[]).filter(row=>allowCostCenter(row)&&(!query||Object.values(row).some(v=>text(v).toLocaleLowerCase().includes(query.toLocaleLowerCase())))&&p.columns.filter(c=>c.visible).every(c=>!p.filters[c.key]||text(row[c.key]).toLocaleLowerCase().includes(p.filters[c.key].toLocaleLowerCase())));if(kind==='GR_REPORT'&&grIssueFilter!=='all')rows=rows.filter(row=>grMatchesFocus(row,grIssueFilter));
  const sorted=prioritySort(rows,p.merge,priorityDate()),visible=p.columns.filter(c=>c.visible),monthColumns=visibleMonthColumns(visible);keepEmptyRows=p.showEmptyMonth===true;lastAmountTotal=sorted.reduce((sum,row)=>{const value=rowAmount(row,monthColumns);return value===null?sum:Number((sum+value).toFixed(2))},0);lastMergedFrom=sorted.length;lastHiddenEmpty=monthColumns.length&&!keepEmptyRows?sorted.filter(row=>rowAmount(row,monthColumns)===null&&!(kind==='GR_REPORT'&&row.__unconverted)).length:0;return reportAggregate(sorted,visible,visible,keepEmptyRows);
 }
 // Fit theo chiều rộng thực của tab; container units tự cập nhật khi đổi sidebar/cửa sổ.
 function reportFitStyle(columns){
  if(!reportKind(kind))return '';
  if(reportKind(kind))return `<style>
   .dt-scope.dt-pr-smart{min-width:0;max-width:100%;--panel:#fff;--stripe:#f6f9fc;--panel-alt:#eaf1f7}
   .dt-pr-smart .dt-panel,.dt-pr-smart .dt-scroll{min-width:0;max-width:100%}
   .dt-pr-smart .dt-scroll{overflow:auto;width:100%;max-height:min(67vh,780px);box-sizing:border-box}
   .dt-pr-smart .dt-table{width:max-content;min-width:100%;table-layout:auto;font-family:"Segoe UI",Arial,sans-serif;font-size:12.5px}
   .dt-pr-smart .dt-table :is(th,td,.dt-col-tight,.dt-col-wide){min-width:125px;max-width:350px;width:auto;padding:8px 11px;white-space:normal;overflow-wrap:break-word}
   .dt-pr-smart .dt-table th.dt-col-tight,.dt-pr-smart .dt-table td.dt-col-tight{min-width:108px;max-width:150px}
   .dt-pr-smart .dt-table th.dt-col-wide,.dt-pr-smart .dt-table td.dt-col-wide{min-width:260px;max-width:480px}
   .dt-pr-smart .dt-table td>span{max-height:70px;max-width:480px;overflow:auto}
   .dt-pr-smart .dt-table thead tr:first-child th{position:sticky;top:0;height:36px;z-index:4;background:#173e59;color:white}
   .dt-pr-smart .dt-table thead tr:nth-child(2) th{position:sticky;top:36px;height:41px;z-index:3;background:#eef4f9}
   .dt-pr-smart .dt-table th input{min-width:90px;width:100%;max-width:none;box-sizing:border-box}
   .dt-pr-smart .dt-table :is(th,td):first-child{position:sticky;left:0;z-index:2;box-shadow:1px 0 #e0e8ef}
   .dt-pr-smart .dt-table thead tr:first-child th:first-child{z-index:6;background:#173e59}
   .dt-pr-smart .dt-table thead tr:nth-child(2) th:first-child{z-index:5;background:#eef4f9}
   .dt-pr-smart .dt-table tbody tr.dt-leaf>td:first-child{background:#fff}
   .dt-pr-smart .dt-table tbody tr.dt-odd>td:first-child{background:#f6f9fc}
   .dt-pr-smart .dt-table tbody tr.dt-pv>td:first-child{background:#e5eff7}
   .dt-pr-smart .dt-table tbody tr.dt-pv-subtotal>td:first-child{background:#dcecf6}
   .dt-pr-smart .dt-table tfoot tr.dt-pv-grand>td:first-child{background:#17405e}
   .dt-pr-smart .dt-table tfoot td{position:sticky;bottom:0;z-index:2}
   .dt-pr-smart .dt-table .dt-num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
   .dt-pr-smart .dt-table .dt-num>span{max-width:none}
   .dt-pr-smart .dt-report-controls{border:1px solid var(--border);background:#f9fbfe;border-radius:10px;margin-bottom:12px;padding:9px 12px}
   .dt-pr-smart .dt-report-controls>summary{cursor:pointer;font-weight:700;color:#254660;list-style-position:inside}
   .dt-pr-smart .dt-report-controls-content{padding-top:12px}
   .dt-pr-smart .dt-report-controls .dt-checks{margin-bottom:10px}
   .dt-pr-smart .dt-report-audit{margin-bottom:12px}
   .dt-pr-smart .dt-report-audit>summary{cursor:pointer;font-size:12px;color:#3b5970}
   .dt-pr-smart .dt-report-audit>.dt-pr-audit{margin-top:8px}
   .dt-pr-smart .dt-report-guide{margin:0 0 9px;color:#536b80;font-size:12px}
   .dt-pr-smart .dt-toolbar[data-dt-primary]{border-bottom:1px solid var(--border);padding-bottom:10px;margin-bottom:11px}
   .dt-pr-smart .dt-pivot-control{display:inline-flex;align-items:center;gap:4px;cursor:pointer;background:none;border:0;padding:3px 1px;color:inherit;font:inherit;font-weight:700;text-align:left}
   .dt-pr-smart .dt-pivot-control:hover{text-decoration:underline}
   .dt-pr-smart .dt-table .dt-pv-subtotal>td{background:#dcecf6;font-weight:750;border-top:1px solid #bad2e3;color:#173b55}
   .dt-pr-smart .dt-table .dt-pv-grand>td{background:#17405e!important;color:white;font-weight:800;border-top:2px solid #10354e}
   .dt-pr-smart .dt-table tbody .dt-pv>td{background:#e5eff7;border-top:1px solid #bfd5e5}
   .dt-pr-smart .dt-table tbody .dt-pv-2>td{background:#f1f6fb}
   .dt-pr-smart .dt-table tr.dt-pv:hover>td{background:#d8e8f5}
   .dt-pr-smart .dt-cc-filter{margin:8px 0;padding:9px 12px}
   .dt-pr-smart .dt-cc-list{display:flex;flex-wrap:wrap;gap:5px 15px;max-height:180px;overflow:auto}
   .dt-pr-smart .dt-cc-list label{display:inline-flex;align-items:center;gap:5px}
   .dt-pr-smart .dt-gr-kpi-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px;margin:8px 0}
   .dt-pr-smart .dt-gr-kpi{min-width:0;display:flex;flex-direction:column;align-items:flex-start;gap:5px;text-align:left;cursor:pointer;border:1px solid #d4e1ea;border-radius:10px;background:#fff;padding:12px;font-family:inherit;color:#27445c}
   .dt-pr-smart .dt-gr-kpi span{font-size:12px;font-weight:700}
   .dt-pr-smart .dt-gr-kpi b{font-size:21px;font-variant-numeric:tabular-nums;word-break:break-word}
   .dt-pr-smart .dt-gr-kpi small{font-size:11px;color:#688094;line-height:1.35}
   .dt-pr-smart .dt-gr-kpi:hover,.dt-pr-smart .dt-gr-kpi.is-active{border-color:#528eb6;background:#f0f7fc;box-shadow:0 0 0 1px #96bfd7}
   .dt-pr-smart .dt-gr-kpi-hint{margin:4px 0 10px}
   .dt-pr-smart [data-dt-gr-cell]{cursor:pointer;text-decoration:underline dotted #9bb8cb;text-underline-offset:3px}
   .dt-pr-smart [data-dt-gr-cell]:hover{background:#dceefb!important}
   @media(max-width:880px){.dt-pr-smart .dt-gr-kpi-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
   @media(max-width:720px){.dt-pr-smart .dt-table :is(th,td){min-width:115px}.dt-pr-smart .dt-toolbar[data-dt-primary]>input[type=search]{width:160px;min-width:130px}}
  </style>`;
  return `<style>
  .dt-scope.dt-report-fit{min-width:0;max-width:100%;container-type:inline-size}
  .dt-report-fit .dt-panel,.dt-report-fit .dt-scroll{min-width:0;max-width:100%}
  .dt-report-fit .dt-scroll{width:100%;box-sizing:border-box}
  .dt-report-fit .dt-table{table-layout:fixed;width:100%;min-width:0;font-family:"Arial Narrow","Segoe UI",Arial,sans-serif;--dt-fit-font:clamp(9px,calc(100cqi / ${Math.max(columns.length,1)} / 8),13px)}
  .dt-report-fit .dt-table :is(th,td,.dt-col-tight,.dt-col-wide){width:auto;min-width:0;max-width:none;box-sizing:border-box;padding:4px 3px;font-size:var(--dt-fit-font);white-space:normal;overflow-wrap:anywhere;letter-spacing:0}
  .dt-report-fit .dt-table thead{position:sticky;top:0;z-index:3}
  .dt-report-fit .dt-table thead th{position:static;height:auto}
  .dt-report-fit .dt-table th input{width:100%;min-width:0;max-width:100%;box-sizing:border-box;padding:3px 2px;font-size:var(--dt-fit-font)}
  .dt-report-fit .dt-table td>span,.dt-report-fit .dt-table td.dt-col-tight>span,.dt-report-fit .dt-table td>span.dt-badge{display:block;width:auto;min-width:0;max-width:100%;max-height:none;white-space:normal;overflow:visible;overflow-wrap:anywhere;text-overflow:clip;font-size:inherit}
  .dt-report-fit .dt-table .dt-badge{padding:1px 2px}
  .dt-report-fit .dt-table .dt-pv-count{display:block;margin:2px 0 0;font-size:inherit}
  .dt-report-fit .dt-table .dt-lv{min-width:0;margin-right:2px;padding:0 2px;font-size:inherit}
  .dt-report-fit [data-dt-column-slicers] fieldset{min-width:0}
  .dt-report-fit .dt-cc-filter{margin:6px 0;padding:6px 10px}
  .dt-report-fit .dt-cc-filter summary{cursor:pointer;display:flex;gap:8px;align-items:center}
  .dt-report-fit .dt-cc-filter .dt-toolbar{margin:6px 0}
  .dt-report-fit .dt-cc-list{display:flex;flex-wrap:wrap;gap:4px 14px;max-height:180px;overflow:auto}
  .dt-report-fit .dt-cc-list label{display:inline-flex;gap:4px;align-items:center;white-space:nowrap}
  </style>`;
 }
 // Các thẻ chọn cột dùng cùng cấu hình với Column Setting và Export Excel.
 function costCenterFilter(value){
  if(!reportKind(kind)||!value?.sheet?.columns?.some(c=>c.name==='COST_CENTER'))return '';
  const counts=new Map();for(const row of value.sheet.rows||[]){const cc=costCenterOf(row);counts.set(cc,(counts.get(cc)||0)+1);}
  const list=[...counts.keys()].sort((a,b)=>(a===''?1:0)-(b===''?1:0)||a.localeCompare(b,'vi',{numeric:true})),excluded=new Set((prefs().excludedCostCenters||[]).filter(cc=>counts.has(cc))),kept=list.length-excluded.size;
  const summary=excluded.size?`Đang lấy ${kept}/${list.length} · loại ${excluded.size}`:`Tất cả (${list.length})`;
  return `<details class="panel dt-cc-filter" data-dt-cc ${costCenterOpen?'open':''}><summary><strong>Cost Center</strong> <span class="small ${excluded.size?'amber':'muted'}">${esc(summary)}</span></summary><div class="dt-toolbar"><button type="button" class="button" data-dt-cc-all ${busy||!excluded.size?'disabled':''}>Chọn tất cả</button><button type="button" class="button" data-dt-cc-none ${busy||!kept?'disabled':''}>Bỏ chọn tất cả</button><span class="small muted">Bỏ dấu ✓ để loại Cost Center không cần lấy dữ liệu.${excluded.size?' Khung đối soát phía trên vẫn tính trên toàn bộ Cost Center.':''}</span></div><div class="dt-cc-list">${list.map(cc=>`<label><input type="checkbox" data-dt-cc-value="${esc(cc)}" ${excluded.has(cc)?'':'checked'} ${busy?'disabled':''}> ${cc?esc(cc):'<i>(Trống)</i>'} <span class="small muted">${counts.get(cc)}</span></label>`).join('')}</div></details>`;
 }
 function columnSlicers(p,meta){
  if(!reportKind(kind)||!p.columns.length)return '';
  const groups=[['Trường nhóm',c=>!meta.get(c.key)],['Tháng',c=>/^(?:[1-9]|1[0-2])$/.test(c.key)],['Giá trị',c=>meta.get(c.key)&&!/^(?:[1-9]|1[0-2])$/.test(c.key)]];
  const locked=busy||!!applied,hidden=prefs().hideSlicers;
  return `<div data-dt-column-slicers role="group" aria-label="Chọn cột PR report"><div class="dt-toolbar"><strong>Chọn cột giữ lại</strong><button type="button" class="button" data-dt-slicers-toggle aria-expanded="${hidden?'false':'true'}" aria-controls="dt-slicer-fields">${hidden?'Hiện Slicer':'Ẩn Slicer'}</button><span class="small muted">${p.columns.filter(c=>c.visible).length}/${p.columns.length} cột · Thẻ có dấu ✓ đang hiển thị</span><button type="button" class="button" data-dt-columns-all ${locked?'disabled':''}>Hiện tất cả cột</button></div><div id="dt-slicer-fields" ${hidden?'hidden':''}>${applied?'<p class="small muted">Bỏ áp dụng bảng kiểm tra để thay đổi cột.</p>':''}${groups.map(([label,accept])=>{const list=p.columns.filter(accept);return list.length?`<fieldset class="panel"><legend>${label}</legend><div class="dt-toolbar">${list.map(c=>`<button type="button" class="button ${c.visible?'primary':''}" data-dt-column-toggle="${esc(c.key)}" aria-pressed="${c.visible?'true':'false'}" aria-label="Giữ cột ${esc(c.label)}" ${locked?'disabled':''}>${c.visible?'✓ ':''}${esc(c.label)}</button>`).join('')}</div></fieldset>`:'';}).join('')}</div></div>`;
 }
 function draw(){const value=records.get(kind),p=view(),columns=p.columns.filter(c=>c.visible),rows=filtered(),meta=columnMeta(),pivot=buildPivot(rows,columns,meta),list=pivot.on?pivot.entries:rows,pages=Math.max(1,Math.ceil(list.length/pageSize));if(restorePage&&value){page=restorePage;if(!busy)restorePage=0;}page=Math.min(page,pages);const keepScroll=restoreScroll&&value?restoreScroll:0;if(keepScroll&&!busy)restoreScroll=0;remembered.state={kind,page:restorePage||page,pageSize,reportYears:{...reportYears},reportYear,applied,selected:[...selected],scrollTop:keepScroll||root.querySelector('.dt-scroll')?.scrollTop||0};const current=list.slice((page-1)*pageSize,page*pageSize),spans=new Map(),scrollTop=keepScroll||root.querySelector('.dt-scroll')?.scrollTop||0,prDetailContexts=new Map(),grDetailContexts=new Map(),shownMonths=visibleMonthColumns(columns).map(c=>Number(c.key));
  const prDetailCellAttr=(row,column)=>{if(kind==='GR_REPORT'){
   if(!meta.get(column.key)||!(column.key==='Amount'||monthKeyRe.test(column.key))||typeof row[column.key]!=='number'||!Array.isArray(row.__detailIds)||!row.__detailIds.length)return '';
   const token=String(grDetailContexts.size+1),months=monthKeyRe.test(column.key)?[Number(column.key)]:shownMonths,scope=['COST_CENTER','Type','Project','Model','Process'].filter(key=>String(row[key]??'').trim()).map(key=>`${key}: ${row[key]}`);
   grDetailContexts.set(token,{detailIds:[...row.__detailIds],months,amount:Number(row[column.key]),scope});return ` data-dt-gr-cell="${token}" tabindex="0" role="button" title="Bấm để xem dòng GMRO tạo ra số tiền này"`;
  }
  if(kind!=='REPORT'||!meta.get(column.key)||!(column.key==='Amount'||monthKeyRe.test(column.key))||typeof row[column.key]!=='number'||!Array.isArray(row.__detailIds)||!row.__detailIds.length)return '';const token=String(prDetailContexts.size+1),months=monthKeyRe.test(column.key)?[Number(column.key)]:shownMonths,visibleTotal=rowAmount(row,visibleMonthColumns(columns)),allYear=column.key==='Amount'&&(!months.length||(visibleTotal!==null&&Math.abs(Number(row.Amount)-visibleTotal)>.01)),scope=['COST_CENTER','Type','Project','Model','Process'].filter(key=>String(row[key]??'').trim()).map(key=>`${key}: ${row[key]}`);prDetailContexts.set(token,{detailIds:[...row.__detailIds],months:allYear?[]:months,allYear,amount:Number(row[column.key]),scope});return ` data-dt-pr-detail="${token}" tabindex="0" role="button" title="Bấm để xem PR cấu thành số tiền này"`;};
  // Gộp ô theo nhiều cột, lồng nhau: cột gộp thứ m chỉ gộp khi trùng cả giá trị của m cột gộp đầu tiên
  // (tính theo thứ tự hiển thị), nên nhóm ngoài không bị "chảy" sang nhóm của cột bên trái.
  if(!pivot.on)p.merge.forEach((key,m)=>{const prefix=p.merge.slice(0,m+1),map=new Map();for(let i=0;i<current.length;){const same=j=>prefix.every(column=>identity(current[i][column])===identity(current[j][column]));let end=i+1;while(end<current.length&&same(end))end++;map.set(i,end-i);for(let j=i+1;j<end;j++)map.set(j,0);i=end;}spans.set(key,map);});
  root.innerHTML=`<div class="dt-scope ${reportKind(kind)?'dt-report-fit':''} ${reportKind(kind)?'dt-pr-smart':''}">${reportFitStyle(columns)}<section class="panel dt-panel"><div class="dt-toolbar" ${reportKind(kind)?'data-dt-primary':''}><div class="dt-tabs">${['REPORT','GR_REPORT','PR','RFQ','GMRO'].map(k=>`<button type="button" class="button ${k===kind?'primary':''}" data-dt-table="${k}">${k==='REPORT'?'PR Report Form':k==='GR_REPORT'?'GR Report Form':k}</button>`).join('')}</div>${reportKind(kind)?`<label>Năm <input type="number" data-dt-report-year aria-label="Năm ${kind==='GR_REPORT'?'GR':'PR'} report" min="2000" max="2100" value="${reportYear}"></label>`:''}<input type="search" data-dt-search placeholder="Tìm trong bảng…" aria-label="Tìm Data Tracking" value="${esc(query)}"><button type="button" class="button" data-dt-reset ${busy?'disabled':''}>Reset bộ lọc</button>${reportKind(kind)?`<label class="small"><input type="checkbox" data-dt-no-repeat ${prefs().noRepeatLabels?'checked':''}> Do not repeat item labels</label>`:''}${pivot.on&&pivot.groups?`<button type="button" class="button" data-dt-collapse ${pivot.groups?'':'disabled'}>${pivot.entries.some(e=>e.type==='group'&&e.collapsed)?'Mở tất cả nhóm':'Thu gọn tất cả nhóm'}</button>`:''}${reportKind(kind)&&visibleMonthColumns(columns).length?`<button type="button" class="button ${keepEmptyRows?'primary':''}" data-dt-showempty title="Mặc định chỉ hiện dòng CÓ tiền trong các cột tháng đang bật (${visibleMonthColumns(columns).map(c=>c.key).join(', ')}). Bấm để xem cả dòng chỉ có tiền ở tháng khác.">${keepEmptyRows?'Ẩn':'Hiện'} dòng chưa có tiền ở cột tháng</button>`:''}<button type="button" class="button" data-dt-settings title="${applied?'Bỏ áp dụng bảng kiểm tra để đổi cài đặt cột':'Column Setting'}" aria-label="Column Setting" ${!value||busy||applied?'disabled':''}>${svg('settings')}</button><button type="button" class="button ${busy?'is-loading':''}" data-dt-reload title="Tải lại dữ liệu" aria-label="Tải lại dữ liệu" ${busy?'disabled':''}>${svg('reload')}</button>${document.documentElement.dataset.downloads==='denied'?'':`<button type="button" class="button ${reportKind(kind)?'primary':''}" data-dt-export title="Xuất báo cáo đang xem (toàn bộ trang, giữ nhóm và subtotal)" aria-label="Export Excel" ${!value||busy?'disabled':''}>${svg('download')}${reportKind(kind)?' Xuất đúng View':''}</button>${kind==='REPORT'?`<button type="button" class="button" data-dt-export-detail title="Xuất dòng PR nguồn trong phạm vi lọc và tháng đang xem" ${!value||busy?'disabled':''}>PR chi tiết</button>`:kind==='GR_REPORT'?`<button type="button" class="button" data-dt-export-gr-detail title="Tải dòng GMRO theo bộ lọc và tháng đang xem" ${!value||busy?'disabled':''}>GR chi tiết</button>`:''}`}</div><p class="small ${error||value?.warning?'amber':'muted'}" role="status">${esc(error||value?.warning||(value?'Cập nhật '+new Date(value.updatedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}):'Chọn bảng để tải SQL.'))}${p.merge.length&&!pivot.on?' · Gộp theo '+esc(p.merge.map(key=>p.columns.find(c=>c.key===key)?.label||key).join(', '))+' trong trang hiện tại':''}${priorityDate()?' · Ưu tiên '+esc(priorityDate())+' gần nhất lên đầu':''}${reportKind(kind)?' · Tabular Form':''}${pivot.on&&pivot.groups?` · Phân cấp ${esc(pivot.texts.filter(c=>pivot.groupLevels.has(c.key)).map(c=>c.label).join(' → '))} · ${pivot.groups} nhóm`:''}${lastHiddenEmpty?` · Ẩn ${lastHiddenEmpty} dòng ${kind==='GR_REPORT'?'GR':'PR'} chỉ có tiền ở tháng khác các cột tháng đang bật (${visibleMonthColumns(columns).map(c=>c.key).join(', ')})`:''}${kind==='PR'&&value?.sheet?.columns?.some(c=>normName(c.name)===normName(fxColumn))?' · '+esc(fxNote):''}</p>${reportKind(kind)?`<p class="dt-report-guide">Pivot ${kind==='GR_REPORT'?'GR':'PR'} · Chọn phạm vi lọc, bấm ▾ trên nhóm để thu/mở. Excel xuất đủ dòng phù hợp bộ lọc, không chỉ trang hiện tại.</p>${kind==='GR_REPORT'?grAuditPanel(value,reportSourceRows(),columns):''}<details class="dt-report-controls" data-dt-report-controls ${reportControlsOpen?'open':''}><summary>Bộ lọc &amp; cấu hình Pivot · ${columns.length} cột · ${prefs().excludedCostCenters?.length||0} Cost Center bị loại · ${Object.values(p.filters).filter(Boolean).length} lọc cột</summary><div class="dt-report-controls-content">${checksBox()}${costCenterFilter(value)}${columnSlicers(p,meta)}</div></details>${kind==='REPORT'?`<details class="dt-report-audit" data-dt-report-audit ${reportAuditOpen?'open':''}><summary>Đối soát PR nguồn (mở khi cần kiểm tra)</summary>${prAuditPanel(value)}</details>`:''}`:`${grAuditPanel(value)}${prAuditPanel(value)}${checksBox()}${costCenterFilter(value)}${columnSlicers(p,meta)}`}<div class="dt-scroll"><table class="dt-table ${pivot.on?'dt-pivot':''}"><thead><tr>${columns.map(c=>`<th class="${widthClass(c.key)} ${meta.get(c.key)?'dt-num':'dt-txt'}" title="${esc(c.key)}">${pivot.on&&pivot.groupLevels.has(c.key)?`<i class="dt-lv">${pivot.texts.indexOf(c)+1}</i>`:''}${esc(c.label)}</th>`).join('')}</tr><tr>${columns.map((c,i)=>`<th class="${widthClass(c.key)} ${meta.get(c.key)?'dt-num':'dt-txt'}"><input type="text" list="dt-values-${kind}-${i}" autocomplete="off" maxlength="500" data-dt-filter="${esc(c.key)}" aria-label="Lọc ${esc(c.label)}" placeholder="Lọc…" value="${esc(p.filters[c.key]||'')}" title="Chọn giá trị hoặc nhập để lọc. Gợi ý tối đa 200 giá trị; bộ lọc áp dụng toàn bộ dữ liệu."><datalist id="dt-values-${kind}-${i}"></datalist></th>`).join('')}</tr></thead><tbody>${busy?`<tr><td colspan="${columns.length||1}" class="empty-state">Đang tải ${kind}…</td></tr>`:pivot.on?pivotBody(current,pivot,columns,meta,prefs().noRepeatLabels,prDetailCellAttr):current.map((row,i)=>`<tr${detailAttr(row)}>${columns.map(c=>{const map=p.merge.includes(c.key)?spans.get(c.key):null,span=map?map.get(i):1,v=text(row[c.key]);if(map&&!span)return '';const cls=[widthClass(c.key),meta.get(c.key)?'dt-num':'dt-txt',map?'dt-merged':''].filter(Boolean).join(' ');return `<td${prDetailCellAttr(row,c)} ${map?`rowspan="${span}"`:''}${cls?` class="${cls}"`:''} title="${esc(v)}">${cellSpan(c,v)}</td>`;}).join('')}</tr>`).join('')||`<tr><td colspan="${columns.length||1}" class="empty-state">${error?'Không tải được dữ liệu.':'Không có dữ liệu phù hợp.'}</td></tr>`}</tbody>${reportKind(kind)&&pivot.grand?`<tfoot>${pivotBody([pivot.grand],pivot,columns,meta,false,prDetailCellAttr)}</tfoot>`:''}</table></div><div class="dt-pagination"><span>${rows.length} / ${value?.sheet.rows.length||0} dòng${reportKind(kind)&&lastMergedFrom!==rows.length?` · đã gộp từ ${lastMergedFrom} dòng ${kind==='GR_REPORT'?'GR':'PR'}`:''} · Trang ${page}/${pages}</span><button class="button" data-dt-prev ${page===1||busy?'disabled':''}>‹</button><button class="button" data-dt-next ${page===pages||busy?'disabled':''}>›</button><select data-dt-size aria-label="Số dòng Data Tracking">${[10,20,50].map(n=>`<option ${n===pageSize?'selected':''}>${n}</option>`).join('')}</select></div></section></div>`;
  const scroller=root.querySelector('.dt-scroll');if(scroller){scroller.scrollTop=scrollTop;scroller.addEventListener('scroll',()=>{if(remembered.state)remembered.state.scrollTop=scroller.scrollTop;},{passive:true});}
  root.querySelectorAll('[data-dt-table]').forEach(el=>el.onclick=()=>{kind=el.dataset.dtTable;grIssueFilter='all';if(reportKind(kind))reportYear=reportYears[kind];query='';page=1;restorePage=0;error='';applied=null;selected.clear();readCachedData();draw();void fetchTable();});
  if(reportKind(kind)&&value){const total=lastAmountTotal,shown=visibleMonthColumns(columns).map(c=>c.key);root.querySelector('[role=status]').append(' · Tổng '+(shown.length?'Amount theo cột tháng đang hiện ('+shown.join(', ')+')':'Amount cả năm')+' trong bộ lọc: '+new Intl.NumberFormat('en-US',{maximumFractionDigits:2}).format(total)+' USD · Tỷ giá VND 26.000 / JPY 180 / USD 1');}
  const changePeriod=()=>{const year=Number(root.querySelector('[data-dt-report-year]').value);if(!Number.isInteger(year)||year<2000||year>2100)return;reportYear=year;reportYears[kind]=year;records.delete(kind);loadedAt.delete(kind);settings.delete(kind);readCachedData();applied=null;query='';page=1;restorePage=0;draw();void fetchTable();};root.querySelector('[data-dt-report-year]')?.addEventListener('change',changePeriod);
  const bindInput=(el,fn)=>el.addEventListener('input',()=>{const key=el.dataset.dtFilter,cursor=el.selectionStart;fn(el.value);page=1;restorePage=0;draw();const next=key?[...root.querySelectorAll('[data-dt-filter]')].find(n=>n.dataset.dtFilter===key):root.querySelector('[data-dt-search]');next.focus();if(cursor!==null)next.setSelectionRange(cursor,cursor);});
  function suggestions(el){if(!value)return;let cache=choices.get(value);if(!cache){cache=new Map();choices.set(value,cache);}const key=el.dataset.dtFilter;if(!cache.has(key))cache.set(key,[...new Set(value.sheet.rows.map(row=>text(row[key]).slice(0,500)))].sort((a,b)=>a.localeCompare(b,'vi',{numeric:true})));const q=el.value.toLocaleLowerCase();el.list.innerHTML=cache.get(key).filter(v=>!q||v.toLocaleLowerCase().includes(q)).slice(0,200).map(v=>`<option value="${esc(v)}"></option>`).join('');}
  root.querySelectorAll('[data-dt-filter]').forEach(el=>el.addEventListener('focus',()=>suggestions(el)));
  bindInput(root.querySelector('[data-dt-search]'),v=>{query=v;p.search=v;persist();});root.querySelectorAll('[data-dt-filter]').forEach(el=>bindInput(el,v=>{p.filters={...p.filters,[el.dataset.dtFilter]:v};persist();}));
  root.querySelector('[data-dt-report-controls]')?.addEventListener('toggle',e=>{reportControlsOpen=e.currentTarget.open;});
  root.querySelector('[data-dt-report-audit]')?.addEventListener('toggle',e=>{reportAuditOpen=e.currentTarget.open;});
  root.querySelector('[data-dt-export-detail]')?.addEventListener('click',()=>{
   try{const sheet=prRawDetailSheet(rows,columns);if(!sheet){toast('Chưa có PR chi tiết. Bấm Tải lại rồi thử lại.');return;}
    exportWorkbook([sheet],`PR-detail-${reportYear}`);}catch(e){toast(e.message);}
  });
  root.querySelector('[data-dt-export-gr-detail]')?.addEventListener('click',()=>{
   try{const sheet=grRawDetailSheet(rows,columns);if(!sheet){toast('Chưa có GR chi tiết. Bấm Tải lại rồi thử lại.');return;}exportWorkbook([sheet],`GR-detail-${reportYear}`);}catch(e){toast(e.message);}
  });
  root.querySelector('[data-dt-slicers-toggle]')?.addEventListener('click',()=>{prefs().hideSlicers=!prefs().hideSlicers;persist();draw();root.querySelector('[data-dt-slicers-toggle]')?.focus();});
  const saveColumnSelection=()=>{p.merge=mergeOrder(p.merge,p.columns);persist();pivotCollapsed.clear();page=1;restorePage=0;draw();};
  root.querySelectorAll('[data-dt-column-toggle]').forEach(el=>el.onclick=()=>{
   if(busy||applied)return;const c=p.columns.find(c=>c.key===el.dataset.dtColumnToggle);if(!c)return;
   if(c.visible&&p.columns.filter(c=>c.visible).length===1){toast('Cần giữ lại ít nhất một cột.');return;}
   c.visible=!c.visible;saveColumnSelection();
   [...root.querySelectorAll('[data-dt-column-toggle]')].find(button=>button.dataset.dtColumnToggle===c.key)?.focus();
  });
  root.querySelector('[data-dt-columns-all]')?.addEventListener('click',()=>{if(busy||applied)return;p.columns.forEach(c=>c.visible=true);saveColumnSelection();});
  root.querySelector('[data-dt-reset]').onclick=()=>{query='';grIssueFilter='all';p.search='';p.filters={};if(reportKind(kind))prefs().excludedCostCenters=[];persist();page=1;restorePage=0;draw();};const ccBox=root.querySelector('[data-dt-cc]');if(ccBox){const setExcluded=list=>{prefs().excludedCostCenters=list;persist();page=1;restorePage=0;draw();};ccBox.addEventListener('toggle',()=>{costCenterOpen=ccBox.open;});ccBox.querySelectorAll('[data-dt-cc-value]').forEach(el=>el.onchange=()=>{const set=new Set(prefs().excludedCostCenters||[]),cc=el.dataset.dtCcValue;if(el.checked)set.delete(cc);else set.add(cc);setExcluded([...set]);});ccBox.querySelector('[data-dt-cc-all]').onclick=()=>setExcluded([]);ccBox.querySelector('[data-dt-cc-none]').onclick=()=>setExcluded([...new Set((value?.sheet.rows||[]).map(costCenterOf))]);}root.querySelector('[data-dt-prev]').onclick=()=>{restorePage=0;page--;draw();};root.querySelector('[data-dt-next]').onclick=()=>{restorePage=0;page++;draw();};root.querySelector('[data-dt-size]').onchange=e=>{pageSize=Number(e.target.value);page=1;restorePage=0;draw();};root.querySelector('[data-dt-reload]').onclick=()=>fetchTable(true);root.querySelector('[data-dt-settings]').onclick=columnSettings;
  root.querySelector('[data-dt-collapse]')&&(root.querySelector('[data-dt-collapse]').onclick=()=>{const groups=pivot.allGroupIds||pivot.entries.filter(e=>e.type==='group').map(e=>e.id);if(groups.some(id=>pivotCollapsed.has(id)))pivotCollapsed.clear();else for(const id of groups)pivotCollapsed.add(id);page=1;restorePage=0;draw();});
  root.querySelectorAll('[data-dt-pivot]').forEach(el=>el.onclick=()=>{const id=decodeURIComponent(el.dataset.dtPivot);if(pivotCollapsed.has(id))pivotCollapsed.delete(id);else pivotCollapsed.add(id);draw();});
  root.querySelectorAll('[data-dt-detail]').forEach(el=>{const open=()=>openGRDetails(el.dataset.dtDetail);el.addEventListener('click',open);el.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open();}});});
  root.querySelectorAll('[data-dt-gr-focus]').forEach(el=>el.onclick=()=>{grIssueFilter=el.dataset.dtGrFocus;page=1;restorePage=0;draw();});
  root.querySelectorAll('[data-dt-gr-cell]').forEach(el=>{const open=event=>{event?.stopPropagation();const ctx=grDetailContexts.get(el.dataset.dtGrCell);if(ctx)openGRAmount(ctx);};el.addEventListener('click',open);el.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open(event);}});});
  root.querySelectorAll('[data-dt-pr-detail]').forEach(el=>{const open=()=>openPRDetails(prDetailContexts.get(el.dataset.dtPrDetail));el.addEventListener('click',open);el.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open();}});});
  // Đang bật cột tháng nào thì mặc định chỉ hiện dòng CÓ tiền ở cột tháng đó; nút này để xem cả
  // dòng chỉ có tiền ở tháng khác (PR 1012962453 = 6,66 USD tháng 2), lựa chọn được lưu lại.
  root.querySelector('[data-dt-no-repeat]')?.addEventListener('change',e=>{prefs().noRepeatLabels=e.target.checked;persist();draw();});
  root.querySelector('[data-dt-showempty]')?.addEventListener('click',()=>{const p=view();p.showEmptyMonth=!(p.showEmptyMonth===true);keepEmptyRows=p.showEmptyMonth===true;persist();page=1;restorePage=0;draw();});
  root.querySelector('[data-dt-check-save]')?.addEventListener('click',saveCheckDialog);root.querySelector('[data-dt-check-export]')?.addEventListener('click',exportChecks);
  root.querySelectorAll('[data-dt-check-toggle]').forEach(el=>el.onchange=()=>{const name=el.dataset.dtCheckToggle;if(el.checked)selected.add(name);else selected.delete(name);if(selected.size===1)applyCheck([...selected][0]);else if(!selected.size&&applied)unapply();draw();});
  root.querySelectorAll('[data-dt-check-apply]').forEach(el=>el.onclick=()=>{const name=el.dataset.dtCheckApply;if(applied?.name===name){selected.delete(name);unapply();}else{selected.clear();selected.add(name);applyCheck(name);}draw();});
  root.querySelectorAll('[data-dt-check-delete]').forEach(el=>el.onclick=()=>{if(!canDeleteCheck()){toast('Chỉ tài khoản Hien.thanh được xóa bảng PR report.');return;}const name=el.dataset.dtCheckDelete;if(!confirm('Xóa bảng kiểm tra "'+name+'"?'))return;const box=checks();delete box[name];if(presetFor(kind)?.name===name)(removedChecks.get(user+'\n'+kind)||removedChecks.set(user+'\n'+kind,new Set()).get(user+'\n'+kind)).add(name);saveChecks();selected.delete(name);if(applied?.name===name){applied=null;query=prefs().search;page=1;restorePage=0;}draw();});
  root.querySelector('[data-dt-export]')?.addEventListener('click',()=>{if(reportKind(kind)){try{const main=reportExcelSheet(rows,columns,meta,pivot);if(kind==='GR_REPORT'){const issues=reasonIssueSheet(value,main),raw=grRawDetailSheet(rows,columns),bad=grRawDetailSheet(rows,columns,true);exportWorkbook([main,...(raw?[raw]:[]),...(bad?[bad]:[]),...(issues?[issues]:[])],'GR-report-'+reportYear);}else{const issues=reasonIssueSheet(value,main);exportWorkbook([main,...(issues?[issues]:[])],'PR-report-'+reportYear);}if(!Array.isArray(value?.reasonIssues))toast('Dữ liệu đang xem là bản lưu cũ, chưa có danh sách dòng thiếu Type. Bấm Tải lại rồi xuất Excel lần nữa.');}catch(e){toast(e.message);}return;}const sheetColumns=columns.map(c=>({key:c.key,label:esc(c.label)}));exportWorkbook([{name:kind,columns:sheetColumns,rows:rows.map(row=>Object.fromEntries(sheetColumns.map(c=>[c.key,row[c.key]]))),merges:mergeRanges(rows,p.merge,columns.map(c=>c.key))}],'Data-Tracking-'+kind);});
 }
 function columnSettings(){const p=prefs(),draft=structuredClone(p);let dragged=null,query='';
  const group=visible=>draft.columns.filter(c=>c.visible===visible);
  function move(sourceKey,targetKey,after=false){const source=draft.columns.find(c=>c.key===sourceKey),target=draft.columns.find(c=>c.key===targetKey);if(!source||!target||source===target)return false;if(source.visible!==target.visible){const status=document.querySelector('[data-dt-config] [role=status]');if(status)status.textContent='Kéo trong cùng nhóm cột đang hiện hoặc đang ẩn.';return false;}const ordered=group(source.visible).filter(c=>c!==source),at=ordered.indexOf(target)+(after?1:0);ordered.splice(at,0,source);let i=0;draft.columns=draft.columns.map(c=>c.visible===source.visible?ordered[i++]:c);show();return true;}
  function show(){const displayed=[...group(true),...group(false)].filter(c=>!query||[c.key,c.label].some(v=>v.toLocaleLowerCase().includes(query.toLocaleLowerCase()))),allVisible=draft.columns.every(c=>c.visible);showDetail('Column Setting · '+kind,`<form data-dt-config><p class="small muted">Kéo thả hoặc dùng mũi tên để đổi thứ tự trong nhóm hiện/ẩn. Cột ẩn ở cuối danh sách; bật lại sẽ về vị trí đã lưu. Tích "Gộp" vào nhiều cột để không lặp lại thông tin trùng (cột bên trái là nhóm ngoài, cột bên phải chỉ gộp khi trùng cả nhóm bên trái; chỉ ảnh hưởng hiển thị trên trang, Excel vẫn giữ từng dòng). Hủy không thay đổi cài đặt.</p><div class="dt-config-controls"><label class="dt-config-search"><span>Tìm cột</span><input type="search" data-dt-column-search value="${esc(query)}" placeholder="Tên SQL hoặc tên hiển thị"></label></div><div class="dt-config-scroll"><table><thead><tr><th>Hiện</th><th>Tên cột SQL</th><th>Tên hiển thị</th><th>Thứ tự</th><th>Gộp <input type="checkbox" data-dt-visible-all ${allVisible?'checked':''} aria-label="Bật hoặc tắt tất cả cột"></th></tr></thead><tbody>${displayed.map(c=>{const peers=group(c.visible),i=draft.columns.indexOf(c),at=peers.indexOf(c);return `<tr data-dt-index="${i}" data-dt-column="${esc(c.key)}" class="${c.visible?'':'dt-column-hidden'}" draggable="true"><td><input type="checkbox" data-dt-visible ${c.visible?'checked':''} aria-label="Hiện ${esc(c.key)}"></td><td>${esc(c.key)}${c.visible?'':'<small class="dt-hidden-label">Đang ẩn</small>'}</td><td><input data-dt-label maxlength="80" value="${esc(c.label)}" required aria-label="Tên hiển thị ${esc(c.key)}"></td><td><span class="dt-column-move"><button class="button dt-drag-handle" draggable="true" type="button" title="Kéo để đổi thứ tự" aria-label="Kéo ${esc(c.key)}">⠿</button><button class="button" type="button" data-dt-up ${!at?'disabled':''} aria-label="Lên ${esc(c.key)}">↑</button><button class="button" type="button" data-dt-down ${at===peers.length-1?'disabled':''} aria-label="Xuống ${esc(c.key)}">↓</button></span></td><td><input type="checkbox" data-dt-merge ${draft.merge.includes(c.key)?'checked':''} ${c.visible?'':'disabled'} aria-label="Gộp ${esc(c.key)}"></td></tr>`;}).join('')||'<tr><td colspan="5" class="empty-state">Không tìm thấy cột.</td></tr>'}</tbody></table></div><p role="status" class="small muted"></p><p role="alert" class="red"></p><div class="account-actions"><button type="button" class="button" data-dt-cancel>Hủy</button><button type="submit" class="button primary">Lưu cài đặt</button></div></form>`);
   const form=document.querySelector('[data-dt-config]'),master=form.querySelector('[data-dt-visible-all]');master.indeterminate=!allVisible&&draft.columns.some(c=>c.visible);master.onchange=e=>{draft.columns.forEach(c=>c.visible=e.target.checked);if(!e.target.checked)draft.merge=[];show();};form.querySelector('[data-dt-column-search]').oninput=e=>{query=e.target.value;show();};form.querySelectorAll('[data-dt-label]').forEach(el=>el.oninput=()=>draft.columns[Number(el.closest('tr').dataset.dtIndex)].label=el.value);form.querySelectorAll('[data-dt-merge]').forEach(el=>el.onchange=()=>{const c=draft.columns[Number(el.closest('tr').dataset.dtIndex)];draft.merge=el.checked?[...new Set([...draft.merge,c.key])]:draft.merge.filter(key=>key!==c.key);show();});form.querySelectorAll('[data-dt-visible]').forEach(el=>el.onchange=()=>{const c=draft.columns[Number(el.closest('tr').dataset.dtIndex)];c.visible=el.checked;if(!c.visible)draft.merge=draft.merge.filter(key=>key!==c.key);show();});
   for(const [selector,delta]of [['[data-dt-up]',-1],['[data-dt-down]',1]])form.querySelectorAll(selector).forEach(el=>el.onclick=()=>{const c=draft.columns[Number(el.closest('tr').dataset.dtIndex)],peers=group(c.visible),target=peers[peers.indexOf(c)+delta];if(target)move(c.key,target.key,delta>0);});
   const clearDrag=()=>form.querySelectorAll('.dt-drop-before,.dt-drop-after').forEach(el=>el.classList.remove('dt-drop-before','dt-drop-after'));
   form.addEventListener('dragstart',e=>{const row=e.target.closest('[data-dt-column]');if(!row||e.target.closest('input')||(e.target.closest('button')&&!e.target.closest('.dt-drag-handle'))){e.preventDefault();return;}dragged=row.dataset.dtColumn;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',dragged);});
   form.addEventListener('dragover',e=>{const row=e.target.closest('[data-dt-column]');if(!row||!dragged)return;e.preventDefault();e.dataTransfer.dropEffect='move';const box=form.querySelector('.dt-config-scroll'),bounds=box.getBoundingClientRect();if(e.clientY<bounds.top+36)box.scrollBy({top:-24});else if(e.clientY>bounds.bottom-36)box.scrollBy({top:24});clearDrag();const rect=row.getBoundingClientRect();row.classList.add(e.clientY>rect.top+rect.height/2?'dt-drop-after':'dt-drop-before');});
   form.addEventListener('wheel',e=>{if(!dragged)return;const box=form.querySelector('.dt-config-scroll');box.scrollBy({top:e.deltaY});e.preventDefault();},{passive:false});
   form.addEventListener('drop',e=>{const row=e.target.closest('[data-dt-column]');if(!row||!dragged)return;e.preventDefault();const source=dragged;dragged=null;const after=row.classList.contains('dt-drop-after');clearDrag();move(source,row.dataset.dtColumn,after);});
   form.addEventListener('dragend',()=>{dragged=null;clearDrag();});
   form.querySelector('[data-dt-cancel]').onclick=()=>document.getElementById('detail').close();form.onsubmit=e=>{e.preventDefault();const labels=draft.columns.map(c=>c.label.trim());if(labels.some(l=>!l)||new Set(labels).size!==labels.length){form.querySelector('[role=alert]').textContent='Tên hiển thị không được để trống hoặc trùng.';return;}draft.columns.forEach(c=>c.label=c.label.trim());draft.merge=mergeOrder(draft.merge,draft.columns);settings.set(kind,draft);persist();page=1;restorePage=0;document.getElementById('detail').close();draw();};
  }show();}

  async function fetchTable(reload=false){const requestKind=kind,requestYear=reportYear,requestId=++requestSequence;busy=true;error='';draw();try{if(!user){const current=(await session())?.user;user=current?.id;username=current?.username||'';if(!user)throw Error('Cần đăng nhập lại để xem dữ liệu.');}if(!records.has(requestKind)||reload||Date.now()-(loadedAt.get(requestKind)||0)>=120000){const result=await load(requestKind,reload||records.has(requestKind),{year:requestYear});if(requestId!==requestSequence)return;const viewResult=requestKind==='PR'?withPRViewSheet(result):result;records.set(requestKind,viewResult);loadedAt.set(requestKind,Date.now());saveCachedData(viewResult,requestKind,requestYear);lastRead=Date.now();settings.delete(requestKind);if(applied){const v=resolveCheck(applied);if(v)Object.assign(applied,v);else{applied=null;selected.clear();}}}}catch(e){if(requestId===requestSequence){error=e.message;lastRead=Date.now();}}finally{if(requestId===requestSequence){busy=false;query=view().search||'';if(root.isConnected)draw();}}}
  draw();void (async()=>{try{const s=await session();user=s?.user?.id||'';username=s?.user?.username||'';if(readCachedData())draw();await fetchTable();}catch{/* fetchTable giữ lỗi tải trong trạng thái màn hình; session lỗi thì chờ đăng nhập lại. */}})();const observer=new MutationObserver(()=>{if(!root.isConnected)observer.disconnect();});observer.observe(root,{attributes:true,attributeFilter:['hidden']});return {reload:()=>fetchTable(true)};
}
