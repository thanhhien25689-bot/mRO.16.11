/**
 * Pure PR Report Form presentation layer. Never changes underlying PR rows or
 * Amount conversion/rounding policy. Both the browser table and XLSX export
 * consume the same entry sequence returned here.
 */
export function createPrPivot(rows, columns, meta, collapsed = new Set(), options = {}) {
  const texts = columns.filter(c => !meta.get(c.key));
  const nums = columns.filter(c => meta.get(c.key));
  const exclude = new Set(['PR_NO','PR_SEQ','PURCHASE_REQ_INFO','RECEIVER',...(options.excludeGroups||[])].map(c=>c.toUpperCase()));
  const eligible = texts.filter(c => !exclude.has(c.key.toUpperCase()));
  const levels = eligible.slice(0, 2);
  const entries = [], allGroupIds = [], groupLevels = new Set(levels.map(c => c.key));
  const asLabel = v => v === null || v === undefined ? 'Null' : String(v);
  let stripe = 0;
  const sums = members => {
    const row = Object.fromEntries(columns.map(c => [c.key, '']));
    for (const c of nums) {
      let total = 0, hasValue = false;
      for (const member of members) {
        if (member[c.key] === '' || member[c.key] == null) continue;
        const n = Number(member[c.key]);
        if (!Number.isFinite(n)) continue;
        total += n;
        hasValue = true;
      }
      row[c.key] = hasValue ? Number(total.toFixed(2)) : '';
    }
    const detail = new Set();
    for (const member of members) if (Array.isArray(member.__detailIds))
      for (const id of member.__detailIds) detail.add(id);
    if (detail.size) row.__detailIds = [...detail];
    return row;
  };
  const leaf = member => entries.push({type: 'row', row: member, odd: (stripe++ % 2) === 1});
  function descend(members, depth, path) {
    if (depth >= levels.length) { for (const member of members) leaf(member); return; }
    const field = levels[depth], buckets = new Map();
    for (const member of members) {
      const label = asLabel(member[field.key]);
      if (!buckets.has(label)) buckets.set(label, []);
      buckets.get(label).push(member);
    }
    for (const [label, subset] of buckets) {
      // A one-line group already IS the result of a pivot aggregation: don't
      // add redundant header/subtotal copies of its monetary values.
      if (subset.length === 1) { descend(subset, levels.length, path); continue; }
      const nextPath = [...path, [field.key, label]];
      const id = (options.prefix||'REPORT') + '\u0000' + JSON.stringify(nextPath);
      const isCollapsed = collapsed.has(id);
      const total = sums(subset);
      allGroupIds.push(id);
      entries.push({type: 'group', row: total, id, level: depth, label,
        groupKey: field.key, collapsed: isCollapsed, count: subset.length});
      if (!isCollapsed) {
        descend(subset, depth + 1, nextPath);
        entries.push({type: 'subtotal', row: total, level: depth,
          label: 'Tổng ' + label, groupKey: field.key, count: subset.length});
      }
    }
  }
  descend(rows, 0, []);
  const grand = texts.length && rows.length
    ? {type: 'grand', row: sums(rows), label: 'Grand Total', groupKey: texts[0].key}
    : null;
  return {on: true, entries, texts, nums, groups: allGroupIds.length,
    allGroupIds, groupLevels, grand};
}
