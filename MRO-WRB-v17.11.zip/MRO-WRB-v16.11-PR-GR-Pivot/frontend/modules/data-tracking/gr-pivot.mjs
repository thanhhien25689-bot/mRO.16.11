/**
 * GR view-only model. It never changes the GMRO/PR matching, currencies, amount
 * conversion, or original source data. All aggregations use already-computed
 * values from the existing backend report.
 */
import {createPrPivot} from './pr-pivot.mjs';

// GR's diagnostic fields are useful for filtering, but NOT useful as the
// main nested hierarchy. Selecting Type/Project should act like Excel Pivot.
export function createGrPivot(rows,columns,meta,collapsed=new Set()) {
 return createPrPivot(rows,columns,meta,collapsed,{
  prefix:'GR_REPORT',excludeGroups:['Class','Thiếu Type','Reason Source','Match Status']
 });
}

export function grMatchesFocus(row,focus) {
 const status=String(row?.['Match Status']??'');
 if(focus==='all')return true;
 if(focus==='matched')return status==='Matched';
 if(focus==='problem-pr')return status==='Unmatched PR'||status==='Ambiguous Match';
 if(focus==='data-issues')return Boolean(String(row?.['Thiếu Type']??'').trim()||!String(row?.Class??'').trim()||row?.__unconverted);
 return true;
}

const monthOf=date=>{const match=String(date??'').match(/^\d{4}-(\d{2})-\d{2}/);return match?Number(match[1]):null;};
const visibleLine=(row,months)=>{
 if(!months.length)return true;
 const month=monthOf(row.GR_DATE);
 // Undated/invalid-source transactions must be visible for data quality checks.
 // Never assign them an invented month; surface them explicitly.
 return month===null||months.includes(month);
};

/** Return each GMRO source once, within the report's filtered group IDs.
 *  The id relation is supplied by the backend; no PO/PR re-joining.
 *  Enrich with Class/Reason status for the issue sheet, without touching SQL.
 */
export function grSourceLines(reportRows,details,months=[]) {
 const groupById=new Map();
 for(const group of reportRows||[]){
  for(const id of group.__detailIds||[])groupById.set(String(id),group);
 }
 const wanted=new Set((months||[]).map(Number));const chosen=[...wanted];
 return (details||[]).filter(row=>groupById.has(String(row.id))&&visibleLine(row,chosen)).map(row=>{
  const group=groupById.get(String(row.id));
  return {...row,Class:group.Class,'Thiếu Type':group['Thiếu Type']};
 });
}

export function grProblemReasons(row){
 const issues=[];
 const match=String(row?.['Match Status']??'');
 if(match==='Unmatched PR')issues.push('Không ghép được PR');
 if(match==='Ambiguous Match')issues.push('Nhiều PR ứng viên');
 if(String(row?.['Thiếu Type']??'').trim())issues.push('Reason thiếu hoặc sai mẫu');
 if(!String(row?.Class??'').trim()&&match==='Matched')issues.push('Thiếu GL Class');
 if(row?.['Amount USD']===null||row?.['Amount USD']===undefined||row?.['Amount USD']==='')issues.push('Chưa quy đổi USD');
 return issues;
}

/** KPI counts source GR lines, not grouped Pivot rows. The displayed amount
 *  follows the current visible-month Amount rule (including negative GRs).
 */
export function grSummary(reportRows,details,months=[]) {
 const selected=grSourceLines(reportRows,details,months);
 let matched=0,unmatched=0,ambiguous=0,issues=0,unconverted=0;
 for(const row of selected){
  if(row['Match Status']==='Matched')matched++;
  else if(row['Match Status']==='Unmatched PR')unmatched++;
  else if(row['Match Status']==='Ambiguous Match')ambiguous++;
  if(grProblemReasons(row).length)issues++;
  if(row['Amount USD']===null||row['Amount USD']===undefined||row['Amount USD']==='')unconverted++;
 }
 const haveMonths=months?.length>0;
 let amount=0;
 for(const row of reportRows||[]){
  if(haveMonths){
   for(const m of months){const v=row[String(m)];if(v!==''&&v!=null&&Number.isFinite(Number(v)))amount+=Number(v);}
  }else if(row.Amount!==''&&row.Amount!=null&&Number.isFinite(Number(row.Amount)))amount+=Number(row.Amount);
 }
 return {amount:Number(amount.toFixed(2)),matched,unmatched,ambiguous,issues,unconverted,sourceRows:selected.length};
}
