import {toast} from '../../shared/ui/index.mjs';
import {render,renderSqlCodes} from './view.mjs';
import {confirmReady} from './actions.mjs';
import {cardFilters} from './cards.mjs';
export {cardFilters};
export function mount(root,data,presentation){
 if(data.codesSource)return renderSqlCodes(root,data,presentation.api,presentation.canEditBusiness);
 const controller=render(root,data,presentation,(r,f)=>{
  confirmReady(data,r,f);
  document.getElementById('detail').close();
  document.dispatchEvent(new CustomEvent('data-edited',{detail:{views:['codes','tracking','projects','overview']}}));
  toast('Đã xác nhận mã và bàn giao PIC3.');
 });
 return Object.assign(controller,{cardFilters:cardFilters()});
}

