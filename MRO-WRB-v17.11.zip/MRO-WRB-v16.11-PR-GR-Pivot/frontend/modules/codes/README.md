# Codes — Phase 6C

## Public interface

Chỉ import index.mjs: mount(root,data,presentation), cardFilters(). presentation chứa badge từ host facade. mount trả table controller kèm cardFilters. Host modules/codes/index.mjs giữ chữ ký mount(root,data); public-card-filters.mjs giữ compatibility facade.

## Ownership và cấu trúc

- index: mount, nối callback, đóng dialog, phát data-edited rồi toast.
- view: HTML/table/detail/form giữ nguyên; không mutation.
- cards: năm descriptor giữ key/thứ tự/filter legacy.
- selectors: countStatus cho màn mẫu legacy; actionReady/statusTest/countCard là công thức đếm thẻ+tab của màn SQL: Cần xử lý và Quá hạn bỏ dòng đã xác nhận Hành động = Ready for PR; Đang xử lý bỏ dòng đã xác nhận và tính cả dòng Trạng thái Ready for PR chưa xác nhận; Ready for PR chỉ đếm dòng Trạng thái Ready for PR đã có Hành động = Ready for PR. SOP vẫn dùng shared/model facade vì xuyên màn.
- actions: confirmReady(data,code,formData), cập nhật code trước rồi gọi public integration.
- tests: unit ownership/filter/duplicate/orphan và browser dark/light/KPI/filter/reset/detail/validation/cancel/CSV/navigation.

Codes sở hữu codes. Public handoffFirstRequestForReadyCode ở frontend/integration/procurement.mjs chỉ tìm request đầu tiên cùng ID bằng find và đổi owner PIC3; không sửa request khác, không tạo request cho orphan, không ghi tracking. Metadata procurementContract giữ nguyên.

Dependency: own → public Shared UI, shared/model facade và procurement public. Không import internal Orders/Tracking. Shared không import Codes; core registry vẫn gọi facade. Không fetch/persist trong module.

Chạy npm test; browser qua tests/codes.browser.cjs với Playwright/Chrome. MRO_FRONTEND_BASELINE trỏ source baseline để đối chiếu cùng kịch bản. Ready mutation thực, thứ tự event/remount/toast và duplicate/orphan được kiểm tra thêm bởi tests/procurement.browser.cjs. Test dùng runtime tạm, không seed dữ liệu thật.
