import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import * as api from '../index.mjs';
import {confirmReady} from '../actions.mjs';
import {countStatus,countCard,statusTest,actionReady} from '../selectors.mjs';
import {handoffFirstRequestForReadyCode} from '../../../integration/procurement.mjs';
const data=JSON.parse(readFileSync(new URL('../../../../tests/fixtures/legacy-raw.json',import.meta.url)));
test('Codes public API, KPI selectors and card mapping preserve legacy results',()=>{
 assert.deepEqual(Object.keys(api).sort(),['cardFilters','mount']);
 const cards=api.cardFilters(),statuses=['Đang xử lý','Sắp quá hạn','Quá hạn','Ready for PR'];
 assert.deepEqual(cards.map(c=>c.key),['all','processing','due-soon','overdue','ready-for-pr']);
 assert.deepEqual(data.codes.filter(cards[0].filter),data.codes);
 statuses.forEach((status,i)=>{const expected=data.codes.filter(r=>r.status===status);assert.deepEqual(data.codes.filter(cards[i+1].filter),expected);assert.equal(countStatus(data.codes,status),expected.length);});
});
test('Ready preserves field order, identity and first request only with duplicate IDs',()=>{
 const d=structuredClone(data),r=d.codes[0];d.requests=[{id:r.id,owner:'PIC1',status:'unchanged'},{id:r.id,owner:'PIC2'},{id:'other',owner:'PIC1'}];
 const before=structuredClone(d),requests=d.requests,codes=d.codes,first=d.requests[0],second=d.requests[1];
 const f=new Map([['code',' READY <& '],['reason','reason']]);const lower=Date.now();confirmReady(d,r,f);const upper=Date.now();
 const expected={...before.codes[0],purchaseCode:' READY <& ',reason:'reason',confirmedAt:r.confirmedAt,status:'Ready for PR',step:'Ready for PR',owner:'PIC3'};
 assert.deepEqual(r,expected);assert.deepEqual(Object.keys(r),Object.keys(expected));assert.ok(Date.parse(r.confirmedAt)>=lower&&Date.parse(r.confirmedAt)<=upper);
 assert.equal(d.codes,codes);assert.equal(d.requests,requests);assert.equal(d.requests[0],first);assert.equal(d.requests[1],second);
 assert.deepEqual(d.requests,[{...before.requests[0],owner:'PIC3'},...before.requests.slice(1)]);
 assert.deepEqual(d.codes.slice(1),before.codes.slice(1));assert.deepEqual({...d,codes:null,requests:null},{...before,codes:null,requests:null});
});
test('Orphan and duplicate codes are not repaired or expanded on Ready',()=>{
 const d=structuredClone(data),r=d.codes[0];d.requests=[];d.codes.push({...r});const duplicate=d.codes.at(-1),saved=structuredClone(duplicate),tracking=structuredClone(d.tracking);
 confirmReady(d,r,new Map([['code','X'],['reason','Y']]));assert.equal(r.owner,'PIC3');assert.deepEqual(d.requests,[]);assert.deepEqual(duplicate,saved);assert.deepEqual(d.tracking,tracking);
});
test('Public Ready handoff changes only first request owner, strict ID match, orphan no-op',()=>{
 const d={requests:[{id:1,owner:'A'},{id:'1',owner:'B'},{id:'1',owner:'C'}],codes:[{id:'1'}],tracking:[]},before=structuredClone(d);
 handoffFirstRequestForReadyCode(d,{id:'1'});assert.deepEqual(d,{...before,requests:[before.requests[0],{...before.requests[1],owner:'PIC3'},before.requests[2]]});
 const after=structuredClone(d);handoffFirstRequestForReadyCode(d,{id:'absent'});assert.deepEqual(d,after);
});
test('Ready action adds no validation or normalization beyond legacy form',()=>{
 const d=structuredClone(data),r=d.codes[0];confirmReady(d,r,new Map([['code',''],['reason','']]));assert.equal(r.purchaseCode,'');assert.equal(r.reason,'');assert.equal(r.status,'Ready for PR');
});
test('Thẻ và tab Codes bỏ dòng đã xác nhận Ready; dòng Trạng thái Ready for PR chưa Hành động đếm vào Đang xử lý',()=>{
 const rows=[{status:'Cần xử lý',action:''},{status:'Cần xử lý',action:'Ready for PR'},{status:'Cần xử lý',action:'Đã hủy'},{status:'Đang xử lý',action:''},{status:'Đang xử lý',action:'Ready for PR'},{status:'Quá hạn',action:''},{status:'Quá hạn',action:'Ready for PR'},{status:'Ready for PR',action:'Ready for PR'},{status:'Ready for PR',action:''}];
 assert.equal(countCard(rows,'Cần xử lý'),2);assert.equal(countCard(rows,'Đang xử lý'),2,'Đang xử lý gồm dòng Trạng thái Ready for PR chưa bấm Ready');assert.equal(countCard(rows,'Quá hạn'),1);assert.equal(countCard(rows,'Ready for PR'),1,'Ready for PR chỉ đếm dòng đã Hành động = Ready for PR');
 assert.deepEqual(rows.filter(statusTest('Đang xử lý')).map(r=>r.status),['Đang xử lý','Ready for PR'],'thẻ Đang xử lý bỏ dòng đã xác nhận và nhận dòng Ready for PR chưa xác nhận');assert.deepEqual(rows.filter(statusTest('Đang xử lý')).map(r=>r.action),['',''],'cả hai dòng Đang xử lý đều chưa có Hành động');assert.deepEqual(rows.filter(statusTest('Cần xử lý')).map(r=>r.action),['','Đã hủy']);assert.deepEqual(rows.filter(statusTest('Ready for PR')).map(r=>r.status),['Ready for PR'],'tab Ready for PR chỉ gồm dòng đã xác nhận');assert.equal(actionReady({action:'Ready for PR'}),true);
 assert.equal(countCard(rows,'Cần xử lý')+countCard(rows,'Đang xử lý')+countCard(rows,'Quá hạn')+countCard(rows,'Ready for PR')+rows.filter(actionReady).filter(r=>r.status!=='Ready for PR').length,rows.length,'mọi dòng chỉ thuộc một thẻ đếm, dòng đã Ready chỉ còn ở Confirm for order');
 assert.equal(countStatus(rows,'Cần xử lý'),3,'màn mẫu legacy vẫn đếm theo cột Trạng thái');assert.equal(countStatus(rows,'Ready for PR'),2,'màn mẫu legacy vẫn đếm đủ theo cột Trạng thái');
 const view=readFileSync(new URL('../view.mjs',import.meta.url),'utf8');
 assert.ok(view.includes("'Đang xử lý':'Bỏ dòng Hành động = Ready for PR · tính cả dòng Trạng thái Ready for PR chưa xác nhận'"),'hint thẻ Đang xử lý phải nêu cả dòng Ready for PR chưa xác nhận');
 assert.ok(view.includes("'Ready for PR':'Trạng thái Ready for PR và Hành động = Ready for PR'"),'hint thẻ Ready for PR phải nêu cả Hành động đã xác nhận');
 assert.ok(view.includes("cardHints[s]||'Theo cột Trạng thái'"),'thẻ phải lấy chú thích từ cardHints');
 assert.ok(view.includes('thẻ và tab Cần xử lý, Đang xử lý, Quá hạn không đếm dòng này'),'tooltip Trạng thái phải giải thích dòng đã Ready không đếm ở ba thẻ này');
 assert.ok(view.includes('vẫn đếm ở thẻ và tab Đang xử lý, không đếm ở thẻ và tab Ready for PR'),'tooltip phải giải thích dòng Ready for PR chưa Hành động vẫn thuộc Đang xử lý');
 assert.ok(!view.includes('const actionReady=r=>')&&!view.includes("r.status==='Đang xử lý'||r.status==='Ready for PR'"),'view phải dùng selectors.mjs làm công thức đếm duy nhất');
});


test('P.A.1: Purchase Code gợi ý = mã mua gần nhất, ưu tiên Ready for PR, bỏ mã đã dùng ở dòng cùng Order',async()=>{
 const {purchaseSuggestions,suggestionFor}=await import('../selectors.mjs');
 const rows=[
  {key:'a',originalCode:'MRO-1',purchaseCode:'P-OLD',typeOfCode:'IMK',action:'Ready for PR',updatedAt:'2026-01-02T00:00:00Z'},
  {key:'b',originalCode:'MRO-1',purchaseCode:'P-NEW',typeOfCode:'Local',action:'Ready for PR',updatedAt:'2026-10-02T00:00:00Z'},
  {key:'c',originalCode:'MRO-1',purchaseCode:'P-DRAFT',typeOfCode:'',action:'',updatedAt:'2026-11-01T00:00:00Z'},
  {key:'d',originalCode:'MRO-1',purchaseCode:'',typeOfCode:'',action:''},
  {key:'e',originalCode:'MRO-1',purchaseCode:'P-NEW',typeOfCode:'',action:'',baseKey:'d',updatedAt:'2026-11-02T00:00:00Z'},
  {key:'f',originalCode:'MRO-2',purchaseCode:'',typeOfCode:'',action:''}
 ];
 const ranked=purchaseSuggestions(rows);
 assert.deepEqual(ranked.get('MRO-1').map(o=>[o.code,o.type]),[['P-NEW','Local'],['P-OLD','IMK'],['P-DRAFT','']],'Ready for PR trước, mới nhất trước; mã chỉ xuất hiện một lần');
 assert.equal(suggestionFor(ranked,rows[3],rows).best.code,'P-OLD','dòng gốc d đã có dòng anh em e dùng P-NEW nên gợi ý mã kế tiếp');
 assert.equal(suggestionFor(ranked,{key:'x',originalCode:'MRO-1',purchaseCode:''},rows).best.code,'P-NEW');
 assert.equal(suggestionFor(ranked,rows[5],rows),null,'chưa có lịch sử thì không gợi ý, giữ fallback Original Code');
 assert.equal(purchaseSuggestions([]).size,0);
});
