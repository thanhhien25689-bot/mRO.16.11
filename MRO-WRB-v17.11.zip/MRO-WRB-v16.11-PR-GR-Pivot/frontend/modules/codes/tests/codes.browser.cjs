﻿const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const source=process.env.MRO_FRONTEND_BASELINE||path.resolve(__dirname,'../../../..');
const {createServer}=require(path.join(source,'server.cjs'));
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
(async()=>{
 const runtime=fs.mkdtempSync(path.join(os.tmpdir(),'mro-codes-browser-'));let server,browser;
 try{
  server=createServer({runtime});await new Promise(r=>server.listen(0,'127.0.0.1',r));browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({viewport:{width:1920,height:1080}});
  await require('../../../../tests/fixtures/legacy-data.cjs').install(page,path.resolve(__dirname,'../../../..'));
  const states=[],csv=[],errors=[];let rawRequests=0;page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(new URL(r.url()).pathname==='/data/raw.json')rawRequests++;});
  await page.goto('http://127.0.0.1:'+server.address().port);for(const [name,value] of Object.entries({username:'codestest',name:'Codes Test',password:'Codes-test-password-2026!',confirm:'Codes-test-password-2026!'}))await page.locator(`#login-form [name=${name}]`).fill(value);await page.locator('#login-form button[type=submit]').click();await page.locator('[data-view=overview]').waitFor({state:'visible'});await page.locator('#loading').waitFor({state:'hidden'});
  const data=JSON.parse(fs.readFileSync(path.join(source,'tests/fixtures/legacy-raw.json'))),rows=data.codes;const expected=[rows.length,...['Đang xử lý','Sắp quá hạn','Quá hạn','Ready for PR'].map(s=>rows.filter(r=>r.status===s).length)];
  await page.evaluate(()=>{window.codesEvents=0;document.addEventListener('data-edited',()=>window.codesEvents++);});
  for(const theme of ['dark','light']){
   if(await page.locator('html').getAttribute('data-theme')!==theme)await page.locator('#theme').click();await page.locator('[data-route=codes]').click();const view=page.locator('[data-view=codes]');await view.waitFor({state:'visible'});const table=view.locator('#codes-table');
   async function record(name){states.push({name:theme+'/'+name,sha256:hash(await view.innerHTML())});}
   async function reset(){await table.locator('.filter-reset').click();assert.equal(await table.locator('.result-count').textContent(),rows.length+' kết quả');}
   await record('initial');for(let i=0;i<5;i++){await view.locator('.kpi').nth(i).click();assert.equal(await table.locator('.result-count').textContent(),expected[i]+' kết quả');await record('card-'+i);await reset();}
   for(const tab of ['processing','soon','late','ready']){await table.locator(`[data-tab=${tab}]`).click();await record('tab-'+tab);await reset();}
   await table.locator('.page-size').selectOption('5');await table.locator('[data-page=next]').click();await record('page-next');await table.locator('[data-page=prev]').click();await record('page-prev');await table.locator('[data-sort="4"]').click();await record('sort');await reset();
   for(const key of ['vendor','pic']){await table.locator(`[data-key=${key}]`).selectOption(rows[0][key]);await record(key);await reset();}
   for(const status of ['Đang xử lý','Ready for PR']){const row=rows.find(r=>r.status===status);await table.locator('input[type=search]').fill(row.id);await table.locator('.row-open').click();assert.equal(await page.locator('#code-form').count(),status==='Ready for PR'?0:1);states.push({name:theme+'/detail-'+status,sha256:hash(await page.locator('#detail-body').innerHTML())});
    if(status!=='Ready for PR'){await page.locator('#code-form button').click();assert.equal(await page.locator('#detail').evaluate(el=>el.open),true);assert.equal(await page.locator('#code-form [name=reason]').evaluate(el=>el.validity.valueMissing),true);await page.locator('#code-form [name=reason]').fill('cancelled reason');await page.locator('#code-form [name=code]').fill('');await page.locator('#code-form button').click();assert.equal(await page.locator('#code-form [name=code]').evaluate(el=>el.validity.valueMissing),true);}
    await page.locator('#close-detail').click();await reset();}
   await table.locator('input[type=search]').fill(rows[0].id);await record('search');const dl=page.waitForEvent('download');await table.locator('.export').click();const download=await dl;assert.equal(download.suggestedFilename(),'Code-Issue.xlsx');csv.push({theme,sha256:hash(fs.readFileSync(await download.path()))});
   await page.evaluate(()=>window.codesView=document.querySelector('[data-view=codes]'));await page.locator('[data-route=orders]').click();await page.locator('[data-view=orders]').waitFor({state:'visible'});await page.locator('[data-route=codes]').click();await view.waitFor({state:'visible'});assert.equal(await page.evaluate(()=>window.codesView===document.querySelector('[data-view=codes]')),true);assert.equal(await table.locator('input[type=search]').inputValue(),rows[0].id);await reset();await record('reset');
  }
  assert.equal(await page.evaluate(()=>window.codesEvents),0);assert.equal(rawRequests,1);assert.deepEqual(errors,[]);console.log(JSON.stringify({passed:true,rawRequests,states,csv,pageErrors:errors},null,2));
 }finally{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));assert.equal(path.dirname(runtime),os.tmpdir());assert.ok(path.basename(runtime).startsWith('mro-codes-browser-'));fs.rmSync(runtime,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
