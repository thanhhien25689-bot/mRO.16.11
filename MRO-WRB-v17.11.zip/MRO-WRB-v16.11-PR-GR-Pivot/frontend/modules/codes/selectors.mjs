export const countStatus=(rows,status)=>rows.filter(r=>r.status===status).length;
export const actionReady=r=>r.action==='Ready for PR';
// Màn Code & code Issue (nguồn SQL): bốn thẻ/tab trạng thái chia nhau tập dòng theo Trạng thái + Hành động
// nên thẻ, tab và bộ đếm tab luôn cùng số. "Cần xử lý" và "Quá hạn" bỏ dòng đã Hành động = Ready for PR vì
// PIC2 đã bàn giao; "Đang xử lý" cũng bỏ dòng đã xác nhận và nhận thêm dòng Trạng thái = Ready for PR nhưng
// chưa bấm Ready (PIC2 còn nợ xác nhận bàn giao — yêu cầu 03/11/2026); "Ready for PR" chỉ đếm dòng
// Trạng thái Ready for PR VÀ Hành động = Ready for PR. countStatus giữ cho màn mẫu legacy.
const cardTests=new Map([
 ['Cần xử lý',r=>r.status==='Cần xử lý'&&!actionReady(r)],
 ['Đang xử lý',r=>(r.status==='Đang xử lý'||r.status==='Ready for PR')&&!actionReady(r)],
 ['Quá hạn',r=>r.status==='Quá hạn'&&!actionReady(r)],
 ['Ready for PR',r=>r.status==='Ready for PR'&&actionReady(r)]
]);
export const statusTest=status=>cardTests.get(status)||((r=>r.status===status));
export const countCard=(rows,status)=>rows.filter(statusTest(status)).length;

// P.A.1 (15/11/2026): gợi ý Purchase Code = mã đã mua gần nhất cho cùng Original Code, tính trên
// chính các dòng codes-live đã tải (toàn bộ Order đã duyệt) — không thêm API/SQL. Ưu tiên dòng đã
// Hành động = Ready for PR, sau đó mới tới mã đã lưu nhưng chưa bàn giao; trong mỗi nhóm lấy mới nhất.
// Chỉ là gợi ý hiển thị: không ghi gì cho tới khi PIC2 bấm Load RFQ rồi Save như luồng hiện tại.
const stamp=r=>String(r.updatedAt||r.createdAt||r.date||'');
export function purchaseSuggestions(rows){
 const byOriginal=new Map();
 for(const r of rows||[]){
  const original=String(r.originalCode||'').trim(),code=String(r.purchaseCode||'').trim();if(!original||!code)continue;
  const entry={code,type:r.typeOfCode||'',at:stamp(r),ready:actionReady(r)?1:0};
  const codes=byOriginal.get(original)||new Map(),prev=codes.get(code);
  if(!prev||entry.ready>prev.ready||(entry.ready===prev.ready&&entry.at>prev.at))codes.set(code,{...entry,type:entry.type||prev?.type||''});
  else if(!prev.type&&entry.type)prev.type=entry.type;
  byOriginal.set(original,codes);
 }
 const ranked=new Map();
 for(const [original,codes] of byOriginal)ranked.set(original,[...codes.values()].sort((a,b)=>b.ready-a.ready||b.at.localeCompare(a.at)||a.code.localeCompare(b.code)));
 return ranked;
}
// Gợi ý cho một dòng: bỏ các mã đã dùng ở dòng anh em cùng dòng Order (nút "+"), để mã thứ hai gợi ý mã khác.
export function suggestionFor(ranked,row,rows){
 const original=String(row.originalCode||'').trim(),list=ranked.get(original);if(!list||!list.length)return null;
 const base=row.baseKey||row.key,used=new Set((rows||[]).filter(r=>r.key!==row.key&&(r.baseKey||r.key)===base).map(r=>String(r.purchaseCode||'').trim()).filter(Boolean));
 const options=list.filter(item=>!used.has(item.code));
 return options.length?{best:options[0],options}:null;
}
