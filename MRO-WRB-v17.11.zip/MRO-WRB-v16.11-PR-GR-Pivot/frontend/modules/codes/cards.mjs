// Public descriptor của module; thứ tự giữ tương thích KPI legacy.
export function cardFilters(){
 const all=()=>true,status=s=>r=>r.status===s;
 return [
  {key:'all',filter:all},
  {key:'processing',filter:status('Đang xử lý')},
  {key:'due-soon',filter:status('Sắp quá hạn')},
  {key:'overdue',filter:status('Quá hạn')},
  {key:'ready-for-pr',filter:status('Ready for PR')}
 ];
}
