import {handoffFirstRequestForReadyCode} from '../../integration/procurement.mjs';
export function confirmReady(data,r,f){
 r.purchaseCode=f.get('code');r.reason=f.get('reason');r.confirmedAt=new Date().toISOString();r.status='Ready for PR';r.step='Ready for PR';r.owner='PIC3';
 handoffFirstRequestForReadyCode(data,r);
}
