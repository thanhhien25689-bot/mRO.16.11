import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createDelivery} from '../actions.mjs';
import {cardFilters,kpiDescriptors} from '../cards.mjs';
import {deliveredForVendor} from '../selectors.mjs';
import * as api from '../index.mjs';
const data=JSON.parse(readFileSync(new URL('../../../../tests/fixtures/legacy-raw.json',import.meta.url)));
test('Delivery public interface and KPI/filter keys match the legacy order',()=>{
 assert.deepEqual(Object.keys(api).sort(),['cardFilters','mount']);
 const rows=data.deliveries,cards=cardFilters(),kpis=kpiDescriptors(rows);
 assert.deepEqual(cards.map(c=>c.key),['all','delivered','preparing','vendors']);assert.deepEqual(kpis.map(c=>c.key),cards.map(c=>c.key));
 const expected=[rows.length,rows.filter(r=>r.status==='SEV đã giao').length,rows.filter(r=>r.status==='Đang chuẩn bị').length,new Set(rows.map(r=>r.vendor)).size];
 assert.deepEqual(kpis.map(k=>k.args[1]),expected);
 assert.deepEqual(cards.map(c=>rows.filter(c.filter).length),[expected[0],expected[1],expected[2],rows.length]);
 for(const vendor of ['Vendor A','Vendor B','Vendor C','Vendor D'])assert.deepEqual(deliveredForVendor(rows,vendor),rows.filter(r=>r.vendor===vendor&&r.status==='SEV đã giao'));
});
test('Delivery creation mutates only its own rows; original item fields, numbering and form conversion stay intact',()=>{
 const snapshot=structuredClone(data),rows=snapshot.deliveries,old=structuredClone(rows),item=snapshot.items[0];
 const foreign=JSON.stringify({...snapshot,deliveries:null});
 const expectedId=`DN-2610-${String(Math.max(...old.map(r=>Number(r.id.split('-').at(-1))))+1).padStart(3,'0')}`;
 const form=new Map(Object.entries({code:item.code,qty:'7',vendor:'Vendor B',date:snapshot.asOf,note:'Ghi chú <& "'}));
 createDelivery(rows,snapshot.items,form);
 assert.equal(snapshot.deliveries,rows);assert.deepEqual(rows.slice(1),old);
 assert.deepEqual(rows[0],{id:expectedId,date:snapshot.asOf,vendor:'Vendor B',code:item.code,name:item.name,qty:7,unit:item.unit,person:'Kho SEV',status:'SEV đã giao',note:'Ghi chú <& "'});
 assert.equal(JSON.stringify({...snapshot,deliveries:null}),foreign);
 createDelivery(rows,snapshot.items,form);assert.equal(rows.length,old.length+2);assert.notEqual(rows[0].id,rows[1].id);
});
test('Delivery preserves existing edge behavior instead of fixing business rules',()=>{
 const rows=[],item=data.items[0],form=new Map(Object.entries({code:item.code,qty:'0',vendor:'Vendor A',date:data.asOf,note:''}));
 createDelivery(rows,[item],form);assert.equal(rows[0].id,'DN-2610--Infinity');assert.equal(rows[0].qty,0);
 assert.throws(()=>createDelivery([],[],form),TypeError);
 const mixed=[{status:'Đã GR',vendor:'Vendor A'},{status:'SEV đã giao',vendor:'Vendor A'},{status:'Đang chuẩn bị',vendor:'Vendor B'}];
 assert.deepEqual(kpiDescriptors(mixed).map(k=>k.args[1]),[3,1,1,2]);
});
