// Cùng kịch bản chạy trên source hiện tại và checkpoint Phase 4B.2.
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const source=process.env.MRO_FRONTEND_BASELINE||path.resolve(__dirname,'../../../..');
const {createServer}=require(path.join(source,'server.cjs'));
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
(async()=>{
 const runtime=fs.mkdtempSync(path.join(os.tmpdir(),'mro-delivery-browser-'));let server,browser;
 try{
  server=createServer({runtime});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({viewport:{width:1920,height:1080}});
  await require('../../../../tests/fixtures/legacy-data.cjs').install(page,path.resolve(__dirname,'../../../..'));
  const errors=[],states=[],csv=[];let rawRequests=0;
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(new URL(r.url()).pathname==='/data/raw.json')rawRequests++;});
  await page.goto('http://127.0.0.1:'+server.address().port);
  for(const [name,value] of Object.entries({username:'deliverytest',name:'Delivery Test',password:'Delivery-test-password-2026!',confirm:'Delivery-test-password-2026!'}))await page.locator(`#login-form [name=${name}]`).fill(value);
  await page.locator('#login-form button[type=submit]').click();await page.locator('[data-view=overview] .ov-fold>.panel').first().waitFor();await page.locator('#loading').waitFor({state:'hidden'});
  const raw=JSON.parse(fs.readFileSync(path.join(source,'tests/fixtures/legacy-raw.json'))),item=raw.items[0];let created=0;
  await page.evaluate(()=>{window.deliveryEvents=0;document.addEventListener('data-edited',()=>window.deliveryEvents++);});
  for(const theme of ['dark','light']){
   if(await page.locator('html').getAttribute('data-theme')!==theme)await page.locator('#theme').click();
   await page.locator('[data-route=delivery]').click();const view=page.locator('[data-view=delivery]');await view.waitFor({state:'visible'});
   const table=view.locator('#delivery-table');
   async function record(name){states.push({name:theme+'/'+name,sha256:hash(await view.innerHTML())});}
   await record('initial');
   const cards=view.locator('.kpi');const count=raw.deliveries.length+created;
   for(let i=0;i<4;i++){await cards.nth(i).click();assert.equal(await cards.nth(i).getAttribute('aria-pressed'),'true');await record('card-'+i);await table.locator('.filter-reset').click();assert.equal(await table.locator('.result-count').textContent(),count+' kết quả');}
   await table.locator('[data-tab=pending]').click();await record('pending');await table.locator('.filter-reset').click();
   await table.locator('[data-key=vendor]').selectOption('Vendor A');await record('vendor');await table.locator('.filter-reset').click();
   await table.locator('.row-open').first().click();await page.locator('#detail').waitFor({state:'visible'});states.push({name:theme+'/detail',sha256:hash(await page.locator('#detail-body').innerHTML())});await page.locator('#close-detail').click();
   await page.evaluate(()=>window.beforeDeliveryViews=[...document.querySelectorAll('[data-view]')]);
   await view.locator('#new-delivery').click();states.push({name:theme+'/form',sha256:hash(await page.locator('#detail-body').innerHTML())});
   await page.locator('#delivery-form [name=code]').selectOption(item.code);await page.locator('#delivery-form [name=vendor]').selectOption('Vendor B');await page.locator('#delivery-form [name=qty]').fill('7');await page.locator('#delivery-form [name=note]').fill('Delivery test <& " '+theme);await page.locator('#delivery-form button').click();created++;
   await page.locator('#detail').waitFor({state:'hidden'});assert.equal(await page.evaluate(()=>window.deliveryEvents),created);
    const deliveryInvalidated=await page.evaluate(()=>Object.fromEntries(window.beforeDeliveryViews.map(el=>[el.dataset.view,el.isConnected])));
    assert.equal(deliveryInvalidated.delivery,false);assert.equal(deliveryInvalidated.overview,false);
    for(const key of ['inventory','vendor-overview','orders','codes','tracking','projects','aps','repair','reports'])if(key in deliveryInvalidated)assert.equal(deliveryInvalidated[key],true,`không remount view không phụ thuộc: ${key}`);
   assert.equal(await table.locator('.result-count').textContent(),(raw.deliveries.length+created)+' kết quả');await record('created');
   await table.locator('.row-open').first().click();assert.ok((await page.locator('#detail-body').textContent()).includes('Delivery test <& " '+theme));states.push({name:theme+'/created-detail',sha256:hash(await page.locator('#detail-body').innerHTML())});await page.locator('#close-detail').click();
   await table.locator('input[type=search]').fill('Delivery test');await record('search');
   const downloadPromise=page.waitForEvent('download');await table.locator('.export').click();const download=await downloadPromise;const bytes=fs.readFileSync(await download.path());
   assert.equal(download.suggestedFilename(),'Giao-hang-SEV.xlsx');assert.equal((bytes.toString('utf8').match(/<row r=/g)||[]).length,created+1);csv.push({theme,sha256:hash(bytes)});
   await page.evaluate(()=>window.deliveryView=document.querySelector('[data-view=delivery]'));
   await page.locator('[data-route=inventory]').click();await page.locator('[data-view=inventory]').waitFor({state:'visible'});await page.locator('[data-route=delivery]').click();await view.waitFor({state:'visible'});
   assert.equal(await page.evaluate(()=>window.deliveryView===document.querySelector('[data-view=delivery]')),true);assert.equal(await table.locator('input[type=search]').inputValue(),'Delivery test');
   await table.locator('.filter-reset').click();await record('reset');
  }
  assert.equal(rawRequests,1);assert.deepEqual(errors,[]);console.log(JSON.stringify({passed:true,rawRequests,created,states,csv,pageErrors:errors},null,2));
 }finally{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));assert.equal(path.dirname(runtime),os.tmpdir());assert.ok(path.basename(runtime).startsWith('mro-delivery-browser-'));fs.rmSync(runtime,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
