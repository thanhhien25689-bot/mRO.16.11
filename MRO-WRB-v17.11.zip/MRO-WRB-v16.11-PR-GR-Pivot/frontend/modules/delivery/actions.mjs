// Chỉ ghi vào danh sách Delivery; items là danh mục chỉ đọc.
export function createDelivery(rows,items,f){
 const item=items.find(r=>r.code===f.get('code'));rows.unshift({id:`DN-2610-${String(Math.max(...rows.map(r=>Number(r.id.split('-').at(-1))))+1).padStart(3,'0')}`,date:f.get('date'),vendor:f.get('vendor'),code:item.code,name:item.name,qty:Number(f.get('qty')),unit:item.unit,person:'Kho SEV',status:'SEV đã giao',note:f.get('note')});
}
