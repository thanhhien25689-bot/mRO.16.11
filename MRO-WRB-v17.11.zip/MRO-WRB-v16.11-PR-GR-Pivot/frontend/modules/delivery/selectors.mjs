export const isDelivered=r=>r.status==='SEV đã giao';
export const isPreparing=r=>r.status==='Đang chuẩn bị';
export const vendorCount=rows=>new Set(rows.map(r=>r.vendor)).size;
export const deliveredForVendor=(rows,vendor)=>rows.filter(r=>r.vendor===vendor&&isDelivered(r));

export const transferVendors=[{key:'alt',label:'Almus Tech',color:'mint'},{key:'alv',label:'Almus Vina',color:'cyan'},{key:'bujeon',label:'Bujeon',color:'amber'},{key:'chitwing',label:'Chitwing',color:'violet'}];
export const inTransferWeek=(r,week)=>!!r.date&&r.date>=week.start&&r.date<=week.end;
