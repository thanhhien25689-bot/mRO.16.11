# Delivery — public contract

`index.mjs` là điểm vào duy nhất cho code bên ngoài module. Không import trực tiếp view/cards/selectors/actions. Hai đường dẫn `modules/delivery/index.mjs` và `modules/delivery/public-card-filters.mjs` chỉ là facade tương thích.

## Interface

- `mount(root, data, presentation)` dựng cùng HTML/DOM như bản legacy. `data.deliveries` là danh sách module được ghi; `data.items` và `data.asOf` chỉ đọc. `presentation` gồm `icon(name)` và `badge(text)`, host cung cấp adapter cũ để giữ nguyên output.
- Trả controller của table: `reset()`, `setCardFilter(value)`, `setTab(value)`, `update(next)` và `cardFilters` (mảng descriptor để binder của host gắn thẻ). Không thêm fetch hoặc render lại khi điều hướng.
- `cardFilters()` trả descriptor theo thứ tự legacy: `all`, `delivered`, `preparing`, `vendors`. Key không thay DOM ID (`delivery-0`…`delivery-3`). Host giữ listener/card/reset; module sở hữu predicate.

## Ownership

- `view.mjs`: layout, table/detail và form, chỉ dùng public Shared UI và adapter presentation.
- `cards.mjs`: KPI labels/values và filter descriptors.
- `selectors.mjs`: trạng thái Delivery, số vendor và số phiếu đã giao theo vendor.
- `actions.mjs`: thêm phiếu vào đầu danh sách Delivery; giữ nguyên cách tạo ID, chuyển số lượng và fields.
- `index.mjs`: nối view/action, đóng dialog, phát `data-edited`, hiện toast theo đúng thứ tự cũ.
- `tests/`: unit và browser flow do Delivery sở hữu; wrappers trong tests root để chạy cùng regression chung.

Không sửa items/tồn kho, requests/codes/tracking hoặc tự xác nhận vendor nhận hàng. Dữ liệu giao hàng hiện chỉ lưu RAM, không có API ghi Delivery. Không sửa hạn chế tạo ID khi rows rỗng, prefix tháng cố định hoặc validation nghiệp vụ trong phase refactor.

## Dependency và kiểm tra

Delivery production chỉ import nội bộ mình và `frontend/shared/ui/index.mjs`. Icon/badge do facade host truyền vào, không import shared legacy từ module mới. DOM dialog/toast toàn cục và event `data-edited` vẫn là contract host hiện tại; module chưa phải ứng dụng deploy riêng.

Từ root chạy `npm test` để chạy cả unit và boundary/static security. Browser: chạy `node tests/delivery.browser.cjs` trong bản sao sandbox có Playwright/Chrome. Có thể đặt `MRO_FRONTEND_BASELINE` tới source baseline để chạy cùng kịch bản và so sánh DOM/CSV. Không dùng runtime vận hành, không seed.

Chỉ năm file index/view/cards/selectors/actions được static allowlist. README và tests không được phục vụ HTTP. Thêm file production cần cập nhật danh sách chính xác qua task tích hợp, không mở wildcard.
