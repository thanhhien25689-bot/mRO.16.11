import {isDelivered,isPreparing,vendorCount} from './selectors.mjs';
export function cardFilters(){
 const all=()=>true;
 return [{key:'all',filter:all},{key:'delivered',filter:isDelivered},{key:'preparing',filter:isPreparing},{key:'vendors',filter:all}];
}
export function kpiDescriptors(rows){
 return [
  {key:'all',args:['Phiếu giao',rows.length,'Lịch sử SEV → Vendor','delivery']},
  {key:'delivered',args:['SEV đã giao',rows.filter(isDelivered).length,'Ghi nhận xuất tại SEV','check','mint']},
  {key:'preparing',args:['Đang chuẩn bị',rows.filter(isPreparing).length,'Chưa xác nhận giao','clock','amber']},
  {key:'vendors',args:['Vendor nhận cấp',vendorCount(rows),'Theo kế hoạch sản xuất','layers','violet']}
 ];
}
