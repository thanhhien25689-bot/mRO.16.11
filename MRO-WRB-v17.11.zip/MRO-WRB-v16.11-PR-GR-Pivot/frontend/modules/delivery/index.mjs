// Public interface duy nhất. icon/badge là presentation adapter do host cung cấp.
import {toast} from '../../shared/ui/index.mjs';
import {render,renderTransfers,showCreateForm} from './view.mjs';
import {createDelivery} from './actions.mjs';
import {cardFilters} from './cards.mjs';
export {cardFilters};
export function mount(root,data,presentation){
 if(data.deliverySource){
  const controller=renderTransfers(root,data,presentation),reload=root.querySelector('[data-reload-delivery]');let timer,lastRead=Date.now(),busy=false;
  const schedule=()=>{clearTimeout(timer);if(root.isConnected&&!root.hidden&&!document.hidden)timer=setTimeout(autoRefresh,Math.max(5000,120000-(Date.now()-lastRead)));};
  const wake=()=>{if(!document.hidden&&!root.hidden){if(Date.now()-lastRead>=120000)autoRefresh();else schedule();}else clearTimeout(timer);};document.addEventListener('visibilitychange',wake);
  async function autoRefresh(){if(!root.isConnected)return;if(root.hidden||document.hidden||busy||document.getElementById('detail')?.open||root.contains(document.activeElement)&&document.activeElement?.matches('input,textarea,select')){schedule();return;}busy=true;reload.disabled=true;try{const result=await presentation.api('delivery-live');if(!root.isConnected)return;Object.assign(data,result);controller.refresh(result);lastRead=Date.now();document.dispatchEvent(new Event('procurement-updated'));}catch(e){lastRead=Date.now();const source=root.querySelector('[data-delivery-source]');if(source)source.textContent='Tự tải SQL chưa thành công: '+e.message;}finally{busy=false;reload.disabled=false;schedule();}}
  reload.onclick=async()=>{if(busy)return;busy=true;reload.disabled=true;try{const result=await presentation.api('delivery-live');Object.assign(data,result);controller.refresh(result);toast(result.deliveryError?'Chưa tải được SQL; kiểm tra cảnh báo.':'Đã tải dữ liệu giao hàng SQL.');}catch(e){toast(e.message);reload.disabled=false;}finally{busy=false;lastRead=Date.now();schedule();}};
  const observer=new MutationObserver(()=>{if(!root.isConnected){observer.disconnect();clearTimeout(timer);document.removeEventListener('visibilitychange',wake);return;}if(root.hidden)clearTimeout(timer);else if(Date.now()-lastRead>=120000)autoRefresh();else schedule();});observer.observe(root,{attributes:true,attributeFilter:['hidden']});observer.observe(document.getElementById('views'),{childList:true});schedule();return controller;
 }
 const rows=data.deliveries;
 const controller=render(root,rows,presentation,data.items);
 root.querySelector('#new-delivery').onclick=()=>{
  showCreateForm(data);
  document.getElementById('delivery-form').onsubmit=e=>{
   e.preventDefault();
   createDelivery(rows,data.items,new FormData(e.target));
   document.getElementById('detail').close();
   document.dispatchEvent(new CustomEvent('data-edited',{detail:{views:['delivery','overview']}}));
   toast('Đã ghi nhận phiếu giao trong phiên mẫu.');
  };
 };
 return Object.assign(controller,{cardFilters:cardFilters()});
}

