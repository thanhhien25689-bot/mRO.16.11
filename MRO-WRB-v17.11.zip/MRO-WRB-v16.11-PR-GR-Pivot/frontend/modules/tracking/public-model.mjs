export function trackingKey(r){return `${r.pr}:${r.sq}`;}
export function mergeTracking(existing,incoming){const map=new Map(existing.map(r=>[trackingKey(r),r]));for(const r of incoming){if(!r.pr||!r.sq||!r.code||r.qty<=0)throw Error('Dòng PR không hợp lệ');map.set(trackingKey(r),{...map.get(trackingKey(r)),...r});}return [...map.values()];}

export {cardFilters} from './cards.mjs';
