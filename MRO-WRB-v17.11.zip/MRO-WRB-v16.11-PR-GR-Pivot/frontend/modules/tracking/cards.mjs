// Public descriptor của module; thứ tự giữ tương thích KPI legacy.
export function cardFilters({ready,pending}){
 const all=()=>true,status=s=>r=>r.status===s;
 return [
  {key:'all',filter:all},
  {key:'pending-pr',filter:{test:all,source:pending}},
  {key:'has-po',filter:r=>!!r.po},
  {key:'shipping',filter:status('Đang giao')},
  {key:'received',filter:status('Đã GR')},
  {key:'ready-for-pr',filter:{test:all,source:ready.map(r=>({...r,code:r.purchaseCode,pr:'Chưa tạo PR',sq:'—',tracking:'—',received:0}))}}
 ];
}
