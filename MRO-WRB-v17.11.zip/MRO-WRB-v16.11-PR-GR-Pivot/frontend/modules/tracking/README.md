# Tracking — Phase 6D

## Public interface

index.mjs export mount(root,data,presentation), cardFilters({ready,pending}), trackingKey(row), mergeTracking(existing,incoming). Presentation nhận badge/icon từ host. Controller giữ setTab/setCardFilter/reset và thêm cardFilters. Legacy modules/tracking/index.mjs giữ mount(root,data).

public-model.mjs là public business entry nhẹ cho model/card facade: export trackingKey/mergeTracking/cardFilters mà không import renderer, DOM hoặc Shared UI. Cần entry này để giữ dependency model legacy nhẹ, không tạo chu kỳ. Ngoài module chỉ dùng hai public entry hoặc facade cũ.

## Cấu trúc

- index: mount và callback xác nhận sync → event → toast.
- view: HTML, table/mode/detail, preview, form và UI errors, giữ nguyên output.
- cards: sáu descriptors giữ source/key/thứ tự.
- selectors: pendingPR, readyCodes, pendingLines, purchaseLines, pasteDefaults; pendingPR dùng key chuỗi nhưng pendingLines dùng so sánh pr/sq nghiêm ngặt như trước.
- actions: syncTracking chỉ thay data.tracking; parsePurchaseJSON giữ validation paste riêng.
- public-model: merge/key đúng implementation legacy và public descriptors.
- tests: unit, browser; wrapper/boundary ở tests root.

## Ownership và thứ tự

Tracking sở hữu tracking, chỉ đọc codes/purchaseLines/budget. Ready chỉ là nguồn hiển thị, không tự tạo PR. Sync map tracking fallback → merge → gán mảng mới → data-edited/remount → toast. Paste JSON parse/validate/merge thử → đóng dialog → map defaults bằng || → preview, chưa ghi dữ liệu; cancel chỉ xóa preview. Giữ Map order, last incoming wins, reference dòng untouched và nguyên trạng input.

Legacy shared/model và shared/card-filters vẫn dùng facade public business. Binder eager đọc nguồn xuyên màn giữ nguyên để không đổi behavior; module mới không kéo workflow module khác vào mình. Procurement contract không sửa.

Chạy npm test; browser tests/tracking.browser.cjs với Playwright/Chrome. MRO_FRONTEND_BASELINE trỏ source baseline cho đối chiếu cùng kịch bản. tests/procurement.browser.cjs kiểm tra mutation thực/resync/validation/reference/event/toast và các chiều Orders/Codes. Tests chỉ dùng sandbox/runtime tạm.
