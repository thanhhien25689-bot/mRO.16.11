import {trackingKey} from './public-model.mjs';
export const pendingPR=(data,rows)=>[...new Set(data.purchaseLines.filter(r=>!rows.some(t=>trackingKey(t)===trackingKey(r))).map(r=>r.pr))];
export const readyCodes=data=>data.codes.filter(r=>r.status==='Ready for PR');
export const pendingLines=data=>data.purchaseLines.filter(r=>!data.tracking.some(t=>t.pr===r.pr&&t.sq===r.sq));
export const purchaseLines=(data,pr)=>data.purchaseLines.filter(r=>r.pr===pr);
export const pasteDefaults=lines=>lines.map(r=>({...r,status:r.status||'Chờ PO',received:r.received||0}));
export const hasPRNo=r=>!!(String(r.prNo||'').trim()||String(r.pr&&r.pr.PR_NO||'').trim());
export const confirmForOrder=r=>r.codeAction==='Ready for PR'&&!hasPRNo(r);
// 06/11/2026: thẻ "Confirm for order" tách tổng (vd 20 dòng) thành "9 Code HHP / 11 code WRB".
// Cờ hhpCode do backend gắn khi Purchase Code trùng cột BQMS Code trong EQM_MRO_HhpOrderCode
// (so sau trim, không phân biệt hoa thường); dòng còn lại tính là code WRB. hhpKnown=false khi
// chưa đọc được danh sách HHP thì lớp hiển thị không được bịa tỷ lệ HHP/WRB.
export const hhpRow=r=>r.hhpCode===true;
export const hhpKnown=rows=>Array.isArray(rows)&&rows.some(r=>r.hhpCode===true||r.hhpCode===false);
export const confirmSplit=rows=>{const list=(rows||[]).filter(confirmForOrder),hhp=list.filter(hhpRow);
 return {total:list.length,hhp:hhp.length,wrb:list.length-hhp.length,hhpCodes:[...new Set(hhp.map(r=>String(r.purchaseCode||'').trim().toUpperCase()).filter(Boolean))].sort(),known:hhpKnown(rows)};};
// 06/11/2026 — "Lí do mua hàng" cho Project Status. PR do PIC ngoài bộ phận chuẩn tạo (chốt: chỉ
// bui.thu2) để trống PURCHASE_REQ_INFO nên Project Status loại dòng; PIC3 nhập lại tại màn PR &
// Tracking. standardReason là bản mô tả phía trình duyệt của backend/integration/pr-reason.cjs và
// phải sửa cùng lúc cả hai (cùng pattern với standardRemark của Orders); không đưa form vào Shared.
const reasonTypes={SETUP:'SETUP',SOP:'SOP',SPARE:'Spare Part','SPARE PART':'Spare Part'};
const reasonClean=value=>String(value??'').replace(/\[non-minimum item\]/gi,'').replace(/\s+/g,' ').trim();
const reasonType=value=>reasonTypes[String(value??'').trim().replace(/\s+/g,' ').toUpperCase()];
const reasonBlank=part=>/^[-\u2010-\u2015]*$/.test(part)?'':part;
// 12/11/2026 — nguyên tắc đặt tên mới: tách theo dấu "-", phần tử ĐẦU TIÊN luôn là Type và Type chỉ
// có SETUP / SOP / Spare Part. Ưu tiên tách tại dấu gạch có khoảng trắng phía sau ("F53-2",
// "E-test" không bị cắt đôi), không nhận được Type thì tách mọi dấu "-". Khớp từng bước với
// splitReason/standardReason trong backend/integration/pr-reason.cjs.
function reasonSplit(raw){const cuts=[...raw.matchAll(/[-\u2010-\u2015]\s+/g)],parts=[];
 if(!cuts.length)parts.push(raw);else{let from=0;for(const cut of cuts){parts.push(raw.slice(from,cut.index));from=cut.index+cut[0].length}parts.push(raw.slice(from))}
 const spaced=parts.map(part=>reasonBlank(part.trim()));
 return reasonType(spaced[0])?spaced:raw.split('-').map(part=>reasonBlank(part.trim()));}
export function standardReason(value){const raw=reasonClean(value);
 if(!raw)return {ok:false,error:'Lí do mua hàng trống; phải theo form Type - Project - Model - Process.'};
 const parts=reasonSplit(raw),type=reasonType(parts[0]);
 if(!type)return {ok:false,error:'Lí do mua hàng phải bắt đầu bằng Type hợp lệ (SETUP, SOP hoặc Spare Part), các phần tách nhau bằng dấu "-".'};
 const project=parts[1]||'',model=parts[2]||'',process=parts.slice(3).filter(Boolean).join(' - ');
 if(!project)return {ok:false,error:'Phần Project bắt buộc; thiếu Project thì Project Status không gom được dự án.'};
 return {ok:true,type,project,model,process,description:reasonFromParts({type,project,model,process})};}
export function reasonFromParts({type='SETUP',project='',model='',process=''}={}){const parts=[type,project,model,process];
 while(parts.length>1&&parts[parts.length-1]==='')parts.pop();return parts.join(' - ').replace(/\s{2,}/g,' ').trim();}
// Gợi ý sẵn: ghi chú Order của PIC1 (vốn đã bị chặn theo cùng form) → PURCHASE_REQ_INFO SQL → bản đã nhập.
export function reasonPrefill(row={}){
 for(const value of [row.orderNote,row.reasonText,row.pr&&row.pr.PURCHASE_REQ_INFO]){const parsed=standardReason(value);if(parsed.ok)return parsed;}
 return null;}
export const reasonNeeded=rows=>(rows||[]).filter(row=>row.needReason);
