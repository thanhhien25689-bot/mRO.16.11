import test from 'node:test';
import assert from 'node:assert/strict';
import * as api from '../index.mjs';
import {syncTracking,parsePurchaseJSON} from '../actions.mjs';
import {pendingPR,pendingLines,readyCodes,pasteDefaults,confirmForOrder,hasPRNo} from '../selectors.mjs';
import {mergeTracking as legacy,trackingKey as legacyKey} from '../../../../tests/fixtures/phase-4b1/model.mjs';
test('Tracking public interface and exact legacy merge implementations',()=>{
 assert.deepEqual(Object.keys(api).sort(),['cardFilters','mergeTracking','mount','trackingKey']);
 assert.equal(api.mergeTracking.toString(),legacy.toString());assert.equal(api.trackingKey.toString(),legacyKey.toString());
});
test('Sync owns only tracking: field/row order, fallback, duplicates, resync and references',()=>{
 const old={pr:'P',sq:'1',code:'C',qty:1,keep:'yes'},untouched={pr:'P',sq:'2',code:'U',qty:3};
 const data={tracking:[old,untouched],requests:[{id:'R'}],codes:[{id:'R',status:'Ready for PR'}],purchaseLines:[]};
 const refs={...data},incoming=[{pr:'Q',sq:'1',code:'X',qty:4},{pr:'P',sq:'1',code:'NEW',qty:8,tracking:''},{pr:'Q',sq:'1',code:'LAST',qty:5}];
 const saved=structuredClone({data,incoming});const expected=legacy(data.tracking,incoming.map(r=>({...r,tracking:r.tracking||`TRK-${r.pr}-${r.sq}`})));
 syncTracking(data,incoming);assert.deepEqual(data.tracking,expected);assert.notEqual(data.tracking,refs.tracking);assert.equal(data.tracking[1],untouched);assert.notEqual(data.tracking[0],old);
 assert.deepEqual(data.tracking.map(Object.keys),expected.map(Object.keys));assert.deepEqual(data.tracking.map(r=>r.pr+':'+r.sq),['P:1','P:2','Q:1']);
 for(const k of ['requests','codes','purchaseLines'])assert.equal(data[k],refs[k]);assert.deepEqual(refs.tracking,saved.data.tracking);assert.deepEqual(incoming,saved.incoming);
 const first=data.tracking;syncTracking(data,incoming);assert.deepEqual(data.tracking,expected);assert.notEqual(data.tracking,first);assert.equal(data.tracking[1],untouched);
});
test('Failed sync leaves original tracking array and other data untouched; no added validation',()=>{
 const d={tracking:[{pr:'P',sq:'1',code:'C',qty:1}],requests:[],codes:[]},before=structuredClone(d),ref=d.tracking;
 assert.throws(()=>syncTracking(d,[{pr:'Q',sq:'1',code:'C',qty:2},{pr:'Q',sq:'2',code:'C',qty:0}]),{message:'Dòng PR không hợp lệ'});assert.equal(d.tracking,ref);assert.deepEqual(d,before);
 syncTracking(d,[{pr:'Q',sq:'1',code:'C',qty:NaN}]);assert.ok(Number.isNaN(d.tracking[1].qty));
});
test('JSON validation and paste defaults preserve strict form vs permissive merge distinction',()=>{
 const row={pr:'P',sq:'1',code:'C',name:'Name',vendor:'V',qty:1,status:'',received:null};
 const parsed=parsePurchaseJSON(JSON.stringify([row]));assert.deepEqual(parsed,[row]);const mapped=pasteDefaults(parsed);assert.notEqual(mapped[0],parsed[0]);assert.deepEqual(mapped,[{...row,status:'Chờ PO',received:0}]);
 for(const value of [[],{},null])assert.throws(()=>parsePurchaseJSON(JSON.stringify(value)),{message:'Cần một danh sách PR lines.'});
 for(const patch of [{qty:0},{qty:'1'},{sq:1},{vendor:null}])assert.throws(()=>parsePurchaseJSON(JSON.stringify([{...row,...patch}])),{message:'Mỗi dòng cần pr, sq, code, name, vendor và qty > 0.'});
 assert.throws(()=>parsePurchaseJSON(JSON.stringify([{...row,pr:''}])),{message:'Dòng PR không hợp lệ'});assert.throws(()=>parsePurchaseJSON('{'),SyntaxError);
});
test('Cột Ghi chú PR & Tracking chỉ đọc, chỉ hiển thị và xuất ghi chú Order',async()=>{
 const fs=await import('node:fs');
 const view=fs.readFileSync(new URL('../view.mjs',import.meta.url),'utf8');
 const column=view.split('\n').find(line=>line.includes("{key:'note',label:'Ghi chú'"));
 assert.ok(column,'cột Ghi chú phải nằm trong bảng Tracking SQL');
 assert.ok(column.includes("value:r=>r.orderNote||''"),'Excel và sắp xếp phải lấy đúng ghi chú Order, không lấy ghi chú PIC3 cũ');
 assert.ok(column.includes('class="tracking-note'),'cột Ghi chú phải là văn bản chỉ đọc có class riêng');
 assert.ok(!column.includes('<input'),'PIC3 không còn ô nhập ghi chú trên Portal');
 assert.ok(!view.includes('data-track-field="note"'),'không còn trường nhập ghi chú ở màn Tracking SQL');
 assert.ok(!view.includes('note-from-order'),'không còn cách hiển thị ghi chú Order dạng chữ nhỏ bên dưới ô nhập');
 const css=fs.readFileSync(new URL('../../../../assets/readability.css',import.meta.url),'utf8');
 assert.ok(/\.tracking-note\{/.test(css)&&/\.tracking-note\.is-empty\{/.test(css),'class cột Ghi chú phải có trong readability.css (dùng cả offline dashboard)');
 assert.ok(!/\.note-from-order/.test(css),'class ghi chú cũ phải được gỡ khỏi CSS');
});
test('Tracking cards retain sources and never turn Ready code into persisted PR',()=>{
 const data={tracking:[{pr:'P',sq:'1',po:'PO',status:'Đang giao'}],purchaseLines:[{pr:'P',sq:'1'},{pr:'Q',sq:'1'}],codes:[{id:'R',purchaseCode:'C',status:'Ready for PR'}]};const before=structuredClone(data);
 assert.deepEqual(pendingPR(data,data.tracking),['Q']);const pending=pendingLines(data),ready=readyCodes(data),cards=api.cardFilters({ready,pending});
 assert.deepEqual(cards.map(c=>c.key),['all','pending-pr','has-po','shipping','received','ready-for-pr']);assert.equal(cards[1].filter.source,pending);assert.deepEqual(cards[5].filter.source,[{...ready[0],code:'C',pr:'Chưa tạo PR',sq:'—',tracking:'—',received:0}]);assert.notEqual(cards[5].filter.source[0],ready[0]);assert.deepEqual(data,before);
});
test('Thẻ và tab Confirm for order bỏ mọi dòng đã cập nhật số PR No',()=>{
 const rows=[
  {codeAction:'Ready for PR',prNo:'',pr:{PR_NO:''},status:'Chờ Cập nhật PR'},
  {codeAction:'Ready for PR',prNo:'PR-01',pr:{PR_NO:'PR-01'},status:'Đã cập nhật PR'},
  {codeAction:'Ready for PR',prNo:'',pr:{PR_NO:'PR-KHOP-SQL'},status:'Đã có PO'},
  {codeAction:'',prNo:'',pr:{PR_NO:''},status:'Chờ Cập nhật PR'},
  {codeAction:'SOP',prNo:'PR-02',pr:{PR_NO:'PR-02'},status:'Đã cập nhật PR'}
 ];
 assert.equal(rows.filter(r=>r.codeAction==='Ready for PR').length,3,'ba dòng có Hành động Ready for PR');
 assert.equal(rows.filter(confirmForOrder).length,1,'chỉ dòng Ready for PR chưa có PR No được đếm');
 assert.equal(hasPRNo({prNo:'',pr:{PR_NO:'PR-01'}}),true,'PR No từ nguồn khớp SQL cũng tính là đã cập nhật');
 assert.equal(hasPRNo({prNo:'PR-01',pr:{}}),true);assert.equal(hasPRNo({prNo:'',pr:{PR_NO:''}}),false);assert.equal(hasPRNo({}),false);
});
test('View Tracking nối thẻ và tab Confirm for order vào cùng một công thức',async()=>{
 const fs=await import('node:fs');
 const view=fs.readFileSync(new URL('../view.mjs',import.meta.url),'utf8');
 const cards=view.split('\n').find(line=>line.includes('function cards()'));
 assert.ok(cards.includes("['Confirm for order',rows.filter(confirmForOrder).length"),'thẻ Confirm for order phải dùng bộ đếm dùng chung confirmForOrder');
 assert.ok(/id:'confirm',label:'Confirm for order',test:confirmForOrder/.test(view),'tab Confirm for order phải dùng cùng công thức với thẻ');
 assert.ok(!/rows\.filter\(r=>r\.codeAction==='Ready for PR'\)/.test(view),'view không còn tự đếm dòng Ready mà không loại PR No');
 const hint=view.match(/\['Confirm for order',[^\]]*'([^']*PR No[^']*)'\]/);
 assert.ok(hint&&/chưa có PR No/i.test(hint[1]),'thẻ phải có chú thích nêu điều kiện loại dòng đã có PR No');
});
// 06/11/2026: thẻ Confirm for order tách tổng (vd 20 dòng) thành "9 Code HHP / 11 code WRB".
test('Thẻ Confirm for order tách tổng thành "N Code HHP / M code WRB" theo cờ hhpCode',async()=>{
 const {confirmSplit,hhpKnown}=await import('../selectors.mjs');
 const rows=[];
 for(let i=0;i<9;i++)rows.push({codeAction:'Ready for PR',prNo:'',pr:{PR_NO:''},purchaseCode:'IMK-'+i,hhpCode:true});
 for(let i=0;i<11;i++)rows.push({codeAction:'Ready for PR',prNo:'',pr:{PR_NO:''},purchaseCode:'LOCAL-'+i,hhpCode:false});
 rows.push({codeAction:'Ready for PR',prNo:'PR-01',pr:{PR_NO:'PR-01'},purchaseCode:'IMK-9',hhpCode:true});
 rows.push({codeAction:'',prNo:'',pr:{PR_NO:''},purchaseCode:'IMK-8',hhpCode:true});
 const split=confirmSplit(rows);
 assert.deepEqual([split.total,split.hhp,split.wrb],[20,9,11],'20 dòng chờ xác nhận phải tách đúng 9 Code HHP / 11 code WRB');
 assert.deepEqual(split.hhpCodes,Array.from({length:9},(_,i)=>'IMK-'+i),'danh sách mã HHP chỉ gồm dòng Confirm for order, chuẩn hóa hoa thường và loại trùng');
 assert.equal(split.known,true);
 assert.deepEqual(confirmSplit([{codeAction:'Ready for PR',prNo:'',pr:{PR_NO:''},purchaseCode:' imk-0 '},{codeAction:'Ready for PR',prNo:'',pr:{PR_NO:''},purchaseCode:'IMK-0',hhpCode:true}]).hhpCodes,['IMK-0'],'một mã nhiều dòng vẫn liệt kê một lần');
 assert.equal(confirmSplit([{codeAction:'Ready for PR',prNo:'',pr:{PR_NO:''},purchaseCode:'X'}]).known,false,'server chưa gắn cờ (nguồn lỗi) thì không được bịa tỷ lệ HHP/WRB');
 assert.deepEqual(confirmSplit([]),{total:0,hhp:0,wrb:0,hhpCodes:[],known:false});
 assert.equal(hhpKnown([{hhpCode:false}]),true);assert.equal(hhpKnown(null),false);
});
test('View Tracking hiển thị tách HHP/WRB trên thẻ Confirm for order và badge trong ô Purchase Code',async()=>{
 const fs=await import('node:fs');
 const view=fs.readFileSync(new URL('../view.mjs',import.meta.url),'utf8');
 assert.ok(/\bconfirmForOrder,confirmSplit(?:,|\})/.test(view),'view phải dùng bộ tách dùng chung ở selectors');
 const cards=view.split('\n').find(line=>line.includes('function cards()'));
 assert.ok(cards.includes("kpi(label,value,tab==='confirm'?hhpNote():'',ico,c)"),'chỉ thẻ Confirm for order có dòng tách HHP/WRB, và chip phải đi qua kpi() để nằm TRONG khung thẻ (không nối sau </article> làm tràn ra ngoài)');
assert.ok(!/\}\$\{tab==='confirm'\?hhpNote\(\):''\}<\/div>/.test(cards),'cấm nối chip ra ngoài element .kpi (sẽ hiện ngoài viền thẻ)');
 assert.ok(cards.includes("['Confirm for order',rows.filter(confirmForOrder).length"),'công thức đếm tổng của thẻ và tab không đổi');
 assert.ok(/hhpNote\(\)\{const split=confirmSplit\(rows\),info=data\.trackingHHP/.test(view),'dòng tách thẻ phải dùng trackingHHP do server trả về');
 assert.ok(/\$\{split\.hhp\} Code HHP/.test(view)&&/\$\{split\.wrb\} code WRB/.test(view),'thẻ phải hiện đúng dạng "N Code HHP / M code WRB"');
 assert.ok(/if\(!split\.known\)return info\.source==='error'/.test(view),'chưa đọc được bảng mã HHP thì không hiển thị tỷ lệ bịa');
 const purchase=view.split('\n').find(line=>line.includes("key:'purchaseCode'"));
 assert.ok(/key:'purchaseCode',label:'Purchase Code',render:/.test(purchase),'cột không đổi value nên Excel vẫn xuất Purchase Code gốc');
 assert.ok(purchase.includes('${hhpBadge(r)}'),'badge HHP nằm ngay trong ô Purchase Code của dòng');
 assert.ok(/const hhpBadge=r=>r\.hhpCode===true'<small class="tracking-hhp-flag"/.test(view)||/const hhpBadge=r=>r\.hhpCode===true\?'<small class="tracking-hhp-flag"/.test(view),'badge chỉ gắn khi server báo trùng BQMS Code');
  assert.ok(/function notice\(\)\{message\.textContent=data\.trackingError\|\|'';?\}/.test(view),'dải tin nhắn chỉ còn trackingError — cảnh báo HHP chuyển vào thẻ Confirm for order');
 assert.ok(!/hhpWarning/.test(view),'cảnh báo HHP không còn ở dải tin nhắn, chỉ nằm trong thẻ Confirm for order');
 assert.ok(/class="tracking-hhp-hhp">\$\{split\.hhp\?'⚠ ':''\}\$\{split\.hhp\} Code HHP/.test(view),'dòng trong thẻ hiện chip "⚠ N Code HHP · M code WRB"');

 const css=fs.readFileSync(new URL('../../../../assets/readability.css',import.meta.url),'utf8');
 assert.ok(/\.tracking-sql-cards \.tracking-hhp\{/.test(css)&&/\.tracking-sql-cards \.tracking-hhp\.is-warn\{background:color-mix/.test(css)&&/\.tracking-sql-cards \.tracking-hhp\.is-warn \.tracking-hhp-hhp\{color:var\(--red\)/.test(css)&&/\.tracking-hhp-flag\{/.test(css),'CSS HHP phải nằm trong readability.css để offline dashboard dùng lại');
});

