﻿const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const source=process.env.MRO_FRONTEND_BASELINE||path.resolve(__dirname,'../../../..');
const {createServer}=require(path.join(source,'server.cjs'));
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
(async()=>{
 const runtime=fs.mkdtempSync(path.join(os.tmpdir(),'mro-tracking-browser-'));let server,browser;
 try{
  server=createServer({runtime});await new Promise(r=>server.listen(0,'127.0.0.1',r));browser=await chromium.launch({channel:'chrome',headless:true});const page=await browser.newPage({viewport:{width:1920,height:1080}});
  await require('../../../../tests/fixtures/legacy-data.cjs').install(page,path.resolve(__dirname,'../../../..'));
  const states=[],csv=[],errors=[];let rawRequests=0;page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(new URL(r.url()).pathname==='/data/raw.json')rawRequests++;});
  await page.goto('http://127.0.0.1:'+server.address().port);for(const [name,value] of Object.entries({username:'trackingtest',name:'Tracking Test',password:'Tracking-test-password-2026!',confirm:'Tracking-test-password-2026!'}))await page.locator(`#login-form [name=${name}]`).fill(value);await page.locator('#login-form button[type=submit]').click();await page.locator('[data-view=overview]').waitFor({state:'visible'});await page.locator('#loading').waitFor({state:'hidden'});
  const data=JSON.parse(fs.readFileSync(path.join(source,'tests/fixtures/legacy-raw.json'))),rows=data.tracking;
  const expected=[rows.length,data.purchaseLines.filter(r=>!rows.some(t=>t.pr===r.pr&&t.sq===r.sq)).length,rows.filter(r=>r.po).length,rows.filter(r=>r.status==='Đang giao').length,rows.filter(r=>r.status==='Đã GR').length,data.codes.filter(r=>r.status==='Ready for PR').length];
  await page.evaluate(()=>{window.trackingEvents=0;document.addEventListener('data-edited',()=>window.trackingEvents++);});
  for(const theme of ['dark','light']){
   if(await page.locator('html').getAttribute('data-theme')!==theme)await page.locator('#theme').click();await page.locator('[data-route=tracking]').click();const view=page.locator('[data-view=tracking]');await view.waitFor({state:'visible'});const table=view.locator('#tracking-table');
   async function record(name){states.push({name:theme+'/'+name,sha256:hash(await view.innerHTML())});}
   async function reset(){await table.locator('.filter-reset').click();assert.equal(await table.locator('.result-count').textContent(),rows.length+' kết quả');}
   await record('initial');for(let i=0;i<6;i++){await view.locator('.kpi').nth(i).click();assert.equal(await table.locator('.result-count').textContent(),expected[i]+' kết quả');await record('card-'+i);await reset();}
   for(const tab of ['waiting','shipping','received']){await table.locator(`[data-tab=${tab}]`).click();await record('tab-'+tab);await reset();}
   await table.locator('[data-page=next]').click();await record('page-next');await table.locator('[data-page=prev]').click();await record('page-prev');await table.locator('[data-sort="4"]').click();await record('sort');await reset();
   await table.locator('[data-key=vendor]').selectOption(rows[0].vendor);await record('vendor');await reset();
   for(const mode of ['list','pr']){await view.locator(`[data-mode=${mode}]`).click();await record('mode-'+mode);await table.locator('input[type=search]').fill(rows[0].pr);await table.locator('.row-open').first().click();states.push({name:theme+'/detail-'+mode,sha256:hash(await page.locator('#detail-body').innerHTML())});await page.locator('#close-detail').click();const dl=page.waitForEvent('download');await table.locator('.export').click();const download=await dl;assert.equal(download.suggestedFilename(),'PR-Tracking.xlsx');csv.push({theme,mode,sha256:hash(fs.readFileSync(await download.path()))});await reset();}
   await view.locator('#budget-detail').click();states.push({name:theme+'/budget',sha256:hash(await page.locator('#detail-body').innerHTML())});await page.locator('#close-detail').click();
   await view.locator('#paste-pr').click();states.push({name:theme+'/paste',sha256:hash(await page.locator('#detail-body').innerHTML())});await page.locator('#paste-form textarea').fill('[]');await page.locator('#paste-form button').click();assert.equal(await page.locator('#paste-error').textContent(),'Cần một danh sách PR lines.');await page.locator('#close-detail').click();
   await view.locator('#pr-number').fill(' pr-1242 ');await view.locator('#sync-form button[type=submit]').click();await record('preview');assert.equal(await view.locator('#pr-preview tbody tr').count(),data.purchaseLines.filter(r=>r.pr==='PR-1242').length);await view.locator('#cancel-sync').click();await record('cancel');
   await table.locator('input[type=search]').fill(rows[0].pr);await page.evaluate(()=>window.trackingView=document.querySelector('[data-view=tracking]'));await page.locator('[data-route=codes]').click();await page.locator('[data-view=codes]').waitFor({state:'visible'});await page.locator('[data-route=tracking]').click();await view.waitFor({state:'visible'});assert.equal(await page.evaluate(()=>window.trackingView===document.querySelector('[data-view=tracking]')),true);assert.equal(await table.locator('input[type=search]').inputValue(),rows[0].pr);await reset();await record('reset');
  }
  assert.equal(await page.evaluate(()=>window.trackingEvents),0);assert.equal(rawRequests,1);assert.deepEqual(errors,[]);console.log(JSON.stringify({passed:true,rawRequests,states,csv,pageErrors:errors},null,2));
 }finally{if(browser)await browser.close();if(server)await new Promise(r=>server.close(r));assert.equal(path.dirname(runtime),os.tmpdir());assert.ok(path.basename(runtime).startsWith('mro-tracking-browser-'));fs.rmSync(runtime,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
