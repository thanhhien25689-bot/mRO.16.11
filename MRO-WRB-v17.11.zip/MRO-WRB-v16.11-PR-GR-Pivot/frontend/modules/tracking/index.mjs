import {toast} from '../../shared/ui/index.mjs';
import {render,renderSqlTracking} from './view.mjs';
import {syncTracking} from './actions.mjs';
import {readyCodes,pendingLines} from './selectors.mjs';
import {cardFilters} from './cards.mjs';
export {cardFilters};
export {trackingKey,mergeTracking} from './public-model.mjs';
export function mount(root,data,presentation){
 if(data.trackingSource)return renderSqlTracking(root,data,presentation);
 const controller=render(root,data,presentation,lines=>{
  syncTracking(data,lines);
  document.dispatchEvent(new CustomEvent('data-edited',{detail:{views:['tracking','projects','overview']}}));
  toast('Đã cập nhật PR Tracking. Đồng bộ lại không tạo dòng trùng.');
 });
 return Object.assign(controller,{cardFilters:cardFilters({ready:readyCodes(data),pending:pendingLines(data)})});
}

