export function changeType(state,type){state.type=state.type===type?null:type;state.project=null;}
export function changeProject(state,id){state.project=state.project===id?null:id;}
export function reset(state){state.type=null;state.project=null;state.statuses=[];if('dateFrom'in state)state.dateFrom='';if('dateTo'in state)state.dateTo='';}

export function changeStatus(state,status){const values=state.statuses||[];state.statuses=values.includes(status)?[]:[status];}
