export const typeLabel=value=>String(value??'').replace(/\bspare(?:\s+part)?\b/gi,'Spare Part');
// 12/11/2026: Type chỉ có ba giá trị SETUP / SOP / Spare Part (key giữ nguyên để URL/trạng thái
// lọc cũ không đổi). Mọi chỗ lọc theo Type phải dùng đúng giá trị chuẩn này.
const typeTabs=[{key:'setup',type:'SETUP'},{key:'sop',type:'SOP'},{key:'spare',type:'Spare Part'}];
export function cardFilters(){return [{key:'all',type:null},...typeTabs];}
export function cards(projects){return [{key:'all',label:'PROJECT',count:projects.length,color:'cyan',icon:'layers',type:null},...typeTabs.map(({key,type},i)=>({key,label:typeLabel(type),count:projects.filter(p=>(p.types||[p.type]).includes(type)).length,color:['violet','mint','amber'][i],icon:['activity','check','stock'][i],type}))];}
