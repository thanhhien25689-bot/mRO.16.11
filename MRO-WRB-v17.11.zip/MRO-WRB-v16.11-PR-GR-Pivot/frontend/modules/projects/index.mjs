import {render} from './view.mjs';
import {projectList,pivotFields} from './selectors.mjs';
import {changeStatus,reset} from './actions.mjs';
import {toast} from '../../shared/ui/index.mjs';
export {cardFilters} from './cards.mjs';
// 15/11/2026: màn chỉ thống kê MỘT dự án. State gọn: dự án đang chọn, kỳ ngày, lọc tiến độ, code đang mở.
const defaultDateFrom=year=>Number(year)===2026?'2026-10-01':'';
export function mount(root,data,presentation){
 const state={project:null,statuses:[],pivot:[],dateFrom:defaultDateFrom(data.projectYear||new Date().getFullYear()),dateTo:'',codeSearch:'',offline:!!presentation.offline};
 let busy=false,timer,lastRead=Date.now(),drawn=false,lastRenderKey,preferenceKey=null,restoring=false,pendingValidation=false;const expanded=new Set();
 const validDate=(value,year)=>value===''||typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&value.startsWith(year+'-')&&!Number.isNaN(Date.parse(value))&&new Date(value).toISOString().slice(0,10)===value;
 const save=()=>{if(!preferenceKey||restoring)return;try{localStorage.setItem(preferenceKey,JSON.stringify({version:2,year:Number(data.projectYear),project:state.project,dateFrom:state.dateFrom,dateTo:state.dateTo,pivot:state.pivot}));}catch{}};
 const restore=()=>{if(!preferenceKey)return;let saved;try{saved=JSON.parse(localStorage.getItem(preferenceKey)||'null');}catch{return;}const year=Number(data.projectYear);
  if(!saved||saved.version!==2||saved.year!==year||!validDate(saved.dateFrom,year)||!validDate(saved.dateTo,year)||saved.dateFrom&&saved.dateTo&&saved.dateFrom>saved.dateTo)return;
  state.dateFrom=saved.dateFrom;state.dateTo=saved.dateTo;state.project=typeof saved.project==='string'&&saved.project.length<=128?saved.project:null;pendingValidation=!!state.project;
  state.pivot=Array.isArray(saved.pivot)?pivotFields.filter(f=>saved.pivot.includes(f)):[];
 };
 const init=async()=>{if(typeof presentation.identity==='function'){try{const session=await presentation.identity(),user=session?.user;const id=user?.id||user?.username;if(id&&root.isConnected)preferenceKey='mro-project-status-v1:'+encodeURIComponent(String(id));}catch{}}if(!root.isConnected)return;restoring=true;restore();restoring=false;draw();schedule();};
 const draw=()=>{
  // Dự án đã lưu nhưng không còn trong kỳ (đã xóa/đổi tên) thì bỏ chọn, chỉ kiểm khi đã có dữ liệu SQL thật.
  if(pendingValidation&&Array.isArray(data.projectRows)&&(data.projectRows.length||data.projectSource==='sql'||data.projectSource==='empty')){if(!projectList(data.projectRows,state).some(p=>p.id===state.project))state.project=null;pendingValidation=false;}
  const key=JSON.stringify([state.project,state.statuses,state.pivot,state.dateFrom,state.dateTo,[...expanded].sort(),Object.fromEntries(Object.entries(data).filter(([k])=>k.startsWith('project')&&!k.endsWith('UpdatedAt')))]);
  if(drawn&&key===lastRenderKey){const freshness=root.querySelector('[data-project-freshness]');if(freshness)freshness.textContent=freshnessText();return;}
  const scrollers=[document.getElementById('main'),...root.querySelectorAll('.table-scroll, .project-options')].filter(Boolean).map(el=>({el,top:el.scrollTop,left:el.scrollLeft}));
  render(root,data,state,{expanded,
   project:id=>{state.project=id||null;state.statuses=[];state.codeSearch='';expanded.clear();draw();},
   status:status=>{changeStatus(state,status);draw();},
   expand:key=>{expanded.has(key)?expanded.delete(key):expanded.add(key);draw();},
   codeSearch:value=>{state.codeSearch=value;},
   pivot:(field,on)=>{const set=new Set(state.pivot);on?set.add(field):set.delete(field);state.pivot=pivotFields.filter(f=>set.has(f));expanded.clear();draw();},
   reset:()=>{reset(state);state.codeSearch='';expanded.clear();draw();},
   dates:(from,to)=>{state.dateFrom=from;state.dateTo=to;state.statuses=[];draw();},
   year:year=>load(year),reload:()=>load(data.projectYear)});
  drawn=true;
  const next=[document.getElementById('main'),...root.querySelectorAll('.table-scroll, .project-options')].filter(Boolean);scrollers.forEach((s,i)=>{const el=s.el.isConnected?s.el:next[i];if(el){el.scrollTop=s.top;el.scrollLeft=s.left;}});
  lastRenderKey=key;save();
 };
 const freshnessText=()=>`Năm ${data.projectYear} · Kỳ ${state.dateFrom||data.projectYear+'-01-01'} → ${state.dateTo||data.projectYear+'-12-31'} · Nguồn ${data.projectSource||'unavailable'}${data.projectUpdatedAt?' · Cập nhật '+new Date(data.projectUpdatedAt).toLocaleString('vi-VN',{timeZone:'Asia/Ho_Chi_Minh'}):''}`;
 const schedule=()=>{clearTimeout(timer);if(root.isConnected&&!root.hidden&&!document.hidden&&!state.offline)timer=setTimeout(autoRefresh,Math.max(5000,120000-(Date.now()-lastRead)));};
 const wake=()=>{if(!document.hidden&&!root.hidden){if(Date.now()-lastRead>=120000)autoRefresh();else schedule();}else clearTimeout(timer);};document.addEventListener('visibilitychange',wake);
 async function autoRefresh(){if(!root.isConnected||state.offline)return;if(root.hidden||document.hidden||busy||document.getElementById('detail')?.open||root.contains(document.activeElement)&&document.activeElement?.matches('input,textarea')){schedule();return;}busy=true;try{const result=await presentation.reload(data.projectYear);if(!root.isConnected)return;Object.assign(data,result);lastRead=Date.now();draw();}catch(error){lastRead=Date.now();const source=root.querySelector('[data-project-source]');if(source)source.textContent='Tự tải SQL chưa thành công: '+error.message;}finally{busy=false;schedule();}}
 async function load(year){if(busy)return;busy=true;const button=root.querySelector('[data-project-reload]');if(button){button.disabled=true;button.classList.add('is-loading');}const controls=[...root.querySelectorAll('[data-project-year],[data-project-from],[data-project-to]')];controls.forEach(el=>el.disabled=true);try{const result=await presentation.reload(year);const yearChanged=Number(year)!==Number(data.projectYear);Object.assign(data,result);lastRead=Date.now();if(yearChanged){reset(state);state.codeSearch='';expanded.clear();state.dateFrom=defaultDateFrom(data.projectYear);}draw();toast(result.projectError?'Chưa tải được Project Status; kiểm tra cảnh báo.':'Đã tải Project Status.');}catch(error){const input=root.querySelector('[data-project-year]');if(input)input.value=data.projectYear;toast(error.message);}finally{controls.forEach(el=>{if(el.isConnected)el.disabled=state.offline&&el.matches('[data-project-year]');});busy=false;if(button?.isConnected){button.disabled=false;button.classList.remove('is-loading');}schedule();}}
 const observer=new MutationObserver(()=>{if(!root.isConnected){observer.disconnect();clearTimeout(timer);document.removeEventListener('visibilitychange',wake);return;}if(root.hidden)clearTimeout(timer);else if(Date.now()-lastRead>=120000)autoRefresh();else schedule();});observer.observe(root,{attributes:true,attributeFilter:['hidden']});const views=document.getElementById('views');if(views)observer.observe(views,{childList:true});
 if(typeof presentation.identity==='function')void init();else{draw();schedule();}return {reset(){reset(state);expanded.clear();draw();}};
}
