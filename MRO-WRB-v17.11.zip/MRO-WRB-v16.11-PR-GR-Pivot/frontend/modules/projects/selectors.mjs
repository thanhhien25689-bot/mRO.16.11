import {typeLabel} from './cards.mjs';
export const states=['Chờ Cập nhật PR','Đã cập nhật PR','Đã có PO','Đang giao','Đã nhận đủ'];
// "PR Month"/"PO Month" chỉ dùng cho file Excel Chi tiết code: lấy phần YYYY-MM của ngày ISO
// để lọc/pivot được; tháng phải 01-12 và ngày 01-31, còn lại trả chuỗi rỗng (không đoán).
export const monthOf=value=>/^\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])$/.test(String(value??''))?String(value).slice(0,7):'';
export function summarize(rows){
 const groups=new Map();
 for(const row of rows){if(row.classification==='missing-project')continue;let project=groups.get(row.projectId);if(!project){project={id:row.projectId,type:row.type,name:row.project||row.description,description:row.description,model:row.model,process:row.process,rows:[],codes:new Map()};groups.set(row.projectId,project);}project.rows.push(row);project.types=[...new Set(project.rows.map(r=>r.type))];project.type=project.types.join(' / ');project.model=[...new Set(project.rows.map(r=>r.model).filter(Boolean))].join(', ');project.process=[...new Set(project.rows.map(r=>r.process).filter(Boolean))].join(', ');if(row.itemCode){const lines=project.codes.get(row.itemCode)||[];lines.push(row);project.codes.set(row.itemCode,lines);}}
 return [...groups.values()].map(project=>{const codeStates=[...project.codes].map(([code,lines])=>{const phases=lines.map(line=>states.indexOf(line.status));return {code,status:phases.some(i=>i<0)?'Chưa xác định':states[Math.min(...phases)],lineCount:lines.length};});const complete=codeStates.filter(c=>c.status==='Đã nhận đủ').length;return {...project,codes:codeStates,codeCount:codeStates.length,complete,completion:codeStates.length?complete/codeStates.length*100:null};}).sort((a,b)=>a.type.localeCompare(b.type)||a.name.localeCompare(b.name)||a.description.localeCompare(b.description));
}
// Bar tiến độ là LŨY KẾ theo yêu cầu nghiệp vụ 2026-11-03: bar thứ i (i>=1) đếm số code đã đạt từ bước i
// trở lên, riêng bar đầu "Chờ Cập nhật PR" chỉ đếm code chưa có PR No. Code "Chưa xác định" không vào bar nào.
const reached=(status,target)=>{const index=states.indexOf(status);if(index<0)return false;return target<=0?index===0:index>=target;};
export function filterOptions(rows,state){
 const time=rows.filter(r=>(!state.dateFrom||r.prDate>=state.dateFrom)&&(!state.dateTo||r.prDate<=state.dateTo)&&(!state.project||r.projectId===state.project)&&r.classification!=='missing-project');
 const values=key=>[...new Set(time.filter(r=>(key==='type'||!state.type||r.type===state.type)&&(key==='model'||!state.model||r.model===state.model)&&(key==='process'||!state.process||r.process===state.process)).map(r=>r[key]).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'vi'));
 return {type:values('type'),model:values('model'),process:values('process')};
}
export function selectView(rows,state){
 const timeRows=rows.filter(r=>(!state.dateFrom||r.prDate>=state.dateFrom)&&(!state.dateTo||r.prDate<=state.dateTo));
 const projects=summarize(timeRows),filtered=timeRows.filter(r=>(!state.type||r.type===state.type)&&(!state.model||r.model===state.model)&&(!state.process||r.process===state.process));
 const visibleProjects=summarize(filtered),selected=visibleProjects.find(p=>p.id===state.project)||null,selectedProjects=state.project?(selected?[selected]:[]):visibleProjects,codes=selectedProjects.flatMap(p=>p.codes);
 return {projects,visibleProjects,selected,selectionMissing:!!state.project&&!selected,rows:[...(!state.type&&!state.model&&!state.process&&!state.project&&!state.statuses?.length?timeRows.filter(r=>r.classification==='missing-project'):[]),...selectedProjects.flatMap(p=>state.statuses?.length?p.rows.filter(row=>p.codes.some(code=>code.code===row.itemCode&&state.statuses.some(choose=>reached(code.status,states.indexOf(choose))))):p.rows)],codeCount:codes.length,progress:states.map((status,index)=>({status,count:codes.filter(c=>reached(c.status,index)).length})),unknown:codes.filter(c=>c.status==='Chưa xác định').length};
}
export function codeGroups(lines){
 const groups=new Map();for(const line of lines){if(!line.itemCode)continue;const key=JSON.stringify([line.projectId,line.itemCode]);if(!groups.has(key))groups.set(key,{projectId:line.projectId,itemCode:line.itemCode,lines:[],processes:new Set(),models:new Set(),types:new Set()});const group=groups.get(key);group.lines.push(line);if(line.process)group.processes.add(line.process);if(line.model)group.models.add(line.model);if(line.type)group.types.add(line.type);}
 return [...groups.values()].map(group=>{const lines=group.lines,unknown=lines.some(r=>r.unknown),complete=lines.every(r=>!r.unknown&&r.stage===4),status=unknown?'Chưa xác định':complete?'Hoàn tất theo Tracking':lines.some(r=>r.intervention)?'Cần xử lý':'Đang thực hiện';return {...group,processes:[...group.processes],models:[...group.models],types:[...group.types],requirements:new Set(lines.map(r=>r.source==='order'?JSON.stringify(['order',r.rowId]):r.prNo&&r.prSeq?JSON.stringify(['pr',r.prNo,r.prSeq]):JSON.stringify(['unverified',r.rowId]))).size,status,actions:[...new Set(lines.filter(r=>r.outstanding||r.unknown).map(r=>r.nextAction))]};}).sort((a,b)=>a.status.localeCompare(b.status)||a.itemCode.localeCompare(b.itemCode));
}

// Operational evidence is derived separately; summarize/reached remain the approved progress rules.
export function actionLine(row){
 const stage=states.indexOf(row.status),isOrder=row.source==='order';
 const contradictory=(stage===0&&(!isOrder||!!row.prNo))||(stage>0&&!row.prNo)||(stage>=2&&!row.poNo);
 const unknown=stage<0||contradictory||!row.itemCode;
 const nextAction=unknown?'Kiểm tra dữ liệu nguồn':stage===0?'Kiểm tra / Cập nhật PR':stage===1?'Theo dõi tạo PO':stage<4?'Theo dõi giao hàng':'Hoàn tất theo Tracking';
 return {...row,stage,unknown,outstanding:!unknown&&stage<4,intervention:!unknown&&stage===0,nextAction,
  responsible:'Chưa xác định',ownerEvidence:'Nguồn Project Status chưa có trường người phụ trách mua hàng được xác minh; không dùng người tạo PR làm Buyer.',
  operationalStatus:unknown?'Chưa xác định':stage===0?'Cần xử lý':stage===4?'Hoàn tất theo Tracking':'Đang thực hiện',
  sourceLabel:isOrder?'Order':'PR'};
}
export function operationalSummary(project){
 // Collapse only exact repeated PR evidence with complete sequence identifiers. Distinct
 // quantities/statuses and Orders without a verified line key remain separate evidence.
 const seen=new Set(),lines=project.rows.filter(row=>{
  if(row.source==='order'||!row.prNo||!row.prSeq||(row.poNo&&!row.poSeq))return true;
  const key=JSON.stringify(Object.fromEntries(Object.entries(row).filter(([k])=>k!=='rowId').sort(([a],[b])=>a.localeCompare(b))));
  if(seen.has(key))return false;seen.add(key);return true;
 }).map(actionLine),codes=new Map();
 for(const line of lines)if(line.itemCode){if(!codes.has(line.itemCode))codes.set(line.itemCode,[]);codes.get(line.itemCode).push(line);}
 const complete=[...codes.values()].filter(rows=>rows.every(r=>!r.unknown&&r.stage===4)).length;
 const outstanding=[...codes.values()].filter(rows=>rows.some(r=>r.outstanding)).length;
 const unknown=[...codes.values()].filter(rows=>rows.some(r=>r.unknown)).length;
 const stages=states.slice(0,4).map((status,stage)=>({status,count:[...codes.values()].filter(rows=>rows.some(r=>!r.unknown&&r.stage===stage)).length}));
 const overlaps=[...codes].filter(([,rows])=>rows.some(r=>r.sourceLabel==='Order')&&rows.some(r=>r.sourceLabel==='PR')).map(([code])=>code);
 const unknownLines=lines.filter(r=>r.unknown).length;
 const classification=unknownLines||overlaps.length||!codes.size?'Chưa xác định':complete===codes.size?'Hoàn tất theo Tracking':lines.some(r=>r.intervention)?'Cần xử lý':'Đang thực hiện';
 const bottleneck=stages.filter(s=>s.count).sort((a,b)=>b.count-a.count).map(s=>s.status+': '+s.count+' code').join(' · ');
 return {codeCount:codes.size,complete,outstanding,unknown,unknownLines,stages,overlaps,classification,
  bottleneck:[bottleneck,unknownLines?unknownLines+' dòng chưa rõ':'',overlaps.length?overlaps.length+' code Order/PR chưa đối soát':''].filter(Boolean).join(' · ')||'Hoàn tất theo Tracking',
  lines:lines.sort((a,b)=>Number(b.outstanding)-Number(a.outstanding)||Number(b.unknown)-Number(a.unknown)||String(a.itemCode).localeCompare(String(b.itemCode)))};
}
export function operationalView(view){
 const projects=view.selected?[view.selected]:view.visibleProjects.filter(p=>!view.selectionMissing);
 const summaries=projects.map(p=>({project:p,operation:operationalSummary(p)}));
 return {summaries,lines:summaries.flatMap(({operation})=>operation.lines),codeCount:summaries.reduce((n,s)=>n+s.operation.codeCount,0)};
}

// 15/11/2026: Project Status chỉ thống kê MỘT dự án được tìm. Mọi số trên màn đều lấy từ hàm này
// để KPI, thanh tiến độ và bảng theo code dùng cùng một trạng thái code (quy tắc summarize đã duyệt).
export const foldText=value=>String(value??'').toLocaleLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/đ/g,'d');
export function inPeriod(row,state){return (!state.dateFrom||row.prDate>=state.dateFrom)&&(!state.dateTo||row.prDate<=state.dateTo);}
export function projectList(rows,state){return summarize(rows.filter(r=>inPeriod(r,state))).sort((a,b)=>a.name.localeCompare(b.name,'vi'));}
// Recent means latest PR/Order date available in the current period, not creation time.
export function recentProjects(projects){
 const latest=p=>(p.rows||[]).map(r=>String(r.prDate||'').slice(0,10)).filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d)).sort().at(-1)||'';
 return projects.map(p=>({...p,latestDate:latest(p)})).sort((a,b)=>b.latestDate.localeCompare(a.latestDate)||a.name.localeCompare(b.name,'vi')||String(a.id).localeCompare(String(b.id)));
}
export function searchProjects(projects,query,limit=50){const q=foldText(query).trim();return (q?projects.filter(p=>foldText(p.name).includes(q)):projects).slice(0,limit);}
const sumAmounts=lines=>{let total=0,priced=0,missing=0;for(const r of lines){if(Number.isFinite(r.amountUsd)){total+=r.amountUsd;priced++;}else missing++;}return {total:Math.round(total*100)/100,priced,missing};};
// Tiền PR: mỗi PR_NO + PR_SEQ chỉ tính một lần (PR tách nhiều dòng PO vẫn là một PR). Dòng Order chưa có PR
// tính riêng làm tham khảo vì chưa có khóa chứng từ xác nhận Order ↔ PR (không cộng chung với tiền PR).
function amountSplit(lines){
 const seen=new Set(),pr=[],order=[];
 for(const r of lines){if(r.source==='order'){order.push(r);continue;}if(!r.prNo||!r.prSeq){pr.push(r);continue;}const key=r.prNo+'\u0000'+r.prSeq;if(seen.has(key))continue;seen.add(key);pr.push(r);}
 return {pr:sumAmounts(pr),order:sumAmounts(order)};
}
// Tổng số lượng theo code (chỉ dòng PR; dòng Order chưa có PR không có PR/PO/GR Qty):
// PR Qty cộng mỗi PR_NO + PR_SEQ một lần (PR tách nhiều dòng PO không bị cộng lặp), PO Qty và GR Qty cộng mỗi
// PO_NO + PO_SEQ một lần. Dòng có chứng từ nhưng số lượng trống được đếm vào `missing` (không coi là 0).
export function codeQuantities(lines){
 const sum=(key,docKey)=>{const seen=new Set();let total=0,count=0,missing=0;for(const r of lines){if(r.source==='order')continue;const doc=docKey(r);if(!doc)continue;if(seen.has(doc))continue;seen.add(doc);if(Number.isFinite(r[key])){total+=r[key];count++;}else missing++;}return {total:count?Math.round(total*1000)/1000:null,count,missing};};
 const pr=r=>r.prNo?JSON.stringify([r.prNo,r.prSeq||r.rowId]):'',po=r=>r.poNo?JSON.stringify([r.poNo,r.poSeq||r.rowId]):'';
 return {pr:sum('prQty',pr),po:sum('poQty',po),gr:sum('grQty',po)};
}
export const pivotFields=['type','model','process'];
// Trạng thái một nhóm dòng theo đúng quy tắc summarize: bước sớm nhất; có dòng ngoài năm bước → Chưa xác định.
export function lineStatus(lines){const phases=lines.map(r=>states.indexOf(r.status));return !phases.length||phases.some(i=>i<0)?'Chưa xác định':states[Math.min(...phases)];}
export function projectFocus(rows,state){
 const projects=projectList(rows,state),selected=projects.find(p=>p.id===state.project)||null;
 if(!selected)return {projects,selected:null,selectionMissing:!!state.project};
 const operation=operationalSummary(selected),codeStatus=new Map(selected.codes.map(c=>[c.code,c.status])),order=['Chưa xác định',...states];
 // Pivot (15/11/2026): người dùng có thể thêm Type / Model / Process làm cột nhóm bên trái Item Code (thứ tự cố định
 // Type → Model → Process). Mỗi tổ hợp giá trị + Item Code là một dòng; số lượng/tiền/trạng thái tính trên đúng các dòng
 // của tổ hợp đó (một code dùng ở hai Process thành hai dòng, như Pivot Excel). Không chọn cột nào = mỗi code một dòng.
 const pivot=pivotFields.filter(f=>state.pivot?.includes(f)),blank='(trống)';
 const valueOf=(r,f)=>(f==='type'?typeLabel(r.type):r[f])||blank;
 const parts=new Map();for(const line of operation.lines){const key=JSON.stringify(pivot.map(f=>valueOf(line,f)));if(!parts.has(key))parts.set(key,[]);parts.get(key).push(line);}
 const groups=[...parts].flatMap(([key,lines])=>{const values=JSON.parse(key);return codeGroups(lines).map(g=>{const first=g.lines[0]||{};return {...g,key:JSON.stringify([g.projectId,...values,g.itemCode]),pivot:Object.fromEntries(pivot.map((f,i)=>[f,values[i]])),
  status:pivot.length?lineStatus(g.lines):codeStatus.get(g.itemCode)||'Chưa xác định',specification:first.specification||first.itemName||'',category:first.category||'',amount:amountSplit(g.lines),quantity:codeQuantities(g.lines),projectName:selected.name};});})
  .sort((a,b)=>{for(const f of pivot){const x=a.pivot[f],y=b.pivot[f];if(x!==y)return x===blank?1:y===blank?-1:x.localeCompare(y,'vi');}return order.indexOf(a.status)-order.indexOf(b.status)||a.itemCode.localeCompare(b.itemCode);});
 const chosen=state.statuses?.[0],chosenIndex=states.indexOf(chosen);
 const visibleGroups=chosenIndex<0?groups:groups.filter(g=>reached(g.status,chosenIndex));
 const unknown=selected.codes.filter(c=>c.status==='Chưa xác định').length;
 return {projects,selected,selectionMissing:false,operation,groups,pivot,visibleGroups,
  codeCount:selected.codeCount,complete:selected.complete,completion:selected.completion,unknown,open:selected.codeCount-selected.complete,
  progress:states.map((status,index)=>({status,count:selected.codes.filter(c=>reached(c.status,index)).length})),
  amount:amountSplit(operation.lines),lineCount:selected.rows.length,
  notes:{missingCode:selected.rows.filter(r=>!r.itemCode).length,incomplete:selected.rows.filter(r=>r.classification==='incomplete').length,unknownLines:operation.unknownLines,overlaps:operation.overlaps}};
}
