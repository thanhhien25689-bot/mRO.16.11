const fs=require('node:fs');
const path=require('node:path');

function createSnapshotCache({runtime,build,available=()=>true,intervalMs=300000,now=()=>new Date()}={}){
  const directory=path.join(runtime,'cache');
  const dataFile=path.join(directory,'raw.json');
  const manifestFile=path.join(directory,'manifest.json');
  let current=null,pending=null,timer=null,lastError=null;
  function readDisk(){
    if(current)return current;
    try{
      const value=JSON.parse(fs.readFileSync(dataFile,'utf8'));
      if(value&&typeof value==='object'&&Array.isArray(value.items)&&value.asOf){
        current={data:value,updatedAt:JSON.parse(fs.readFileSync(manifestFile,'utf8')).updatedAt||null,source:'server-cache'};
      }
    }catch{}
    return current;
  }
  function write(value){
    fs.mkdirSync(directory,{recursive:true});
    const updatedAt=now().toISOString();
    const tmp=dataFile+'.'+process.pid+'.tmp';
    fs.writeFileSync(tmp,JSON.stringify(value));
    fs.renameSync(tmp,dataFile);
    const manifest={version:1,updatedAt,source:'sql',keys:Object.keys(value).sort()};
    const mtmp=manifestFile+'.'+process.pid+'.tmp';
    fs.writeFileSync(mtmp,JSON.stringify(manifest,null,2));
    fs.renameSync(mtmp,manifestFile);
    current={data:value,updatedAt,source:'server-cache'};lastError=null;return current;
  }
  async function refresh(){
    if(pending)return pending;
    pending=(async()=>write(await build()))().finally(()=>{pending=null;bootServed=false;});
    try{return await pending;}catch(error){lastError=error;throw error;}
  }
  function start(){
    readDisk();
    if(timer||intervalMs<=0)return;
    timer=setInterval(()=>{void refresh().catch(()=>{});},intervalMs);
    timer.unref?.();
  }
  function stop(){if(timer)clearInterval(timer);timer=null;}
  // 12/11/2026: bản sao đĩa chỉ tăng tốc LẦN đọc đầu sau khi khởi động (đăng nhập là có dữ liệu
  // ngay, không phải chờ đủ 8 nguồn). Từ lần kế tiếp, còn cấu hình SQL là đọc lại thật — người
  // dùng bấm "Cập nhật" phải thấy dữ liệu hiện tại, không phải snapshot 5 phút trước; chính chỗ
  // này trước đây trả mãi bản sao cũ nên Portal không bao giờ chịu làm mới. Mất kết nối (hoặc
  // dựng snapshot lỗi) mới quay về bản sao gần nhất, kèm đúng nguyên nhân.
  let bootServed=false;
  async function get({refreshIfMissing=true}={}){
    const value=readDisk();
    // Offline/preview mode: available()=false khoá mọi refresh để không ghi đè cache tốt bằng bản rỗng.
    if(value&&!available())return value;
    if(value&&pending)return value;
    if(value&&!bootServed){bootServed=true;void refresh().catch(()=>{});return value;}
    if(!refreshIfMissing)return value||null;
    try{return await refresh();}
    catch(error){
      return value||{data:{asOf:new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}),production:{plan:0,actual:0},items:[],requests:[],codes:[],tracking:[],deliveries:[],budget:[],purchaseLines:[],dataErrors:[{source:'snapshot',message:String(error?.message||'Chưa tải được SQL.').slice(0,300)}]},updatedAt:null,source:'empty'};
    }
  }
  return {start,stop,get,refresh,get lastError(){return lastError;},directory,dataFile,manifestFile};
}

module.exports={createSnapshotCache};
