function setSecurityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' https://genai.sec.samsung.net ws://localhost:29282 wss://localhost:29283 ws://127.0.0.1:29282 wss://127.0.0.1:29283; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
}

module.exports = {setSecurityHeaders};
