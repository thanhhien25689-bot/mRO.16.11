const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

// 12/11/2026 — "Lưu snapshot tất cả các màn, vào màn là dựng ngay".
// Mỗi màn đọc một endpoint /api/*-live riêng. Ở đây giữ bản thành công gần nhất của TỪNG endpoint
// trong runtime/cache/screens và áp hai quy tắc:
//  1) SQL lỗi/mất kết nối -> trả bản gần nhất kèm x-mro-snapshot, màn không còn trắng xoá;
//  2) SQL lâu hơn `patienceMs` -> trả bản gần nhất ngay để màn hiện số, SQL chạy nốt nền rồi
//     được lưu lại cho lần đọc kế tiếp.
// Nguon SQL nhanh (trả trước hạn) thì hành vi y hệt cũ: không đệm, không đổi nội dung trả về.
// Yêu cầu có header x-mro-refresh (nút "Cập nhật") được bỏ qua hạn chế 2 để người dùng luôn
// thấy số hiện tại khi chủ động tải lại.
const SCREEN_ENDPOINTS=[
  '/api/budget-oh/live','/api/cost-saving','/api/stock-live','/api/orders-live','/api/orders-context',
  '/api/delivery-live','/api/codes-live','/api/tracking-live','/api/aps-live','/api/vendor-data','/api/data-tracking'
];
function isScreenEndpoint(pathname){return SCREEN_ENDPOINTS.includes(pathname)}
// Module API báo lỗi NGAY TRONG 200 (warning/degraded/connected:false) — nếu không biết điều này
// thì bản "không đọc được SQL" sẽ bị coi là dữ liệu tốt: vừa đè snapshot tốt trên đĩa, vừa khiến
// màn không bao giờ được cứu bằng bản gần nhất. Cảnh báo lành tính (năm chưa có dữ liệu) KHÔNG tính.
function degraded(data){
  if(!data||typeof data!=='object'||Array.isArray(data))return false;
  if(data.degraded===true||data.connected===false)return true;
  const notes=[data.error,data.warning].filter(Boolean).join(' ').toLowerCase();
  if(!notes)return false;
  return /không (đọc|tải|kết nối|phản hồi|lấy|truy cập)|mất kết nối|không hợp lệ|lỗi|timeout|refused|econn/.test(notes);
}
function snapshotKey(pathname,search){return (pathname+(search||'')).replace(/[^\w.-]+/g,'_').slice(0,120)+'-'+crypto.createHash('sha1').update(pathname+(search||'')).digest('hex').slice(0,10)+'.json'}
// res giả chỉ thu output vào bộ đệm rồi mới quyết định gửi gì; module chỉ dùng writeHead/write/end.
function createCollector(){
  const state={code:null,headers:{},chunks:[],ended:false,error:null};
  const finish=()=>{state.ended=true;if(state.onFinish)state.onFinish()};
  const res={
    statusCode:200,headersSent:false,writableEnded:false,
    setHeader(name,value){state.headers[name]=value;return res},
    getHeader(name){return state.headers[name]},
    removeHeader(name){delete state.headers[name];return res},
    writeHead(status,headers){state.code=status;if(headers)Object.assign(state.headers,headers);res.statusCode=status;res.headersSent=true;return res},
    write(chunk){if(chunk!==undefined&&chunk!==null)state.chunks.push(Buffer.from(chunk));return true},
    end(chunk){if(chunk!==undefined&&chunk!==null)state.chunks.push(Buffer.from(chunk));finish();return res},
    on(event,handler){if(event==='finish'||event==='close')state.onFinish=handler;return res},
    once(event,handler){return res.on(event,handler)},
    removeListener(){return res},emit(){return false},addListener(){return res},
    writeContinue(){},addTrailers(){},flushHeaders(){},cork(){},uncork(){},
    destroy(){finish()},destroySoon(){finish()},
    get body(){return Buffer.concat(state.chunks)},
    locals:{},socket:{setTimeout(){},setNoDelay(){}}
  };
  return {res,state};
}
function createScreenSnapshots({runtime,patienceMs=2500,maxBytes=8*1024*1024,now=()=>new Date()}={}){
  const directory=path.join(runtime,'cache','screens');
  function fileFor(key){return path.join(directory,key)}
  function read(pathname,search){
    try{
      const value=JSON.parse(fs.readFileSync(fileFor(snapshotKey(pathname,search)),'utf8'));
      if(value&&value.data!==undefined&&value.savedAt)return value;
    }catch{}
    return null;
  }
  function write(pathname,search,body){
    if(!Buffer.isBuffer(body)||!body.length||body.length>maxBytes)return null;
    let data;
    try{data=JSON.parse(body.toString('utf8'))}catch{return null} // chi dam nhiem JSON (cac /api/*-live)
    if(degraded(data))return null; // không bao giờ lưu bản lỗi/degraded
    const record={savedAt:now().toISOString(),pathname,search:search||'',data};
    try{
      fs.mkdirSync(directory,{recursive:true});
      const file=fileFor(snapshotKey(pathname,search));
      const temp=`${file}.${process.pid}.tmp`;
      fs.writeFileSync(temp,JSON.stringify(record));
      fs.renameSync(temp,file);
    }catch{}
    return record;
  }
  function replay(res,state){
    const headers={...state.headers};
    if(res.headersSent)return;
    res.writeHead(state.code??200,headers);
    res.end(state.chunks.length?Buffer.concat(state.chunks):undefined);
  }
  function sendSnapshot(res,record,reason){
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','x-mro-snapshot':record.savedAt,'x-mro-snapshot-reason':reason});
    res.end(JSON.stringify(record.data));
  }
  // runReal(chu) : hàm xử lý thật (thường là auth.handle với res được thay bằng res giả).
  async function serve(req,res,url,runReal){
    const record=read(url.pathname,url.search);
    const skipHedge=!record||req.headers?.['x-mro-refresh']==='1';
    const collector=createCollector();
    let delivered=false;
    let timer=null;
    if(!skipHedge)timer=setTimeout(()=>{if(delivered)return;delivered=true;sendSnapshot(res,record,'slow')},patienceMs);
    timer?.unref?.();
    try{await runReal(collector.res)}catch(error){collector.state.error=error}
    if(timer)clearTimeout(timer);
    // SQL trả về sau khi bản cũ đã được gửi: chỉ lưu, không gửi lần hai.
    if(delivered){if(!collector.state.error)write(url.pathname,url.search,collector.state.chunks.length?Buffer.concat(collector.state.chunks):Buffer.alloc(0));return}
    delivered=true;
    // Không có handler nào trả lời (404 thật) thì trả 404, không bịa snapshot cho endpoint lạ.
    if(collector.state.code===null&&!collector.state.chunks.length){res.writeHead(404,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}).end(JSON.stringify({message:'Không tìm thấy endpoint.'}));return}
    const code=collector.state.code??500;
    const body=collector.state.chunks.length?Buffer.concat(collector.state.chunks):Buffer.alloc(0);
    let payload=null;try{payload=JSON.parse(body.toString('utf8'))}catch{}
    const broken=!(code>=200&&code<300&&body.length)||!!collector.state.error||degraded(payload);
    // Bản hỏng mà còn bản gần nhất thì đưa bản gần nhất; người dùng bấm "Cập nhật" thì tôn trọng
    // yêu cầu tải lại: trả đúng những gì module nói, không giấu bằng dữ liệu cũ.
    if(broken&&record&&collector.state.code!==null&&!skipHedge){sendSnapshot(res,record,collector.state.error?'error':'partial');return}
    if(!broken)write(url.pathname,url.search,body);
    replay(res,collector.state);
  }
  return {directory,read,write,serve,isScreenEndpoint,patienceMs};
}
module.exports={createScreenSnapshots,isScreenEndpoint,SCREEN_ENDPOINTS};