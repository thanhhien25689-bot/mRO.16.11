const fs = require('node:fs');
const path = require('node:path');
const {readTreeConfig} = require('./config.cjs');

function createStaticHandler({root, auth, budget,stock,delivery,orders,codes,tracking,projects,aps,costSaving,snapshotCache}) {
  const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml'};
  return function serveStatic(req, res, pathname) {
    if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405).end(); return; }
    if (pathname === '/aps-app') { res.writeHead(301, { Location: '/aps-app/' }).end(); return; }
    if (pathname.startsWith('/aps-app/')) {
      // Ngoại lệ chính xác cho ứng dụng APS nhúng (chỉ same-origin): app cũ dùng thuộc tính sự kiện inline.
      res.setHeader('X-Frame-Options', 'SAMEORIGIN');
      res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'; form-action 'self'");
    }
    const allowed = pathname === '/frontend/integration/genai.mjs' || pathname === '/frontend/integration/presence.mjs' || ['/aps-app/','/aps-app/index.html','/aps-app/app.mjs','/aps-app/styles.css'].includes(pathname) || ['/modules/data-tracking/index.mjs','/frontend/modules/data-tracking/index.mjs','/modules/aps/index.mjs','/frontend/modules/aps/index.mjs'].includes(pathname) || pathname === '/' || ['/index.html', '/app.mjs'].includes(pathname) || ['/assets/favicon.svg', '/assets/readability.css', '/assets/styles.css', '/assets/theme-init.js', '/modules/codes/index.mjs', '/modules/delivery/index.mjs', '/modules/inventory/index.mjs', '/modules/orders/index.mjs', '/modules/overview/index.mjs', '/modules/tracking/index.mjs', '/modules/tracking/public-card-filters.mjs', '/modules/tracking/public-model.mjs', '/shared/auth-ui.mjs', '/shared/card-filters.mjs', '/shared/icons.mjs', '/shared/model.mjs', '/shared/screen-cache.mjs', '/shared/store.mjs', '/shared/ui.mjs'].includes(pathname) || pathname === '/data/raw.json' || ['/frontend/core/bootstrap.mjs', '/frontend/core/router.mjs', '/frontend/core/module-registry.mjs', '/frontend/core/data-store.mjs', '/frontend/core/auth-gate.mjs'].includes(pathname) || ['/frontend/shared/ui/index.mjs', '/frontend/shared/ui/table.mjs', '/frontend/shared/ui/dialog.mjs', '/frontend/shared/ui/toast.mjs', '/frontend/shared/ui/charts.mjs', '/frontend/shared/ui/primitives.mjs', '/frontend/shared/utils/format.mjs', '/frontend/shared/utils/csv.mjs', '/frontend/shared/utils/holder-store.mjs'].includes(pathname) || ['/frontend/modules/delivery/index.mjs', '/frontend/modules/delivery/view.mjs', '/frontend/modules/delivery/cards.mjs', '/frontend/modules/delivery/selectors.mjs', '/frontend/modules/delivery/actions.mjs'].includes(pathname) || ['/frontend/modules/inventory/index.mjs', '/frontend/modules/inventory/view.mjs', '/frontend/modules/inventory/cards.mjs', '/frontend/modules/inventory/selectors.mjs', '/frontend/modules/inventory/actions.mjs'].includes(pathname) || ['/frontend/modules/overview/index.mjs', '/frontend/modules/overview/view.mjs', '/frontend/modules/overview/cards.mjs', '/frontend/modules/overview/selectors.mjs', '/frontend/modules/overview/actions.mjs', '/frontend/modules/overview/budget.mjs'].includes(pathname) || ['/frontend/modules/orders/index.mjs', '/frontend/modules/orders/view.mjs', '/frontend/modules/orders/cards.mjs', '/frontend/modules/orders/selectors.mjs', '/frontend/modules/orders/actions.mjs', '/frontend/integration/procurement.mjs', '/frontend/integration/notifications.mjs','/frontend/integration/downloads.mjs','/frontend/integration/mail.mjs','/frontend/integration/aps-contracts.mjs','/frontend/integration/aps-plan.mjs','/frontend/integration/messages.mjs'].includes(pathname) || ['/frontend/modules/codes/index.mjs', '/frontend/modules/codes/view.mjs', '/frontend/modules/codes/cards.mjs', '/frontend/modules/codes/selectors.mjs', '/frontend/modules/codes/actions.mjs'].includes(pathname) || ['/frontend/modules/tracking/index.mjs', '/frontend/modules/tracking/view.mjs', '/frontend/modules/tracking/cards.mjs', '/frontend/modules/tracking/selectors.mjs', '/frontend/modules/tracking/actions.mjs', '/frontend/modules/tracking/public-model.mjs'].includes(pathname) || ['/modules/projects/index.mjs','/frontend/modules/projects/index.mjs','/frontend/modules/projects/view.mjs','/frontend/modules/projects/cards.mjs','/frontend/modules/projects/selectors.mjs','/frontend/modules/projects/actions.mjs'].includes(pathname);
    const extraAssets = ['/assets/db-alert.css','/assets/db-alert.js'];
    const vendorAssets = ['/modules/vendor/index.mjs','/frontend/modules/vendor/index.mjs'];
    const setpbaAssets = ['/modules/setpba/index.mjs','/modules/setpba/operations.mjs','/frontend/modules/setpba/index.mjs','/frontend/modules/setpba/operations.mjs'];
    if ((!allowed && !extraAssets.includes(pathname) && !vendorAssets.includes(pathname) && !setpbaAssets.includes(pathname)) || pathname.includes('..') || pathname.includes('\\')) { res.writeHead(404).end('Not found'); return; }
    let _rawUser = null;
    if (pathname === '/data/raw.json') {
      try {
        const s = auth.requireUser(req);
        if (s.user.mustChangePassword) throw {status:403};
        _rawUser = s.user;
      } catch (e) {
        res.writeHead(e.status || 401, {'Content-Type':'application/json'}).end(JSON.stringify({message:'Login required.'}));
        return;
      }
    }
    const file = pathname === '/aps-app/' ? path.resolve(root, './aps-app/index.html') : path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
    fs.readFile(file, async (error, body) => {
      // /data/raw.json is generated from SQL/cache below. Source-only releases
      // need no physical raw.json; keep ordinary static-file failures as 404.
      if (error && !(pathname === '/data/raw.json' && budget)) { res.writeHead(404).end('Not found'); return; }
      if (pathname === '/data/raw.json' && budget) {
        // Vendor users receive a scoped response: no SEV aggregate stock, no cross-vendor balances.
        if (_rawUser?.vendorScope) {
          const asOf=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'});
          body=JSON.stringify({asOf,production:{plan:0,actual:0},items:[],requests:[],codes:[],tracking:[],deliveries:[],budget:[],purchaseLines:[],stockSource:'vendor-scoped',dataErrors:[]});
          res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
          res.end(req.method==='HEAD'?undefined:body);
          return;
        }
        try {
          if(snapshotCache){
            const snapshot=await snapshotCache.get();
            body=JSON.stringify(snapshot.data);
            res.setHeader('X-MRO-Snapshot-At',snapshot.updatedAt||'');
            res.setHeader('X-MRO-Snapshot-Source',snapshot.source||'server-cache');
          } else {
          const data={asOf:new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}),production:{plan:0,actual:0},items:[],requests:[],codes:[],tracking:[],deliveries:[],budget:[],purchaseLines:[]};
          const errors=[];
          const safeMessage=error=>String(error&&error.message||'Không đọc được nguồn dữ liệu.').slice(0,300);
          const readSource=(name,task)=>Promise.resolve().then(task).catch(error=>{errors.push({source:name,message:safeMessage(error)});return {};});
          let base;
          try { base=budget.overlay(data); }
          catch(error) { errors.push({source:'budget',message:safeMessage(error)});base=data; }
          const [stockData,deliveryData,orderData,codesData]=await Promise.all([
            readSource('stock',()=>stock?stock.live(base):{}),
            readSource('delivery',()=>delivery?delivery.live(base):{}),
            readSource('orders',()=>orders?orders.live(base):{}),
            readSource('codes',()=>codes?codes.live(base):{})
          ]);
          let next={...base,...stockData,...deliveryData,...orderData,...codesData};
          const applySource=async(name,task)=>{const value=await readSource(name,task);next={...next,...value};};
          if(tracking)await applySource('tracking',()=>tracking.refresh(next));
          if(projects)await applySource('projects',()=>projects.live(next));
          if(aps)await applySource('aps',()=>aps.live(next));
          if(costSaving)await applySource('cost-saving',()=>costSaving.live(next));
          if(errors.length)next.dataErrors=errors;
          body=JSON.stringify(next);
          }
        }
        catch(e) {res.writeHead(500,{'Content-Type':'application/json'}).end(JSON.stringify({message:'Không đọc được dữ liệu nền của Portal. Kiểm tra máy chủ.'}));return;}
      }
      if (path.extname(file) === '.html') {
        // Đọc mỗi lần phục vụ HTML như trước; không cache cấu hình.
        const config = readTreeConfig(root);
        const initial = ['overview','inventory','delivery','projects','data-tracking','aps','orders','codes','tracking'].includes(config.module) ? config.module : 'overview';
        body = body.toString().replace('name="mro-start" content="overview"', 'name="mro-start" content="' + initial + '"');
      }
      // Portal thay đổi module frontend theo từng bản triển khai; không để browser/LAN client
      // giữ HTML hoặc module cũ rồi chạy lệch với backend hiện tại.
      res.writeHead(200, {'Content-Type':mime[path.extname(file)] || 'application/octet-stream','Cache-Control':'no-store'});
      res.end(req.method === 'HEAD' ? undefined : body);
    });
  };
}

module.exports = {createStaticHandler};
