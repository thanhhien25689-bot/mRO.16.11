const {createAI}=require('../modules/ai/index.cjs');
const {createPricing}=require('../modules/pricing/index.cjs');
const {createDataTracking}=require('../modules/data-tracking/index.cjs');
const {createAps}=require('../modules/aps/index.cjs');
const {createApsContracts}=require('../modules/aps/contracts.cjs');
const {createApsPlan}=require('../modules/aps/plan.cjs');
const {createApsApp}=require('../modules/aps/app.cjs');
const {createOrderContext}=require('../integration/procurement-context.cjs');
const http = require('node:http');
const path = require('node:path');
const {createAuth} = require('../../server/auth.cjs');
const {createBudget} = require('../modules/budget/index.cjs');
const {createCostSaving}=require('../modules/cost-saving/index.cjs');
const {createNotifications}=require('../modules/notifications/index.cjs');
const {createMail}=require('../modules/mail/index.cjs');
const {createMessages}=require('../modules/messages/index.cjs');
const {createKnox}=require('../modules/knox/index.cjs');
const {createDownloads}=require('../modules/downloads/index.cjs');
const {createProjects}=require('../modules/projects/index.cjs');
const {prState}=require('../modules/tracking/index.cjs');
const {createTracking}=require('../modules/tracking/index.cjs');
const {createCodes}=require('../modules/codes/index.cjs');
const {createOrders}=require('../modules/orders/index.cjs');
const {createDelivery}=require('../modules/delivery/index.cjs');
const {createStock}=require('../modules/stock/index.cjs');
const {createVendor}=require('../modules/vendor/index.cjs');
const {createSql} = require('../modules/sql/index.cjs');
const {createSetPba} = require('../modules/setpba/index.cjs');
const {projectRoot} = require('./config.cjs');
const {createStaticHandler} = require('./static-files.cjs');
const {setSecurityHeaders} = require('./middleware/security-headers.cjs');
const {createSnapshotCache} = require('./snapshot-cache.cjs');
const {createScreenSnapshots, isScreenEndpoint} = require('./screen-snapshot.cjs');
const fs = require('node:fs');

function createServer({root = projectRoot, runtime = path.join(root, '.runtime'),sqlAdapter} = {}) {
  const sql = sqlAdapter||createSql({runtime});
  const budget = createBudget({runtime, root, sql});
  const stock=createStock({root,runtime,sql});
  const vendor=createVendor({runtime,sql});
  const delivery=createDelivery({sql});
  const pricing=createPricing({sql});
  const codes=createCodes({root,runtime,sql,pricing});
  const tracking=createTracking({root,runtime,sql,codes,prReasons:()=>projects.prReasons});
  const orders=createOrders({sql,pricing,getOrderContext:createOrderContext({codes,tracking})});
  const projects=createProjects({root,runtime,sql,getOrderTypes:codes.purchaseTypes,classifyPR:prState,pricing});
  const downloads=createDownloads({sql,root});
  const dataTracking=createDataTracking({sql,runtime});
  const notifications=createNotifications({sql,codes,tracking});
  const aps=createAps({sql});
  const costSaving=createCostSaving({sql});
  const apsApp=createApsApp({runtime,contractCheck:async no=>{if(!sql||typeof sql.readApsContracts!=='function')throw Error('Portal chưa có kết nối SQL để kiểm tra bảng Hợp đồng dịch vụ');const rows=await sql.readApsContracts();const key=String(no||'').trim().toLowerCase();return rows.some(c=>String(c.contractNo||'').trim().toLowerCase()===key)}});
  const apsContracts=createApsContracts({runtime,sql});
const apsPlan=createApsPlan({sql});
  const snapshotSteps=[['Tồn kho',seed=>stock?stock.live(seed):seed],['Giao hàng',seed=>delivery?delivery.live(seed):seed],['Order',seed=>orders?orders.live(seed):seed],['Codes',seed=>codes?codes.live(seed):seed],['Tracking',seed=>tracking?tracking.refresh(seed):seed],['Project',seed=>projects?projects.live(seed):seed],['Repair & Service',seed=>aps?aps.live(seed):seed],['Cost Saving',seed=>costSaving?costSaving.live(seed):seed]];
  // Mail cần đủ dữ liệu nên fail-fast: một nguồn lỗi là báo lỗi, không gửi mail với số thiếu. Bốn nguồn đầu đọc độc lập nên chạy song song đúng như /data/raw.json của static handler (tổng thời gian chỉ bằng nguồn chậm nhất); Tracking/Project/Repair/Cost Saving giữ tuần tự vì cần dữ liệu đã nạp.
  const PARALLEL_SOURCES=4;
  const dashboardChain=async()=>{
    const seed={asOf:new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}),production:{plan:0,actual:0},items:[],requests:[],codes:[],tracking:[],deliveries:[],budget:[],purchaseLines:[]};
    const runStep=async([,step],input)=>{try{return await step(input);}catch{return {};}};
    const base=budget.overlay(seed);
    // 12/11/2026: mọi nguồn (Tồn kho/Giao hàng/Order/Codes/Project/Repair…) trả về nguyên object
    // đầu vào đã rải ({...data, ...nguồn của nó}), nên gộp bằng Object.assign thông thường làm
    // nguồn chạy SAU đè mảng RỖNG của chính nó lên kết quả nguồn chạy TRƯỚC: Tồn kho đọc được
    // items rồi bị Giao hàng/Order/Codes đè items=[] trở lại, /data/raw.json mất danh sách hàng
    // tồn dù stockSource vẫn là "sql". Gộp theo quy tắc: khóa nào trả về đúng tham chiếu giá trị
    // của seed là khóa nguồn này chưa đụng tới -> bỏ qua, không cho đè.
    const keepChanged=(acc,part)=>{const out={...acc};for(const [key,value] of Object.entries(part||{})){if(base[key]===value)continue;out[key]=value;}return out;};
    const parts=await Promise.all(snapshotSteps.slice(0,PARALLEL_SOURCES).map(step=>runStep(step,base)));
    let next=parts.reduce(keepChanged,{...base});
    for(const [,step] of snapshotSteps.slice(PARALLEL_SOURCES)){try{next=keepChanged(next,await step(next));}catch{}}
    return next;
  };
  const dashboardSnapshot=()=>dashboardChain();
  const snapshotCache=createSnapshotCache({runtime,build:dashboardSnapshot,available:()=>process.env.MRO_OFFLINE!=='1'&&fs.existsSync(path.join(runtime,'sql','connection.json'))});
  // 12/11/2026: bộ đệm snapshot riêng cho TỪNG màn /api/*-live (backend/core/screen-snapshot.cjs).
  const screenSnapshots=createScreenSnapshots({runtime});
  // Tin nhắn Knox không dựng cả dashboard 8 nguồn nữa (nguồn gốc timeouts 25 giây): mỗi nhóm thẻ chỉ đọc API công khai của đúng màn đó — PR & Tracking qua tracking.live() y hệt GET /api/tracking-live, Codes qua codes.live(), Repair/Service qua aps.snapshot().
  const messageSnapshot=async()=>{const value=await tracking.live();return{trackingSQL:value.trackingSQL,trackingSource:value.trackingSource,trackingError:value.trackingError};};
  const codesMessageSnapshot=async()=>codes.live({codes:[]});
  const apsMessageSnapshot=async()=>aps.snapshot();
  const mail=createMail({runtime,getDashboard:dashboardSnapshot});
  const messages=createMessages({runtime,getTracking:messageSnapshot,getCodes:codesMessageSnapshot,getAps:apsMessageSnapshot});
  const knox=createKnox({readConfig:messages.readConfig});
  const ai=createAI({sql,codes,tracking});
  // SP_USE_MOCK=1 enables in-memory store for dev/test; no SQL fallback — explicit opt-in only.
  let sp = null;
  if (process.env.SP_USE_MOCK === '1') {
    const { createMockStore } = require('../modules/setpba/mock-store.cjs');
    sp = createSetPba({ store: createMockStore({ seed: true }) });
  }

  const auth = createAuth(runtime, {ai,budget, sql,stock,vendor,delivery,orders,codes,tracking,notifications,projects,downloads,dataTracking,aps,apsApp,apsContracts,apsPlan,costSaving,mail,messages,knox,sp});
  const serveStatic = createStaticHandler({root, auth, budget,stock,delivery,orders,codes,tracking,projects,aps,costSaving,snapshotCache});
  const server = http.createServer(async (req, res) => {
    setSecurityHeaders(res);
    let url, pathname;
    try {
      url = new URL(req.url, 'http://localhost');
      pathname = decodeURIComponent(url.pathname);
    } catch {
      res.writeHead(400).end();
      return;
    }
    // Giữ auth trước static/method check, kể cả API không tồn tại.
    // MRO_OFFLINE=1: chế độ xem offline — khoá mọi request ghi/mutation, chỉ cho đọc.
    if (process.env.MRO_OFFLINE==='1' && !['GET','HEAD'].includes(req.method)) {
      const ALLOW_WRITE=['/api/setup','/api/login','/api/logout','/api/change-password'];
      if(!ALLOW_WRITE.includes(pathname)){res.writeHead(503,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}).end(JSON.stringify({message:'Portal đang chạy ở chế độ xem offline. Mọi thao tác ghi, duyệt, import và mutation đã bị khoá.'}));return;}
    }
    // 12/11/2026: endpoint dữ liệu của từng màn đi qua bộ đệm snapshot: SQL chậm hoặc lỗi thì
    // màn vẫn có số để xem (header x-mro-snapshot), bản SQL thật về sau sẽ được lưu cho lần sau.
    if (req.method === 'GET' && isScreenEndpoint(pathname)) {
      await screenSnapshots.serve(req, res, url, candidate => auth.handle(req, candidate, url));
      return;
    }
    if (await auth.handle(req, res, url)) return;
    serveStatic(req, res, pathname);
  });
  // 06/11/2026: 30 giây cắt giữa thân bài khi upload PDF hợp đồng (file lớn, người dùng ở WiFi/VPN)
  // -> trình duyệt chỉ báo "Failed to fetch". Nới thời gian NHẬN toàn bộ request lên 5 phút;
  // headersTimeout vẫn 15 giây nên slow-loris ở pha header không đổi. Mọi deadline bên trong
  // (messages 25s, worker PDF 300s) nằm dưới mức này.
  server.requestTimeout = 300000;
  server.headersTimeout = 15000;
  snapshotCache.start();
  server.on('close',()=>snapshotCache.stop());
  return server;
}

module.exports = {createServer};
