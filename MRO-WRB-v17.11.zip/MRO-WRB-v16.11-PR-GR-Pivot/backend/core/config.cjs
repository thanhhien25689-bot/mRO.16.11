const fs = require('node:fs');
const path = require('node:path');

// Mốc là repository, không phải cwd hay thư mục backend/core.
const projectRoot = path.resolve(__dirname, '../..');

function readTreeConfig(root = projectRoot) {
  const configFile = path.join(root, 'tree.config.json');
  return fs.existsSync(configFile) ? JSON.parse(fs.readFileSync(configFile, 'utf8')) : {};
}

function getStartupConfig(root = projectRoot, env = process.env) {
  const config = readTreeConfig(root);
  // Giữ nguyên phép || và Number của entrypoint cũ, không thêm validation.
  return {
    port: Number(env.PORT || config.port || 8000),
    host: env.HOST || '0.0.0.0',
    runtime: env.MRO_RUNTIME || path.join(root, '.runtime')
  };
}

module.exports = {projectRoot, readTreeConfig, getStartupConfig};
