// Lớp tích hợp (không phải core/shared): quy tắc "Lí do mua hàng" (PURCHASE_REQ_INFO) dùng chung
// giữa Project Status và PR & Tracking.
//
// Hiện hành 06/11/2026 (yêu cầu người dùng): PR do PIC ngoài bộ phận chuẩn tạo trên ERP thường để
// trống PURCHASE_REQ_INFO, nên parseDescription của Project Status loại hẳn dòng đó khỏi Chi tiết code
// và Tiến độ mua hàng. Portal cho phép PIC3 nhập lại Lí do mua hàng theo ĐÚNG form
// "Type - Project - Model - Process"; bản nhập tay lưu tại data/pr-reasons.json (Project Status sở hữu).
// SQL vẫn là nguồn thật: PURCHASE_REQ_INFO hợp lệ thì không dùng bản nhập tay.
//
// Form mô tả giữ khớp standardRemark của Orders (backend/modules/orders/index.cjs) nhưng KHÔNG import
// module khác — hai bản phải sửa cùng nhau nếu anh đổi form. Receiver chuẩn do người dùng chốt 06/11:
// chỉ bui.thu2; PR do người khác tạo và thiếu lí do mới bị màn PR & Tracking nhắc.
const crypto=require('node:crypto');
const text=value=>String(value??'').trim();
const reasonTypes={SETUP:'SETUP',SOP:'SOP',SPARE:'Spare Part','SPARE PART':'Spare Part'};
const standardReceivers=['bui.thu2'];
const clean=value=>text(value).replace(/\[non-minimum item\]/gi,'').replace(/\s+/g,' ').trim();
const typeOf=value=>reasonTypes[text(value).replace(/\s+/g,' ').toUpperCase()];
// 12/11/2026 — nguyên tắc đặt tên mới (người dùng chốt): PURCHASE_REQ_INFO tách theo dấu "-";
// phần tử ĐẦU TIÊN luôn là Type, và Type chỉ có ba giá trị SETUP / SOP / Spare Part ("SPARE" cũ
// được chuẩn hoá về "Spare Part"). parseReasonParts là CHỖ DUY NHẤT tách Lí do mua hàng:
// Project Status (parseDescription), hàng chờ Lí do (aggregatable) và Data Tracking Report Form
// đều gọi qua đây, không chỗ nào tự split('-') nữa. Ưu tiên tách tại dấu gạch có khoảng trắng
// phía sau để "F53-2", "E-test" không bị cắt đôi; nếu Type không đọc được ở cách tách đó thì
// tách mọi dấu "-" đúng theo nguyên tắc (dạng ERP viết dính "SOP-A-M-P"). Phần tử chỉ gồm dấu
// gạch ("SETUP - X - -") tính là trống.
const DASHES=/[-\u2010-\u2015]\s+/g;
const blankPart=part=>/^[-\u2010-\u2015]*$/.test(part)?'':part;
function splitReason(raw){const cuts=[...raw.matchAll(DASHES)],parts=[];
 if(!cuts.length)parts.push(raw);else{let from=0;for(const cut of cuts){parts.push(raw.slice(from,cut.index));from=cut.index+cut[0].length}parts.push(raw.slice(from))}
 const spaced=parts.map(part=>blankPart(part.trim()));
 return typeOf(spaced[0])?spaced:raw.split('-').map(part=>blankPart(part.trim()));}
function formatReason({type,project='',model='',process=''}){const parts=[type,project,model,process];
 while(parts.length>1&&parts[parts.length-1]==='')parts.pop();return parts.join(' - ').replace(/\s{2,}/g,' ').trim();}
// Type không thuộc ba giá trị trên => null: chuỗi đó không phải Lí do mua hàng theo form.
function parseReasonParts(value){const raw=clean(value);if(!raw)return null;
 const parts=splitReason(raw),type=typeOf(parts[0]);if(!type)return null;
 const project=parts[1]||'',model=parts[2]||'',process=parts.slice(3).filter(Boolean).join(' - ');
 return {type,project,model,process,description:formatReason({type,project,model,process})};}
// 12/11/2026 (người dùng chốt): Data Tracking → Report Form vẫn phải ra cột Type đúng một trong
// ba giá trị chuẩn dù ERP ghi PURCHASE_REQ_INFO tự do ("Mua hàng theo SOP tháng 2", "Sử dụng cho
// máy Unclamping SPARE 3EA"). parseReasonParts ở trên bắt BUỘC giữ nghiêm (Project Status và hàng
// chờ Lí do mua hàng dựa vào đó nên không được nhận bừa), vì vậy có hàm riêng này cho báo cáo:
// tìm từ khóa xuất hiện SỚM NHẤT trong chuỗi, chỉ đếm khi đứng độc lập (có ranh giới từ, nên
// "SOPHIA" hay "despair" không bị tính nhầm; riêng "spares" số nhiều vẫn tính là Spare Part),
// "SPARE PART" thắng "SPARE" khi trùng vị trí vì dài hơn. Không có từ khóa => chuỗi rỗng: thà để
// trống cột Type còn hơn đổ cả câu mô tả vào Type (lỗi cũ: 2.250/2.390 dòng Report Form có Type
// là nguyên văn PURCHASE_REQ_INFO).
const typeKeywords=[[/\bSPARE[\s-]+PART\b/gi,'Spare Part'],[/\bSET[\s-]?UP\b/gi,'SETUP'],[/\bSOP\b/gi,'SOP'],[/\bSPARES?\b/gi,'Spare Part']];
function keywordReasonType(value){const raw=clean(value);if(!raw)return '';let best=null;
 for(const [pattern,type] of typeKeywords)for(const hit of raw.matchAll(pattern)){if(!best||hit.index<best.index||(hit.index===best.index&&hit[0].length>best.length))best={index:hit.index,length:hit[0].length,type};}
 return best?best.type:'';}
// Chỉ cần Type hợp lệ là Project Status gộp được. Không dùng chuỗi đầy đủ ở đây —
// parseDescription cũng chỉ yêu cầu phần đầu.
function aggregatable(value){const raw=clean(value);if(!raw)return false;return !!typeOf(splitReason(raw)[0]);}
function standardReason(value){const raw=clean(value);
 if(!raw)return {ok:false,error:'Lí do mua hàng trống; phải theo form Type - Project - Model - Process.'};
 const parts=splitReason(raw),type=typeOf(parts[0]);
 if(!type)return {ok:false,error:'Lí do mua hàng phải bắt đầu bằng Type hợp lệ (SETUP, SOP hoặc Spare Part), các phần tách nhau bằng dấu "-".'};
 const project=parts[1]||'',model=parts[2]||'',process=parts.slice(3).filter(Boolean).join(' - ');
 if(!project)return {ok:false,error:'Phần Project bắt buộc; thiếu Project thì Project Status không gom được dự án.'};
 return {ok:true,type,project,model,process,description:formatReason({type,project,model,process})};}
function isStandardReceiver(name){return standardReceivers.includes(text(name).toLowerCase());}
// Khóa ổn định theo đúng dòng PR, cùng kiểu khóa tracking.identity (JSON.stringify + sha256).
function reasonKey(itemCode,prNo,prSeq){return crypto.createHash('sha256').update(JSON.stringify([text(itemCode),text(prNo),text(prSeq)])).digest('hex');}
module.exports={reasonTypes,standardReceivers,standardReason,parseReasonParts,keywordReasonType,formatReason,aggregatable,aggregatableReason:aggregatable,isStandardReceiver,reasonKey};