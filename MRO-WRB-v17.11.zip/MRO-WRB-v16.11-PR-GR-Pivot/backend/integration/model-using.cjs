// Read-only contract shared by SEV stock and Vendor stock. Never infer a model
// from a code prefix: EQM_MRO_Model owns the Project -> Model -> Basic relation.
const text=value=>String(value??'').trim();
const key=value=>text(value).normalize('NFC').toUpperCase();
const vendorKey=value=>({'ALMUS TECH':'ALT','ALMUS VINA':'ALV',BUJEON:'BJ',CHITWING:'CW'}[key(value)]||key(value));
function createModelResolver(mapping=[],production=[]){
 const projects=new Map(),models=new Map(),basics=new Set(),parents=new Map(),cache=new Map();
 const add=(map,id,basic)=>{if(!id)return;const set=map.get(id)||new Set();set.add(basic);map.set(id,set);};
 for(const row of mapping){
  const basic=key(row.Atb2),project=key(row.Atb1),model=key(row.Model);if(!basic)continue;
  basics.add(basic);add(projects,project,basic);add(models,model,basic);
  const set=parents.get(basic)||new Set();set.add(project+'|'+model);parents.set(basic,set);
 }
 for(const row of production)if(key(row.Atb2))basics.add(key(row.Atb2));
 return value=>{
  const input=text(value);if(cache.has(input))return cache.get(input);
  const labels=[...new Set(input.split(',').map(text).filter(Boolean))],resolved=new Set(),problems=[];
  for(const label of labels){
   const id=key(label),candidates=[projects.get(id),models.get(id),basics.has(id)?new Set([id]):null].filter(Boolean);
   if(!candidates.length){problems.push('Model Using không tìm thấy trong EQM_MRO_Model / Production: '+label);continue;}
   const signatures=new Set(candidates.map(set=>[...set].sort().join(',')));
   if(signatures.size>1){problems.push('Model Using trùng tên giữa Project/Model/Basic: '+label);continue;}
   for(const basic of candidates[0])resolved.add(basic);
  }
  for(const basic of resolved)if(parents.get(basic)?.size>1)problems.push('EQM_MRO_Model gán Basic vào nhiều Model/Project: '+basic);
  const result={labels,basics:[...resolved].sort(),problems};cache.set(input,result);return result;
 };
}
// Production is weekly wide rows. One Basic may run at several Vendors.
// Aggregate distinct Vendor rows globally; in a Vendor view select its rows first.
// Duplicate Vendor + Basic + Year remains an error instead of doubling demand.
function productionIndex(rows){
 const scoped=rows.some(row=>text(row.Vendor??row.VendorCode)),entries=new Map(),vendorBasics=new Map(),basicVendors=new Map();
 for(const row of rows){
  const vendor=scoped?vendorKey(row.Vendor??row.VendorCode):'',basic=key(row.Atb2),year=Number(row.Year??row.ISOYear);
  if(!basic||!Number.isInteger(year)||scoped&&!vendor)continue;
  if(!vendorBasics.has(vendor))vendorBasics.set(vendor,new Set());vendorBasics.get(vendor).add(basic);
  if(!basicVendors.has(basic))basicVendors.set(basic,new Set());basicVendors.get(basic).add(vendor);
  const id=vendor+'|'+basic+'|'+year;
  entries.set(id,entries.has(id)?null:row);
 }
 return {
  basics(vendor){return vendorBasics.get(vendor&&scoped?vendorKey(vendor):'')||new Set();},
  values(basic,year,week,vendor){
   const selected=vendor&&scoped?[vendorKey(vendor)]:[...(basicVendors.get(key(basic))||[])];
   const matching=selected.map(v=>entries.get(v+'|'+key(basic)+'|'+year));
   if(!matching.length||matching.some(row=>row===null||row===undefined))return null;
   const values=matching.map(row=>row['W'+String(week).padStart(2,'0')]);
   if(values.some(v=>v===null||v===undefined||text(v)===''||!Number.isFinite(Number(v))||Number(v)<0))return null;
   return values.reduce((sum,v)=>sum+Number(v),0);
  }
 };
}
module.exports={createModelResolver,productionIndex,vendorKey};
