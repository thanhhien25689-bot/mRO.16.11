const excluded=new Set(['PR Withdrew','PR Denied','PO Withdrew','[CLOSE] PO Approved','[CLOSE] IV Approved','PO Canceled','[CLOSE] Delivery Completed'].map(s=>s.toLowerCase()));
function eligiblePR(row={}){return !['STATUS','PR_STATUS','PO_STATUS'].some(key=>excluded.has(String(row[key]??'').trim().toLowerCase()));}
module.exports={eligiblePR};
