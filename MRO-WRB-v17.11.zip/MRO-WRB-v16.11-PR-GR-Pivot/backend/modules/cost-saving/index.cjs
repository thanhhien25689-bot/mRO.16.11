const fail = (status, message) => Object.assign(new Error(message), {status});

// Cost Saving đọc trực tiếp dbo.EQM_CostSavingActivity (đơn vị USD), không còn bản ghi nhập tay.
// Tổng mỗi tháng theo lịch Asia/Ho_Chi_Minh: tháng đã và đang diễn ra = Σ Actual mọi mục;
// các tháng còn lại của năm = Σ Plan (dự kiến). Nguồn chỉ SELECT, không ghi SQL.
const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MAX_USD = 10000000000;
const CACHE_MS = 30000;

// Đã chốt 28/10/2026: hai cột số tiền tên đúng là `Plan` và `Actual` (USD). Vì vậy plan/actual
// chỉ nhận khớp CHÍNH XÁC tên cột (EXACT_FIELDS) để PlanQty/ActualQty/Plan % không thành số tiền.
// Các cột còn lại vẫn dò ứng viên: khớp không phân biệt hoa thường/khoảng trắng/gạch dưới,
// thiếu cột thì báo 502 kèm danh sách cột thật, không tự bịa số liệu. Audit: node scripts/audit-cost-saving.cjs [năm].
const EXACT_FIELDS = new Set(['plan', 'actual']);
const CANDIDATES = {
  year: ['year', 'nam', 'activityyear', 'fiscalyear', 'namsinhrong'],
  month: ['month', 'thang', 'monthnumber', 'monthno', 'activitymonth'],
  date: ['date', 'ngay', 'activitydate', 'executefrom', 'executeto', 'completedate', 'closedate', 'createdate', 'datestart', 'dateend'],
  plan: ['plan', 'planusd', 'planamount', 'planvalue', 'plants', 'target', 'kehoach', 'giaplan'],
  actual: ['actual', 'actualusd', 'actualamount', 'actualvalue', 'thucte', 'achieved', 'real'],
  amount: ['amount', 'amountusd', 'value', 'usd', 'saving', 'savings', 'costsaving', 'costsavings', 'tietkiem', 'money'],
  type: ['type', 'kind', 'loai', 'category', 'planactual', 'planning', 'status'],
  item: ['activity', 'activityname', 'item', 'itemcode', 'code', 'name', 'description', 'ten', 'noidung'],
};
// Nhãn trạng thái được bỏ dấu/khoảng trắng trước khi xét (fold): "Kế hoạch" -> kehoach, "Thực hiện" -> thuchien.
const PLAN_TEXT = /^(plan|plants|target|kehoach|khtd|forecast|du(?:k|q)ien|expected)/i;
const ACTUAL_TEXT = /^(actual|act|real|thucte|thuchien|achieved|result|done|completed|finish)/i;
function isPlanLabel(text) { const key = fold(text); return key === 'kh' || key === 'khtd' || PLAN_TEXT.test(key); }
function isActualLabel(text) { return ACTUAL_TEXT.test(fold(text)); }
const NUMBER_TEXT = /^-?\d+(?:\.\d{1,6})?$/;

// Bỏ dấu tiếng Việt thật sự (Kế hoạch -> kehoach, Thực hiện -> thuchien, Loại -> loai) rồi mới so khớp.
const fold = value => String(value ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/[^a-z0-9]/g, '');
const round2 = value => Math.round(value * 100) / 100;

// Số USD theo quy ước chuỗi SQL: dấu chấm thập phân, không dấu hàng nghìn; null/rỗng là chưa có.
function usd(value) {
  if (value === null || value === undefined) return null;
  const text = String(value).trim();
  if (!text) return null;
  if (!NUMBER_TEXT.test(text)) return {invalid: 'giá trị USD (cần số thập phân dùng dấu chấm)'};
  const number = Number(text);
  if (!Number.isFinite(number) || Math.abs(number) > MAX_USD) return {invalid: `giá trị USD vượt giới hạn ${MAX_USD.toLocaleString('en-US')}`};
  return number;
}

function calendar(now = new Date()) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-US', {timeZone: 'Asia/Ho_Chi_Minh', year: 'numeric', month: 'numeric'}).formatToParts(now).map(p => [p.type, p.value]));
  return {year: Number(parts.year), month: Number(parts.month)};
}

// Cột đọc hợp nhất vài dòng đầu để không phụ thuộc thứ tự cột hay một dòng thiếu khóa.
const columnsOf = rows => {
  if (!Array.isArray(rows) || !rows.length) return [];
  const seen = [];
  for (const row of rows.slice(0, 25)) for (const key of Object.keys(row)) if (!seen.includes(key)) seen.push(key);
  return seen;
};

// Định vị cột theo ứng viên; khớp chính xác trước rồi mới khớp chứa để không đoán nhầm cột khác.
// Định vị cột theo ứng viên; khớp chính xác trước rồi mới khớp chứa để không đoán nhầm cột khác.
// Plan/Actual là tên đã chốt nên chỉ nhận tên cột đúng nguyên văn (chỉ bỏ hoa thường và khoảng
// trắng hai đầu): "Plan %" hay "PlanQty" không bao giờ được nhận làm số tiền.
function find(rows, field) {
  const keys = columnsOf(rows);
  if (EXACT_FIELDS.has(field)) return keys.find(key => String(key).trim().toLowerCase() === CANDIDATES[field][0]) || null;
  const byFolded = new Map();
  for (const key of keys) { const folded = fold(key); if (!byFolded.has(folded)) byFolded.set(folded, []); byFolded.get(folded).push(key); }
  for (const candidate of CANDIDATES[field]) {
    const matches = byFolded.get(candidate);
    if (!matches) continue;
    const bare = matches.find(key => String(key).trim().toLowerCase() === candidate);
    if (bare) return bare;
    if (matches.length === 1) return matches[0]; // Nhiều cột trùng tên sau khi gộp ký tự đặc biệt thì không chọn bừa.
  }
  for (const candidate of CANDIDATES[field]) { const hit = keys.find(key => fold(key).includes(candidate)); if (hit) return hit; }
  return null;
}
function detect(rows) {
  const map = {};
  for (const field of Object.keys(CANDIDATES)) map[field] = find(rows, field);
  map.no = findNo(rows);
  return map;
}
// Cột khóa hàng cho phép ghi: chỉ chấp nhận tên nguyên văn (no/stt/sott/id) để không nhận nhầm
// cột chữ như "Note". Phép ghi chỉ UPDATE đúng ô tháng của dòng trùng No duy nhất.
const NO_FIELDS = ['no', 'stt', 'sott', 'id'];
function findNo(rows) {
  return columnsOf(rows).find(key => NO_FIELDS.includes(String(key).trim().toLowerCase())) || null;
}
function schemaError(rows) {
  const keys = columnsOf(rows);
  return fail(502, keys.length
    ? `Bảng EQM_CostSavingActivity thiếu cột tháng hoặc Plan/Actual (cần một trong: cột Plan + cột Actual; hoặc các cột tháng Jan..Dec + cột trạng thái Plan/Actual; hoặc một cột giá trị + cột loại). Cột đọc được: ${keys.slice(0, 30).join(', ')}.`
    : 'Bảng EQM_CostSavingActivity chưa có dòng nào để xác định cột.');
}



// Một dòng = một mục tiết kiệm. Tháng lấy từ cột tháng, nếu không có thì suy từ cột ngày.
function monthOf(row, used, year) {
  if (used.month) {
    const text = String(row[used.month] ?? '').trim();
    const number = Number(text);
    if (Number.isInteger(number) && number >= 1 && number <= 12) return number;
    const named = monthNames.findIndex(name => text.toLowerCase().startsWith(name.toLowerCase()));
    if (named >= 0) return named + 1;
    const parts = text.split(/[/.\-]/).map(Number);
    const first = parts.length > 1 ? parts[0] : NaN, second = parts.length > 1 ? parts[1] : NaN;
    if (Number.isInteger(first) && first >= 1 && first <= 12) return first;
    if (Number.isInteger(second) && second >= 1 && second <= 12) return second;
    return used.date ? monthOfDate(String(row[used.date] ?? ''), year) : null;
  }
  if (used.date) return monthOfDate(String(row[used.date] ?? ''), year);
  return null;
}
// Cột ngày chấp nhận ISO YYYY-MM-DD và dd/MM/YYYY; chỉ tính khi năm trùng năm đang đọc.
function monthOfDate(text, year) {
  const iso = text.match(/^(\d{4})-(\d{2})/);
  if (iso) return Number(iso[1]) === year ? Number(iso[2]) : null;
  const short = text.match(/^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2,4})$/);
  if (!short) return null;
  const raw = Number(short[3]), full = raw < 100 ? 2000 + raw : raw;
  if (full !== year) return null;
  const first = Number(short[1]), second = Number(short[2]);
  return second >= 1 && second <= 12 ? second : (first >= 1 && first <= 12 ? first : null);
}
// Năm của dòng: ưu tiên cột năm; bảng chỉ có Month + Date thì lấy số năm trong cột ngày
// (nhận cả ISO 2026-10-05 và dd/MM/yyyy). Không có cả hai nguồn thì trả null để bỏ dòng,
// vì không thể gán dòng đó vào năm đang đọc.
function yearOf(row, used) {
  const candidates = [used.year ? String(row[used.year] ?? '') : '', used.date ? String(row[used.date] ?? '') : ''];
  for (const text of candidates) {
    const match = text.trim().match(/(?:19|20)\d{2}/);
    if (!match) continue;
    const number = Number(match[0]);
    if (number >= 2000 && number <= 2100) return number;
  }
  return null;
}

// Bảng EQM_CostSavingActivity thật (đọc trực tiếp 28/10/2026) có dạng NGANG: mỗi dòng là một
// Project/Item của một Năm, 12 cột tháng Jan..Dec chứa USD, cột Status nhận 'Plan' hoặc 'Actual'.
// Hai dạng dọc cũ vẫn được hỗ trợ: cột Plan/Actual riêng, hoặc một cột giá trị + cột loại.
const MONTH_INDEX = new Map([['jan', 1], ['january', 1], ['feb', 2], ['february', 2], ['mar', 3], ['march', 3],
  ['apr', 4], ['april', 4], ['may', 5], ['jun', 6], ['june', 6], ['jul', 7], ['july', 7], ['aug', 8],
  ['august', 8], ['sep', 9], ['sept', 9], ['september', 9], ['oct', 10], ['october', 10], ['nov', 11],
  ['november', 11], ['dec', 12], ['december', 12]]);
const MONTH_COLUMNS_MIN = 6; // Dưới nửa năm thì không coi là bảng ngang, tránh nhận nhầm cột chữ "May"/"Mar".
function monthColumns(rows) {
  const columns = Array(12).fill(null);
  for (const key of columnsOf(rows)) { const index = MONTH_INDEX.get(fold(key)); if (index && !columns[index - 1]) columns[index - 1] = key; }
  return columns;
}

// Cộng dồn mọi mục cùng tháng; tháng chưa có số liệu giữ null để UI hiện "—", không quy về 0.
function aggregate(rows, {year, month, used}) {
  const map = used || detect(rows);
  const monthCols = monthColumns(rows);
  const wide = monthCols.filter(Boolean).length >= MONTH_COLUMNS_MIN;
  const shape = map.plan ? 'columns' : (wide && map.type ? 'months' : (map.amount && map.type ? 'type' : null));
  if (!shape) throw schemaError(rows);
  if (shape !== 'months' && !map.month && !map.date) throw schemaError(rows); // Bảng dọc cần cột tháng hoặc cột ngày.
  const plan = Array(12).fill(null), actual = Array(12).fill(null);
  const problems = new Set();
  let items = 0, skipped = 0;
  const yearSource = Boolean(map.year || map.date); // Bảng EQM_CostSavingActivity chỉ có Month + Date.
  const noCol = shape === 'months' ? map.no || null : null; // Ghi ô chỉ khả dụng với bảng ngang có khóa No và lọc được năm.
  const activities = [];
  const add = (series, index, value) => { series[index] = round2((series[index] ?? 0) + value); };
  for (const row of Array.isArray(rows) ? rows : []) {
    const rowYear = yearOf(row, map);
    if (yearSource) {
      if (rowYear === null) { problems.add('năm (dòng không có năm hoặc ngày hợp lệ)'); skipped++; continue; }
      if (rowYear !== year) { skipped++; continue; } // Dòng năm khác tuyệt đối không được rò vào năm đang đọc.
    }
    if (shape === 'months') { // Bảng ngang: một dòng trải 12 cột tháng, Status quyết định cộng vào Plan hay Actual.
      const label = String(row[map.type] ?? '').trim();
      const series = isActualLabel(label) ? actual : (isPlanLabel(label) ? plan : null);
      if (!series) { problems.add(`trạng thái ${label || '(trống)'} không phải Plan/Actual`); skipped++; continue; }
      let hasValue = false, invalid = false;
      monthCols.forEach((column, index) => {
        if (!column) return;
        const value = usd(row[column]);
        if (value === null) return; // Ô trống nghĩa là chưa có số, khác ô giá trị 0.
        if (typeof value === 'object') { problems.add(`${column}: ${value.invalid}`); invalid = true; return; }
        add(series, index, value);
        hasValue = true;
      });
      if (invalid) { skipped++; continue; }
      if (hasValue && series === actual) items++;
      if (noCol && yearSource && activities.length < 200) { // Bang hoat dong cho o nhap: giu so USD goc theo dung khoa No.
        const rowNo = String(row[noCol] ?? '').trim();
        if (rowNo) activities.push({no: rowNo.slice(0, 50), label: (map.item ? String(row[map.item] ?? '') : '').trim().slice(0, 200), status: isActualLabel(label) ? 'Actual' : 'Plan', values: monthCols.map(column => { const value = column ? usd(row[column]) : null; return typeof value === 'object' || value === null ? null : value; })});
      }
      continue;
    }
    const index = monthOf(row, map, year);
    if (!index) { problems.add('cột tháng'); skipped++; continue; }
    let rowPlan = null, rowActual = null;
    if (shape === 'columns') { rowPlan = usd(row[map.plan]); rowActual = usd(row[map.actual]); }
    else {
      const label = String(row[map.type] ?? '').trim(), amount = usd(row[map.amount]);
      if (isActualLabel(label)) rowActual = amount;
      else if (isPlanLabel(label)) rowPlan = amount;
      else { problems.add(`giá trị ${label || '(trống)'} không phải Plan/Actual`); skipped++; continue; }
    }
    let valid = true;
    for (const value of [rowPlan, rowActual]) if (value && typeof value === 'object' && value.invalid) { problems.add(value.invalid); valid = false; break; }
    if (!valid) { skipped++; continue; }
    if (rowPlan !== null) add(plan, index - 1, rowPlan);
    if (rowActual !== null) { add(actual, index - 1, rowActual); items++; }
  }
  // Tháng hiện tại và tháng đã qua dùng Actual; tháng tương lai dùng Plan làm dự kiến.
  const months = Array.from({length: 12}, (_, index) => (index + 1) <= month ? actual[index] : plan[index]);
  const warning = [...problems];
  return {
    year, currentMonth: month, months, plan, actual, items, skipped,
    activities, editable: Boolean(noCol && yearSource), noColumn: noCol || '',
    missingPlan: plan.filter(v => v === null).length, missingActual: actual.filter(v => v === null).length,
    total: round2(months.reduce((total, v) => total + (v ?? 0), 0)),
    planTotal: round2(plan.reduce((total, v) => total + (v ?? 0), 0)),
    actualTotal: round2(actual.reduce((total, v) => total + (v ?? 0), 0)),
    monthColumns: monthCols.filter(Boolean).join('/'),
    mapping: {shape, year: map.year || '', month: map.month || '', date: map.date || '', plan: map.plan || '', actual: map.actual || '', amount: map.amount || '', type: map.type || ''},
    warning: `${warning.length ? `${skipped} dòng EQM_CostSavingActivity bị bỏ do ${[...new Set(warning)].join(', ')} không hợp lệ. ` : ''}${yearSource ? '' : 'Bảng EQM_CostSavingActivity không có cột năm hoặc ngày nên không lọc được theo năm; mọi dòng được gộp vào năm đang đọc.'}`,
  };
}
function empty(year, month, warning) {
  return {year, currentMonth: month, months: Array(12).fill(null), plan: Array(12).fill(null), actual: Array(12).fill(null), items: 0, skipped: 0, activities: [], editable: false, noColumn: '', missingPlan: 12, missingActual: 12, total: 0, planTotal: 0, actualTotal: 0, monthColumns: '', mapping: null, source: 'empty', updatedAt: '', warning};
}


function createCostSaving({sql, now = () => new Date()}) {
  const cache = new Map(); let flight = null;

  // Một lần đọc SQL dùng chung cho snapshot và yêu cầu đổi năm; lỗi giữ cache cũ kèm cảnh báo.
  async function read(year) {
    const {month} = calendar(now()), key = Number(year);
    if (!sql || typeof sql.readCostSaving !== 'function') return empty(key, month, 'Adapter SQL chưa hỗ trợ đọc Cost Saving.');
    const cached = cache.get(key);
    if (cached && now().getTime() - Date.parse(cached.readAt) < CACHE_MS) return cached.value;
    if (flight && flight.year === key) return flight.promise;
    const task = {year: key, promise: (async () => {
      const rows = await sql.readCostSaving();
      const value = {...aggregate(rows, {year: key, month}), source: 'sql', updatedAt: now().toISOString()};
      cache.set(key, {value, readAt: now().toISOString()});
      return value;
    })()};
    flight = task;
    try { return await task.promise; }
    catch (error) {
      const previous = cache.get(key);
      if (previous) return {...previous.value, source: 'cache', warning: `Không đọc được Cost Saving từ SQL: ${error.message}`};
      return empty(key, month, `Không đọc được Cost Saving từ SQL: ${error.message}`);
    } finally { if (flight === task) flight = null; }
  }

  // Snapshot luôn mang năm hiện hành theo giờ Việt Nam; các năm khác Overview đọc khi chọn.
  function overlay(data) {
    if (!data || typeof data !== 'object') return data;
    const {year, month} = calendar(now());
    return {...data, costSaving: (cache.get(year) || {}).value || empty(year, month, 'Cost Saving sẽ hiển thị sau lần đọc SQL đầu tiên.')};
  }
  async function live(data) {
    if (!data || typeof data !== 'object') return data;
    return {...data, costSaving: await read(calendar(now()).year)};
  }
  async function handle({req, res, url, actor, body, send}) {
    if (url.pathname !== '/api/cost-saving') return false;
    if (req.method === 'POST') {await save({req, res, actor, body, send}); return true;}
    if (req.method !== 'GET') throw fail(405, 'Cost Saving chỉ hỗ trợ GET để đọc và POST để lưu ô Plan/Actual.');
    const year = Number(url.searchParams.get('year') || calendar(now()).year);
    if (!Number.isInteger(year) || year < 2000 || year > 2100) throw fail(400, 'Cần chọn năm Cost Saving hợp lệ (2000–2100).');
    send(res, 200, await read(year));
    return true;
  }
  // O nhap Plan/Actual (05/11/2026): chi Admin tro len; tung o UPDATE dung cot thang theo khoa No.
  async function save({req, res, actor, body, send}) {
    const ranks = {user: 1, admin: 2, supervisor: 3, developer: 4};
    if (!actor || !(ranks[actor.role] >= 2)) throw fail(403, 'Chỉ Admin trở lên được cập nhật Cost Saving.');
    if (!sql || typeof sql.writeCostSaving !== 'function') throw fail(501, 'Adapter SQL chưa hỗ trợ ghi Cost Saving.');
    const b = await body(req);
    const year = Number(b && b.year);
    if (!Number.isInteger(year) || year < 2000 || year > 2100) throw fail(400, 'Cần chọn năm Cost Saving hợp lệ (2000–2100).');
    const list = b && b.changes;
    if (!Array.isArray(list) || !list.length || list.length > 200) throw fail(400, 'Cần 1–200 ô thay đổi để lưu.');
    const changes = list.map((change, index) => {
      const no = String((change && change.no) ?? '').trim(), month = Number(change && change.month);
      if (!no || no.length > 50) throw fail(400, `Ô ${index + 1}: thiếu số thứ tự dòng (No) hợp lệ.`);
      if (!Number.isInteger(month) || month < 1 || month > 12) throw fail(400, `Ô ${index + 1}: tháng phải từ 1 đến 12.`);
      const raw = change.value;
      let value = null;
      if (raw !== null && raw !== undefined && String(raw).trim() !== '') {
        const parsed = usd(raw);
        if (typeof parsed === 'object') throw fail(400, `Ô ${index + 1}: ${parsed.invalid}.`);
        value = String(round2(parsed));
      }
      return {no, month, value};
    });
    const result = await sql.writeCostSaving(changes);
    cache.clear();
    send(res, 200, {...await read(year), saved: {count: changes.length, updated: result.updated, at: now().toISOString()}});
  }
  return {handle, overlay, live, read};
}

module.exports = {createCostSaving, aggregate, detect, calendar, monthNames, columnsOf, usd};


