const crypto=require('node:crypto');
const fail=(status,message)=>Object.assign(Error(message),{status});
const fingerprint=rows=>crypto.createHash('sha256').update(JSON.stringify(rows.map(r=>Object.keys(r).sort().map(k=>[k,r[k]])).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))))).digest('hex');
const {currentWeek}=require('../delivery/index.cjs');
const text=v=>String(v??'').trim();
// 12/11/2026: Type chỉ có ba giá trị SETUP / SOP / Spare Part (nguyên tắc đặt tên mới, khớp
// backend/integration/pr-reason.cjs). Orders vẫn bắt buộc đủ bốn phần vì đây là ô nhập của PIC1.
const remarkTypes={SETUP:'SETUP',SOP:'SOP',SPARE:'Spare Part','SPARE PART':'Spare Part'};
const remarkDashes=raw=>[...raw.matchAll(/(?:^|\s)-(?=\s|$)/g)].map(m=>m.index+m[0].length-1);
function standardRemark(value){const raw=text(value).replace(/\[non-minimum item\]/gi,'').trim();if(!raw)return{ok:false,error:'Remark trống; phải theo form Type - Project - Model - Process.'};const dashes=remarkDashes(raw);if(dashes.length<3)return{ok:false,error:'Remark phải đủ bốn phần Type - Project - Model - Process; Project, Model và Process được để trống nhưng vẫn phải giữ dấu " - " giữa các phần.'};const parts=[raw.slice(0,dashes[0]).trim(),raw.slice(dashes[0]+1,dashes[1]).trim(),raw.slice(dashes[1]+1,dashes[2]).trim(),raw.slice(dashes[2]+1).trim()],type=remarkTypes[parts[0].replace(/\s+/g,' ').toUpperCase()];if(!type)return{ok:false,error:'Remark phải bắt đầu bằng Type hợp lệ (SETUP, SOP hoặc Spare Part) và các phần cách nhau bằng " - ".'};return{ok:true,type,project:parts[1],model:parts[2],process:parts[3]};}
function mapOrders(rows,now=new Date()){
 if(!Array.isArray(rows))throw Error('Dữ liệu Order SQL không hợp lệ.');
 const current=currentWeek(now),mapped=rows.map((r,i)=>{
  const date=text(r.__orderDate??r.Date),valid=/^\d{4}-\d{2}-\d{2}$/.test(date)&&Number.isFinite(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date;
    const time=text(r.__orderTime??r.Time),timeValid=/^([01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d{1,7})?$/.test(time),qty=text(r.Quantity);
  // 06/11/2026: nhiều dòng cùng khóa trong một lần gửi Order nhận mốc Time lệch nhau ở PHẦN THẬP PHÂN
  // (xem worker orders-add); hiển thị/export chỉ nguyên giây, còn timeKey giữ đủ 7 chữ số để chọn
  // trạng thái cuối theo Date + Time không bị trùng mốc.
  return {date:valid?date:'',rawDate:date,time:timeValid?time.split('.')[0]:time,timeKey:timeValid?time.split('.')[0]+'.'+(time.split('.')[1]||'').padEnd(7,'0'):'00:00:00.0000000',week:valid?currentWeek(new Date(date+'T05:00:00Z')).start:'',vendor:text(r.Vendor),requester:text(r.Requester),code:text(r['WRB Code']),itemCode:text(r['Item Code']),itemName:text(r['Item Name']),quantity:qty!==''&&Number.isFinite(Number(qty))?Number(qty):null,unit:text(r.Unit),reason:text(r.Reason),status:text(r.Status),approver:text(r.Approver),remark:text(r.Remark??r.Remake),comment:text(r.Comment),bill:text(r.Bill),sourceIndex:i,warning:!valid?'Ngày không hợp lệ':time&&!timeValid?'Time không hợp lệ; dùng 00:00:00 để sắp xếp':''};
 });
 // 06/11/2026 (yêu cầu người dùng): mỗi dòng SQL nhập vào là một Order độc lập — bảng hiển thị TỪNG DÒNG,
 // không gộp theo khóa nữa. Dòng "Chờ duyệt" bị ẩn chỉ khi một dòng quyết định (Status khác Chờ duyệt,
 // muộn hơn) đã xử lý nó; mỗi dòng quyết định ẩn đúng MỘT dòng chờ muộn nhất chưa xử lý trước nó, cộng
 // thêm dòng quyết định MUỘN NHẤT của khóa hiện trạng thái hiện tại.
 const groups=new Map();
 for(const row of mapped){if(!row.week)continue;const key=JSON.stringify([row.week,row.vendor,row.code,row.itemCode]);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(row);}
 const orders=[],keys=[];
 for(const group of groups.values()){
  group.sort((a,b)=>a.date.localeCompare(b.date)||a.timeKey.localeCompare(b.timeKey)||a.sourceIndex-b.sourceIndex);
  const pending=group.filter(r=>r.status==='Chờ duyệt'),decisions=group.filter(r=>r.status!=='Chờ duyệt'),consumed=new Set();
  for(const d of decisions){for(const p of pending){if(consumed.has(p)||p.date+p.timeKey>=d.date+d.timeKey)continue;consumed.add(p);break;}}
  for(const p of pending)if(!consumed.has(p))orders.push(p);
  if(decisions.length)orders.push(decisions[decisions.length-1]);
  // Dạng gộp theo khóa (dùng bởi Codes): mọi dòng quyết định do Portal ghi (Approver kết thúc '*') là
  // các Order đã duyệt độc lập; ERP không có '*' nên chỉ dòng muộn nhất của khóa đại diện như trước đây.
  const portal=group.filter(r=>r.approver.endsWith('*')&&r.status!=='Chờ duyệt'),last=group[group.length-1];
  for(const r of portal)keys.push(r);
  if(!last.approver.endsWith('*')||last.status==='Chờ duyệt')keys.push(last);
 }
 orders.sort((a,b)=>b.date.localeCompare(a.date)||b.timeKey.localeCompare(a.timeKey)||a.sourceIndex-b.sourceIndex);
 keys.sort((a,b)=>b.date.localeCompare(a.date)||b.timeKey.localeCompare(a.timeKey)||a.sourceIndex-b.sourceIndex);
 const first=mapped.filter(r=>r.week&&r.week<=current.start).map(r=>r.week).sort()[0]||current.start,weeks=[];
 for(let day=Date.parse(current.start);day>=Date.parse(first);day-=604800000){const w=currentWeek(new Date(day+43200000));weeks.push({start:w.start,end:w.end,week:w.week,year:w.year});}
 for(const r of orders){r.deleted=mapped.some(x=>x.vendor===r.vendor&&x.code===r.code&&x.itemCode===r.itemCode&&x.status==='Đã xóa'&&x.date+x.timeKey>=r.date+r.timeKey);}
 for(const r of keys){r.deleted=mapped.some(x=>x.vendor===r.vendor&&x.code===r.code&&x.itemCode===r.itemCode&&x.status==='Đã xóa'&&x.date+x.timeKey>=r.date+r.timeKey);}
 for(const r of orders)r.revision=fingerprint(rows.filter(v=>text(v.Vendor)===r.vendor&&text(v['WRB Code'])===r.code&&text(v['Item Code'])===r.itemCode));
 for(const r of keys)r.revision=fingerprint(rows.filter(v=>text(v.Vendor)===r.vendor&&text(v['WRB Code'])===r.code&&text(v['Item Code'])===r.itemCode));
 return {ordersSQL:orders,ordersKeys:keys,orderWeeks:weeks,orderCurrentWeek:current.start,orderInvalidDates:mapped.filter(r=>!r.week).length,orderRawCount:rows.length};
}
function createOrders({sql,pricing,getOrderContext=async()=>({codes:[],tracking:[]}),now=()=>new Date()}){
 let pending,last;const attempts=new Map();
 async function load(){if(pending)return pending;pending=(async()=>{const raw=await sql.readOrders(),mapped=mapOrders(raw,now());last={raw,updatedAt:now().toISOString()};if(pricing)mapped.ordersSQL=await pricing.enrich(mapped.ordersSQL,r=>r.itemCode,{force:true});return {...mapped,ordersSource:'sql',ordersUpdatedAt:last.updatedAt,ordersError:null};})();try{return await pending;}finally{pending=null;}}
 async function live(data){if(!Array.isArray(data.requests)&&!Array.isArray(data.ordersSQL))return data;try{return {...data,...await load()};}catch(e){const mapped=mapOrders(last?.raw||[],now());if(pricing)mapped.ordersSQL=await pricing.enrich(mapped.ordersSQL,r=>r.itemCode);return {...data,...mapped,ordersSource:last?'sql-cache':'empty',ordersUpdatedAt:last?.updatedAt||null,ordersError:e.message};}}
 async function decide(input,user){
    if(!input||Object.keys(input).some(k=>!['week','vendor','code','itemCode','timeKey','revision','decision','requestId','comment','contextRevision'].includes(k)))throw fail(400,'Yêu cầu không hợp lệ.');
  if(input.comment!==undefined&&(typeof input.comment!=='string'||input.comment.length>10000))throw fail(400,'Comment tối đa 10000 ký tự.');
  const statuses={approve:'Đã duyệt',edit:'Cần sửa',reject:'Đã từ chối',delete:'Đã xóa'};
  if(!Object.hasOwn(statuses,input.decision)||!/^\d{4}-\d{2}-\d{2}$/.test(input.week)||!/^([01]\d|2[0-3]):[0-5]\d:[0-5]\d\.\d{7}$/.test(input.timeKey||'')||!/^\w[\w-]{15,79}$/.test(input.requestId||'')||! /^[a-f0-9]{64}$/.test(input.revision||''))throw fail(400,'Thông tin phê duyệt không hợp lệ.');
  for(const k of ['vendor','code','itemCode'])if(typeof input[k]!=='string'||input[k].length>500)throw fail(400,'Mã/vendor không hợp lệ.');
  const attempt=user.id+':'+input.requestId,digest=JSON.stringify(input),old=attempts.get(attempt);
  if(old){if(old.digest!==digest)throw fail(409,'Mã thao tác đã dùng cho yêu cầu khác.');if(old.error)throw old.error;return old.result;}
  for(const [k,v]of attempts)if(v.at<Date.now()-1800000)attempts.delete(k);
  if(attempts.size>=500)throw fail(429,'Có nhiều thao tác gần đây. Vui lòng thử sau.');
    const raw=await sql.readOrders(),mapped=mapOrders(raw,now()),row=mapped.ordersSQL.find(r=>r.week===input.week&&r.vendor===input.vendor&&r.code===input.code&&r.itemCode===input.itemCode&&r.timeKey===input.timeKey);
  if(!row||row.revision!==input.revision)throw fail(409,'Order đã thay đổi. Tải lại SQL rồi mở lại chi tiết.');
  // 06/11/2026: mỗi dòng Order là độc lập — quyết định nhắm đúng dòng theo timeKey; các dòng trùng khóa
  // còn lại không bị khóa theo trạng thái của dòng này.
  const latest=mapped.ordersSQL.find(r=>r.vendor===row.vendor&&r.code===row.code&&r.itemCode===row.itemCode&&r.status!=='Chờ duyệt');if(input.decision==='delete'){if(!['supervisor','developer'].includes(user.role))throw fail(403,'Chỉ Supervisor trở lên được xóa Order đã duyệt.');if(!['Đã duyệt','Đã xác nhận'].includes(row.status)||row.deleted||latest!==row)throw fail(409,'Order không còn ở trạng thái đã duyệt. Tải lại dữ liệu.');const context=await contextFor(row);if(input.contextRevision!==context.contextRevision)throw fail(409,'Trạng thái Code hoặc PR/PO đã thay đổi. Mở lại xác nhận xóa.');}else if(!['Chờ duyệt','Cần sửa'].includes(row.status)||row.deleted)throw fail(409,'Order đã được phê duyệt hoặc không còn chờ xử lý. Tải lại dữ liệu.');
  if(row.warning)throw fail(409,'Dữ liệu ngày giờ không rõ ràng. Kiểm tra SQL trước khi phê duyệt.');
  const instant=now(),date=currentWeek(instant).today,time=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Ho_Chi_Minh',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(instant);
    const week=currentWeek(new Date(row.date+'T05:00:00Z')),historyOf=rows=>rows.filter(v=>text(v.Vendor)===row.vendor&&text(v['WRB Code'])===row.code&&text(v['Item Code'])===row.itemCode&&text(v.__orderDate??v.Date)>=week.start&&text(v.__orderDate??v.Date)<=week.end);
  // 06/11/2026: bỏ guard "bản ghi cùng hoặc sau thời điểm quyết định" — với mô hình từng dòng, dòng quyết định
  // do portal vừa ghi (cùng giây) tự chặn mọi quyết định kế tiếp trong lô. Chống xung đột đã do revision
  // (fingerprint toàn bộ dòng của khóa) + historyCount của worker bảo đảm.
  // 12/11/2026 (lỗi người dùng báo: xóa order của mã đặt nhiều lần/ngày luôn 409 "lich-su-thay-doi"):
  // historyCount đọc lúc đầu decide() thành lạc hậu trong lúc chờ hàng đợi worker SQL và các truy vấn
  // codes/PR/PO (contextFor) — mọi dòng mới cùng khóa trong tuần xen vào đều làm rollback lần ghi.
  // Mỗi lần ghi giờ đọc lại Orders, kiểm tra lại dòng đích và trạng thái không đổi rồi gửi với
  // historyCount vừa đếm; worker vẫn báo lich-su-thay-doi (có dòng mới trong cửa sổ đọc lại→ghi)
  // thì tự retry đúng một lần. Lý do nguon-khong-khop/khong-con-dong không bao giờ retry;
  // dòng đích thay đổi vẫn 409 "Order đã thay đổi. Tải lại SQL rồi mở lại chi tiết."
  const targetState=r=>JSON.stringify([r.date,r.timeKey,r.status,r.approver,r.requester,r.itemName,r.quantity,r.unit,r.reason,r.comment,r.remark]);
  async function attemptAppend(){const rawX=await sql.readOrders(),mappedX=mapOrders(rawX,now()),rowX=mappedX.ordersSQL.find(r=>r.week===input.week&&r.vendor===input.vendor&&r.code===input.code&&r.itemCode===input.itemCode&&r.timeKey===input.timeKey),latestX=mappedX.ordersSQL.find(r=>r.vendor===row.vendor&&r.code===row.code&&r.itemCode===row.itemCode&&r.status!=='Chờ duyệt');
   const decidable=!!rowX&&!rowX.deleted&&!rowX.warning&&targetState(rowX)===targetState(row)&&(input.decision==='delete'?latestX===rowX&&['Đã duyệt','Đã xác nhận'].includes(rowX.status):['Chờ duyệt','Cần sửa'].includes(rowX.status));
   if(!decidable)throw fail(409,'Order đã thay đổi. Tải lại SQL rồi mở lại chi tiết.');
   const result=await sql.appendOrder({vendor:row.vendor,code:row.code,itemCode:row.itemCode,start:week.start,end:week.end,source:rawX[rowX.sourceIndex],historyCount:historyOf(rawX).length,status:statuses[input.decision],approver:user.username+'*',date,time,...(input.comment===undefined?{}:{comment:input.comment})});return {result,source:rawX[rowX.sourceIndex]};}
  const entry={digest,at:Date.now()};attempts.set(attempt,entry);
   try{
   let {result,source}=await attemptAppend();
   if(result.conflict&&result.reason==='lich-su-thay-doi')({result,source}=await attemptAppend());
   if(result.conflict)throw fail(409,'Order đã thay đổi trong khi phê duyệt'+(result.reason?' (nguyên nhân: '+result.reason+')':'')+'. Tải lại SQL.');
   if(!result.inserted)throw fail(502,'Chưa xác nhận được kết quả ghi SQL. Tải lại dữ liệu trước khi thao tác tiếp.');
      if(pending)await pending.catch(()=>{});
   const appended={...source,Status:statuses[input.decision],Approver:user.username+'*',Date:date,Time:time,__orderDate:date,__orderTime:time,...(input.comment===undefined?{}:{Comment:input.comment})};
   // 06/11/2026: đọc lại SQL thật để lập snapshot — mô phỏng dòng appended sẽ sai revision (SQL gán ID mới,
   // bản mô phỏng copy identity của dòng nguồn) làm mọi quyết định kế tiếp cùng phiên 409 "Order đã thay đổi".
   let snapshot,freshError=null;
   try{snapshot=mapOrders(await sql.readOrders(),now());}
   catch(e){snapshot=mapOrders([...raw,appended],now());freshError='Đã ghi SQL nhưng tải lại chưa thành công. Nhấn Tải lại dữ liệu.';}
   if(pricing)snapshot.ordersSQL=await pricing.enrich(snapshot.ordersSQL,r=>r.itemCode);entry.result={...snapshot,ordersSource:'sql',ordersUpdatedAt:new Date().toISOString(),ordersError:freshError,inserted:true,approvalDate:date,approvalTime:time,approvalWeek:currentWeek(instant).start};return entry.result;
  }catch(e){entry.error=e.status?e:fail(502,'Chưa xác nhận được kết quả ghi SQL. Tải lại dữ liệu trước khi thao tác tiếp.');throw entry.error;}
 }
 async function contextFor(row){const value=await getOrderContext(row);return {...value,orderStatus:row.status,contextRevision:fingerprint([{revision:row.revision,context:JSON.stringify(value)}])};}
 async function add(input,user,ip){
  if(!input||Object.keys(input).some(k=>!['rows','requestId'].includes(k))||!/^\w[\w-]{15,79}$/.test(input.requestId||'')||!Array.isArray(input.rows)||!input.rows.length||input.rows.length>200)throw fail(400,'Cần 1–200 dòng Order và mã thao tác hợp lệ.');
  const limits={vendor:200,requester:200,code:50,itemCode:100,itemName:500,unit:50,reason:1000,remark:10000},keys=new Set();
    // 06/11/2026: cho phép trùng Vendor + WRB Code + Item Code trong bảng nhập (cùng mã nhưng gia công
  // khác nhau cần nhiều dòng) — chỉ đếm và trả `duplicates` về UI để cảnh báo, không chặn gửi nữa.
  let duplicates=0;const rows=input.rows.map((r,i)=>{if(!r||Object.keys(r).some(k=>!['quantity',...Object.keys(limits)].includes(k)))throw fail(400,'Dòng '+(i+1)+' có cột không hợp lệ.');const out={};for(const [k,max]of Object.entries(limits)){if(typeof r[k]!=='string'||r[k].length>max)throw fail(400,'Dòng '+(i+1)+': '+k+' không hợp lệ.');out[k]=r[k].trim();}if(!out.vendor||!out.itemCode||!out.itemName||!out.unit)throw fail(400,'Dòng '+(i+1)+': cần Vendor, Item Code, Item Name và Unit.');const remark=standardRemark(out.remark);if(!remark.ok)throw fail(400,'Dòng '+(i+1)+': '+remark.error);const q=String(r.quantity??'').trim();if(!/^\d{1,15}(?:\.\d{1,3})?$/.test(q)||Number(q)<=0)throw fail(400,'Dòng '+(i+1)+': Quantity phải > 0, tối đa 3 số thập phân.');out.quantity=q;if(!out.requester)out.requester=user.name||user.username;const key=JSON.stringify([out.vendor,out.code,out.itemCode]);if(keys.has(key))duplicates++;keys.add(key);return out;});
  const attempt=user.id+':add:'+input.requestId,digest=JSON.stringify(input),old=attempts.get(attempt);if(old){if(old.digest!==digest)throw fail(409,'Mã thao tác đã sử dụng.');if(old.error)throw old.error;return old.result;}
  for(const [k,v]of attempts)if(v.at<Date.now()-1800000)attempts.delete(k);if(attempts.size>=500)throw fail(429,'Quá nhiều thao tác, thử lại sau.');
  const instant=now(),date=currentWeek(instant).today,time=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Ho_Chi_Minh',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(instant),entry={digest,at:Date.now()};attempts.set(attempt,entry);
  try{const result=await sql.addOrders({rows,date,time,ip:String(ip||'').replace(/^::ffff:/,'')});if(result.conflict)throw fail(409,'Đã có Order cùng khóa tại thời điểm này; chưa thêm dòng nào. Đợi một giây và tải lại.');if(result.inserted!==rows.length)throw fail(502,'Chưa xác nhận được số dòng SQL; tải lại trước khi thao tác tiếp.');if(pending)await pending.catch(()=>{});entry.result={...await live({ordersSQL:[]}),inserted:result.inserted,duplicates,approvalWeek:currentWeek(instant).start};return entry.result;}catch(e){entry.error=e.status?e:fail(502,'Chưa xác nhận được kết quả thêm Order. Tải lại dữ liệu, không gửi lại ngay.');throw entry.error;}
 }
 async function handle({req,res,url,send,body,protectedTransaction,requireUser}){
  if(url.pathname==='/api/orders-live'){if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ đọc Order SQL.');send(res,200,await live({ordersSQL:[]}));return true;}
  if(url.pathname==='/api/orders-context'){const u=requireUser(req).user;if(!['supervisor','developer'].includes(u.role))throw fail(403,'Chỉ Supervisor trở lên.');if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ GET.');const data=await load(),row=data.ordersSQL.find(r=>r.week===url.searchParams.get('week')&&r.vendor===url.searchParams.get('vendor')&&r.code===url.searchParams.get('code')&&r.itemCode===url.searchParams.get('itemCode'));if(!row)throw fail(404,'Không tìm thấy Order.');send(res,200,await contextFor(row));return true;}
  if(url.pathname==='/api/orders-add'){if(req.method!=='POST')throw fail(405,'Chỉ hỗ trợ POST.');const input=await body(req);send(res,200,await protectedTransaction(()=>add(input,requireUser(req).user,req.socket.remoteAddress)));return true;}
  if(url.pathname!=='/api/orders-decision')return false;
  const editable=()=>{const user=requireUser(req).user;if(!['admin','supervisor','developer'].includes(user.role))throw fail(403,'Chỉ admin trở lên được phê duyệt Order.');return user;};editable();
  if(req.method!=='POST')throw fail(405,'Phương thức không hỗ trợ.');const input=await body(req);
  send(res,200,await protectedTransaction(()=>decide(input,editable())));return true;
 }

 return {live,handle};
}
module.exports={mapOrders,createOrders,standardRemark};
