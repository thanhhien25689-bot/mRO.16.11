const text=value=>String(value??'').trim();
function pricesByCode(rows){
 if(!Array.isArray(rows))throw Error('Dữ liệu đơn giá không hợp lệ.');const grouped=new Map();
 for(const row of rows){const code=text(row.ITEM_CODE);if(!code)continue;const raw=text(row.USD_PRICE),price=raw===''||!Number.isFinite(Number(raw))?null:Number(raw);const list=grouped.get(code)||[];grouped.set(code,list);list.push(price);}
 const result=new Map();for(const[code,prices]of grouped){let unitPrice=null,warning='';if(new Set(prices.map(String)).size>1)warning='EQM_MRO_UnitPrice có nhiều dòng khác USD_PRICE cho mã này; chưa tự chọn.';else if(prices[0]===null)warning='USD_PRICE trống hoặc không hợp lệ trong EQM_MRO_UnitPrice.';else unitPrice=prices[0];result.set(code,{unitPrice,priceCurrency:unitPrice===null?'':'USD',priceDate:'',priceWarning:warning});}return result;
}
function createPricing({sql,now=()=>Date.now()}){let last=null,pending=null,expires=0,attempted=false,warning='';
 async function read(force){if(pending)return pending;if(attempted&&!force&&now()<expires)return;pending=(async()=>{attempted=true;try{last=pricesByCode(await sql.readLatestPrices());expires=now()+5000;warning='';}catch{warning='Không đọc được đơn giá PR mới nhất.'+(last?' Đang dùng cache giá lần trước.':'');expires=now()+5000;}})();try{await pending;}finally{pending=null;}}
 async function enrich(rows,codeOf,{force=false}={}){if(!rows.length||typeof sql.readLatestPrices!=='function')return rows;await read(force);return rows.map(row=>{const priceCode=text(codeOf(row)),value=last?.get(priceCode)||{unitPrice:null,priceCurrency:'',priceDate:'',priceWarning:'Chưa có đơn giá USD_PRICE trong EQM_MRO_UnitPrice.'},quantity=row.quantity,total=value.unitPrice!==null&&quantity!==null&&quantity!==undefined&&Number.isFinite(Number(quantity))?value.unitPrice*Number(quantity):null;return {...row,...value,totalPrice:Number.isFinite(total)?total:null,priceCode,priceWarning:[warning,value.priceWarning].filter(Boolean).join(' ')};});}
 return {enrich};
}
module.exports={createPricing,pricesByCode};
