const crypto=require('node:crypto');
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const canonical=rows=>rows.map(row=>Object.keys(row).sort().map(key=>[key,row[key]])).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
function createNotifications({sql,codes,tracking,now=()=>new Date()}){
 let pending,previous,finished=0;
 async function snapshot(){if(pending)return pending;if(previous&&now().getTime()-finished<5000)return previous;
 pending=(async()=>{const data={},errors={};
 const capture=async(key,fn)=>{try{data[key]=await fn();}catch(e){errors[key]='Chưa kiểm tra được dữ liệu '+key+'.';}};
 await Promise.all([
 capture('stock',async()=>{const rows=await sql.readUpdateHistory(),latest={};for(const row of rows){if(String(row.Type).trim().toLowerCase()!=='stock')continue;const vendor=String(row.Vendor??'').trim(),time=String(row.Time??'').trim(),instant=Date.parse(time);if(!vendor||!Number.isFinite(instant))continue;if(!latest[vendor]||instant>Date.parse(latest[vendor]))latest[vendor]=new Date(instant).toISOString();}return latest;}),
 capture('delivery',async()=>hash(canonical(await sql.readTransfers()))),
 capture('orders',async()=>hash(canonical(await sql.readOrders()))),
 (async()=>{try{const value=await codes.live({codesSQL:[]});if(value.codesSource!=='sql')throw Error('offline');data.codes=value.codesSQL.map(r=>({key:r.key,ready:r.status==='Ready for PR',code:r.purchaseCode||r.originalCode}));if(typeof tracking.ensureLoaded==='function')await tracking.ensureLoaded();const rows=tracking.overlay(value).trackingSQL;data.tracking=rows.filter(r=>!r.warning&&r.pr?.PR_NO).map(r=>({key:r.sourceKey,pr:r.pr.PR_NO,seq:r.pr.PR_SEQ,code:r.purchaseCode}));}catch(e){errors.codes='Chưa kiểm tra được Codes.';errors.tracking='Chưa kiểm tra được Tracking.';}})()
 ]);previous={data,errors,checkedAt:now().toISOString()};finished=now().getTime();return previous;})();try{return await pending;}finally{pending=null;}}
 async function handle({req,res,url,send}){if(url.pathname!=='/api/notifications/check')return false;if(req.method!=='GET')throw Object.assign(Error('Chỉ hỗ trợ kiểm tra thông báo.'),{status:405});send(res,200,await snapshot());return true;}
 return {handle,snapshot};
}
module.exports={createNotifications};
