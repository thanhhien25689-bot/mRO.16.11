const {eligiblePR}=require('../../integration/pr-eligibility.cjs');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const fail=(status,message)=>Object.assign(Error(message),{status});
const text=v=>v==null||/^null$/i.test(String(v).trim())?'':String(v).trim();
const hash=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const number=v=>text(v)===''?null:Number.isFinite(Number(v))?Number(v):null;
const identity=r=>hash([text(r.ITEM_CODE),text(r.PR_NO),text(r.PR_SEQ)]);
function prState(pr={}){
 const prNo=text(pr.PR_NO),po=text(pr.PO_NO),shipping=number(pr.SHIPPING_QTY),qty=number(pr.PO_QTY),gr=number(pr.GR_QTY);
 let status='Chưa xác định',reason='PO/Shipping Qty thiếu, âm hoặc Shipping Qty vượt PO Qty; cần kiểm tra nguồn SQL.';
 if(!prNo){status='Chờ Cập nhật PR';reason='PR No chưa có giá trị.';}
 else if(!po){status='Đã cập nhật PR';reason='Đã có PR No, chưa có PO No.';}
 else if(shipping===0){status='Đã có PO';reason='Đã có PO No và Shipping Qty = 0.';}
 else if(qty!==null&&qty>0&&shipping>0&&shipping<qty){status='Đang giao';reason='Đã có PO No; 0 < Shipping Qty < PO Qty.';}
 else if(qty!==null&&qty>0&&shipping===qty){status='Đã nhận đủ';reason='Đã có PO No; Shipping Qty = PO Qty.';}
 return {status,reason,poQty:qty,shippingQty:shipping,grQty:gr,progress:status==='Đang giao'?`${gr??'—'} / ${qty??'—'}`:''};
}
function mapPR(rows){if(!Array.isArray(rows))throw fail(502,'Dữ liệu PR không hợp lệ.');const unique=new Map();for(const raw of rows){if(!eligiblePR(raw))continue;const r={};for(const k of ['ITEM_CODE','PURCHASE_REQ_INFO','PR_SEQ','PR_CREATOR_NAME','COST_CENTER','PR_NO','PO_NO','PO_SEQ','PR_DATE','PR_QTY','STATUS','PR_STATUS','PO_STATUS','PO_DATE','PO_QTY','SHIPPING_QTY','GR_QTY'])r[k]=text(raw[k]);r.selectionId=hash(r);unique.set(r.selectionId,r);}return [...unique.values()];}
function createTracking({root,runtime,sql,codes,prReasons,now=()=>new Date()}){
 const file=path.join(path.resolve(runtime)===path.resolve(root,'.runtime')?path.join(root,'data'):path.join(runtime,'data'),'pic3.json');
 function read(){if(!fs.existsSync(file))return {version:1,entries:{},drafts:{}};const doc=JSON.parse(fs.readFileSync(file,'utf8'));if(doc.version!==1||!doc.entries||!doc.drafts||Array.isArray(doc.entries)||Array.isArray(doc.drafts))throw fail(500,'pic3.json không hợp lệ. Kiểm tra file và bản sao lưu; chưa ghi thay đổi.');return doc;}
 function write(doc){fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(temp,JSON.stringify(doc,null,2),{mode:0o600});fs.renameSync(temp,file);}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}}
 // 09-11-2026: theo yêu cầu người dùng, xác nhận PIC3 lưu trên dbo.EQM_MRO_PRSelect, KHÔNG ghi data/pic3.json
 // khi core nối adapter SQL (sql.readPrSelect/writePrSelect). Bảng là nguồn: mỗi lượt tracking-live đọc lại,
 // mọi thay đổi chỉ báo đã lưu sau khi ghi SQL thành công; lỗi đọc → giữ cache gần nhất + cảnh báo trackingError,
 // không giả dữ liệu rỗng. Adapter vắng mặt (test/dev cũ) vẫn dùng file để tương thích regression.
 const prSelectMode=typeof sql.readPrSelect==='function'&&typeof sql.writePrSelect==='function';
 let prSelectCache={version:1,entries:{},drafts:{}},prSelectWarning='',prSelectLoadedAt=0;
 const trimQty=v=>{const s=String(v??'');return /^\d+(?:\.\d+)?$/.test(s)?s.replace(/(\.\d*?)0+$/,'$1').replace(/\.$/,''):s;}; // SQL decimal(18,6) trả "5.000000" → "5"
 const isoUtc=v=>{const s=String(v??'');return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?$/.test(s)?s+'Z':s;}; // CONVERT 126 mất "Z" → gắn lại để đúng mốc UTC
 function docFromRows(rows){const doc={version:1,entries:{},drafts:{}};for(const row of rows||[]){const key=String(row&&row.LineKey||'');if(!/^[a-f0-9]{64}$/.test(key))continue;let source={},pr=null;
  try{source=JSON.parse(String(row.SourceJson||'{}'))||{};}catch{}
  if(row.PRJson&&String(row.PRJson))try{pr=JSON.parse(String(row.PRJson))||null;}catch{}
  const entry={source,purchaseQuantity:trimQty(row.BuyQty),note:row.Note==null?'':String(row.Note),pr,updatedAt:isoUtc(row.UpdatedAt),updatedBy:row.UpdatedBy==null?'':String(row.UpdatedBy),revision:row.Revision==null?'':String(row.Revision)};
  if(String(row.PRNo||''))doc.entries[key]=entry;else doc.drafts[key]=entry;}return doc;}
 function entryCols(key,entry){const source=entry.source||{};return{lineKey:key,purchaseCode:source.purchaseCode||'',originalCode:source.originalCode||'',itemName:source.itemName||'',vendor:source.vendor||'',orderDate:/^\d{4}-\d{2}-\d{2}$/.test(String(source.date||''))?String(source.date):'',prNo:entry.pr?text(entry.pr.PR_NO):'',prSeq:entry.pr?text(entry.pr.PR_SEQ):'',buyQty:entry.purchaseQuantity||'',note:entry.note||'',sourceJson:JSON.stringify(source),prJson:entry.pr?JSON.stringify(entry.pr):'',revision:entry.revision||'',updatedAt:entry.updatedAt||now().toISOString(),updatedBy:entry.updatedBy||''};}
 function opsBetween(prev,next){const ops={inserts:[],updates:[],deletes:[]};
  for(const group of ['entries','drafts']){const before=prev[group]||{},after=next[group]||{};
   for(const[key,entry]of Object.entries(after)){const old=before[key];if(!old)ops.inserts.push(entryCols(key,entry));else if(JSON.stringify(old)!==JSON.stringify(entry))ops.updates.push({...entryCols(key,entry),expectedRevision:old.revision||''});}
   for(const[key,old]of Object.entries(before))if(!after[key])ops.deletes.push({lineKey:key,expectedRevision:old.revision||''});}
  return ops;}
 async function freshDoc(){if(!prSelectMode)return read();try{const doc=docFromRows(await sql.readPrSelect());prSelectCache=doc;prSelectWarning='';return doc;}catch(error){throw fail(503,'Không đọc được bảng EQM_MRO_PRSelect từ SQL. Chưa lưu thay đổi. Nguyên nhân: '+text(error&&error.message).slice(0,200));}}
 async function persistDoc(prev,doc){if(!prSelectMode){write(doc);return;}const ops=opsBetween(prev,doc);if(!ops.inserts.length&&!ops.updates.length&&!ops.deletes.length)return;await sql.writePrSelect(ops);prSelectCache=doc;}
 const cloneDoc=doc=>JSON.parse(JSON.stringify(doc));
 // 09-11-2026: người đọc đồng bộ (notifications) phải gọi ensureLoaded() trước overlay() khi tiến trình
 // vừa khởi động, để overlay không trả tài liệu lạnh (không giả tracking rỗng). Cache dùng 60 giây.
 async function ensureLoaded(){if(!prSelectMode)return;if(prSelectLoadedAt&&now().getTime()-prSelectLoadedAt<60000)return;try{prSelectCache=docFromRows(await sql.readPrSelect());prSelectWarning='';prSelectLoadedAt=now().getTime();}catch(error){prSelectWarning='Không đọc được xác nhận PR từ EQM_MRO_PRSelect: '+text(error&&error.message).slice(0,200);if(!prSelectLoadedAt)throw fail(503,prSelectWarning);}}
 const sourceFields=r=>({key:r.key,date:r.date,originalCode:r.originalCode,purchaseCode:r.purchaseCode,itemName:r.itemName,quantity:r.quantity,unit:r.unit,vendor:r.vendor,typeOfCode:r.typeOfCode});
 const codeMetadata=r=>({codeStatus:r.action==='Ready for PR'?'Ready for PR':(r.status||''),codeAction:r.action||''});
 const sourceRevision=r=>hash({...sourceFields(r),...codeMetadata(r)});
 // Gợi ý ghi chú cho màn Tracking: lấy từ Order, ưu tiên Comment → Remark → Reason.
 // Chỉ để hiển thị; không lưu vào pic3.json và không nằm trong sourceRevision.
 const orderNote = r => text(r.comment || r.remark || r.reason);
 // 06/11/2026: "Lí do mua hàng" cho Project Status. PR do PIC ngoài bộ phận chuẩn tạo trên ERP (danh
 // sách chốt: chỉ bui.thu2) thường để trống PURCHASE_REQ_INFO, nên parseDescription của Project Status
 // loại hẳn dòng đó. PIC3 nhập lại Lí do theo form Type - Project - Model - Process ngay khi chọn PR.
 // Kho nhập tay do Project Status sở hữu (data/pr-reasons.json); Tracking chỉ đọc trạng thái qua adapter
 // public do core nối — không đọc file, không ghi, và lỗi kho không được làm hỏng lượt tải Tracking.
 function reasonStore(){try{const store=typeof prReasons==='function'?prReasons():prReasons;return store&&typeof store.stateFor==='function'?store:null;}catch{return null;}}
 function reasonFor(pr){
  const empty={needReason:false,reasonFilled:false,reasonIgnored:false,reasonSource:'',reasonText:'',reasonBy:'',reasonRevision:''};
  const store=reasonStore();
  if(!store||!pr||!text(pr.PR_NO)||!text(pr.PR_SEQ))return empty;
  try{
   const state=store.stateFor({itemCode:pr.ITEM_CODE,prNo:pr.PR_NO,prSeq:pr.PR_SEQ,purchaseReqInfo:pr.PURCHASE_REQ_INFO,creator:pr.PR_CREATOR_NAME});
   if(!state)return empty;
   return {needReason:!!state.needed,reasonFilled:!!state.filled,reasonIgnored:!!state.ignored,reasonSource:state.source||'',reasonText:state.description||'',reasonBy:state.updatedBy||'',reasonRevision:state.revision||''};
  }catch{return empty;}
 }
 function reasonSummary(rows){
  const store=reasonStore();
  const needed=(rows||[]).filter(row=>row.needReason).length;
  if(!store)return {source:'unavailable',message:'Portal chưa nối được kho Lí do mua hàng của Project Status.',total:0,needed,filled:0,ignored:0};
  try{
   const state=store.summary();
   return {source:state.error?'error':'ok',message:state.error||'',total:state.total,needed,filled:state.filled,ignored:state.ignored};
  }catch(error){return {source:'error',message:'Không đọc được kho Lí do mua hàng: '+text(error&&error.message).slice(0,200),total:0,needed,filled:0,ignored:0};}
 }
 function renderRow(source,entry={},warning=''){const pr=entry.pr||{},excludedPR=!!entry.pr&&!eligiblePR(entry.pr);return {rowId:hash([source.key,source.purchaseCode]),...(excludedPR?{excludedPR:true}:{}),sourceKey:source.key,sourceRevision:sourceRevision(source),...sourceFields(source),...codeMetadata(source),purchaseQuantity:entry.purchaseQuantity??'',note:entry.note||'',orderNote:orderNote(source),pr,prNo:text(pr.PR_NO),prSeq:text(pr.PR_SEQ),poNo:text(pr.PO_NO),...prState(pr),...reasonFor(pr),poWarning:'',revision:entry.revision||'',updatedAt:entry.updatedAt||'',warning};}
 function overlay(data,includeExcluded=false){if(!Array.isArray(data.codesSQL))return data;const doc=prSelectMode?prSelectCache:read(),used=new Set(),rows=[];
  for(const source of data.codesSQL){const saved=Object.entries(doc.entries).find(([,v])=>v.source.key===source.key&&v.source.purchaseCode===source.purchaseCode);if(saved){used.add(saved[0]);rows.push(renderRow(source,saved[1]));}else{const draft=doc.drafts[source.key];rows.push(renderRow(source,draft?.source.purchaseCode===source.purchaseCode?draft:{}));}}
  for(const [key,entry]of Object.entries(doc.entries))if(!used.has(key))rows.push(renderRow(entry.source,entry,'Order hoặc Purchase Code đã thay đổi/không còn trong Codes. Giữ dữ liệu đã lưu; tải lại và kiểm tra trước khi sửa.'));
  return {...data,trackingSQL:includeExcluded?rows:rows.filter(r=>!r.excludedPR),trackingSource:data.codesSource||'empty',trackingError:data.codesError||null};
 }
 // 06/11/2026: cảnh báo mã HHP — Purchase Code của dòng "Confirm for order" được so với cột
 // BQMS Code trong EQM_MRO_HhpOrderCode. Danh sách mã là bảng tham chiếu nên cache RAM 60 giây
 // (15 giây sau lần lỗi); mỗi lượt tải Tracking gọi SQL tối đa một lần.
 const hhpTTL=60000,hhpFailTTL=15000;let hhpCache=null;
 async function hhpState(){const at=now().getTime();
  if(hhpCache&&at-hhpCache.at<(hhpCache.source==='sql'?hhpTTL:hhpFailTTL))return hhpCache;
  if(typeof sql.readHhpCodes!=='function'){hhpCache={at,source:'unavailable',message:'Portal chưa có đường đọc bảng mã HHP từ SQL.',codes:new Set()};return hhpCache;}
  try{const codes=await sql.readHhpCodes();hhpCache={at,source:'sql',message:'',codes:new Set((Array.isArray(codes)?codes:[]).map(code=>text(code).toUpperCase()).filter(Boolean))};}
  catch(error){hhpCache={at,source:'error',message:'Không đọc được mã HHP từ EQM_MRO_HhpOrderCode: '+text(error&&error.message).slice(0,300),codes:new Set()};}
  return hhpCache;}
 // Gắn cờ hhpCode cho từng dòng (true = Purchase Code trùng BQMS Code, so trim + không phân biệt hoa thường)
 // và khóa trackingHHP cho lớp hiển thị. Lỗi đọc SQL chỉ làm trackingHHP.source='error' kèm nguyên nhân,
 // không được làm mất dòng Tracking hay giả danh sách rỗng.
 function markHHP(value,state){
  if(state.source!=='sql'){value.trackingHHP={source:state.source,message:state.message,total:null};return value;}
  for(const row of value.trackingSQL||[]){const code=text(row.purchaseCode).toUpperCase();row.hhpCode=!!code&&state.codes.has(code);}
  value.trackingHHP={source:'sql',message:'',total:state.codes.size};
  return value;}
 async function refresh(data){
  // 09-11-2026: ở chế độ bảng, đọc EQM_MRO_PRSelect trước khi lớp phủ; lỗi đọc giữ cache + cảnh báo.
  if(prSelectMode){try{prSelectCache=docFromRows(await sql.readPrSelect());prSelectWarning='';prSelectLoadedAt=now().getTime();}catch(error){prSelectWarning='Không đọc được xác nhận PR từ EQM_MRO_PRSelect: '+text(error&&error.message).slice(0,200)+' Đang hiển thị bản tải gần nhất.';}}
  const value=overlay(data,true),cache=new Map();let failed=false;
  const purchaseCodes=[...new Set((value.trackingSQL||[]).filter(row=>row.prNo&&row.purchaseCode).map(row=>row.purchaseCode))];
  // Batch action tracking-pr-batch (SELECT IN tham số hóa, cùng bảng/cột với tracking-pr) gộp toàn bộ mã về một lượt worker;
  // adapter giả hoặc bản chưa có batch vẫn đi đường lookupPR từng mã như trước.
  if(typeof sql.lookupPRBatch==='function'&&purchaseCodes.length){
   const chunks=[];for(let i=0;i<purchaseCodes.length;i+=200)chunks.push(purchaseCodes.slice(i,i+200));
   const results=await Promise.all(chunks.map(async chunk=>{try{return await sql.lookupPRBatch(chunk);}catch{failed=true;return[];}}));
   for(const records of results)for(const record of records){const code=text(record.ITEM_CODE);if(!cache.has(code))cache.set(code,[]);cache.get(code).push(record);}
  }else{
   await Promise.all(purchaseCodes.map(async purchaseCode=>{try{cache.set(purchaseCode,await sql.lookupPR(purchaseCode));}catch{failed=true;}}));
  }
  for(const row of value.trackingSQL||[]){if(!row.prNo||!row.purchaseCode)continue;const records=cache.get(row.purchaseCode);if(!records)continue;
   const matches=records.filter(r=>text(r.ITEM_CODE)===row.purchaseCode&&text(r.PR_NO)===row.prNo&&text(r.PR_SEQ)===row.prSeq),exact=matches.filter(r=>text(r.PO_NO)===row.poNo&&text(r.PO_SEQ)===text(row.pr.PO_SEQ)),pool=exact.length?exact:matches,eligible=pool.filter(eligiblePR),match=eligible[0]||pool[0];
   if(!matches.length)continue;const newer=matches.filter(r=>eligiblePR(r)&&text(r.PO_NO)&&!exact.includes(r));if(!exact.length&&eligible.length>1){row.poWarning='PR/Seq này có '+eligible.length+' dòng PO mới ('+eligible.map(r=>text(r.PO_NO)).join(', ')+'); PIC3 cần chọn lại PR để gắn đúng PO.';}
   else if(exact.length&&!row.poNo&&newer.length){row.poWarning='PR/Seq này đã có PO mới trên SQL ('+newer.map(r=>text(r.PO_NO)).join(', ')+') nhưng dòng đã lưu chưa gắn PO; PIC3 cần chọn lại PR.';}
   else if(!eligiblePR(match)){row.pr={};row.prNo='';row.prSeq='';row.poNo='';Object.assign(row,prState({}),reasonFor({}));row.excludedPR=true;}
   // PURCHASE_REQ_INFO + PR_CREATOR_NAME được hydrate cùng trạng thái PR để cờ "cần nhập Lí do"
   // (needReason/reasonSource) luôn theo đúng dòng SQL mới nhất, không theo bản lưu cũ trong pic3.json.
   else{delete row.excludedPR;row.pr={...row.pr,...Object.fromEntries(['PR_DATE','PR_QTY','STATUS','PR_STATUS','PO_NO','PO_SEQ','PO_STATUS','PO_DATE','PO_QTY','SHIPPING_QTY','GR_QTY','PURCHASE_REQ_INFO','PR_CREATOR_NAME'].map(k=>[k,text(match[k])]))};row.poNo=text(row.pr.PO_NO);Object.assign(row,prState(row.pr),reasonFor(row.pr));}
  }
  if(value.trackingSQL)value.trackingSQL=value.trackingSQL.filter(r=>!r.excludedPR);
  if(value.trackingSQL)value.trackingReasons=reasonSummary(value.trackingSQL);
  if(failed)value.trackingError=[value.trackingError,'Không xác minh được trạng thái PR mới nhất từ SQL. Dữ liệu đã lưu được giữ nguyên.'].filter(Boolean).join(' ');
  if(prSelectWarning)value.trackingError=[value.trackingError,prSelectWarning].filter(Boolean).join(' ');
  // Đọc mã HHP không bao giờ được làm hỏng lượt tải Tracking: mọi lỗi chỉ ghi vào trackingHHP.
  try{return markHHP(value,await hhpState());}
  catch(error){value.trackingHHP={source:'error',message:'Không đọc được mã HHP từ EQM_MRO_HhpOrderCode: '+text(error&&error.message).slice(0,300),total:null};return value;}
 }
 async function live(){return refresh(await codes.live({codesSQL:[]}));}
 async function lookup(code){if(typeof code!=='string'||!code.trim()||code.length>50)throw fail(400,'Cần Purchase Code từ Codes, tối đa 50 ký tự.');return mapPR(await sql.lookupPR(code.trim())).filter(r=>r.ITEM_CODE===code.trim());}
 async function search(prNumber){
  if(typeof prNumber!=='string'||!prNumber.trim()||prNumber.trim().length>50)throw fail(400,'Cần số PR, tối đa 50 ký tự.');
  if(typeof sql.lookupPRNumber!=='function')throw fail(503,'SQL adapter chưa hỗ trợ tìm theo PR.');
  const pr=prNumber.trim(),candidates=mapPR(await sql.lookupPRNumber(pr)).filter(r=>r.PR_NO===pr);
  const snapshot=await live();if(snapshot.trackingSource!=='sql')throw fail(503,'Không xác minh được Codes từ SQL. Chưa thể match Order.');
  return {rows:candidates.map(r=>({...r,matches:snapshot.trackingSQL.filter(t=>!t.warning&&t.purchaseCode===r.ITEM_CODE).map(t=>({rowId:t.rowId,sourceKey:t.sourceKey,sourceRevision:t.sourceRevision,revision:t.revision,originalCode:t.originalCode,purchaseCode:t.purchaseCode,itemName:t.itemName,quantity:t.quantity,quantityMatch:(number(t.purchaseQuantity)??number(t.quantity))!==null&&number(r.PR_QTY)!==null&&(number(t.purchaseQuantity)??number(t.quantity))===number(r.PR_QTY),vendor:t.vendor,purchaseQuantity:String(t.purchaseQuantity),note:t.note}))}))};
 }
 async function edit(input,user){
  if(!input||Object.keys(input).some(k=>!['sourceKey','sourceRevision','revision','purchaseQuantity','note','selectionId'].includes(k)))throw fail(400,'Thông tin Tracking không hợp lệ.');
  for(const k of ['sourceKey','sourceRevision'])if(!/^[a-f0-9]{64}$/.test(input[k]||''))throw fail(400,'Khóa nguồn không hợp lệ.');
  if(typeof input.revision!=='string'||(input.revision!==''&&!/^[a-f0-9]{64}$/.test(input.revision)))throw fail(400,'Revision không hợp lệ.');
  if(typeof input.note!=='string'||input.note.length>4000)throw fail(400,'Ghi chú tối đa 4000 ký tự.');
  const qty=input.purchaseQuantity;if(typeof qty!=='string'||(qty!==''&&(!/^\d{1,12}(?:\.\d{1,6})?$/.test(qty)||!Number.isFinite(Number(qty)))))throw fail(400,'Số lượng mua phải không âm, tối đa 6 số thập phân.');
  if(input.selectionId!==undefined&&!/^[a-f0-9]{64}$/.test(input.selectionId))throw fail(400,'Lựa chọn PR không hợp lệ.');
  const snapshot=await codes.live({codesSQL:[]});if(snapshot.codesSource!=='sql')throw fail(503,'Không xác minh được Order/Codes từ SQL. Chưa lưu.');const source=snapshot.codesSQL.find(r=>r.key===input.sourceKey);
  if(!source||source.warning||sourceRevision(source)!==input.sourceRevision)throw fail(409,'Dữ liệu Codes đã thay đổi. Tải lại Tracking trước khi sửa.');
  const prev=await freshDoc(),doc=cloneDoc(prev),previous=Object.entries(doc.entries).find(([,e])=>e.source.key===source.key&&e.source.purchaseCode===source.purchaseCode);const draft=doc.drafts[source.key];const old=previous?.[1]||(draft?.source.purchaseCode===source.purchaseCode?draft:{})||{};
  if((old.revision||'')!==input.revision)throw fail(409,'Dòng đã được người khác cập nhật. Tải lại Tracking.');
  let pr=old.pr||null;if(input.selectionId){pr=(await lookup(source.purchaseCode)).find(r=>r.selectionId===input.selectionId);if(!pr)throw fail(409,'PR đã thay đổi. Nhấn Load để chọn lại.');if(!pr.PR_NO||!pr.PR_SEQ)throw fail(400,'Dòng SQL thiếu PR No hoặc PR Seq; chưa thể xác định khóa lưu.');}
  const entry={source:sourceFields(source),purchaseQuantity:qty,note:input.note.trim(),pr,updatedAt:now().toISOString(),updatedBy:user.username,revision:crypto.randomBytes(32).toString('hex')};
  if(pr){const key=identity(pr),collision=doc.entries[key];if(collision&&collision.source.key!==source.key)throw fail(409,'Purchase Code + PR No + PR Seq này đã được chọn cho Order khác. Không tạo dòng trùng hoặc tự cộng số lượng.');if(previous&&previous[0]!==key)delete doc.entries[previous[0]];doc.entries[key]=entry;delete doc.drafts[source.key];}
  else doc.drafts[source.key]=entry;
  await persistDoc(prev,doc);return {row:renderRow(source,entry)};
 }
 async function editBatch(input,user){
  if(!input||Object.keys(input).length!==1||!Array.isArray(input.entries)||!input.entries.length||input.entries.length>200)throw fail(400,'Danh sách số lượng mua không hợp lệ.');
  const ids=new Set();for(const item of input.entries){if(!item||Object.keys(item).some(k=>!['sourceKey','sourceRevision','revision','purchaseQuantity','note'].includes(k))||ids.has(item.sourceKey))throw fail(400,'Dòng Tracking không hợp lệ.');ids.add(item.sourceKey);for(const k of ['sourceKey','sourceRevision'])if(!/^[a-f0-9]{64}$/.test(item[k]||''))throw fail(400,'Khóa nguồn không hợp lệ.');if(typeof item.revision!=='string'||(item.revision!==''&&!/^[a-f0-9]{64}$/.test(item.revision)))throw fail(400,'Revision không hợp lệ.');if(typeof item.note!=='string'||item.note.length>4000)throw fail(400,'Ghi chú tối đa 4000 ký tự.');if(typeof item.purchaseQuantity!=='string'||(item.purchaseQuantity!==''&&(!/^\d{1,12}(?:\.\d{1,6})?$/.test(item.purchaseQuantity)||!Number.isFinite(Number(item.purchaseQuantity)))))throw fail(400,'Số lượng mua phải không âm, tối đa 6 số thập phân.');}
  const snapshot=await codes.live({codesSQL:[]});if(snapshot.codesSource!=='sql')throw fail(503,'Không xác minh được Order/Codes từ SQL. Chưa lưu.');const prev=await freshDoc(),doc=cloneDoc(prev),prepared=[];
  for(const item of input.entries){const source=snapshot.codesSQL.find(row=>row.key===item.sourceKey);if(!source||source.warning||sourceRevision(source)!==item.sourceRevision)throw fail(409,'Dữ liệu Codes đã thay đổi. Tải lại Tracking trước khi sửa.');const previous=Object.entries(doc.entries).find(([,entry])=>entry.source.key===source.key&&entry.source.purchaseCode===source.purchaseCode),draft=doc.drafts[source.key],old=previous?.[1]||(draft?.source.purchaseCode===source.purchaseCode?draft:{})||{};if((old.revision||'')!==item.revision)throw fail(409,'Có dòng đã được người khác cập nhật. Tải lại Tracking.');prepared.push({item,source,old});}
  const saved=[];for(const {item,source,old} of prepared){const entry={source:sourceFields(source),purchaseQuantity:item.purchaseQuantity,note:item.note.trim(),pr:old.pr||null,updatedAt:now().toISOString(),updatedBy:user.username,revision:crypto.randomBytes(32).toString('hex')};if(entry.pr){const key=identity(entry.pr),collision=doc.entries[key];if(collision&&collision.source.key!==source.key)throw fail(409,'Purchase Code + PR No + PR Seq này đã được chọn cho Order khác.');doc.entries[key]=entry;delete doc.drafts[source.key];}else doc.drafts[source.key]=entry;saved.push(renderRow(source,entry));}
  await persistDoc(prev,doc);return {rows:saved};
 }
 async function remove(input){
  if(!input||Object.keys(input).some(key=>!['rowId','revision'].includes(key))||!['rowId','revision'].every(key=>typeof input[key]==='string'&&/^[a-f0-9]{64}$/.test(input[key])))throw fail(400,'Khóa xóa Tracking không hợp lệ.');
  const prev=await freshDoc(),doc=cloneDoc(prev),matches=[];for(const group of ['entries','drafts'])for(const [key,entry]of Object.entries(doc[group]))if(hash([entry.source.key,entry.source.purchaseCode])===input.rowId)matches.push({group,key,entry});
  if(!matches.length)throw fail(404,'Không còn dữ liệu Tracking đã lưu cho dòng này. Tải lại dữ liệu.');if(matches.length!==1)throw fail(409,'Nhiều bản ghi cùng dòng; chưa xóa để tránh mất dữ liệu.');const target=matches[0];if(target.entry.revision!==input.revision)throw fail(409,'Dòng đã được người khác cập nhật. Tải lại trước khi xóa.');
  delete doc[target.group][target.key];await persistDoc(prev,doc);return {removed:input.rowId,cleared:{purchaseQuantity:'',note:'',pr:{},prNo:'',prSeq:'',poNo:'',...prState({}),...reasonFor({}),revision:'',updatedAt:''}};
 }
 async function handle({req,res,url,body,send,protectedTransaction,requireUser}){
  if(!['/api/tracking-live','/api/tracking-pr','/api/tracking-edit','/api/tracking-edit-batch','/api/tracking-search'].includes(url.pathname))return false;
  if(url.pathname==='/api/tracking-live'){if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ GET.');const value=await live();send(res,200,{trackingSQL:value.trackingSQL,trackingSource:value.trackingSource,trackingError:value.trackingError,trackingHHP:value.trackingHHP||{source:'unavailable',message:'Chưa kiểm tra được mã HHP từ EQM_MRO_HhpOrderCode.',total:null},trackingReasons:value.trackingReasons||{source:'unavailable',message:'Portal chưa nối được kho Lí do mua hàng của Project Status.',total:0,needed:0,filled:0,ignored:0}});return true;}
  if(url.pathname==='/api/tracking-search'){if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ GET.');send(res,200,await search(url.searchParams.get('pr')));return true;}
  if(url.pathname==='/api/tracking-pr'){if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ GET.');send(res,200,{rows:await lookup(url.searchParams.get('code'))});return true;}
  if(url.pathname==='/api/tracking-edit-batch'){if(req.method!=='PATCH')throw fail(405,'Chỉ hỗ trợ PATCH.');const input=await body(req);send(res,200,await protectedTransaction(()=>editBatch(input,requireUser(req).user)));return true;}
  if(req.method==='DELETE'){const input=await body(req);send(res,200,await protectedTransaction(()=>remove(input)));return true;}
  if(req.method!=='PATCH')throw fail(405,'Chỉ hỗ trợ PATCH hoặc DELETE.');const input=await body(req);send(res,200,await protectedTransaction(()=>edit(input,requireUser(req).user)));return true;
 }
 return {overlay,refresh,live,ensureLoaded,handle};
}
module.exports={createTracking,prState,mapPR,identity};
