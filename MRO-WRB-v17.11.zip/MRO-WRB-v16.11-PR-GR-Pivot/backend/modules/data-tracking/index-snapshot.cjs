const fs=require('node:fs'),path=require('node:path');
const base=require('./index-v2.cjs');

function createDataTracking(options={}){
  const inner=base.createDataTracking(options),directory=options.runtime?path.join(options.runtime,'cache','data-tracking'):null,recent=new Map();
  const reportKind=kind=>kind==='REPORT'||kind==='GR_REPORT';
  const fileFor=(kind,year)=>directory?path.join(directory,(reportKind(kind)?kind+'-'+year:kind)+'.json'):null;
  const read=(kind,year)=>{const file=fileFor(kind,year);if(!file)return null;try{const value=JSON.parse(fs.readFileSync(file,'utf8'));if(kind==='REPORT'&&!Array.isArray(value?.details))return null;if(reportKind(kind)&&!Array.isArray(value?.reasonIssues))return null;return value?.sheet?.columns&&Array.isArray(value.sheet.rows)?value:null;}catch{return null;}};
  const write=(kind,year,value)=>{const file=fileFor(kind,year);if(!file)return;fs.mkdirSync(directory,{recursive:true});const tmp=file+'.'+process.pid+'.tmp';fs.writeFileSync(tmp,JSON.stringify(value));fs.renameSync(tmp,file);};
  return {async handle(context){
    const {url,send}=context;
    if(url.pathname!=='/api/data-tracking'||context.req.method!=='GET')return inner.handle(context);
    const kind=url.searchParams.get('table'),year=Number(url.searchParams.get('year')),key=reportKind(kind)?kind+'-'+year:kind,validKind=['REPORT','GR_REPORT','PR','RFQ','GMRO'].includes(kind),validYear=!reportKind(kind)||(Number.isInteger(year)&&year>=2000&&year<=2100),disk=validKind&&validYear?(read(kind,year)||recent.get(key)):null;
    if(disk&&url.searchParams.get('reload')!=='1'){send(context.res,200,disk);return true;}
    let sent=false;
    try{return await inner.handle({...context,send:(res,status,value)=>{sent=true;recent.set(key,value);write(kind,year,value);send(res,status,value);}});}
    catch(error){if(disk&&!sent){send(context.res,200,{...disk,source:'sql-cache',warning:'Không tải được SQL; đang giữ snapshot server lần tải thành công trước.'});return true;}throw error;}
  }};
}

module.exports={...base,createDataTracking};
