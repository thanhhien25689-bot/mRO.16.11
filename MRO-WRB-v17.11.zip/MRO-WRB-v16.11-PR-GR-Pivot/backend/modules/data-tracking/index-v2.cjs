const {normalizeSheets}=require('../downloads/index.cjs');
const {eligiblePR}=require('../../integration/pr-eligibility.cjs');
// Report Form chỉ nhận Type từ đầu Reason đúng cấu trúc; không đoán từ khóa trong ghi chú tự do.
const {parseReasonParts}=require('../../integration/pr-reason.cjs');
const dims=['PR_NO','COST_CENTER','Class','Type','Project','Model','Process'];   // khóa gộp dòng (mỗi PR một dòng)
const rawColumn='PURCHASE_REQ_INFO';                               // cột đối chiếu, không nằm trong khóa gộp
const valueCols=[...Array.from({length:12},(_,i)=>String(i+1)),'Amount'];
const cols=[...dims,...valueCols,rawColumn];
const numericCols=new Set(valueCols);
// Một nhóm có thể gom nhiều chuỗi ERP khác nhau: hiển thị tối đa 5 chuỗi (cắt 120 ký tự), phần
// thừa nêu "(+N chuỗi khác)" để người dùng biết còn dữ liệu chưa hiện thay vì âm thầm cắt.
const joinRaw=set=>{const items=[...(set||[])];if(!items.length)return '';return items.slice(0,5).map(item=>item.length>120?`${item.slice(0,119)}…`:item).join(' | ')+(items.length>5?` (+${items.length-5} chuỗi khác)`:'');};
// Nối GL theo docs/data-tracking-report-form.md: EQM_MRO_PR.GL_ACCOUNT có thể mang tiền tố "GL"
// và phần mô tả sau dấu ":" (ví dụ "GL 53536969:Product supplies" phải khớp GL_Account "53536969").
// Chỉ bỏ tiền tố + mô tả khi chuỗi thực sự là "dãy số" + ":mô tả"; các dạng khác giữ nguyên để không đoán nhầm.
const glKey=value=>{const raw=String(value??'').trim().replace(/^GL\s*/i,'');return raw.match(/^(\d+)\s*(?::.*)?$/)?.[1]||raw.replace(/\s+/g,'').toUpperCase();};
const num=v=>{const n=Number(String(v??'').replace(/,/g,''));return Number.isFinite(n)?n:null;};
// 12/11/2026 (người dùng chốt): bản sửa Lí do trong dbo.EQM_MRO_PR_ReasonOverride (PIC nhập ở màn PR &
// Tracking) THẮNG TUYỆT ĐỐI so với PURCHASE_REQ_INFO của ERP — PIC sửa sau nghĩa là chuỗi ERP sai, dùng
// bản sửa để suy Type/Project/Model/Process. IS_IGNORED=1 ("không dùng cho Project Status") thì KHÔNG lấy
// bản sửa mà quay về chuỗi ERP: tiền của PR vẫn ở lại Report Form, chỉ là không được "cứu" bằng override.
// Dòng nào lấy bản sửa thì cột PURCHASE_REQ_INFO mang tiền tố "[Override]" để nhìn là biết Type đến từ đâu.
const truthy=value=>value===true||/^(1|true|yes)$/i.test(String(value??'').trim());
const up=value=>String(value??'').trim().toUpperCase();
// PR_SEQ trên EQM_MRO_PR là nvarchar ('000010') nhưng bản ghi override có thể được lưu từ nguồn khác
// ('10'). Khóa chính so nguyên văn; khóa phụ bỏ số 0 dẫn đầu chỉ dùng khi không có hai bản ghi nào
// cùng khóa phụ (thà không áp còn hơn đoán nhầm dòng PR).
const seqKey=value=>up(value).replace(/^0+(?=\d)/,'');
const overrideKey=(item,pr,seq)=>[up(item),up(pr),up(seq)].join('\u0000');
const looseOverrideKey=(item,pr,seq)=>[up(item),up(pr),seqKey(seq)].join('\u0000');
// 16/11/2026 (người dùng chốt): file Excel của PR/GR Report Form có thêm sheet chi tiết các dòng PR
// KHÔNG có Type (Reason trống hoặc Reason không đúng mẫu "Type - Project - Model - Process") để PIC cập
// nhật lại Reason. Một dòng PR (ITEM_CODE + PR_NO + PR_SEQ) chỉ xuất hiện một lần dù có nhiều tháng /
// nhiều GR; COST_CENTERS giữ mọi Cost Center của dòng để bộ lọc Cost Center trên màn hình áp được.
function reasonIssueList(){const map=new Map();return{add(source,cc){const item=String(source.ITEM_CODE??'').trim(),pr=String(source.PR_NO??'').trim(),seq=String(source.PR_SEQ??'').trim(),raw=String(source.raw??'');const key=[up(item),up(pr),up(seq)].join('\u0000');let entry=map.get(key);if(!entry){entry={ITEM_CODE:item,PR_NO:pr,PR_SEQ:seq,PURCHASE_REQ_INFO:raw,RECEIVER:String(source.RECEIVER_NAME??'').trim(),Issue:raw?'Reason không đúng mẫu (không đọc được Type)':'Reason trống',COST_CENTERS:[]};map.set(key,entry);}const center=String(cc??'').trim();if(!entry.COST_CENTERS.includes(center))entry.COST_CENTERS.push(center);},list(){return [...map.values()].sort((a,b)=>a.PR_NO.localeCompare(b.PR_NO,'vi',{numeric:true})||a.PR_SEQ.localeCompare(b.PR_SEQ,'vi',{numeric:true})||a.ITEM_CODE.localeCompare(b.ITEM_CODE,'vi',{numeric:true}));}};}
function reasonOverrides(rows){const exact=new Map(),loose=new Map(),all=[];for(const row of rows||[]){if(!row||typeof row!=='object')continue;const item=up(row.ITEM_CODE),pr=up(row.PR_NO),seq=up(row.PR_SEQ);if(!pr)continue;const entry={item,pr,text:String(row.PURCHASE_REQ_INFO_OVERRIDE??'').replace(/\s+/g,' ').trim(),ignored:truthy(row.IS_IGNORED),used:false};all.push(entry);if(item&&seq)exact.set(overrideKey(item,pr,seq),entry);const key=looseOverrideKey(item,pr,seq);loose.set(key,loose.has(key)?null:entry);}return {exact,loose,all};}
function pickOverride(sets,row){if(!sets.all.length)return null;const saved=sets.exact.get(overrideKey(row.ITEM_CODE,row.PR_NO,row.PR_SEQ))||sets.loose.get(looseOverrideKey(row.ITEM_CODE,row.PR_NO,row.PR_SEQ))||null;if(saved)saved.used=true;return saved;}
// Class: một GL_Account có nhiều GL_Class khác nhau thì để trống + cảnh báo (không tự chọn);
// mọi dòng không xác định được Class, sai PR_Month hoặc không quy đổi USD đều nêu trong warning
// để Data Tracking không bao giờ hiện cột Class rỗng mà không có lý do.
function reportForm(prRows,glRows,reasonRows){const classes=new Map(),ambiguous=new Set(),overrides=reasonOverrides(reasonRows);let overrideRows=0;const seenPr=new Set();for(const r of glRows||[]){const key=glKey(r.GL_Account),value=String(r.GL_Class??'').trim();if(!key||!value)continue;if(classes.has(key)&&classes.get(key)!==value)ambiguous.add(key);else classes.set(key,value);}const rates={USD:1,VND:26000,JPY:180},groups=new Map(),raws=new Map(),details=[],issues=reasonIssueList();let missingClass=0,missingMonth=0,missingAmount=0;const unknown=new Map();
 // 15/11/2026: Đối soát dữ liệu PR (song song khung GR). Chỉ đếm/cộng, không đổi công thức hay số của bảng.
 const allRows=(prRows||[]).filter(row=>row&&typeof row==='object'),eligibleRows=allRows.filter(eligiblePR),sourceByCurrency=new Map();
 const audit={sourceRows:eligibleRows.length,excludedStatusRows:allRows.length-eligibleRows.length,reportedRows:0,missingMonthRows:0,unconvertedRows:0,missingReasonRows:0,missingClassRows:0,overrideRows:0,convertedUSD:0,reportUSD:0,differenceUSD:0,sourceByCurrency:[]};
 for(const r of eligibleRows){const gl=glKey(r.GL_ACCOUNT),className=ambiguous.has(gl)?'':classes.get(gl)||'';if(!className){missingClass++;if(!unknown.has(gl))unknown.set(gl,String(r.GL_ACCOUNT??'').trim().slice(0,40)||'(GL Account trống)');}const saved=pickOverride(overrides,r);seenPr.add(up(r.PR_NO));const usedOverride=!!(saved&&!saved.ignored&&saved.text),raw=usedOverride?saved.text:String(r.PURCHASE_REQ_INFO??'').replace(/\s+/g,' ').trim(),info=parseReasonParts(raw),f={PR_NO:String(r.PR_NO??'').trim(),COST_CENTER:String(r.COST_CENTER??'').trim(),Class:className,Type:info?info.type:'',Project:info?info.project:'',Model:info?info.model:'',Process:info?info.process:''},key=JSON.stringify(dims.map(k=>f[k])),m=Number(r.PR_Month),a=num(r.PR_BUYING_AMOUNT),rate=rates[String(r.BUYING_CURRENCY??'').trim().toUpperCase()],usd=rate&&a!==null?a/rate:null;
  // 12/11/2026 (người dùng chốt): khóa ghép ITEM_CODE+PR_NO+PR_SEQ lấy ở EQM_MRO_PR_ReasonOverride TRƯỚC, phần
  // còn lại lấy ở EQM_MRO_PR. Tiền CHỈ tồn tại trên EQM_MRO_PR (bảng override không có tiền) nên MỌI dòng lên
  // báo cáo bắt buộc có Amount: dòng PR không quy đổi được tiền hoặc PR_Month ngoài 1-12 không tạo dòng rỗng
  // nữa, chỉ đếm trong warning.
  {const currency=String(r.BUYING_CURRENCY??'').trim().toUpperCase();if(a!==null&&currency){const state=sourceByCurrency.get(currency)||{currency,rows:0,amount:0};state.rows++;state.amount=Number((state.amount+a).toFixed(6));sourceByCurrency.set(currency,state);}}
  if(!info){audit.missingReasonRows++;issues.add({...r,raw},r.COST_CENTER);}
  if(!Number.isInteger(m)||m<1||m>12){missingMonth++;continue;}
  if(usd===null){missingAmount++;continue;}
  audit.reportedRows++;audit.convertedUSD=Number((audit.convertedUSD+usd).toFixed(2));
  if(raw){if(!raws.has(key))raws.set(key,new Set());raws.get(key).add(usedOverride?`[Override] ${raw}`:raw);if(usedOverride)overrideRows++;}
  if(!groups.has(key))groups.set(key,{...f,...Object.fromEntries(valueCols.map(k=>[k,''])),__detailIds:[]});
  const g=groups.get(key),monthKey=String(m),beforeMonth=Number(g[monthKey])||0,beforeAmount=Number(g.Amount)||0;
  g[monthKey]=Number((beforeMonth+usd).toFixed(2));g.Amount=Number((beforeAmount+usd).toFixed(2));
  // Hai delta dưới đây dùng chính phép làm tròn hiện hành của Report Form. Popup chọn cột tháng dùng
  // MonthAmountUSD; Amount cả năm dùng AmountUSD, nhờ đó footer khớp tuyệt đối với ô đã bấm mà không
  // thay đổi công thức hay số tiền của bảng cha.
  const detailId=String(details.length+1),monthAmount=Number((g[monthKey]-beforeMonth).toFixed(2)),amountUSD=Number((g.Amount-beforeAmount).toFixed(2));
  details.push({id:detailId,Receiver:String(r.RECEIVER_NAME??'').trim(),PR_no:String(r.PR_NO??'').trim(),COST_CENTER:String(r.COST_CENTER??'').trim(),PO_no:String(r.PO_NO??'').trim(),PR_Amount:amountUSD,Purchase_req_infor:raw,PR_Month:m,MonthAmountUSD:monthAmount,AmountUSD:amountUSD,PR_SEQ:String(r.PR_SEQ??'').trim(),ITEM_CODE:String(r.ITEM_CODE??'').trim(),lineKey:[up(r.ITEM_CODE),up(r.PR_NO),up(r.PR_SEQ),String(m)].join('\u0000')});
  g.__detailIds.push(detailId);
 }for(const [key,group] of groups){
    const set=raws.get(key)||new Set();group[rawColumn]=joinRaw(set);

  }const notices=[];if(!classes.size)notices.push('Bảng GL Account không trả dòng GL_Account/GL_Class hợp lệ nào nên không xác định được Class');else if(missingClass)notices.push(`${missingClass} dòng chưa xác định được Class từ GL Account (chưa có trong bảng GL: ${[...unknown.values()].slice(0,5).join(', ')})`);if(ambiguous.size)notices.push(`${ambiguous.size} GL Account có nhiều GL_Class khác nhau nên Class để trống`);if(missingMonth)notices.push(`${missingMonth} dòng có PR_Month ngoài 1–12 hoặc để trống`);if(missingAmount)notices.push(`${missingAmount} dòng chưa quy đổi được Amount sang USD`);if(overrideRows)notices.push(`${overrideRows} dòng lấy Lí do từ bảng sửa EQM_MRO_PR_ReasonOverride (ưu tiên hơn chuỗi ERP trên PR)`);
  // Chẩn đoán ghép khóa: PIC đã nhập Lí do mà báo cáo không đổi thì phải nói rõ vì sao (PR không có
  // trong năm đang xem / bị loại vì Trạng thái PR, hay lệch ITEM_CODE + PR_SEQ so với dòng PR).
  if(overrides.all.length){const unused=overrides.all.filter(entry=>!entry.used&&!entry.ignored&&entry.text),orphan=[...new Set(unused.filter(entry=>!seenPr.has(entry.pr)).map(entry=>entry.pr))],mismatch=[...new Set(unused.filter(entry=>seenPr.has(entry.pr)).map(entry=>entry.pr))];notices.push(`Đã nạp ${overrides.all.length} bản ghi Lí do từ EQM_MRO_PR_ReasonOverride${orphan.length?`; ${orphan.length} PR đã nhập Lí do nhưng không có dòng tiền nào trong năm đang xem (PR ${orphan.slice(0,5).join(', ')})`:''}${mismatch.length?`; ${mismatch.length} PR lệch ITEM_CODE/PR_SEQ so với dòng PR (PR ${mismatch.slice(0,5).join(', ')})`:''}`);}const reportRows=[...groups.values()];Object.assign(audit,{missingMonthRows:missingMonth,unconvertedRows:missingAmount,missingClassRows:missingClass,overrideRows,reportUSD:Number(reportRows.reduce((sum,row)=>sum+(typeof row.Amount==='number'?row.Amount:0),0).toFixed(2)),sourceByCurrency:[...sourceByCurrency.values()].sort((x,y)=>x.currency.localeCompare(y.currency))});audit.differenceUSD=Number((audit.convertedUSD-audit.reportUSD).toFixed(2));
  return{sheet:{name:'REPORT',columns:cols.map(name=>({name,type:numericCols.has(name)?'decimal':'nvarchar',numeric:numericCols.has(name)})),rows:reportRows},details,reasonIssues:issues.list(),audit,warning:notices.join('; ')||null};}

// GR Report Form: mỗi dòng nguồn GMRO được xử lý đúng một lần. Không JOIN SQL trực tiếp để tránh
// nhân bản tiền khi một PO có nhiều dòng PR; việc phân giải ứng viên được thực hiện ở đây.
const grDims=['PR_NO','COST_CENTER','Class','Type','Thiếu Type','Project','Model','Process','Reason Source','Match Status'];
const grCols=[...grDims,...valueCols,rawColumn];
const rates={USD:1,VND:26000,JPY:180};
const joinText=value=>String(value??'').trim().replace(/\s+/g,' ').toUpperCase();
const joinKey=(po,seq,item,loose=false)=>[joinText(po),loose?seqKey(seq):joinText(seq),joinText(item)].join('\u0000');
const prIdentity=row=>[joinText(row.ITEM_CODE),joinText(row.PR_NO),joinText(row.PR_SEQ)].join('\u0000');
const strictNumber=value=>{if(typeof value==='number')return Number.isFinite(value)?value:null;if(typeof value!=='string')return null;let raw=value.trim(),negative=false;if(!raw)return null;if(/^\(.*\)$/.test(raw)){negative=true;raw=raw.slice(1,-1).trim();}raw=raw.replace(/[\u00a0\u202f]/g,' ');if(/^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$/.test(raw))raw=raw.replace(/,/g,'');if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(raw))return null;const parsed=Number(raw)*(negative?-1:1);return Number.isFinite(parsed)?parsed:null;};
function classIndex(rows){const classes=new Map(),ambiguous=new Set();for(const row of rows||[]){const key=glKey(row.GL_Account),value=String(row.GL_Class??'').trim();if(!key||!value)continue;if(classes.has(key)&&classes.get(key)!==value)ambiguous.add(key);else classes.set(key,value);}return{classes,ambiguous};}
function candidateIndex(rows){const exact=new Map(),loose=new Map();const add=(map,key,row)=>{if(!key.split('\u0000')[0]||!key.split('\u0000')[2])return;let values=map.get(key);if(!values){values=new Map();map.set(key,values);}const identity=prIdentity(row);if(identity&&!values.has(identity))values.set(identity,row);};for(const row of rows||[]){if(!row||typeof row!=='object')continue;add(exact,joinKey(row.PO_NO,row.PO_SEQ,row.ITEM_CODE),row);add(loose,joinKey(row.PO_NO,row.PO_SEQ,row.ITEM_CODE,true),row);}return{exact,loose};}
function matchPR(index,row){const exact=[...(index.exact.get(joinKey(row.PO_NO,row.PO_SEQ,row.ITEM_CODE))?.values()||[])];if(exact.length===1)return{status:'Matched',row:exact[0]};if(exact.length>1)return{status:'Ambiguous Match',row:null};const loose=[...(index.loose.get(joinKey(row.PO_NO,row.PO_SEQ,row.ITEM_CODE,true))?.values()||[])];if(loose.length===1)return{status:'Matched',row:loose[0]};if(loose.length>1)return{status:'Ambiguous Match',row:null};return{status:'Unmatched PR',row:null};}
function grReportForm(grRows,prRows,glRows,reasonRows){
 const {classes,ambiguous:ambiguousGL}=classIndex(glRows),candidates=candidateIndex(prRows),overrides=reasonOverrides(reasonRows);
 const groups=new Map(),raws=new Map(),details=[],sourceByCurrency=new Map(),issues=reasonIssueList();
 const audit={sourceRows:0,matchedRows:0,unmatchedRows:0,ambiguousRows:0,missingReasonRows:0,missingClassRows:0,unconvertedRows:0,convertedUSD:0,reportUSD:0,differenceUSD:0,sourceByCurrency:[]};
 for(const [index,gr] of (grRows||[]).entries()){
  if(!gr||typeof gr!=='object')continue;audit.sourceRows++;
  const match=matchPR(candidates,gr),pr=match.row;
  if(match.status==='Matched')audit.matchedRows++;else if(match.status==='Ambiguous Match')audit.ambiguousRows++;else audit.unmatchedRows++;
  const saved=pr?pickOverride(overrides,pr):null,usedOverride=!!(saved&&!saved.ignored&&saved.text);
  const raw=pr?(usedOverride?saved.text:String(pr.PURCHASE_REQ_INFO??'').replace(/\s+/g,' ').trim()):'';
  const info=parseReasonParts(raw),reasonSource=match.status==='Ambiguous Match'?'Ambiguous':!pr?'Missing':usedOverride?'Override':raw?'ERP':'Missing';
  const gl=pr?glKey(pr.GL_ACCOUNT):'',className=pr&&!ambiguousGL.has(gl)?classes.get(gl)||'':'';
  // Chỉ dòng GR đã ghép đúng một dòng PR mới vào sheet lỗi Reason: GR không tìm thấy / ghép nhiều PR thì không có
  // PR_NO + PR_SEQ để sửa Reason (đã đếm riêng ở Unmatched PR / Ambiguous Match).
  if(!info)audit.missingReasonRows++;if(!info&&pr)issues.add({...pr,raw},gr.COST_CENTER_CODE);if(pr&&!className)audit.missingClassRows++;
  const missingType=info?'':raw?'Thiếu: Reason không đúng mẫu':'Thiếu: Reason trống';
  const fields={PR_NO:pr?String(pr.PR_NO??'').trim():'',COST_CENTER:String(gr.COST_CENTER_CODE??'').trim(),Class:className,Type:info?.type||'','Thiếu Type':missingType,Project:info?.project||'',Model:info?.model||'',Process:info?.process||'','Reason Source':reasonSource,'Match Status':match.status};
  const key=JSON.stringify(grDims.map(name=>fields[name])),date=String(gr.GR_DATE??'').trim(),dateMatch=date.match(/^(\d{4})-(\d{2})-(\d{2})/),month=dateMatch?Number(dateMatch[2]):null;
  const currency=String(gr.CURRENCY??'').trim().toUpperCase(),amount=strictNumber(gr.GR_AMOUNT),rate=rates[currency],usd=amount!==null&&rate?Number((amount/rate).toFixed(2)):null;
  if(amount!==null&&currency){const state=sourceByCurrency.get(currency)||{currency,rows:0,amount:0};state.rows++;state.amount=Number((state.amount+amount).toFixed(6));sourceByCurrency.set(currency,state);}
  if(usd===null)audit.unconvertedRows++;else audit.convertedUSD=Number((audit.convertedUSD+usd).toFixed(2));
  const detailId=String(index+1);details.push({id:detailId,GR_NO:String(gr.GR_NO??'').trim(),COST_CENTER:String(gr.COST_CENTER_CODE??'').trim(),GR_DATE:date,PO_NO:String(gr.PO_NO??'').trim(),PO_SEQ:String(gr.PO_SEQ??'').trim(),PR_NO:pr?String(pr.PR_NO??'').trim():'',PR_SEQ:pr?String(pr.PR_SEQ??'').trim():'',ITEM_CODE:String(gr.ITEM_CODE??'').trim(),GR_QTY:gr.GR_QTY??'',GR_AMOUNT:gr.GR_AMOUNT??'',CURRENCY:currency,PURCHASE_REQ_INFO:raw,'Reason Source':reasonSource,'Match Status':match.status,'Amount USD':usd});
  if(!groups.has(key))groups.set(key,{...fields,...Object.fromEntries(valueCols.map(name=>[name,''])),[rawColumn]:'',__detailIds:[],__unconverted:false});
  const group=groups.get(key);group.__detailIds.push(detailId);if(usd===null)group.__unconverted=true;if(raw){if(!raws.has(key))raws.set(key,new Set());raws.get(key).add(usedOverride?`[Override] ${raw}`:raw);}
  if(usd!==null&&Number.isInteger(month)&&month>=1&&month<=12){group[String(month)]=Number(((Number(group[String(month)])||0)+usd).toFixed(2));group.Amount=Number(((Number(group.Amount)||0)+usd).toFixed(2));}
 }
 for(const [key,group] of groups)group[rawColumn]=joinRaw(raws.get(key)||new Set());
 const rows=[...groups.values()];audit.reportUSD=Number(rows.reduce((sum,row)=>sum+(typeof row.Amount==='number'?row.Amount:0),0).toFixed(2));audit.differenceUSD=Number((audit.convertedUSD-audit.reportUSD).toFixed(2));audit.sourceByCurrency=[...sourceByCurrency.values()].sort((a,b)=>a.currency.localeCompare(b.currency));
 const notices=[];if(audit.unmatchedRows)notices.push(`${audit.unmatchedRows} dòng GR không tìm thấy PR`);if(audit.ambiguousRows)notices.push(`${audit.ambiguousRows} dòng GR ghép nhiều PR chưa phân giải`);if(audit.missingReasonRows)notices.push(`${audit.missingReasonRows} dòng thiếu hoặc không hợp lệ Reason`);if(audit.missingClassRows)notices.push(`${audit.missingClassRows} dòng thiếu GL Class`);if(audit.unconvertedRows)notices.push(`${audit.unconvertedRows} dòng chưa quy đổi được USD`);if(ambiguousGL.size)notices.push(`${ambiguousGL.size} GL Account có nhiều GL_Class khác nhau`);
 return{sheet:{name:'GR_REPORT',columns:grCols.map(name=>({name,type:numericCols.has(name)?'decimal':'nvarchar',numeric:numericCols.has(name)})),rows},details,reasonIssues:issues.list(),audit,warning:notices.join('; ')||null};
}
function createDataTracking({sql}){const cache=new Map(),pending=new Map(),reportKinds=new Set(['REPORT','GR_REPORT']);return{async handle({req,res,url,send}){if(url.pathname!=='/api/data-tracking')return false;if(req.method!=='GET')throw Object.assign(Error('Chỉ hỗ trợ đọc dữ liệu.'),{status:405});const kind=url.searchParams.get('table'),year=Number(url.searchParams.get('year'));if(!['REPORT','GR_REPORT','PR','RFQ','GMRO'].includes(kind))throw Object.assign(Error('Bảng dữ liệu không hợp lệ.'),{status:400});if(reportKinds.has(kind)&&(!Number.isInteger(year)||year<2000||year>2100))throw Object.assign(Error('Năm báo cáo không hợp lệ.'),{status:400});const key=reportKinds.has(kind)?`${kind}:${year}`:kind;const load=async()=>{if(pending.has(key))return pending.get(key);const task=(async()=>{let result;if(kind==='REPORT'){const x=await sql.readReportForm(year);result=reportForm(x.pr,x.gl,x.reason);}else if(kind==='GR_REPORT'){const x=await sql.readGRReport(year);result=grReportForm(x.gr,x.pr,x.gl,x.reason);}else{const sheet=normalizeSheets(await sql.downloadData(kind),kind)[0];if(kind==='PR')sheet.rows=sheet.rows.filter(eligiblePR);result={sheet,warning:null};}const value={...result,updatedAt:new Date().toISOString(),source:'sql'};cache.set(key,value);return value;})();pending.set(key,task);try{return await task;}finally{pending.delete(key);}};send(res,200,cache.has(key)&&url.searchParams.get('reload')!=='1'?cache.get(key):await load());return true;}};}
module.exports={createDataTracking,reportForm,grReportForm};
