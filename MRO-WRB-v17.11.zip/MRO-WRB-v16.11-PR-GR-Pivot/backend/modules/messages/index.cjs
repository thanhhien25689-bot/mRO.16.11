// Trung tâm tin nhắn: dựng cảnh báo KPI từ ba nguồn public — màn PR & PR Tracking (tracking.live), màn Code & code issue (codes.live) và tab Repair & Service (aps.snapshot) — rồi gửi vào phòng Knox Teams qua APIBOT.
const fs=require('node:fs'),path=require('node:path');
const fail=(status,message)=>Object.assign(new Error(message),{status});
// Nguyên nhân thật của lỗi fetch/SQL (Node bọc trong error.cause) để báo cho người dùng thay vì "Kiểm tra máy chủ".
const errorCause=error=>String((error&&error.cause&&error.cause.code)||(error&&error.code)||(error&&error.message)||(error&&error.name)||'khong ro nguyen nhan').slice(0,80);
// Địa chỉ Node thực sự gọi (cause.address:cause.port) — phân biệt 127.0.0.1 và ::1 khi URL dùng "localhost".
const errorTarget=error=>{const cause=error&&error.cause;return cause&&cause.address?String(`${cause.address}${cause.port?`:${cause.port}`:''}`).slice(0,60):'';};
// Gợi ý ngắn theo mã lỗi; muốn biết sâu chạy CLI chẩn đoán trên máy chủ Portal.
const statusHint=code=>code==='ECONNREFUSED'?'Chưa có gì đang nghe tại địa chỉ này TÍNH TỪ MÁY CHỦ PORTAL. Chạy start.bat trong thư mục KnoxChatbox ngay trên máy chủ Portal (Knox Local Messenger phải mở, đúng port đã lưu), hoặc chạy npm run knox:check để in nguyên nhân thật.':(code==='ENOTFOUND'||code==='EAI_AGAIN')?'Không phân giải được tên máy trong URL — nhập IP thay tên.':(code==='ETIMEDOUT'||code==='UND_ERR_CONNECT_TIMEOUT'||code==='TimeoutError')?'Máy trong URL không trả lời sau 3 giây — kiểm tra IP và tường lửa.':'Chạy npm run knox:check trên máy chủ Portal để in nguyên nhân thật.';
// /health của Knox Local Messenger luôn trả HTTP 200, kèm ok:false khi server sống nhưng CDP chưa điều khiển được cửa sổ Knox Teams.
// Portal phải nói rõ hai trạng thái này, không gộp thành "APIBOT trả về HTTP 200" như trước.
const knoxHealthHint=info=>{const data=info||{};const cdp=data.cdp_port?String(data.cdp_port).slice(0,10):'';
 if(data.knox_exe_found===false)return `Knox Local Messenger đã chạy nhưng không tìm thấy KnoxTeams.exe tại ${String(data.knox_exe||'(để trống)').slice(0,180)}. Sửa KNOX_TEAMS_EXE trong file .env của thư mục KnoxChatbox rồi chạy lại start.bat.`;
 return `Knox Local Messenger đã chạy nhưng chưa kết nối được cửa sổ Knox Teams qua cổng CDP${cdp?` ${cdp}`:''}. Mở Knox Teams (đã đăng nhập) rồi chạy start-knox-cdp.bat, hoặc chạy start.bat trong thư mục KnoxChatbox; Knox Local Messenger chỉ gửi được khi cửa sổ Knox Teams đang mở trên máy này.`;};
// Bản xử lý tin nhắn: UI hiển thị revision để nhận ra portal đã nạp code mới hay chưa (chưa thấy revision = chưa khởi động lại server).
const MODULE_REVISION='msg-2026-11-06c';
// Giới hạn thời gian đọc nguồn Tracking, đặt dưới requestTimeout 30s của server, để lỗi luôn kèm nguyên nhân thay vì bị cắt socket.
const withDeadline=(promise,ms,label)=>{const settled=Promise.resolve(promise);settled.catch(()=>{});let timer;const guard=new Promise((_,reject)=>{timer=setTimeout(()=>reject(fail(504,`hết thời gian chờ ${Math.round(ms/1000)} giây khi đọc ${label}`)),ms);});return Promise.race([settled,guard]).finally(()=>clearTimeout(timer));};
// Bảy thẻ KPI lấy đúng công thức bảy thẻ màn PR & PR Tracking (frontend/modules/tracking/view.mjs cards() + selectors.mjs confirmForOrder),
// tính trên payload trackingSQL y hệt GET /api/tracking-live: status từ prState, Confirm for order = Hành động Ready for PR và chưa có PR No.
const TRACKING_STATES=[['waiting_pr','Chờ Cập nhật PR'],['pr_updated','Đã cập nhật PR'],['po_created','Đã có PO'],['shipping','Đang giao'],['received','Đã nhận đủ']];
const KPI_CARDS=[
 {key:'rows_total',label:'Tổng số dòng',unit:'dòng'},
 {key:'waiting_pr',label:'Chờ Cập nhật PR',unit:'dòng'},
 {key:'pr_updated',label:'Đã cập nhật PR',unit:'dòng'},
 {key:'po_created',label:'Đã có PO',unit:'dòng'},
 {key:'shipping',label:'Đang giao',unit:'dòng'},
 {key:'received',label:'Đã nhận đủ',unit:'dòng'},
 {key:'confirm_order',label:'Confirm for order',unit:'dòng'},
 // Sáu thẻ màn Code & code issue (06/11/2026): cùng công thức thẻ/tab của frontend/modules/codes (view.mjs renderSqlCodes +
 // selectors.mjs statusTest/actionReady), đếm trên payload codesSQL y hệt GET /api/codes-live: Trạng thái + Hành động.
 {key:'codes_total',label:'Codes · Tổng yêu cầu',unit:'dòng',section:'codes'},
 {key:'codes_need',label:'Codes · Cần xử lý',unit:'dòng',section:'codes'},
 {key:'codes_processing',label:'Codes · Đang xử lý',unit:'dòng',section:'codes'},
 {key:'codes_late',label:'Codes · Quá hạn',unit:'dòng',section:'codes'},
 {key:'codes_ready',label:'Codes · Ready for PR',unit:'dòng',section:'codes'},
 {key:'codes_confirm',label:'Codes · Confirm for order',unit:'dòng',section:'codes'},
 // Mười thẻ tab Repair & Service (06/11/2026): sáu nhóm panel Pending Repair + bốn nhóm panel Pending Service,
 // đếm trên payload aps.snapshot() theo đúng isPending() của aps-app/app.mjs (bỏ dòng Completed/Cancel, Repair chỉ tính ở bước mở sớm nhất).
 {key:'repair_rfq',label:'Repair · Chưa gửi RFQ',unit:'request',section:'repair'},
 {key:'repair_accept',label:'Repair · Pur chưa accept',unit:'request',section:'repair'},
 {key:'repair_price',label:'Repair · Pur chưa confirm Price',unit:'request',section:'repair'},
 {key:'repair_po',label:'Repair · Chờ tạo PO',unit:'request',section:'repair'},
 {key:'repair_ibm',label:'Repair · Chờ IBM',unit:'request',section:'repair'},
 {key:'repair_unpaid',label:'Repair · Chờ thanh toán',unit:'request',section:'repair'},
 {key:'service_before_app',label:'Service · Pending Before App',unit:'request',section:'service'},
 {key:'service_contract',label:'Service · Pending Contract',unit:'request',section:'service'},
 {key:'service_sign',label:'Service · Pending Sign Contract',unit:'request',section:'service'},
 {key:'service_payment',label:'Service · Chờ thanh toán',unit:'request',section:'service'}
];
const DEFAULT_CARDS=['confirm_order','waiting_pr','shipping'];
const DEFAULT_APIBOT='http://127.0.0.1:2292';
// Phòng Knox Teams mặc định (ID chatroom do anh chỉ định). Chỉ dùng khi chưa lưu phòng nào; gửi vẫn qua trường roomchat như mọi phòng khác.
const DEFAULT_ROOMS=['116968871796146176'];
// hasPRNo/confirmForOrder mô phỏng đúng frontend/modules/tracking/selectors.mjs; PR No xét cả row.prNo lẫn row.pr.PR_NO.
const hasPRNo=row=>!!(String(row?.prNo||'').trim()||String(row?.pr&&row.pr.PR_NO||'').trim());
const confirmForOrder=row=>row?.codeAction==='Ready for PR'&&!hasPRNo(row);
function kpiValues(data){
 const rows=Array.isArray(data.trackingSQL)?data.trackingSQL:[];
 const statusOf=row=>String(row?.status||'').trim();
 return {rows_total:rows.length,...Object.fromEntries(TRACKING_STATES.map(([key,status])=>[key,rows.filter(row=>statusOf(row)===status).length])),confirm_order:rows.filter(confirmForOrder).length};
}
// codesKpiValues mô phỏng đúng thẻ/tab màn Code & code issue (frontend/modules/codes/selectors.mjs statusTest/actionReady):
 // Cần xử lý/Đang xử lý/Quá hạn bỏ dòng Hành động = Ready for PR; Đang xử lý nhận thêm dòng Trạng thái Ready for PR chưa xác nhận;
 // Ready for PR cần cả Trạng thái lẫn Hành động; Confirm for order đếm theo Hành động.
 const codesReady=row=>row&&row.action==='Ready for PR';
 function codesKpiValues(data){
  const rows=Array.isArray(data.codesSQL)?data.codesSQL:[];
  const statusOf=row=>String(row&&row.status||'').trim();
  return {codes_total:rows.length,
   codes_need:rows.filter(row=>statusOf(row)==='Cần xử lý'&&!codesReady(row)).length,
   codes_processing:rows.filter(row=>(statusOf(row)==='Đang xử lý'||statusOf(row)==='Ready for PR')&&!codesReady(row)).length,
   codes_late:rows.filter(row=>statusOf(row)==='Quá hạn'&&!codesReady(row)).length,
   codes_ready:rows.filter(row=>statusOf(row)==='Ready for PR'&&codesReady(row)).length,
   codes_confirm:rows.filter(row=>codesReady(row)).length};
 }
 // apsKpiValues mô phỏng đúng isPending() của aps-app/app.mjs nên sáu thẻ Repair / bốn thẻ Service trùng số
 // với panel Pending Repair / Pending Service: bỏ dòng Completed/Cancel; mỗi Request Repair chỉ đếm ở bước mở sớm nhất
 // (dòng Rejected/qty=0 loại khỏi bước); Chờ thanh toán đếm mọi Request chưa Completed/Cancel;
 // Service đếm theo bước Before App → Contract → Sign và Chờ thanh toán đếm mọi Request chưa trả.
 const REPAIR_STEPS=['chua-gui-rfq','pur-chua-accept','pur-chua-confirm-price','cho-tao-po','cho-ibm'];
 const stepOf=line=>!line.wrb?'chua-gui-rfq':!line.accept?'pur-chua-accept':!line.priceDate?'pur-chua-confirm-price':!line.poNo?'cho-tao-po':'cho-ibm';
 function apsKpiValues(aps){
  const rows=Array.isArray(aps.requests)?aps.requests:[];
  const rejectedLine=line=>Boolean(line&&line.rejectDate)||Number(line&&line.qty)===0;
  const values={repair_rfq:0,repair_accept:0,repair_price:0,repair_po:0,repair_ibm:0,repair_unpaid:0,service_before_app:0,service_contract:0,service_sign:0,service_payment:0};
  for(const row of rows){
   if(row&&(row.payment==='Completed'||row.payment==='Cancel'))continue;
   if(row&&row.type==='Repair'){
    const lines=(Array.isArray(row.lines)?row.lines:[]).filter(line=>!rejectedLine(line));
    if(lines.length){
     const active=lines.filter(line=>String(line.wrb||'').trim());
     const current=REPAIR_STEPS.find(step=>(active.length?active:lines).some(line=>stepOf(line)===step));
     if(current==='chua-gui-rfq')values.repair_rfq++;else if(current==='pur-chua-accept')values.repair_accept++;else if(current==='pur-chua-confirm-price')values.repair_price++;else if(current==='cho-tao-po')values.repair_po++;else if(current==='cho-ibm')values.repair_ibm++;
    }
    values.repair_unpaid++;
   }else if(row&&row.type==='Service'){
    const contract=row.contract||{};
    if(!contract.beforeApproval)values.service_before_app++;else if(!contract.created)values.service_contract++;else if(!contract.signed)values.service_sign++;
    values.service_payment++;
   }
  }
  return values;
 }
 function composeText(config,payload){
  const selected=KPI_CARDS.filter(card=>(config.cards||[]).includes(card.key));
  if(!selected.length)throw fail(400,'Hãy chọn ít nhất một thẻ KPI để cảnh báo.');
  const date=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Ho_Chi_Minh',day:'2-digit',month:'2-digit',year:'numeric'}).format(new Date());
  const blocks=[];
  const trackingCards=selected.filter(card=>!card.section||card.section==='tracking');
  if(trackingCards.length){
   const data=payload&&payload.tracking;
   if(!data||!Array.isArray(data.trackingSQL))throw fail(400,'Chưa đọc được dữ liệu Tracking để soạn cảnh báo. Hãy thử Tải lại dữ liệu rồi gửi lại.');
   // Số liệu rỗng từ nguồn lỗi không được gửi như KPI thật (quy tắc Download Center): chỉ chấp nhận nguồn SQL hoặc cache SQL thật.
   if(!['sql','sql-cache'].includes(String(data.trackingSource||'')))throw fail(503,'Nguồn Tracking chưa đọc được từ SQL; không gửi tin với số liệu rỗng.');
   const values=kpiValues(data);
   blocks.push([`CANH BAO PR & TRACKING MRO (${date})`,...trackingCards.map(card=>`- ${card.label}: ${values[card.key]} ${card.unit}`)]);
  }
  const codesCards=selected.filter(card=>card.section==='codes');
  if(codesCards.length){
   const data=payload&&payload.codes;
   if(!data||!Array.isArray(data.codesSQL))throw fail(400,'Chưa đọc được dữ liệu Code & code issue để soạn cảnh báo. Hãy thử Tải lại dữ liệu rồi gửi lại.');
   if(!['sql','sql-cache'].includes(String(data.codesSource||'')))throw fail(503,'Nguồn Codes chưa đọc được từ SQL; không gửi tin với số liệu rỗng.');
   const values=codesKpiValues(data);
   blocks.push([`CANH BAO CODE & CODE ISSUE MRO (${date})`,...codesCards.map(card=>`- ${card.label}: ${values[card.key]} ${card.unit}`)]);
  }
  const apsCards=selected.filter(card=>card.section==='repair'||card.section==='service');
  if(apsCards.length){
   const aps=payload&&payload.aps;
   if(!aps||!Array.isArray(aps.requests))throw fail(400,'Chưa đọc được dữ liệu Repair & Service để soạn cảnh báo. Hãy thử Tải lại dữ liệu rồi gửi lại.');
   // Snapshot APS không ném lỗi mà trả connected=false + warning khi SQLite đọc không được — cũng không được gửi số 0 như số thật.
   if(aps.connected===false)throw fail(503,'Không đọc được dữ liệu Repair & Service từ portal APS; không gửi tin với số liệu rỗng.');
   const values=apsKpiValues(aps);
   blocks.push([`CANH BAO REPAIR & SERVICE MRO (${date})`,...apsCards.map(card=>`- ${card.label}: ${values[card.key]} ${card.unit}`)]);
  }
  const lines=blocks.map((block,index)=>index?['',...block]:block).flat();
  const note=String(config.note||'').trim();
  if(note)lines.push('',note);
  lines.push('','Gui tu Portal MRO WRB.');
  return lines.join('\n');
 }
// Lịch gửi tự động (06/11/2026): frequency 'daily' mỗi ngày, 'weekly' nhiều thứ trong tuần (days 0=Chủ nhật..6=Thứ bảy),
// 'monthly' một ngày dương lịch; monthDay lớn hơn số ngày của tháng ngắn (VD 31 gặp tháng 2) thì gửi vào ngày cuối tháng.
const SCHEDULE_FREQUENCIES=['daily','weekly','monthly'];
function scheduleFields(value){
 const frequency=SCHEDULE_FREQUENCIES.includes(String(value&&value.frequency))?String(value.frequency):'weekly';
 const days=Array.isArray(value&&value.days)?[...new Set(value.days.map(Number).filter(day=>Number.isInteger(day)&&day>=0&&day<=6))].sort((a,b)=>a-b):[];
 const weekday=Number.isInteger(value&&value.weekday)?value.weekday:2;
 const monthDay=Math.min(31,Math.max(1,Math.trunc(Number(value&&value.monthDay)||1)));
 return {frequency,days:days.length?days:[weekday],monthDay};
}
function scheduleDue(config,slot){const {frequency,days,monthDay}=scheduleFields(config);if(frequency==='daily')return true;if(frequency==='monthly')return slot.dayNumber===Math.min(monthDay,slot.lastDay);return days.includes(slot.weekday);}
function createMessages({runtime,getTracking=async()=>null,getCodes=async()=>null,getAps=async()=>null,request=fetch,autoStartScheduler=true,dashboardTimeoutMs=25000}={}){
 const file=path.join(runtime,'messages','settings.json'),outboxFile=path.join(runtime,'messages','outbox.json');
 const defaults=()=>({apibotUrl:DEFAULT_APIBOT,rooms:[...DEFAULT_ROOMS],cards:[...DEFAULT_CARDS],note:'',weekday:2,frequency:'weekly',days:[2],monthDay:1,time:'08:00',afternoon:'',enabled:false,revision:1});
 const read=()=>{try{const value=JSON.parse(fs.readFileSync(file,'utf8'));if(!value||typeof value!=='object')return null;const rooms=Array.isArray(value.rooms)?value.rooms.map(room=>String(room||'').trim()).filter(Boolean):[];const savedCards=Array.isArray(value.cards)?value.cards.filter(key=>KPI_CARDS.some(card=>card.key===key)):[];return {...value,cards:savedCards.length?savedCards:[...DEFAULT_CARDS],rooms:rooms.length?rooms:[...DEFAULT_ROOMS]};}catch{return null;}};
 const write=value=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file+'.tmp',JSON.stringify(value,null,2),{mode:0o600});fs.renameSync(file+'.tmp',file);};
 const readOutbox=()=>{try{const value=JSON.parse(fs.readFileSync(outboxFile,'utf8'));return value&&Array.isArray(value.entries)?{lastSlot:typeof value.lastSlot==='string'?value.lastSlot:null,entries:value.entries}:{lastSlot:null,entries:[]};}catch{return{lastSlot:null,entries:[]};}};
 const writeOutbox=value=>{fs.mkdirSync(path.dirname(outboxFile),{recursive:true});fs.writeFileSync(outboxFile+'.tmp',JSON.stringify(value,null,2),{mode:0o600});fs.renameSync(outboxFile+'.tmp',outboxFile);};
 const record=(event,slot)=>{try{const outbox=readOutbox();if(slot!==undefined)outbox.lastSlot=slot;outbox.entries=[...outbox.entries,{at:new Date().toISOString(),...event}].slice(-200);writeOutbox(outbox);}catch{}};
 const normalizeUrl=value=>{const raw=String(value||DEFAULT_APIBOT).trim().replace(/\/+$/,'');let url;try{url=new URL(raw);}catch{throw fail(400,'URL APIBOT không hợp lệ.');}if(!['http:','https:'].includes(url.protocol)||url.pathname!=='/')throw fail(400,'URL APIBOT phải có dạng http://may:2292.');return url.origin;};
 const normalizeRooms=value=>{const list=Array.isArray(value)?value:String(value||'').split(/[;\n]/);const rooms=[...new Set(list.map(room=>String(room||'').trim()).filter(Boolean))];if(!rooms.length||rooms.length>10)throw fail(400,'Khai báo từ 1 đến 10 phòng Knox Teams.');return rooms;};
 const normalizeTime=(value,label='Giờ gửi tự động phải có dạng HH:MM.')=>{const match=/^([01]?\d|2[0-3]):([0-5]\d)$/.exec(String(value||'').trim());if(!match)throw fail(400,label);return `${String(Number(match[1])).padStart(2,'0')}:${match[2]}`;};
 const normalizeOptionalTime=value=>{const raw=String(value??'').trim();return raw?normalizeTime(raw,'Giờ gửi buổi chiều phải có dạng HH:MM; để trống nếu không gửi buổi chiều.'):'';};
 const publicConfig=value=>({...value,...scheduleFields(value),cardCatalog:KPI_CARDS.map(({key,label,unit,section})=>({key,label,unit,section:section||'tracking'}))});
 const save=input=>{
  if(!input||typeof input!=='object')throw fail(400,'Dữ liệu cấu hình không hợp lệ.');
  const current=read()||null;
  if(current&&input.revision!==undefined&&Number(input.revision)!==Number(current.revision))throw fail(409,'Cấu hình đã được thay đổi ở nơi khác. Hãy tải lại trang.');
  const cards=Array.isArray(input.cards)?[...new Set(input.cards.map(String))].filter(key=>KPI_CARDS.some(card=>card.key===key)):[];
  if(!cards.length)throw fail(400,'Hãy chọn ít nhất một thẻ KPI để cảnh báo.');
  const frequency=SCHEDULE_FREQUENCIES.includes(String(input.frequency||''))?String(input.frequency):'weekly';
  const days=[...new Set((Array.isArray(input.days)?input.days:(Number.isInteger(input.weekday)?[input.weekday]:[])).map(Number).filter(day=>Number.isInteger(day)&&day>=0&&day<=6))].sort((a,b)=>a-b);
  if(frequency==='weekly'&&!days.length)throw fail(400,'Chọn ít nhất một thứ trong tuần để gửi tự động.');
  const monthDay=Math.trunc(Number(input.monthDay)||1);
  if(frequency==='monthly'&&(monthDay<1||monthDay>31))throw fail(400,'Ngày gửi hàng tháng phải từ 1 đến 31 (dương lịch).');
  const value={apibotUrl:normalizeUrl(input.apibotUrl),rooms:normalizeRooms(input.rooms),cards,note:String(input.note||'').trim().slice(0,500),weekday:days.length?days[0]:2,frequency,days,monthDay:Math.min(31,Math.max(1,monthDay)),time:normalizeTime(input.time),afternoon:normalizeOptionalTime(input.afternoon),enabled:!!input.enabled,revision:(current?Number(current.revision)||1:1)+1};
  write(value);return publicConfig(value);
 };
 async function buildMessage(override={}){
  const current=read()||defaults();
  const config={...current,...(override&&typeof override==='object'?override:{})};
  if(Array.isArray(override?.cards)&&override.cards.length)config.cards=[...new Set(override.cards.map(String))].filter(key=>KPI_CARDS.some(card=>card.key===key));
  if(override?.rooms!==undefined&&String(override.rooms??'').trim())config.rooms=normalizeRooms(override.rooms);
  // Mỗi nhóm thẻ chỉ đọc đúng nguồn public của màn đó: PR & Tracking → tracking.live(), Codes → codes.live(), Repair/Service → aps.snapshot().
  const selected=KPI_CARDS.filter(card=>(config.cards||[]).includes(card.key));
  if(!selected.length)throw fail(400,'Hãy chọn ít nhất một thẻ KPI để cảnh báo.');
  const sectionOf=card=>card.section||'tracking';
  const payload={},warnings=[];
  if(selected.some(card=>sectionOf(card)==='tracking')){
   let data;try{data=await withDeadline(getTracking(),dashboardTimeoutMs,'nguồn Tracking (màn PR & PR Tracking)');}catch(error){throw fail(error&&error.status||503,`Không đọc được dữ liệu Tracking để soạn tin nhắn (${errorCause(error)}). Kiểm tra kết nối SQL hoặc bấm Tải lại dữ liệu rồi gửi lại.`);}
   warnings.push(...(Array.isArray(data&&data.warnings)?data.warnings:[]),...(data&&data.trackingError?[`Tracking: ${String(data.trackingError).trim()}`]:[]));
   payload.tracking=data;
  }
  if(selected.some(card=>sectionOf(card)==='codes')){
   let data;try{data=await withDeadline(getCodes(),dashboardTimeoutMs,'nguồn Codes (màn Code & code issue)');}catch(error){throw fail(error&&error.status||503,`Không đọc được dữ liệu Code & code issue để soạn tin nhắn (${errorCause(error)}). Kiểm tra kết nối SQL hoặc bấm Tải lại dữ liệu rồi gửi lại.`);}
   warnings.push(...(data&&data.codesError?[`Codes: ${String(data.codesError).trim()}`]:[]));
   payload.codes=data;
  }
  if(selected.some(card=>sectionOf(card)==='repair'||sectionOf(card)==='service')){
   let aps;try{aps=await withDeadline(getAps(),dashboardTimeoutMs,'nguồn Repair & Service (tab Repair & Service)');}catch(error){throw fail(error&&error.status||503,`Không đọc được dữ liệu Repair & Service để soạn tin nhắn (${errorCause(error)}). Kiểm tra tab Repair & Service rồi gửi lại.`);}
   if(!aps)throw fail(503,'Portal chưa kết nối nguồn Repair & Service cho Trung tâm tin nhắn.');
   // snapshot() không ném lỗi: SQLite đọc không được trả connected=false + warning — không gửi số 0 như số thật.
   if(aps.connected===false)throw fail(503,`Không đọc được dữ liệu Repair & Service để soạn tin nhắn (${String(aps.warning||'nguồn APS không khả dụng').slice(0,200)}).`);
   payload.aps=aps;
  }
  const text=composeText(config,payload);
  return {config,text,warnings};
 }
 async function deliver(config,text,kind){
  const rooms=normalizeRooms(config.rooms),results=[];
  for(const room of rooms){
   try{
    let response;try{response=await request(`${config.apibotUrl}/api/v1/knox/messages/send`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({roomchat:room,text})});}catch(error){const target=errorTarget(error);throw fail(502,`Không kết nối được APIBOT tại ${config.apibotUrl} (${errorCause(error)}${target?` · gọi ${target}`:''}). Chạy start.bat trong thư mục KnoxChatbox trên máy chủ Portal hoặc chạy npm run knox:check để biết nguyên nhân thật.`);}
    let payload={};try{payload=await response.json();}catch{}
    // Knox trả 503 khi server sống nhưng CDP chưa điều khiển được cửa sổ Knox Teams — phải hướng dẫn mở Knox Teams.
    if(!response.ok||payload.status==='error'||payload.status==='timeout'||payload.ok===false){const detail=String(payload.error||payload.detail||payload.result||`HTTP ${response.status}`).slice(0,300);const cdp=/local messaging connection|could not be (re)?started|Redux store|renderer window/i.test(detail)?' Mở Knox Teams (đã đăng nhập) rồi chạy start-knox-cdp.bat trong thư mục KnoxChatbox.':'';throw fail(502,`APIBOT trả lỗi cho phòng ${room}: ${detail}${cdp}`);}
    results.push({room,ok:true});
   }catch(error){results.push({room,ok:false,message:error.message,status:error.status||502});}
  }
  const failed=results.filter(entry=>!entry.ok);
  record({kind,status:failed.length?'failed':'success',rooms:rooms.join(', '),message:text.slice(0,300),...(failed.length?{error:failed.map(entry=>entry.message).join(' | ').slice(0,600)}:{})});
  if(failed.length&&failed.length===results.length)throw Object.assign(Error(failed[0].message),{status:failed[0].status||502});
  return {result:failed.length?'partial':'success',delivered:results.filter(entry=>entry.ok).map(entry=>entry.room),failed:failed.map(entry=>({room:entry.room,message:entry.message}))};
 }
 async function sendNow(override={}){const {config,text,warnings}=await buildMessage(override);const result=await deliver(config,text,'manual');return {...result,warnings};}
 async function status(){
  const current=read()||defaults();
  try{const response=await request(`${current.apibotUrl}/health`,{method:'GET',signal:AbortSignal.timeout(3000)});let info={};try{info=await response.json();}catch{}if(!response.ok)throw Object.assign(Error(`APIBOT trả về HTTP ${response.status}`),{reported:true});const ready=info.ok!==false;return {online:true,apibotUrl:current.apibotUrl,knoxReady:ready,...(info.version?{version:String(info.version).slice(0,20)}:{}),...(ready?{}:{knoxWarning:knoxHealthHint(info)}),revision:MODULE_REVISION};}
  catch(error){const code=error.reported?error.message:errorCause(error);const target=errorTarget(error);return {online:false,apibotUrl:current.apibotUrl,error:code,...(target?{target}:{}),hint:statusHint(code),revision:MODULE_REVISION};}
 }
 function slotParts(date){const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Ho_Chi_Minh',weekday:'short',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(date);const get=type=>parts.find(part=>part.type===type)?.value||'';const year=Number(get('year')),month=Number(get('month'));return {weekday:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(get('weekday')),date:`${get('year')}-${get('month')}-${get('day')}`,dayNumber:Number(get('day')),lastDay:new Date(Date.UTC(year,month,0)).getUTCDate(),minutes:Number(get('hour'))%24*60+Number(get('minute'))};}
 async function tick(date=new Date()){try{const config=read();if(!config||!config.enabled)return;const slot=slotParts(date);if(!scheduleDue(config,slot))return;const times=[config.time,...(config.afternoon?[config.afternoon]:[])].filter(Boolean);for(const time of times){const[h,m]=String(time).split(':').map(Number);if(slot.minutes<h*60+m||slot.minutes>h*60+m+10)continue;const slotKey=`msg ${slot.date} ${time}`;const outbox=readOutbox();if(outbox.lastSlot===slotKey)continue;outbox.lastSlot=slotKey;writeOutbox(outbox);try{const {text}=await buildMessage();await deliver(config,text,'scheduled');}catch(error){record({kind:'scheduled',status:'failed',rooms:(config.rooms||[]).join(', '),message:'',error:error.message});}}}catch{}}
 let schedulerTimer;function startScheduler(){if(schedulerTimer)return;schedulerTimer=setInterval(()=>{tick().catch(()=>{});},60000);if(schedulerTimer.unref)schedulerTimer.unref();}function stopScheduler(){if(schedulerTimer)clearInterval(schedulerTimer);schedulerTimer=undefined;}
 async function route({req,res,url,actor,body,send}){
  if(!url.pathname.startsWith('/api/messages-'))return false;
  if(!['developer','supervisor'].includes(actor.role))throw fail(403,'Chỉ developer hoặc supervisor được cấu hình hoặc gửi tin nhắn Knox.');
  if(url.pathname==='/api/messages-settings/send-now'){if(req.method!=='POST')throw fail(405,'Phương thức không hỗ trợ.');send(res,200,await sendNow(await body(req)));return true;}
  if(url.pathname==='/api/messages-preview'){if(req.method!=='GET')throw fail(405,'Phương thức không hỗ trợ.');const cards=String(url.searchParams.get('cards')||'').split(',').map(card=>card.trim()).filter(Boolean);const {text,warnings}=await buildMessage(cards.length?{cards}:{});send(res,200,{text,warnings});return true;}
  if(url.pathname==='/api/messages-history'){if(req.method!=='GET')throw fail(405,'Phương thức không hỗ trợ.');send(res,200,{entries:readOutbox().entries.slice(-50).reverse()});return true;}
  if(url.pathname==='/api/messages-status'){if(req.method!=='GET')throw fail(405,'Phương thức không hỗ trợ.');send(res,200,await status());return true;}
  if(url.pathname!=='/api/messages-settings')return false;
  if(req.method==='GET'){const value=read();send(res,200,publicConfig(value||defaults()));return true;}
  if(req.method!=='PUT')throw fail(405,'Phương thức không hỗ trợ.');
  send(res,200,save(await body(req)));return true;
 }
 if(autoStartScheduler)startScheduler();
 // Lỗi lập trình bên trong (không có status) phải báo rõ nguyên nhân, không rơi vào thông báo chung "Kiểm tra máy chủ" của auth.
 async function handle(input){
  const {url,res}=input;
  if(!url||!url.pathname.startsWith('/api/messages-'))return false;
  try{return await route(input);}
  catch(error){if((res&&res.headersSent)||(error&&error.status))throw error;throw fail(503,`Không xử lý được yêu cầu tin nhắn Knox (${errorCause(error)}).`);}
 }
 return {handle,startScheduler,stopScheduler,tick,sendNow,kpiValues,KPI_CARDS,readConfig:read,revision:MODULE_REVISION};
}
module.exports={createMessages,KPI_CARDS,MODULE_REVISION};
