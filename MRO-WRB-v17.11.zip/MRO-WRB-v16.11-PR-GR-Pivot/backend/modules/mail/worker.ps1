$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Security

function Protect-Secret([byte[]]$bytes) {
    try {
        $sealed = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        return @{ secret = 'user:' + [Convert]::ToBase64String($sealed) }
    } catch {
        # Some service hosts do not load an interactive Windows profile.  Keep the
        # secret DPAPI-protected on this computer rather than writing it in plain text.
        $sealed = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
        return @{ secret = 'machine:' + [Convert]::ToBase64String($sealed) }
    }
}

function Unprotect-Secret([string]$secret) {
    $scope = [Security.Cryptography.DataProtectionScope]::CurrentUser
    $encoded = $secret
    if ($secret.StartsWith('machine:')) {
        $scope = [Security.Cryptography.DataProtectionScope]::LocalMachine
        $encoded = $secret.Substring(8)
    } elseif ($secret.StartsWith('user:')) {
        $encoded = $secret.Substring(5)
    }
    $bytes = [Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($encoded), $null, $scope)
    return [Text.Encoding]::UTF8.GetString($bytes)
}

try {
    $job = [Console]::In.ReadToEnd() | ConvertFrom-Json
    if ($job.action -eq 'protect') {
        $bytes = [Text.Encoding]::UTF8.GetBytes([string]$job.secret)
        Protect-Secret $bytes | ConvertTo-Json -Compress
    } elseif ($job.action -eq 'unprotect') {
        @{value=(Unprotect-Secret ([string]$job.secret))} | ConvertTo-Json -Compress
    } else { throw 'Unsupported mail protection action.' }
    exit 0
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}
