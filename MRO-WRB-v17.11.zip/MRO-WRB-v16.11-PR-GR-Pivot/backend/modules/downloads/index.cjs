const fs=require('node:fs'),path=require('node:path');
const {eligiblePR}=require('../../integration/pr-eligibility.cjs');
const fail=(status,message)=>Object.assign(Error(message),{status});
function numericColumn(column){const name=column.name.replace(/[ -]+/g,'_');return /^(tinyint|smallint|int|bigint|decimal|numeric|float|real|money|smallmoney|bit)$/i.test(column.type)||(!/(?:^|_)(?:CODE|NO|SEQ|ID|NAME|DATE|CURRENCY|CENTER|STATUS)(?:_|$)/i.test(name)&&(/(?:^|_)(?:QTY|QUANTITY|AMOUNT|PRICE)(?:_|$)/i.test(name)||/^(?:Số lượng|Đơn giá|Thành tiền)$/i.test(column.name.trim())));}
// Measures stored as nvarchar may contain ERP labels. Preserve unparseable text;
// never replace it with zero or abort an otherwise valid export.
function measureValue(value){
 if(typeof value!=='string')return value;
 let s=value.trim();if(!s||/^null$/i.test(s))return null;
 let negative=false;if(/^\(.*\)$/.test(s)){negative=true;s=s.slice(1,-1).trim();}
 s=s.replace(/[\u00a0\u202f]/g,' ').trim();
 if(/^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$/.test(s))s=s.replace(/,/g,'');
 if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(s))return value;
 const n=Number(s)*(negative?-1:1);return Number.isFinite(n)&&(!Number.isInteger(n)||Number.isSafeInteger(n))?n:value;
}
function normalizeSheets(value,kind){
 const names=kind==='ALL'?['PR','RFQ','GMRO']:[kind];
 if(!Array.isArray(value.sheets)||value.sheets.length!==names.length)throw fail(502,'SQL chưa trả đủ bảng; chưa tạo file một phần.');
 return names.map(name=>{const s=value.sheets.find(s=>s.name===name);
  if(!s||!Array.isArray(s.columns)||!s.columns.length||!Array.isArray(s.rows))throw fail(502,'Dữ liệu '+name+' không hợp lệ.');
  const columns=s.columns.map(c=>({name:String(c.name),type:String(c.type),numeric:numericColumn(c)}));
  if(new Set(columns.map(c=>c.name)).size!==columns.length)throw fail(502,'Tên cột trùng trong '+name);
  return {name,columns,rows:s.rows.map(row=>Object.fromEntries(columns.map(c=>{let v=row[c.name]??null;
   if(/^bit$/i.test(c.type)&&/^(true|false)$/i.test(String(v)))v=String(v).toLowerCase()==='true'?1:0;
   if(c.numeric)v=measureValue(v);return [c.name,v];
  })))};
 });
}
const dashboardTabs=['overview','delivery','projects','data-tracking','aps','vendor-overview','vendor-weekly-orders','vendor-order-history','inventory','orders','codes','tracking'];
function overviewAssets(root,tabs){
 const legacy=tabs===undefined;tabs=tabs||['overview'];if(!Array.isArray(tabs)||!tabs.length||tabs.length>dashboardTabs.length||new Set(tabs).size!==tabs.length||tabs.some(id=>!dashboardTabs.includes(id)))throw fail(400,'Danh sách tab dashboard không hợp lệ.');
 const modules={},visit=file=>{if(modules[file])return;const absolute=path.resolve(root,file);if(!absolute.startsWith(path.resolve(root)+path.sep)||!file.endsWith('.mjs')||file.includes('auth-ui'))throw fail(500,'Dependency offline không hợp lệ.');const source=fs.readFileSync(absolute,'utf8');modules[file]=source;for(const m of source.matchAll(/\b(?:import|export)\s+(?:[^;'"\n]+?\s+from\s*)?['"]([^'"]+)['"]/g)){if(!m[1].startsWith('.'))throw fail(500,'Dependency offline phải là file local.');visit(path.relative(root,path.resolve(path.dirname(absolute),m[1])).replaceAll('\\','/'));}};
 [...tabs.map(id=>'frontend/modules/'+(id.startsWith('vendor-')?'vendor':id)+'/index.mjs'),'shared/ui.mjs','shared/icons.mjs',...(legacy?[]:['shared/card-filters.mjs','shared/model.mjs'])].forEach(visit);
 return {entry:fs.readFileSync(path.join(root,'backend/modules/downloads/'+(legacy?'overview-entry.txt':'dashboard-entry.txt')),'utf8'),modules,css:['assets/styles.css','assets/readability.css'].map(f=>fs.readFileSync(path.join(root,f),'utf8')).join('\n')};
}
function createDownloads({sql,root}){return {async handle({req,res,url,actor,send}){if(!['/api/download-data','/api/download-overview-assets'].includes(url.pathname))return false;if(actor.role==='viewer')throw fail(403,'Viewer không được tải dữ liệu.');if(actor.vendorScope)throw fail(403,'Tài khoản Vendor không được tải dữ liệu nội bộ.');if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ GET.');if(url.pathname.endsWith('overview-assets')){send(res,200,overviewAssets(root,url.searchParams.has('tabs')?url.searchParams.get('tabs').split(','):undefined));return true;}const kind=url.searchParams.get('kind');if(!['PR','RFQ','GMRO','ALL'].includes(kind))throw fail(400,'Loại download không hợp lệ.');if(typeof sql.downloadData!=='function')throw fail(503,'SQL chưa hỗ trợ download.');const result=await sql.downloadData(kind);send(res,200,{sheets:normalizeSheets(result,kind),updatedAt:new Date().toISOString()});return true;}};}
module.exports={createDownloads,normalizeSheets,numericColumn,overviewAssets};
