const crypto = require('node:crypto');
const {mapOrders} = require('../orders/index.cjs');
const text = value => String(value ?? '').trim();
function calendarDate(value) {
  const s = text(value);
  return /^\d{4}-\d{2}-\d{2}$/.test(s) && Number.isFinite(Date.parse(s)) &&
    new Date(s).toISOString().slice(0, 10) === s ? s : '';
}
function today(now) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh', year: 'numeric', month: '2-digit', day: '2-digit'
  }).format(now);
}
function rfqState(rfq = {}, now = new Date()) {
  const requestDate = calendarDate(rfq.REQUEST_DATE);
  const receiptDate = calendarDate(rfq.RECEIPT_DATE);
  const processingDays = receiptDate
    ? Math.floor((Date.parse(today(now)) - Date.parse(receiptDate)) / 86400000)
    : null;
  const status = text(rfq.RFQ_STATUS_NAME) === 'Selection Completed' ? 'Ready for PR'
    : processingDays !== null && processingDays > 20 ? 'Quá hạn'
    : requestDate ? 'Đang xử lý' : 'Cần xử lý';
  return {requestDate, receiptDate, processingDays, status};
}
// Public mapping contract: preserve the Orders weekly latest-state rule.
// No mutation of requests, codes or tracking in another module.
function approvedRows(orderRows, _legacyMasterRows, now = new Date()) {
  return mapOrders(orderRows, now).ordersKeys
    .filter(row => !row.deleted && (row.status === 'Đã duyệt' || row.status === 'Đã xác nhận'))
    .map((row, index) => ({
      key: crypto.createHash('sha256')
        .update(JSON.stringify([row.week, row.vendor, row.code, row.itemCode])).digest('hex'),
      sequence: index + 1,
      date: row.date,
      week: row.week,
      vendor: row.vendor,
      wrbCode: row.code,
      originalCode: row.itemCode,
      itemName: row.itemName,
      quantity: row.quantity,
      unit: row.unit,
      // Ba trường ghi chú của Order được truyền xuống dưới dạng read-only để
      // màn Tracking gợi ý nội dung cho ô Ghi chú. Không đưa vào sourceRevision
      // của Tracking nên không làm mất hiệu lực bản PIC3 đã lưu.
      reason: row.reason,
      remark: row.remark,
      comment: row.comment,
      // Codes không còn phụ thuộc dbo.EQM_MRO_MasterData. Giữ field để không
      // phá vỡ contract/UI cũ; loại hàng sẽ để trống khi không có nguồn riêng.
      itemType: '',
      warning: row.warning
    }));
}


const fail = (status,message) => Object.assign(Error(message),{status});
const digest = value => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
function mapRFQ(rows) {
 if(!Array.isArray(rows))throw Error('Dữ liệu RFQ không hợp lệ.');
 const unique=new Map();
 for(const r of rows){const value={};for(const k of ['ITEM_CODE','QT_REQ_NO','QT_REQ_SEQ','RFQ_REQ_SUB_NO','RFQ_STATUS_NAME','REQUEST_DATE','RECEIPT_DATE','CONTRACT_NAME'])value[k]=text(r[k]);value.id=digest(value);unique.set(value.id,value);}
 return [...unique.values()];
}
function sqlTimestamp(value){const raw=text(value);if(!raw)return '';const normalized=/Z$/i.test(raw)?raw:raw+'Z';const date=new Date(normalized);return Number.isFinite(date.getTime())?date.toISOString():'';}
function sqlEntry(row){
 const lineKey=text(row.LineKey),baseKey=text(row.BaseKey)||lineKey;let rfq=null;
 if(row.RFQJson){try{const parsed=JSON.parse(String(row.RFQJson));if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw Error();rfq=mapRFQ([parsed])[0];}catch{throw fail(502,'Snapshot RFQ trong dbo.EQM_MRO_CodeIssue không hợp lệ.');}}
 else if(row.RFQItemCode||row.RFQNo||row.RFQSeq||row.RFQReqSubNo||row.RFQStatus||row.RequestDate||row.ReceiptDate||row.ContractName){rfq=mapRFQ([{ITEM_CODE:row.RFQItemCode,QT_REQ_NO:row.RFQNo,QT_REQ_SEQ:row.RFQSeq,RFQ_REQ_SUB_NO:row.RFQReqSubNo,RFQ_STATUS_NAME:row.RFQStatus,REQUEST_DATE:row.RequestDate,RECEIPT_DATE:row.ReceiptDate,CONTRACT_NAME:row.ContractName}])[0];}
 return{baseKey,date:text(row.OrderDate),week:text(row.OrderWeek),vendor:text(row.Vendor),wrbCode:text(row.WRBCode),originalCode:text(row.OriginalCode),purchaseCode:text(row.PurchaseCode),typeOfCode:text(row.TypeOfCode),action:text(row.Action),rfq,status:text(row.Status),createdAt:sqlTimestamp(row.CreatedAt),createdBy:text(row.CreatedBy),updatedAt:sqlTimestamp(row.UpdatedAt),updatedBy:text(row.UpdatedBy),revision:text(row.Revision)};
}
// 15/11/2026 (Project Owner): Ready for PR bắt buộc có Type of code (IMK / Direct / Local).
// Dòng cũ đã Ready mà chưa có Type vẫn được sửa (không ép migrate dữ liệu cũ); chỉ chặn chuyển
// sang Ready khi thiếu Type, hoặc xóa Type của dòng đang Ready.
const READY_TYPE_MESSAGE='Chọn Type of code (IMK / Direct / Local) trước khi Ready for PR.';
function assertReadyType(action,typeOfCode,old={}){
 if(String(action||'').trim()!=='Ready for PR'||typeOfCode)return;
 if(old.action==='Ready for PR'&&!old.typeOfCode)return;
 throw fail(400,READY_TYPE_MESSAGE);
}
function createCodes({root,runtime,sql,pricing,now=()=>new Date()}) {
 let last=null,pending=null;
 // A Load RFQ always reads first, then immediately saves the selected result.
 // Keep that exact result briefly per user so the save can validate the same
 // snapshot without issuing a duplicate SQL lookup.
 const rfqLookups=new Map(),rfqLookupTtl=30000;
 function enrich(row,entry={}){const rfq=entry.rfq||{},state=rfqState(rfq,now());return {...row,baseKey:row.baseKey||row.key,purchaseCode:entry.purchaseCode||'',typeOfCode:entry.typeOfCode||'',action:entry.action||'',rfq,...state,updatedAt:entry.updatedAt||'',createdAt:entry.createdAt||'',revision:entry.revision||''};}
 // Một dòng Order có thể mua bằng nhiều Purchase Code: dòng gốc giữ nguyên key,
 // mỗi code phát sinh lưu dưới key 64-hex riêng cùng baseKey trỏ về dòng gốc,
 // nên Codes/Tracking/KPI vẫn xem mỗi code là một dòng có định danh riêng.
 function extraCodes(entries){const grouped=new Map();for(const [key,entry] of Object.entries(entries)){const base=entry&&entry.baseKey;if(!base||base===key)continue;const list=grouped.get(base)||[];list.push([key,entry]);grouped.set(base,list);}return grouped;}
 function expand(rows,entries){const extras=extraCodes(entries),out=[];for(const row of rows){out.push(enrich(row,entries[row.key]));const list=(extras.get(row.key)||[]).slice().sort((a,b)=>String(a[1].createdAt||a[1].updatedAt||'').localeCompare(String(b[1].createdAt||b[1].updatedAt||''))||a[0].localeCompare(b[0]));for(const [key,entry] of list)out.push(enrich({...row,key,baseKey:row.key},entry));}return out;}
 async function readEntries(){if(typeof sql.readCodeIssues!=='function')throw fail(503,'SQL adapter chưa hỗ trợ dbo.EQM_MRO_CodeIssue.');const rows=await sql.readCodeIssues();if(!Array.isArray(rows))throw fail(502,'SQL không trả danh sách Code Issue hợp lệ.');const entries={};for(const row of rows){const key=text(row&&row.LineKey);if(!/^[a-f0-9]{64}$/.test(key)||entries[key])throw fail(502,'Khóa dòng dbo.EQM_MRO_CodeIssue không hợp lệ hoặc bị trùng.');entries[key]=sqlEntry(row);}return entries;}
 function toSqlRow(row,entry){const rfq=entry.rfq||null;return{lineKey:row.key,baseKey:entry.baseKey||row.baseKey||row.key,orderDate:entry.date||row.date||'',orderWeek:entry.week||row.week||'',vendor:entry.vendor||row.vendor||'',wrbCode:entry.wrbCode||row.wrbCode||'',originalCode:entry.originalCode||row.originalCode||'',purchaseCode:entry.purchaseCode||'',typeOfCode:entry.typeOfCode||'',action:entry.action||'',status:entry.status||rfqState(rfq||{},now()).status,rfqItemCode:rfq?.ITEM_CODE||'',rfqNo:rfq?.QT_REQ_NO||'',rfqSeq:rfq?.QT_REQ_SEQ||'',rfqReqSubNo:rfq?.RFQ_REQ_SUB_NO||'',rfqStatus:rfq?.RFQ_STATUS_NAME||'',requestDate:rfq?.REQUEST_DATE||'',receiptDate:rfq?.RECEIPT_DATE||'',contractName:rfq?.CONTRACT_NAME||'',rfqJson:rfq?JSON.stringify(rfq):'',createdAt:entry.createdAt||now().toISOString(),createdBy:entry.createdBy||entry.updatedBy||'migrate',updatedAt:entry.updatedAt||now().toISOString(),updatedBy:entry.updatedBy||'migrate',revision:entry.revision||''};}
 async function source(){if(typeof sql.readOrders!=='function')throw Error('SQL adapter chưa hỗ trợ đọc Order cho Code Issue.');const orders=await sql.readOrders();return approvedRows(orders,undefined,now());}
 async function lookup(code,userId,{consume=false}={}){if(typeof code!=='string'||!code.trim()||code.length>50)throw fail(400,'Purchase Code cần từ 1–50 ký tự.');const purchaseCode=code.trim(),key=String(userId||'')+'\u0000'+purchaseCode,at=Date.now(),cached=rfqLookups.get(key);if(cached&&cached.until>at){if(consume)rfqLookups.delete(key);return cached.rows;}const rows=mapRFQ(await sql.lookupRFQ(purchaseCode)).filter(r=>r.ITEM_CODE===purchaseCode);if(!consume)rfqLookups.set(key,{rows,until:at+rfqLookupTtl});if(rfqLookups.size>500)for(const [cacheKey,value] of rfqLookups)if(value.until<=at||rfqLookups.size>500)rfqLookups.delete(cacheKey);return rows;}
 async function lookupBatch(codes,userId){
  if(!Array.isArray(codes)||!codes.length||codes.length>200||codes.some(code=>typeof code!=='string'||!code.trim()||code.trim().length>50))throw fail(400,'Danh sách Purchase Code không hợp lệ.');
  const unique=[...new Set(codes.map(code=>code.trim()))],at=Date.now(),missing=[];
  for(const code of unique)if(!rfqLookups.get(String(userId||'')+'\u0000'+code)?.until||rfqLookups.get(String(userId||'')+'\u0000'+code).until<=at)missing.push(code);
  if(missing.length){
   const source=typeof sql.lookupRFQBatch==='function'?await sql.lookupRFQBatch(missing):(await Promise.all(missing.map(code=>sql.lookupRFQ(code)))).flat();
   for(const code of missing)rfqLookups.set(String(userId||'')+'\u0000'+code,{rows:mapRFQ(source.filter(row=>text(row.ITEM_CODE)===code)),until:at+rfqLookupTtl});
  }
  return Object.fromEntries(unique.map(code=>[code,(rfqLookups.get(String(userId||'')+'\u0000'+code)?.rows||[])]));
 }
 async function live(data){if(!Array.isArray(data.codes)&&!Array.isArray(data.codesSQL))return data;
  if(!pending)pending=(async()=>{let rows,error=null;try{rows=await source();last=rows;}catch(e){rows=last||[];error='Không đọc được Order/MasterData từ SQL. '+(last?'Đang hiển thị lần đọc thành công gần nhất.':'Chưa có dữ liệu.');}
   // Không có Order hợp lệ thì Code Issue SQL cũng không thể tạo dòng hiển thị;
   // bỏ truy vấn thừa nhưng không dùng JSON/cache làm nguồn thay thế.
   const entries=rows.length?await readEntries():{};
   const decorated=expand(rows,entries);
   return {codesSQL:pricing?await pricing.enrich(decorated,r=>r.purchaseCode||r.originalCode):decorated,codesSource:error?(last?'sql-cache':'empty'):'sql',codesError:error};})();
  try{return {...data,...await pending};}finally{pending=null;}
 }
 async function edit(input,user){
  if(!input||Object.keys(input).some(k=>!['key','revision','purchaseCode','typeOfCode','action','rfqId'].includes(k))||! /^[a-f0-9]{64}$/.test(input.key||''))throw fail(400,'Yêu cầu Code Issue không hợp lệ.');
  for(const [k,max]of [['purchaseCode',50],['typeOfCode',10],['action',500],['revision',64]])if(typeof input[k]!=='string'||input[k].length>max)throw fail(400,'Giá trị '+k+' không hợp lệ.');
  if(!['','IMK','Direct','Local'].includes(input.typeOfCode))throw fail(400,'Type of code không hợp lệ.');
  if(input.rfqId!==undefined&&input.rfqId!==''&&!/^[a-f0-9]{64}$/.test(input.rfqId))throw fail(400,'RFQ không hợp lệ.');
  const [base,entries]=await Promise.all([source(),readEntries()]),rows=expand(base,entries),row=rows.find(r=>r.key===input.key);if(!row||row.warning)throw fail(409,'Order đã thay đổi hoặc ngày giờ không rõ ràng. Tải lại SQL.');
  const old=entries[input.key]||{};if((old.revision||'')!==input.revision)throw fail(409,'Dòng đã được người khác sửa. Tải lại trước khi chỉnh tiếp.');
  assertReadyType(input.action,input.typeOfCode,old);
  const purchaseCode=input.purchaseCode.trim();let rfq=purchaseCode===old.purchaseCode?old.rfq||null:null;
  if(input.rfqId){const choices=await lookup(purchaseCode,user.id,{consume:true});rfq=choices.find(r=>r.id===input.rfqId);if(!rfq)throw fail(409,'RFQ đã thay đổi. Load lại và chọn lại RFQ.');}
  else if(input.rfqId==='')rfq=null;
  const entry={baseKey:row.baseKey||row.key,date:row.date,week:row.week,vendor:row.vendor,wrbCode:row.wrbCode,originalCode:row.originalCode,purchaseCode,typeOfCode:input.typeOfCode,action:input.action.trim(),rfq,status:rfqState(rfq||{},now()).status,createdAt:old.createdAt||now().toISOString(),createdBy:old.createdBy||user.username,updatedAt:now().toISOString(),updatedBy:user.username,revision:crypto.randomBytes(32).toString('hex')};
  const sqlRow=toSqlRow(row,entry),isInsert=!Object.hasOwn(entries,input.key);if(typeof sql.writeCodeIssues!=='function')throw fail(503,'SQL adapter chưa hỗ trợ lưu dbo.EQM_MRO_CodeIssue.');
  await sql.writeCodeIssues(isInsert?{inserts:[{...sqlRow,parentKey:input.key,parentExpectedRevision:input.revision}],updates:[],deletes:[]}:{inserts:[],updates:[{...sqlRow,expectedRevision:input.revision}],deletes:[]});last=base;return {row:pricing?(await pricing.enrich([enrich(row,entry)],r=>r.purchaseCode||r.originalCode))[0]:enrich(row,entry)};
 }
 async function editBatch(input,user){
  if(!input||Object.keys(input).length!==1||!Array.isArray(input.entries)||!input.entries.length||input.entries.length>200)throw fail(400,'Danh sách lưu RFQ không hợp lệ.');
  const keys=new Set();for(const item of input.entries){if(!item||Object.keys(item).some(k=>!['key','revision','purchaseCode','typeOfCode','action','rfqId'].includes(k))||! /^[a-f0-9]{64}$/.test(item.key||'')||keys.has(item.key))throw fail(400,'Dòng RFQ không hợp lệ.');keys.add(item.key);for(const [k,max]of [['purchaseCode',50],['typeOfCode',10],['action',500],['revision',64]])if(typeof item[k]!=='string'||item[k].length>max)throw fail(400,'Giá trị '+k+' không hợp lệ.');if(!['','IMK','Direct','Local'].includes(item.typeOfCode)||!/^[a-f0-9]{64}$/.test(item.rfqId||''))throw fail(400,'RFQ hoặc Type of code không hợp lệ.');}
  const [base,entries]=await Promise.all([source(),readEntries()]),rows=expand(base,entries),prepared=[];
  for(const item of input.entries){const row=rows.find(value=>value.key===item.key);if(!row||row.warning)throw fail(409,'Order đã thay đổi hoặc ngày giờ không rõ ràng. Tải lại SQL.');const old=entries[item.key]||{};if((old.revision||'')!==item.revision)throw fail(409,'Có dòng đã được người khác sửa. Tải lại trước khi lưu.');assertReadyType(item.action,item.typeOfCode,old);const purchaseCode=item.purchaseCode.trim(),choices=await lookup(purchaseCode,user.id),rfq=choices.find(value=>value.id===item.rfqId);if(!rfq)throw fail(409,'RFQ đã thay đổi. Load lại và chọn lại RFQ.');prepared.push({item,row,old,rfq,purchaseCode});}
  const saved=prepared.map(({item,row,old,rfq,purchaseCode})=>{const state=rfqState(rfq,now()),entry={baseKey:row.baseKey||row.key,date:row.date,week:row.week,vendor:row.vendor,wrbCode:row.wrbCode,originalCode:row.originalCode,purchaseCode,typeOfCode:item.typeOfCode,action:item.action.trim(),rfq,status:state.status,createdAt:old.createdAt||now().toISOString(),createdBy:old.createdBy||user.username,updatedAt:now().toISOString(),updatedBy:user.username,revision:crypto.randomBytes(32).toString('hex')};return{item,row,old,entry};});
  const operations={inserts:[],updates:[],deletes:[]};for(const {item,row,entry} of saved){const value=toSqlRow(row,entry);if(Object.hasOwn(entries,item.key))operations.updates.push({...value,expectedRevision:item.revision});else operations.inserts.push({...value,parentKey:item.key,parentExpectedRevision:item.revision});}
  await sql.writeCodeIssues(operations);last=base;const rendered=saved.map(value=>enrich(value.row,value.entry));return {rows:pricing?await pricing.enrich(rendered,r=>r.purchaseCode||r.originalCode):rendered};
 }
 // Purchase Code bổ sung cho cùng một dòng Order (ví dụ lần 1 mã IMK, lần 2 mã Local).
 // Chỉ ghi bảng Code Issue; không đụng SQL nghiệp vụ khác, requests hay tracking.
 async function addCode(input,user){
  if(!input||Object.keys(input).some(k=>!['key','revision'].includes(k))||!/^[a-f0-9]{64}$/.test(input.key||'')||typeof input.revision!=='string'||(input.revision!==''&&!/^[a-f0-9]{64}$/.test(input.revision)))throw fail(400,'Yêu cầu thêm Purchase Code không hợp lệ.');
  const [base,entries]=await Promise.all([source(),readEntries()]),rows=expand(base,entries),row=rows.find(r=>r.key===input.key);if(!row||row.warning)throw fail(409,'Order đã thay đổi hoặc ngày giờ không rõ ràng. Tải lại SQL.');
  const oldEntry=entries[input.key]||{};if((oldEntry.revision||'')!==input.revision)throw fail(409,'Dòng đã được người khác sửa. Tải lại trước khi chỉnh tiếp.');
  const baseKey=row.baseKey||row.key;
  if(Object.entries(entries).filter(([entryKey,entry])=>(entry.baseKey||entryKey)===baseKey).length>=5)throw fail(409,'Mỗi dòng Order chỉ có tối đa 5 Purchase Code.');
  const key=crypto.randomBytes(32).toString('hex'),stamp=now().toISOString();
  const entry={baseKey,date:row.date,week:row.week,vendor:row.vendor,wrbCode:row.wrbCode,originalCode:row.originalCode,purchaseCode:'',typeOfCode:'',action:'',rfq:null,status:rfqState({},now()).status,createdAt:stamp,createdBy:user.username,updatedAt:stamp,updatedBy:user.username,revision:crypto.randomBytes(32).toString('hex')};
  await sql.writeCodeIssues({inserts:[{...toSqlRow({...row,key,baseKey},entry),parentKey:input.key,parentExpectedRevision:input.revision}],updates:[],deletes:[]});last=base;const created=expand(base,{...entries,[key]:entry}).find(r=>r.key===key);
  return {row:pricing?(await pricing.enrich([created],r=>r.purchaseCode||r.originalCode))[0]:created};
 }
 async function removeCode(input,user){
  if(!input||Object.keys(input).some(k=>!['key','revision','remove'].includes(k))||!/^[a-f0-9]{64}$/.test(input.key||'')||typeof input.revision!=='string'||input.revision==='')throw fail(400,'Yêu cầu xóa Purchase Code không hợp lệ.');
  const entries=await readEntries(),entry=entries[input.key];
  if(!entry||!entry.baseKey||entry.baseKey===input.key)throw fail(404,'Chỉ xóa được dòng Purchase Code đã thêm cho dòng Order; dòng Order gốc không xóa được.');
  if((entry.revision||'')!==input.revision)throw fail(409,'Dòng đã được người khác sửa. Tải lại trước khi xóa.');
  await sql.writeCodeIssues({inserts:[],updates:[],deletes:[{lineKey:input.key,expectedRevision:input.revision}]});
  return {removed:true};
 }
 async function handle({req,res,url,body,send,protectedTransaction,requireUser}){
  if(!['/api/codes-live','/api/codes-rfq','/api/codes-rfq-batch','/api/codes-edit','/api/codes-edit-batch','/api/codes-code'].includes(url.pathname))return false;
  if(url.pathname==='/api/codes-live'){if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ GET.');send(res,200,await live({codesSQL:[]}));return true;}
  if(url.pathname==='/api/codes-rfq'){if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ GET.');send(res,200,{rows:await lookup(url.searchParams.get('code'),requireUser(req).user.id)});return true;}
  if(url.pathname==='/api/codes-rfq-batch'){if(req.method!=='POST')throw fail(405,'Chỉ hỗ trợ POST.');const input=await body(req);send(res,200,{rows:await lookupBatch(input?.codes,requireUser(req).user.id)});return true;}
  if(url.pathname==='/api/codes-edit-batch'){if(req.method!=='PATCH')throw fail(405,'Chỉ hỗ trợ PATCH.');const input=await body(req);send(res,200,await protectedTransaction(()=>editBatch(input,requireUser(req).user)));return true;}
  if(url.pathname==='/api/codes-code'){if(req.method!=='POST')throw fail(405,'Chỉ hỗ trợ POST.');const input=await body(req);if(input&&input.remove===true){send(res,200,await protectedTransaction(()=>removeCode(input,requireUser(req).user)));return true;}send(res,201,await protectedTransaction(()=>addCode(input,requireUser(req).user)));return true;}
  if(req.method!=='PATCH')throw fail(405,'Chỉ hỗ trợ PATCH.');const input=await body(req);send(res,200,await protectedTransaction(()=>edit(input,requireUser(req).user)));return true;
 }
 return {live,handle,addCode,purchaseTypes:async()=>Object.values(await readEntries()).filter(entry=>entry&&entry.purchaseCode&&entry.typeOfCode).map(entry=>({purchaseCode:entry.purchaseCode,typeOfCode:entry.typeOfCode,updatedAt:entry.updatedAt}))};
}
module.exports={approvedRows,rfqState,mapRFQ,createCodes};
