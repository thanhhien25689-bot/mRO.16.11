// sql-store.cjs — 09/11/2026 (phương án C): nguồn vận hành của tab Repair & Service là SQL Server.
// File này chuyển hàng đọc được từ action `aps-rows` (EQM_MRO_REPAIR + EQM_MRO_SERVICE) về đúng
// hình request mà module APS + Overview đang dùng, và chuẩn hoá bản ghi trước khi gửi `aps-row-write`.
// Mapping ngược của scripts/migrate-aps-sql.cjs (buildRepairRows/buildServiceRows/paymentRow):
//   • mỗi Request ID = một request; mỗi dòng Repair = một Jig line; dòng Service = request-level;
//   • dòng thanh toán = dòng có Remark bắt đầu "TT " và trống toàn bộ cột nghiệp vụ của loại đó;
//   • Reject date/Reject reason/Buyer/IBM/UpdatedAt/UpdatedBy là cột bổ sung (aps:ensure-schema).
// Không đọc SQLite, không import module khác, không tự bịa giá trị khi cột chưa có.
const fail=(status,message)=>Object.assign(new Error(message),{status});
const text=value=>String(value===null||value===undefined?'':value).trim();
const dateOnly=value=>{const match=/^(\d{4}-\d{2}-\d{2})/.exec(text(value));return match?match[1]:'';};
const num=value=>{const raw=text(value).replace(/,/g,'');if(!raw)return 0;const parsed=Number(raw);return Number.isFinite(parsed)?parsed:0;};
const yes=value=>['yes','y','true','1','đã ký','đã tạo','done','completed'].includes(text(value).toLowerCase());
const paymentRemark=value=>/^TT(\s|$)/i.test(text(value));
const normalizeStatus=value=>{const t=text(value).toLowerCase();if(t.startsWith('compl'))return'Completed';if(t.startsWith('cancel'))return'Cancel';return'Pending';};
// Cột "nghiệp vụ" của từng loại: dòng thanh toán không mang các cột này (xem paymentRow bản migrate).
const REPAIR_CONTENT=['BQMSCode','JigName','Fault','DetailRequest','ServiceCode','PO','NoteOfService','WRB','PurAccept','PriceConfirmDate'];
const SERVICE_CONTENT=['StatusRequest','ServiceType','StartDate','EndDate','BeforeApproval','Contract','ContractSigned','ContractNo'];
const isPaymentRow=(row,src)=>paymentRemark(row.Remark)&&(!src||src==='S'?SERVICE_CONTENT:REPAIR_CONTENT).every(name=>text(row[name])==='');
function firstValue(rows,names){for(const name of names)for(const row of rows){const value=text(row[name]);if(value)return value;}return '';}

// Cho một nhóm hàng cùng Request ID: dựng lại request + lines + payments.
function buildRequest(group){
 const ordered=[...group.rows].sort((a,b)=>num(a.No)-num(b.No));
 const src=group.src;
 const base=ordered.filter(row=>!isPaymentRow(row,src));
 const payments=ordered.filter(row=>isPaymentRow(row,src));
 const main=base.length?base[0]:ordered[0]||{};
 const pick=(...names)=>firstValue(base.length?base:ordered,names);
 const updatedAt=pick('UpdatedAt'),updatedBy=pick('UpdatedBy');
 const request={
  id:group.requestId,type:src==='R'?'Repair':'Service',src,no:num(main.No),requestId:group.requestId,
  vendor:pick('Vendor'),model:pick('Model'),pic:pick('Pic'),costCenter:pick('CostCenter'),
  date:dateOnly(main.RequestDate)||dateOnly(pick('RequestDate')),currency:pick('Cur')||'USD',
  payment:normalizeStatus(pick('PaymentStatus')),paymentMonth:text(main.MonthPayment)||'',paymentYear:text(main.YearPayment)||'',
  // SQL không có cột author/updated như SQLite: lấy UpdatedAt/UpdatedBy làm dấu sửa gần nhất.
  updated:updatedAt?Date.parse(updatedAt.replace(' ','T')+'Z')||0:0,author:updatedBy,updatedAt,updatedBy,
  payments:payments.map(row=>({date:'',amount:num(row.Amount),currency:text(row.Cur)||'USD',amountUSD:text(row.AmountUSD)===''?null:num(row.AmountUSD),reference:text(row.Remark).replace(/^TT\s*/i,''),month:text(row.MonthPayment),year:text(row.YearPayment)}))
 };
 if(src==='R'){
  request.item=base.map(row=>text(row.JigName)).filter(Boolean).join(', ');
  request.detail=base.map(row=>text(row.DetailRequest)).find(Boolean)||'';
  request.est=num(pick('EstimatedCost'));request.actualCost=0;
  request.qty=0;request.finalPrice=0;request.finalUSD=0;request.amount=0;request.amount2USD=0;
  request.vendorRepair=base.map(row=>text(row.VendorRepair)).find(Boolean)||'';request.serviceType='';request.serviceKind='';
  request.local='';request.gl='';request.start='';request.end='';request.status='';
  request.beforeApproval=false;request.contractCreated=false;request.contractSigned=false;request.contractNo='';
  request.lines=base.map(row=>({
   no:num(row.No),name:text(row.JigName),bqms:text(row.BQMSCode),fault:text(row.Fault),detail:text(row.DetailRequest),
   serviceCode:text(row.ServiceCode),vendorRepair:text(row.VendorRepair),serviceType:text(row.ServiceType),
   serviceKind:text(row.NoteOfService),qty:num(row.Qty),est:num(row.EstimatedCost),finalPrice:num(row.FinalPrice),
   finalUSD:num(row.FinalUSD),amount:num(row.Amount),amount2USD:num(row.AmountUSD),poNo:text(row.PO),
   local:text(row.Local),gl:text(row.GL),remark:text(row.Remark),wrb:text(row.WRB),accept:text(row.PurAccept),
   priceDate:dateOnly(row.PriceConfirmDate),rejectDate:dateOnly(row.RejectDate),rejectReason:text(row.RejectReason),
   buyer:text(row.Buyer),ibm:text(row.IBM)
  }));
 }else{
  request.lines=[];
  request.item=pick('ServiceType');request.detail=pick('Remark');
  request.est=num(pick('EstimatedCost'));request.actualCost=num(pick('EstimatedCost'));
  request.qty=num(pick('Qty'));request.finalPrice=num(pick('FinalPrice'));request.finalUSD=num(pick('FinalUSD'));
  request.amount=num(main.Amount);request.amount2USD=num(main.AmountUSD);
  request.vendorRepair=pick('VendorRepair');request.serviceType=pick('ServiceType');request.serviceKind='';
  request.local=pick('Local');request.gl=pick('GL');
  request.start=dateOnly(pick('StartDate'));request.end=dateOnly(pick('EndDate'));
  request.status=pick('StatusRequest');
  request.beforeApproval=yes(pick('BeforeApproval'));request.contractCreated=yes(pick('Contract'));
  request.contractSigned=yes(pick('ContractSigned'));request.contractNo=pick('ContractNo');
 }
 return request;
}


// payload = {rows, extras} từ sql.readApsRows(). Trả requests đã sắp xếp theo request date giảm dần.
function mapRows(payload){
 const rows=Array.isArray(payload&&payload.rows)?payload.rows:[];
 const extras=payload&&payload.extras===true;
 // Worker dò cột thật theo từng bảng nên biết chính xác cột nào thiếu -> nêu tên, không nói chung.
 const missing=Array.isArray(payload&&payload.missing)?payload.missing.map(text).filter(Boolean):[];
 const warnings=[];
 const groups=new Map();
 let orphans=0;
 for(const row of rows){
  const src=text(row.Src).toUpperCase()==='S'?'S':'R';
  const requestId=text(row.RequestId);
  if(!requestId)orphans++;
  const key=src+':'+(requestId||'NO-'+text(row.No));
  if(!groups.has(key))groups.set(key,{src,requestId,no:num(row.No),rows:[]});
  groups.get(key).rows.push(row);
 }
 const requests=[...groups.values()].map(buildRequest)
  .sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(a.id).localeCompare(String(b.id)));
 const payments=[];
 for(const request of requests)for(const p of request.payments)payments.push({request_id:request.id,amount:p.amount,amountUSD:p.amountUSD,currency:p.currency,month:p.month,year:p.year,reference:p.reference,date:''});
 if(!extras)warnings.push(missing.length
  ? ('Thiếu cột bổ sung trên SQL: '+missing.join(', ')+' — chạy npm run aps:ensure-schema trên máy chủ Portal. Các cột đó đang hiển thị trống và chưa ghi được.')
  : 'Hai bảng SQL chưa có cột Reject date / Reject reason / Buyer / IBM / UpdatedAt / UpdatedBy — chạy npm run aps:ensure-schema trên máy chủ Portal. Các cột đó đang hiển thị trống và chưa ghi được.');
 if(orphans)warnings.push(orphans+' dòng SQL không có Request ID nên được coi là request tạm theo số dòng (No).');
 return{requests,payments,extras,warnings,missing,rows:rows.length};
}

// Allowlist phải trùng KHỚP tên cột trong nhánh aps-row-write của backend/modules/sql/worker.ps1.
const LINE_FIELDS=['bqms','jigName','fault','detail','serviceCode','qty','estimatedCost','finalPrice','finalUSD','gl','local','remark','vendorRepair','wrb','accept','priceDate','po','rejectDate','rejectReason','buyer','ibm'];
const SERVICE_FIELDS=['statusRequest','qty','estimatedCost','finalPrice','finalUSD','cur','gl','local','remark','vendorRepair','type','startDate','endDate','beforeApproval','contract','contractSigned','contractNo','paymentStatus','monthPayment','yearPayment'];
const STATUS_FIELDS=['paymentStatus','monthPayment','yearPayment','cur'];
const PAYMENT_FIELDS=['paymentStatus','monthPayment','yearPayment','cur','amount','amountUSD','remark'];
const PAY_STATUSES=['Pending','Completed','Cancel'];
const DATE_FIELDS=new Set(['priceDate','rejectDate','startDate','endDate']);
const NUM_FIELDS=new Set(['qty','estimatedCost','finalPrice','finalUSD','monthPayment','yearPayment','amount','amountUSD']);
const BOOL_FIELDS=new Set(['beforeApproval','contract','contractSigned']);
const YES=['yes','y','true','1','đã ký','đã tạo','có'];
const NO=['no','n','false','0','không','chưa'];

// Chuẩn hoá một bản ghi ghi SQL. Trả {src,op,no,requestId,fields,expectedUpdatedAt} hoặc ném 400.
function validateWrite(payload){
 const input=payload&&typeof payload==='object'?payload:{};
 const src=String(input.src||'').toUpperCase();
 if(src!=='R'&&src!=='S')throw fail(400,'src phải là R (Repair) hoặc S (Service).');
 const op=String(input.op||'');
 if(!['line','service','status','payment'].includes(op))throw fail(400,'op không được hỗ trợ.');
 if((op==='line'&&src!=='R')||(op==='service'&&src!=='S'))throw fail(400,'op không khớp loại request đang sửa.');
 const requestId=String(input.requestId||'').trim();
 if(!requestId||requestId.length>50)throw fail(400,'Thiếu Request ID của dòng cần ghi.');
 const no=Number(input.no);
 if(op!=='status'&&(!Number.isInteger(no)||no<=0))throw fail(400,'Thiếu số dòng SQL (No) của bản ghi cần ghi.');
 const allowed=op==='line'?LINE_FIELDS:op==='service'?SERVICE_FIELDS:op==='status'?STATUS_FIELDS:PAYMENT_FIELDS;
 const raw=input.fields&&typeof input.fields==='object'&&!Array.isArray(input.fields)?input.fields:{};
 for(const key of Object.keys(raw))if(!allowed.includes(key))throw fail(400,'Trường không được phép sửa: '+key);
 if(op==='payment'){for(const key of PAYMENT_FIELDS)if(!Object.hasOwn(raw,key))throw fail(400,'Thiếu trường thanh toán: '+key);}
 else if(!Object.keys(raw).length)throw fail(400,'Không có trường nào để sửa.');
 const fields={};
 for(const key of allowed){
  if(!Object.hasOwn(raw,key))continue;
  const value=raw[key];
  if(value===null||value===undefined||String(value).trim()==='')fields[key]='';
  else if(BOOL_FIELDS.has(key)){const t=String(value).trim().toLowerCase();if(YES.includes(t))fields[key]='Yes';else if(NO.includes(t))fields[key]='No';else throw fail(400,'Cột '+key+' chỉ nhận Yes/No.');}
  else if(DATE_FIELDS.has(key)){const day=dateOnly(value);if(!day)throw fail(400,'Cột '+key+' cần ngày theo dạng YYYY-MM-DD.');fields[key]=day;}
  else if(NUM_FIELDS.has(key)){
   const parsed=Number(String(value).replace(/,/g,''));
   if(!Number.isFinite(parsed))throw fail(400,'Cột '+key+' phải là số.');
   if(key==='monthPayment'&&(!Number.isInteger(parsed)||parsed<1||parsed>12))throw fail(400,'Tháng thanh toán phải từ 1 đến 12.');
   if(key==='yearPayment'&&(!Number.isInteger(parsed)||parsed<2000||parsed>2100))throw fail(400,'Năm thanh toán phải từ 2000 đến 2100.');
   if(Math.abs(parsed)>=1e15)throw fail(400,'Cột '+key+' vượt giới hạn số cho phép.');
   fields[key]=String(Math.round(parsed*10000)/10000);
  }
  else if(key==='cur'){const code=String(value).trim().toUpperCase();if(!/^[A-Z]{3}$/.test(code))throw fail(400,'Loại tiền phải đúng 3 ký tự (VD: USD, VND).');fields[key]=code;}
  else if(key==='paymentStatus')fields[key]=normalizeStatus(value);
  else{const t=String(value).trim();if(t.length>1000)throw fail(400,'Giá trị cột '+key+' vượt 1000 ký tự.');fields[key]=t;}
 }
 if(op==='status'&&(!fields.paymentStatus||fields.paymentStatus===''))throw fail(400,'Thiếu Trạng thái thanh toán.');
 if(op==='payment'){
  if(!fields.monthPayment||!fields.yearPayment)throw fail(400,'Cần tháng và năm thanh toán.');
  if(!fields.paymentStatus||fields.paymentStatus==='Pending')fields.paymentStatus='Completed';
  if(!paymentRemark(fields.remark))fields.remark=('TT '+(fields.remark||'')).trim();
 }
 const expectedUpdatedAt=String(input.expectedUpdatedAt===null||input.expectedUpdatedAt===undefined?'':input.expectedUpdatedAt).trim().slice(0,19);
 if(expectedUpdatedAt&&!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(expectedUpdatedAt))throw fail(400,'Mốc bản ghi đang mở không hợp lệ — tải lại tab rồi thử lại.');
 return{src,op,no:op==='status'?0:no,requestId,fields,expectedUpdatedAt};
}
module.exports={mapRows,validateWrite,isPaymentRow,normalizeStatus,PAY_STATUSES,LINE_FIELDS,SERVICE_FIELDS,STATUS_FIELDS,PAYMENT_FIELDS};
