param([string]$InputPath,[string]$OutputPath)
$ErrorActionPreference='Stop'
$e=New-Object -ComObject Excel.Application
$e.Visible=$false
$e.DisplayAlerts=$false
try{
$wb=$e.Workbooks.Open($InputPath,0,$true)
$ws=$null
foreach($s in $wb.Worksheets){if($s.Name -eq 'Data'){$ws=$s;break}}
if(-not $ws){$ws=$wb.Worksheets.Item(1)}
$range=$ws.UsedRange
$values=$range.Value2
$rows=$values.GetLength(0)
$cols=$values.GetLength(1)
$sb=New-Object System.Text.StringBuilder
for($r=1;$r -le $rows;$r++){
$line=@()
for($c=1;$c -le $cols;$c++){
$v=$values[$r,$c]
if($v -eq $null){$line+=''}else{
$s=($v).ToString([System.Globalization.CultureInfo]::InvariantCulture)
if($s.Contains(',') -or $s.Contains('"') -or $s.Contains("`n")){$s='"'+$s.Replace('"','""')+'"'}
$line+=$s}}
[void]$sb.Append($line -join ',')
[void]$sb.Append("`n")}
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($range)|Out-Null
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($ws)|Out-Null
$wb.Close($false)
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($wb)|Out-Null
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($e)|Out-Null
[System.IO.File]::WriteAllText($OutputPath,$sb.ToString(),[System.Text.Encoding]::UTF8)
}catch{
$msg=$_.Exception.Message
try{if($e){$e.Quit()}}catch{}
[Console]::Error.WriteLine($msg)
exit 1
}
try{$e.Quit()}catch{}
[GC]::Collect()
[GC]::WaitForPendingFinalizers()
[GC]::Collect()
[Environment]::Exit(0)