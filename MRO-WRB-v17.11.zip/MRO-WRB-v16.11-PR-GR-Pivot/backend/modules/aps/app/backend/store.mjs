import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
export function openStore(runtime){fs.mkdirSync(path.join(runtime,'files'),{recursive:true});const db=new DatabaseSync(path.join(runtime,'aps.sqlite'));db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;
 CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE,name TEXT,role TEXT,password TEXT,active INTEGER DEFAULT 1);
 CREATE TABLE IF NOT EXISTS registrations(id TEXT PRIMARY KEY,username TEXT UNIQUE,name TEXT,password TEXT,created TEXT);
 CREATE TABLE IF NOT EXISTS reset_requests(id TEXT PRIMARY KEY,username TEXT UNIQUE,created TEXT);
 CREATE TABLE IF NOT EXISTS sessions(sid TEXT PRIMARY KEY,user TEXT NOT NULL,csrf TEXT NOT NULL,expires INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY,type TEXT,body TEXT NOT NULL,revision INTEGER NOT NULL,updated TEXT,author TEXT);
 CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY,request_id TEXT REFERENCES requests(id),body TEXT NOT NULL,source TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY,request_id TEXT REFERENCES requests(id),name TEXT,size INTEGER,created TEXT);
 CREATE TABLE IF NOT EXISTS budgets(year INTEGER PRIMARY KEY,body TEXT NOT NULL,revision INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT,user TEXT,action TEXT,target TEXT,detail TEXT);
 CREATE TABLE IF NOT EXISTS notify_settings(key TEXT PRIMARY KEY,body TEXT NOT NULL,revision INTEGER NOT NULL,updated TEXT);
 CREATE TABLE IF NOT EXISTS alerts(id TEXT PRIMARY KEY,at TEXT,kind TEXT,title TEXT,body TEXT,status TEXT,tries INTEGER DEFAULT 0,next_at INTEGER,error TEXT);
 `);try{db.exec('ALTER TABLE users ADD COLUMN avatar TEXT')}catch{}const q=(sql,...args)=>db.prepare(sql).all(...args),one=(sql,...args)=>db.prepare(sql).get(...args),run=(sql,...args)=>db.prepare(sql).run(...args);const tx=fn=>{db.exec('BEGIN IMMEDIATE');try{const result=fn();db.exec('COMMIT');return result}catch(e){db.exec('ROLLBACK');throw e}};const audit=(user,action,target,detail)=>run('INSERT INTO audit(at,user,action,target,detail) VALUES(?,?,?,?,?)',new Date().toISOString(),user?.username||'setup',action,target,JSON.stringify(detail));const requests=()=>q('SELECT * FROM requests ORDER BY updated DESC,id').map(r=>({...JSON.parse(r.body),revision:r.revision,updated:r.updated,author:r.author}));const payments=()=>q('SELECT * FROM payments ORDER BY rowid').map(p=>({...JSON.parse(p.body),id:p.id,requestId:p.request_id,source:p.source}));return {db,q,one,run,tx,audit,requests,payments}}
