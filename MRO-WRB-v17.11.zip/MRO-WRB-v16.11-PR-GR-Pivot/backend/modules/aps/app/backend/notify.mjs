import {check, days, rejected, purReset, unpriced, status} from './domain.mjs';

export const DEFAULT_NOTIFY = {enabled:false, portalAlerts:true, endpoint:'', payload:'{"text":{{bodyJson}}}', contentType:'application/json', dailyAt:'08:00', priceDays:35, acceptDays:3, contractDays:5, events:{purReject:false,importDone:false}, lastRunAt:''};

const int=(v,min,max,label)=>{const n=Math.round(Number(v));check(Number.isFinite(n)&&n>=min&&n<=max,`${label} phải từ ${min} đến ${max}`);return n};
const pad=n=>String(n).padStart(2,'0');
export const dateLabel=(d=new Date())=>`${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()}`;
const dayLabel=iso=>{const m=/^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso||''));return m?`${m[3]}/${m[2]}/${m[1]}`:dateLabel()};
export const minuteNow=(d=new Date())=>`${pad(d.getHours())}:${pad(d.getMinutes())}`;
const openRepair=r=>r.type==='Repair'&&r.payment!=='Completed'&&r.payment!=='Cancel';
const requestId=r=>r&&r.noId?'Request chưa có ID':String(r&&r.id||'(chưa có ID)');

export function notifySettings(input={}){
 const src=input&&typeof input==='object'?input:{},base={...DEFAULT_NOTIFY,...src},events={...DEFAULT_NOTIFY.events,...(src.events&&typeof src.events==='object'?src.events:{})};
 const endpoint=String(base.endpoint||'').trim();
 check(!endpoint||/^https?:\/\/[^\s]{6,500}$/i.test(endpoint),'Webhook URL phải bắt đầu bằng http:// hoặc https://');
 const dailyAt=String(base.dailyAt||'').trim();
 check(/^\d{2}:\d{2}$/.test(dailyAt)&&Number(dailyAt.slice(0,2))<24&&Number(dailyAt.slice(3,5))<60,'Giờ gửi phải dạng HH:MM (24h)');
 const payload=String(base.payload||'').trim()||DEFAULT_NOTIFY.payload;
 check(payload.length<=4000,'Mẫu payload tối đa 4000 ký tự');
 check(/\{\{(body|bodyJson|title|titleJson)\}\}/.test(payload),'Mẫu payload phải chứa {{body}}, {{bodyJson}}, {{title}} hoặc {{titleJson}} để Knox Teams hiển thị được nội dung');
 return {enabled:base.enabled===true,portalAlerts:base.portalAlerts!==false,endpoint,payload,contentType:String(base.contentType||'application/json').trim().slice(0,60)||'application/json',dailyAt,priceDays:int(base.priceDays,1,365,'Ngưỡng ngày chờ giá'),acceptDays:int(base.acceptDays,0,365,'Ngưỡng ngày chờ Purchasing'),contractDays:int(base.contractDays,0,365,'Ngưỡng ngày chờ ký hợp đồng'),events:{purReject:events.purReject===true,importDone:events.importDone===true},lastRunAt:String(base.lastRunAt||'').slice(0,40)};
}

export function priceAlert(requests,today,cfg){
 const rows=[];
 for(const r of (requests||[])){if(!openRepair(r))continue;
  for(const l of (r.lines||[])){if(rejected(l)||purReset(l)||!unpriced(l)||!l.wrb)continue;const n=days(l.wrb,today);if(n>cfg.priceDays)rows.push({id:r.id,noId:r.noId,name:l.name||'Jig',wrb:l.wrb,days:n})}}
 rows.sort((a,b)=>b.days-a.days||String(a.id).localeCompare(String(b.id)));
 if(!rows.length)return null;
 const shown=rows.slice(0,8).map(x=>`• ${requestId(x)} · ${x.name} · ${x.days} ngày (WRB ${x.wrb})`).join('\n');
 return {kind:'price-late',title:`⚠ ${rows.length} dòng Repair chờ xác nhận giá quá ${cfg.priceDays} ngày`,body:shown+(rows.length>8?`\n• … và ${rows.length-8} dòng khác`:'')};
}

export function stepAlert(requests,today,cfg){
 const slow=[],stuck=[];
 for(const r of (requests||[])){if(!openRepair(r))continue;const open=(r.lines||[]).filter(l=>!rejected(l)&&!purReset(l));if(!open.length)continue;
  const step=status(r),ages=open.filter(l=>l.wrb).map(l=>days(l.wrb,today)),age=ages.length?Math.max(...ages):null;
  if(step==='Pur chưa accept'&&age!==null&&age>cfg.acceptDays)slow.push({id:r.id,noId:r.noId,age});
  if(step==='Pur chưa confirm Price'&&age!==null&&age>cfg.priceDays)stuck.push({id:r.id,noId:r.noId,age})}
 if(!slow.length&&!stuck.length)return null;
 const part=a=>a.sort((x,y)=>y.age-x.age).slice(0,6).map(x=>`• ${requestId(x)} · ${x.age} ngày`).join('\n');
 const blocks=[];
 if(slow.length)blocks.push(`Pur chưa accept quá ${cfg.acceptDays} ngày (${slow.length} Request):\n${part(slow)}`);
 if(stuck.length)blocks.push(`Pur chưa confirm Price quá ${cfg.priceDays} ngày (${stuck.length} Request):\n${part(stuck)}`);
 return {kind:'step-slow',title:'⏱ Tiến độ Purchasing chậm hơn ngưỡng',body:blocks.join('\n\n')};
}

export function contractAlert(requests,today,cfg){
 const rows=[];
 for(const r of (requests||[])){if(r.type!=='Service'||r.payment==='Completed'||r.payment==='Cancel')continue;const s=status(r);if(s!=='Pending Contract'&&s!=='Pending Sign Contract')continue;
  const from=String(r.start||r.date||'');rows.push({id:r.id,item:r.item||r.model||'Service',step:s,age:from?days(from,today):null})}
 if(!rows.length)return null;
 const shown=rows.slice(0,8).map(x=>`• ${requestId(x)} · ${x.item} · ${x.step}${x.age!==null&&x.age>cfg.contractDays?` · ${x.age} ngày`:''}`).join('\n');
 return {kind:'contract-wait',title:`📑 ${rows.length} Service đang chờ hợp đồng / chờ ký`,body:shown+(rows.length>8?`\n• … và ${rows.length-8} Service khác`:'')};
}

export function digestAlert(requests,today,cfg){
 const list=requests||[],count=set=>{const m=new Map();for(const r of set){const s=status(r);m.set(s,(m.get(s)||0)+1)}return m},fmt=(m,keys)=>keys.map(k=>`${k} ${m.get(k)||0}`).join(' · ');
 const rm=count(list.filter(r=>r.type==='Repair')),sm=count(list.filter(r=>r.type==='Service')),late=priceAlert(list,today,cfg);
 const body=[`Repair: ${fmt(rm,['Chưa gửi RFQ','Pur chưa accept','Pur chưa confirm Price','Chờ tạo PO','Chờ IBM','Đã thanh toán'])}`,`Service: ${fmt(sm,['Pending Before APP','Pending Contract','Pending Sign Contract','Chờ Thanh Toán','Đã thanh toán'])}`,late?`Cảnh báo giá: ${late.title}`:'Cảnh báo giá: không có dòng quá ngưỡng'].join('\n');
 return {kind:'daily-digest',title:`📋 APS Portal — bản tin ${dayLabel(today)}`,body};
}

export function buildAlerts(requests,today,cfg){
 return [digestAlert(requests,today,cfg),priceAlert(requests,today,cfg),stepAlert(requests,today,cfg),contractAlert(requests,today,cfg)].filter(Boolean);
}

export function eventAlert(kind,payload={}){
 if(kind==='pur-reject')return {kind:'pur-reject',title:'⛔ Pur reject một dòng Jig',body:`Request ${payload.oldId||'?'} vừa bị Pur reject 1 dòng: ${payload.name||('dòng '+(Number(payload.lineIndex)+1||1))}.\nDòng bị trả về đã tách sang Request ${payload.splitId||'?'} ở bước "Chưa gửi RFQ".`};
 if(kind==='import-done')return {kind:'import-done',title:'📥 Import Excel hoàn tất',body:`Vừa nạp ${Number(payload.created)||0} request mới và cập nhật ${Number(payload.updated)||0} request từ file Excel.`};
 return null;
}

export function renderPayload(cfg,title,body){
 const map={'{{titleJson}}':JSON.stringify(String(title||'')),'{{bodyJson}}':JSON.stringify(String(body||'')),'{{title}}':String(title||''),'{{body}}':String(body||'')};
 return String(cfg&&cfg.payload||DEFAULT_NOTIFY.payload).replace(/\{\{(titleJson|bodyJson|title|body)\}\}/g,m=>map[m]);
}

export async function deliver(cfg,alert,{fetchImpl=fetch,timeoutMs=15000}={}){
 if(!cfg||!cfg.endpoint)return {ok:false,status:0,error:'Chưa cấu hình Webhook URL Knox Teams'};
 const payload=renderPayload(cfg,alert.title,`${alert.title}\n${alert.body}`.trim());
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),timeoutMs);
 try{
  const res=await fetchImpl(cfg.endpoint,{method:'POST',headers:{'Content-Type':cfg.contentType,'User-Agent':'APS-Portal/1.0'},body:payload,signal:ctrl.signal});
  const text=String(await res.text().catch(()=>'')||'').replace(/\s+/g,' ').slice(0,240);
  return {ok:res.status>=200&&res.status<300,status:res.status,error:res.status>=200&&res.status<300?'':`HTTP ${res.status}${text?' · '+text:''}`,preview:payload};
 }catch(e){return {ok:false,status:0,error:String(e&&e.message||e).slice(0,240),preview:payload}}finally{clearTimeout(timer)}
}
