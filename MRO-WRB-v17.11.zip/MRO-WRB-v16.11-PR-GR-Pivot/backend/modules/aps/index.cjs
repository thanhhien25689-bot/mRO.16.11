const path=require('node:path');
const {DatabaseSync}=require('node:sqlite');
const {mapRows,validateWrite,isPaymentRow}=require('./sql-store.cjs');
const fail=(status,message)=>Object.assign(new Error(message),{status});
// Ngữ nghĩa trạng thái sao chép từ APS Repair & Service Portal V1 (backend/domain.mjs) — chỉ đọc.
// 09/11/2026 (phương án C): requests/payments đọc từ SQL Server (EQM_MRO_REPAIR + EQM_MRO_SERVICE)
// qua sql.readApsRows(), ghi lại qua sql.writeApsRow(). SQLite (.runtime/aps/aps.sqlite) chỉ còn là
// kho ngân sách P03/Actual nhập tay (chưa có bảng SQL tương ứng). KHÔNG dùng SQLite thay dữ liệu
// Repair/Service khi SQL lỗi — thà hiện cảnh báo thật còn hơn số giả.
const LINE_STEPS=['chua-gui-rfq','pur-chua-accept','pur-chua-confirm-price','cho-tao-po','cho-ibm'];
const LINE_STATUS_VI={'chua-gui-rfq':'Chưa gửi RFQ','pur-chua-accept':'Pur chưa accept','pur-chua-confirm-price':'Pur chưa confirm Price','cho-tao-po':'Chờ tạo PO','cho-ibm':'Chờ IBM','rejected':'Rejected'};
const days=(a,b)=>Math.floor((Date.parse(b+'T00:00:00Z')-Date.parse(a+'T00:00:00Z'))/86400000);
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const round2=x=>Math.round((x||0)*100)/100;
const money=list=>round2(list.reduce((s,v)=>s+Number(v||0),0));
const rejectedLine=line=>Boolean(line&&line.rejectDate)||Number(line&&line.qty)===0;
const purResetLine=line=>Boolean(line&&line.purReset)&&!String(line&&line.wrb||'').trim();
const openLine=line=>!rejectedLine(line);
const unpriced=line=>openLine(line)&&!line.priceDate&&!(Number(line.finalPrice)||Number(line.amount2USD));
function lineStatus(line){if(rejectedLine(line))return'rejected';if(!line.wrb)return'chua-gui-rfq';if(!line.accept)return'pur-chua-accept';if(!line.priceDate)return'pur-chua-confirm-price';if(!line.poNo)return'cho-tao-po';return'cho-ibm';}
function requestStatus(r){if(r.payment==='Cancel')return'Cancel';if(r.type==='Service')return r.payment==='Completed'?'Đã thanh toán':!r.beforeApproval?'Pending Before APP':!r.contractCreated?'Pending Contract':!r.contractSigned?'Pending Sign Contract':'Chờ Thanh Toán';const lines=r.lines||[];if(!lines.length)return'Chờ xác nhận giá';if(r.payment==='Completed')return'Đã thanh toán';const open=lines.filter(line=>!rejectedLine(line)&&!purResetLine(line));if(!open.length)return lines.some(purResetLine)?'Chưa gửi RFQ':'Rejected';const act=open.filter(line=>String(line.wrb||'').trim());const use=act.length?act:open;const step=LINE_STEPS.findIndex(s=>use.some(line=>lineStatus(line)===s));return LINE_STATUS_VI[LINE_STEPS[step]]||'Chờ xác nhận giá';}
function statusColor(status){if(status==='Đã thanh toán')return'mint';if(status==='Chờ IBM')return'purple';if(status==='Chờ tạo PO'||status==='Chờ Thanh Toán')return'cyan';if(status==='Pur chưa confirm Price'||status==='Pur chưa accept'||status==='Pending Contract'||status==='Pending Sign Contract')return'amber';if(status==='Chưa gửi RFQ'||status==='Pending Before APP')return'red';if(status==='Rejected'||status==='Cancel')return'gray';return'amber';}
// worklistFlags (Phase 1 R&S cho tab SQL): nhóm Pending của danh sách công việc — Repair khớp nếu CÓ ÍT NHẤT MỘT Jig
// đang ở bước đó (lineStatus của chính dòng; dòng rejected không tính); Request Completed/Cancel không vào nhóm đang xử lý.
// Service "Chờ thanh toán" = đủ Before approval + hợp đồng tạo/ký + Số hợp đồng (cùng điều kiện canConfirmPayment).
// Trường bổ sung: pendingFlags/kpis (Overview đọc) giữ nguyên.
function worklistFlags(r){const active=r.payment!=='Completed'&&r.payment!=='Cancel';if(r.type!=='Repair'){const svc=r.type==='Service';return{beforeApp:svc&&active&&!r.beforeApproval,contractPend:svc&&active&&!!r.beforeApproval&&!r.contractCreated,signContract:svc&&active&&!!r.beforeApproval&&!!r.contractCreated&&!r.contractSigned,choThanhToan:svc&&active&&!!(r.beforeApproval&&r.contractCreated&&r.contractSigned&&r.contractNo),unpaid:svc&&active};}const lines=r.lines||[];const has=step=>active&&lines.some(line=>lineStatus(line)===step);return{chuaGuiRfq:has('chua-gui-rfq'),purChuaAccept:has('pur-chua-accept'),purChuaConfirmPrice:has('pur-chua-confirm-price'),choTaoPo:has('cho-tao-po'),choIbm:has('cho-ibm'),unpaid:active&&lines.some(openLine),rejected:lines.some(rejectedLine)};}
function pendingFlags(r,todayStr){if(r.type!=='Repair')return{waiting:false,late:false,missingDate:false,rejected:false,contract:r.type==='Service'&&(!r.contractSigned||!r.contractNo),unpaid:r.type==='Service'&&r.payment!=='Completed'&&r.payment!=='Cancel',steps:[]};const lines=r.lines||[];const waitingLine=line=>unpriced(line)&&line.wrb?Math.max(0,days(line.wrb,todayStr)):null;return{waiting:lines.some(unpriced),late:lines.some(line=>waitingLine(line)>35),missingDate:lines.some(line=>unpriced(line)&&!line.wrb),rejected:lines.some(rejectedLine),unpaid:r.payment!=='Completed'&&r.payment!=='Cancel',steps:LINE_STEPS.filter(step=>lines.some(line=>lineStatus(line)===step))};}
// monthOf: nguồn thanh toán có thể là SQLite (date YYYY-MM-DD) hoặc SQL (chỉ Month/Year Payment,
// không có ngày) — ưu tiên month/year tường minh, còn lại suy từ date như trước.
const monthOf=p=>{if(p&&p.month&&p.year)return{month:Number(p.month),year:String(p.year)};const d=String(p&&p.date||'');if(!d.startsWith('2'))return null;return{month:Number(d.slice(5,7)),year:d.slice(0,4)};};
function outlook(b,payments,requests){const reqMap=new Map(requests.map(r=>[r.id,r]));const months=b.months.map((m,i)=>{const monthStr=String(i+1).padStart(2,'0');const list=payments.filter(p=>{if(b.source==='payments'){const req=reqMap.get(p.request_id);if(req&&req.paymentMonth){const payMonth=String(Number(req.paymentMonth)).padStart(2,'0'),payYear=req.paymentYear||b.year;return payMonth===monthStr&&String(payYear)===String(b.year)}}const when=monthOf(p);return !!when&&when.year===String(b.year)&&String(when.month).padStart(2,'0')===monthStr});return{month:i+1,p03:Number(m.p03),actual:Number(m.actual),plan:Number(m.plan),reason:m.reason||'',closed:i<b.closed,value:i<b.closed?round2(b.source==='manual'?Number(m.actual):money(list.map(p=>p.amountUSD))):Number(m.plan)}});const p03=round2(money(months.map(m=>m.p03))),actual=round2(money(months.filter(m=>m.closed).map(m=>m.actual))),plan=round2(money(months.filter(m=>!m.closed).map(m=>m.plan))),total=round2(actual+plan);const missing=b.source==='payments'?payments.filter(p=>{const when=monthOf(p);return p.request_id&&!!when&&when.year===String(b.year)&&when.month<=b.closed&&p.amountUSD==null}).length:0;return{year:b.year,closed:b.closed,source:b.source,months,p03,actual,plan,total,missing,variance:round2(total-p03),status:missing?'INCOMPLETE':total<=p03?'PASS':'FAIL'};}
const emptyKpis=()=>({total:0,completed:0,cancel:0,unpaid:0,repair:{total:0,waitingPrice:0,late:0,missingDate:0,rejected:0,byStep:{}},service:{total:0,beforeApp:0,contract:0,sign:0,payWait:0}});
function defaultDbPath(){if(process.env.MRO_APS_DB)return process.env.MRO_APS_DB;return path.join(__dirname,'../../../.runtime','aps','aps.sqlite');}
// Nguồn GR thật cho biểu đồ OH Repair là SQL Server (EQM_MRO_REPAIR + EQM_MRO_SERVICE), đọc qua
// public adapter sql.readApsOH(). Từ 09/11/2026 toàn bộ tab Repair & Service cũng đọc/ghi SQL
// (sql.readApsRows / sql.writeApsRow); SQLite chỉ còn giữ ngân sách P03/Actual nhập tay.
// Cache SQL riêng (mặc định 30s, lỗi thử lại sau 5s) vì Overview poll 5s; lỗi SQL không tạo số giả.
const USD_RATE=26000;
// 16/11/2026 (người dùng chốt): nút "Tải toàn bộ dữ liệu" ở tab Repair & Service -> Excel 2 sheet Repair / Service.
// Lấy đúng các hàng SQL của action aps-rows (EQM_MRO_REPAIR + EQM_MRO_SERVICE), kể cả dòng thanh toán "TT", đặt lại
// TÊN CỘT GỐC của bảng SQL; thêm cột "(Portal)" ghi loại dòng / bước Jig / trạng thái Request mà màn hình đang hiện.
// Chỉ đọc, không cache, không ghi. Số đọc được thì đổi sang số; chuỗi không đọc được giữ nguyên (không thay bằng 0).
const EXPORT_COMMON_HEAD=[['No','No'],['RequestId','Request ID'],['RequestDate','Request date'],['Vendor','Vendor APS'],['CostCenter','Cost Center'],['Model','Model / Project'],['Pic','Pic request']];
const EXPORT_MONEY=[['Qty',"Q'ty"],['EstimatedCost','Estimated cost'],['FinalPrice','Final price'],['FinalUSD','Final Price (USD)'],['Amount','Amount'],['AmountUSD','Amount 2 (USD)']];
const EXPORT_PAY=[['PaymentStatus','Payment Status'],['MonthPayment','Month Payment'],['YearPayment','Year Payment'],['Remark','Remark']];
const EXPORT_EXTRA=[['RejectDate','Reject date'],['RejectReason','Reject reason'],['Buyer','Buyer'],['IBM','IBM'],['UpdatedAt','UpdatedAt'],['UpdatedBy','UpdatedBy']];
const EXPORT_COLUMNS={
 R:[...EXPORT_COMMON_HEAD,['BQMSCode','BQMS code'],['JigName','Jig /Eqm Name'],['Fault','Current Status / Fault'],['DetailRequest','Detail Request'],['ServiceCode','Service code'],['VendorRepair','Vendor Repair'],['NoteOfService','Note of service'],...EXPORT_MONEY,['Cur','Currency'],['Local','Local/Oversea'],['GL','GL'],['PO','PO NO'],['WRB','WRB request'],['PurAccept','Pur accept'],['PriceConfirmDate','Price confirm date'],...EXPORT_PAY,...EXPORT_EXTRA],
 S:[...EXPORT_COMMON_HEAD,['ServiceType','Type'],['StatusRequest','Current Status / Request'],['VendorRepair','Vendor Repair'],...EXPORT_MONEY,['Cur','Cur'],['Local','Local/Oversea'],['GL','GL'],['StartDate','Start date'],['EndDate','End Date'],['BeforeApproval','Before approval'],['Contract','Contract'],['ContractSigned','Contract signed'],['ContractNo','ContractNo'],...EXPORT_PAY,...EXPORT_EXTRA]
};
const EXPORT_NUMERIC=new Set(['No','Qty','EstimatedCost','FinalPrice','FinalUSD','Amount','AmountUSD','MonthPayment','YearPayment']);
const exportValue=(alias,value)=>{if(value===null||value===undefined)return '';const raw=String(value).trim();if(!EXPORT_NUMERIC.has(alias)||!raw)return raw;const plain=raw.replace(/,/g,'');return /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(plain)&&Number.isFinite(Number(plain))?Number(plain):raw;};
function exportSheets(payload,asOf=today()){
 const rows=Array.isArray(payload&&payload.rows)?payload.rows:[],{requests}=mapRows(payload||{});
 const groupKey=(src,row)=>src+':'+(String(row.RequestId??row.requestId??'').trim()||'NO-'+String(row.No??row.no??'').trim());
 const statusOf=new Map(),stepOf=new Map();
 for(const r of requests){const key=groupKey(r.src,r);statusOf.set(key,requestStatus(r));for(const line of r.lines||[])stepOf.set(key+':'+String(line.no),LINE_STATUS_VI[lineStatus(line)]||'');}
 const build=src=>{const columns=EXPORT_COLUMNS[src],list=[];
  for(const row of rows){if((String(row.Src??'').trim().toUpperCase()==='S'?'S':'R')!==src)continue;const key=groupKey(src,row),payment=isPaymentRow(row,src);
   const out=Object.fromEntries(columns.map(([alias,label])=>[label,exportValue(alias,row[alias])]));
   out['Loại dòng (Portal)']=payment?'Thanh toán (TT)':src==='R'?'Jig':'Service';
   if(src==='R')out['Bước Jig (Portal)']=payment?'':stepOf.get(key+':'+String(Number(String(row.No??'').replace(/,/g,''))||0))||'';
   out['Trạng thái Request (Portal)']=statusOf.get(key)||'';list.push(out);}
  list.sort((a,b)=>(Number(a.No)||0)-(Number(b.No)||0));
  return{name:src==='R'?'Repair':'Service',columns:[...columns.map(([,label])=>label),'Loại dòng (Portal)',...(src==='R'?['Bước Jig (Portal)']:[]),'Trạng thái Request (Portal)'],rows:list};};
 return{asOf,sheets:[build('R'),build('S')],extras:payload&&payload.extras===true,missing:Array.isArray(payload&&payload.missing)?payload.missing:[]};
}
function createAps({dbPath,now=()=>Date.now(),cacheMs=5000,ohCacheMs=30000,sql,open}={}){
 const file=dbPath||defaultDbPath();
  let cache=null,cacheAt=0,flight=null,coldUntil=0,ohCache=null,ohNext=0,ohFlight=null,hasLiveCache=false;
 const round=n=>Math.round((Number(n)||0)*100)/100;
 async function ohSource(){
  if(!sql||typeof sql.readApsOH!=='function')return{available:false,connected:false,gr:[],plan:[],warning:'Chưa cấu hình kết nối SQL cho nguồn OH Repair.'};
  if(ohCache&&now()<ohNext)return ohCache;
  if(ohFlight)return ohFlight;
  const job=(async()=>{
   try{
    const raw=await sql.readApsOH();
    const gr=raw&&Array.isArray(raw.gr)?raw.gr:[];
    const plan=raw&&Array.isArray(raw.plan)?raw.plan:[];
    const payload={available:true,connected:true,asOf:today(),degraded:false,warning:'',
     gr:gr.filter(g=>g&&Number.isInteger(Number(g.year))&&Number.isInteger(Number(g.month))).map(g=>({year:Number(g.year),month:Number(g.month),amountUSD:round(g.amount),rows:Number(g.rows)||0})),
     plan:plan.filter(p=>p&&Number.isInteger(Number(p.year))&&Number.isInteger(Number(p.month))).map(p=>({year:Number(p.year),month:Number(p.month),currency:String(p.currency||'').trim().toUpperCase(),version:String(p.version||''),amountUSD:round(String(p.currency||'').trim().toUpperCase()==='VND'?(Number(p.amount)||0)/USD_RATE:(Number(p.amount)||0))}))};
    ohCache=payload;ohNext=now()+ohCacheMs;return payload;
   }catch(error){
    const message='Không đọc được OH Repair từ SQL Server: '+((error&&error.message)||error);
    const payload=ohCache?{...ohCache,degraded:true,warning:message}:{available:true,connected:false,gr:[],plan:[],degraded:true,warning:message};
    ohNext=now()+Math.min(5000,ohCacheMs);return payload;
   }
  })().finally(()=>{ohFlight=null;});
  ohFlight=job;return job;
 }
 const openDb=open||(()=>new DatabaseSync(file,{readOnly:true}));
 // SQLite chỉ còn được đọc cho ngân sách P03/Actual nhập tay (bảng budgets) — chưa có bảng SQL.
 // requests/payments của tab Repair & Service lấy từ SQL Server (xem sql-store.cjs).
 function readBudgets(){try{const db=openDb();try{return db.prepare('SELECT year,body FROM budgets ORDER BY year DESC').all().map(row=>{try{return JSON.parse(row.body);}catch{return null;}}).filter(Boolean);}finally{try{db.close();}catch{}};}catch{return[];}}
 async function build(){
  if(!sql||typeof sql.readApsRows!=='function')throw fail(503,'Chưa cấu hình kết nối SQL — lưu kết nối trong mục Cài đặt SQL (developer) rồi tải lại tab Repair & Service.');
  const{requests,payments,extras,warnings,missing:missingColumns,rows:sqlRows}=mapRows(await sql.readApsRows());
  const budgets=readBudgets();
  const day=today();
  const paymentsByRequest=new Map();for(const p of payments){if(!paymentsByRequest.has(p.request_id))paymentsByRequest.set(p.request_id,[]);paymentsByRequest.get(p.request_id).push(p);}
  const kpis=emptyKpis();const rows=[];
  for(const r of requests){
   const status=requestStatus(r),flags=pendingFlags(r,day),lines=r.lines||[];
   const row={id:r.id,type:r.type,vendor:r.vendor||'',model:r.model||'',item:r.type==='Repair'?lines.map(line=>line.name).filter(Boolean).join(', '):(r.item||''),pic:r.pic||'',date:r.date||'',currency:r.currency||'USD',est:Number(r.est)||0,actualCost:Number(r.actualCost)||0,payment:r.payment||'Pending',paymentMonth:r.paymentMonth||'',paymentYear:r.paymentYear||'',serviceType:r.serviceType||'',vendorRepair:r.vendorRepair||'',qty:Number(r.qty)||0,finalPrice:Number(r.finalPrice)||0,finalUSD:Number(r.finalUSD)||0,amount:Number(r.amount)||0,amount2USD:Number(r.amount2USD)||0,start:r.start||'',end:r.end||'',status,color:statusColor(status),pending:flags,worklist:worklistFlags(r),updated:r.updated||'',updatedAt:r.updatedAt||'',author:r.author||'',lines:r.type==='Repair'?lines.map(line=>({name:line.name,qty:Number(line.qty)||0,serviceCode:line.serviceCode||'',vendorRepair:line.vendorRepair||'',serviceType:line.serviceType||'',wrb:line.wrb||'',accept:line.accept||'',priceDate:line.priceDate||'',poNo:line.poNo||'',finalPrice:Number(line.finalPrice)||0,amount:Number(line.amount)||0,amount2USD:Number(line.amount2USD)||0,rejectDate:line.rejectDate||'',step:LINE_STATUS_VI[lineStatus(line)]||'—',no:Number(line.no)||0,bqms:line.bqms||'',buyer:line.buyer||'',rejectReason:line.rejectReason||'',purReset:line.purReset||'',status:lineStatus(line)})):[],contract:r.type==='Service'?{beforeApproval:!!r.beforeApproval,created:!!r.contractCreated,signed:!!r.contractSigned,contractNo:r.contractNo||'',contractFile:r.contractFile||''}:null,payments:(paymentsByRequest.get(r.id)||[]).map(p=>({date:p.date||'',amount:Number(p.amount)||0,currency:p.currency||'USD',amountUSD:p.amountUSD==null?null:Number(p.amountUSD),reference:p.reference||''}))};
   rows.push(row);
   kpis.total++;kpis.unpaid+=flags.unpaid?1:0;kpis.completed+=r.payment==='Completed'?1:0;kpis.cancel+=r.payment==='Cancel'?1:0;
   if(r.type==='Repair'){const k=kpis.repair;k.total++;k.waitingPrice+=flags.waiting?1:0;k.late+=flags.late?1:0;k.missingDate+=flags.missingDate?1:0;k.rejected+=flags.rejected?1:0;for(const step of flags.steps||[])k.byStep[step]=(k.byStep[step]||0)+1;}
   else if(r.type==='Service'){const k=kpis.service;k.total++;if(status==='Pending Before APP')k.beforeApp++;else if(status==='Pending Contract')k.contract++;else if(status==='Pending Sign Contract')k.sign++;else if(status==='Chờ Thanh Toán')k.payWait++;}
  }
  const budget=budgets.length?outlook(budgets[0],payments,requests):null;
  const payload={connected:true,fromCache:false,error:'',asOf:day,source:'aps-sql',sqlRows,extras:extras===true,missingColumns:Array.isArray(missingColumns)?missingColumns:[],sourceWarnings:warnings,kpis,requests:rows,budget,warning:warnings.join(' ')};
  payload.sql=await ohSource();
  return payload;
 }
 function snapshot(force=false){
  if(!force&&cache&&now()-cacheAt<cacheMs)return Promise.resolve(cache);
  if(!force&&now()<coldUntil&&cache)return Promise.resolve(cache);
  if(!force&&flight)return flight;
  const job=Promise.resolve().then(build).then(payload=>{cache=payload;hasLiveCache=true;cacheAt=now();return payload;}).catch(error=>{coldUntil=now()+cacheMs;const message='Không đọc được Repair & Service từ SQL Server'+(error&&error.sqlAction?' (bước '+error.sqlAction+')':'')+': '+((error&&error.message)||error);const payload=hasLiveCache?{...cache,fromCache:true,error:message,warning:message}:{connected:false,fromCache:false,error:message,asOf:today(),kpis:emptyKpis(),requests:[],budget:null,warning:message};cache=payload;cacheAt=now();return payload;});
  if(!force)flight=job.finally(()=>{flight=null;});
  return job;
 }
 async function live(data){return{...data,aps:await snapshot()};}
 async function handle({req,res,url,actor,body,send}){
  if(url.pathname==='/api/aps-edit'){
   // 09/11/2026 (phương án C): một route ghi duy nhất cho tab Repair & Service, ghi thẳng SQL qua
   // action aps-row-write (chỉ UPDATE/INSERT trên EQM_MRO_REPAIR/EQM_MRO_SERVICE). Session/CSRF/
   // viewer/vendor đã chặn ở server/auth.cjs; kiểm tra lại ở đây để module không phụ thuộc thứ tự route.
   if(req.method!=='POST')throw fail(405,'Chỉ hỗ trợ POST /api/aps-edit.');
   if(!actor||!['user','admin','supervisor','developer'].includes(actor.role))throw fail(403,'Tài khoản không đủ quyền sửa Repair & Service.');
   if(actor.vendorScope)throw fail(403,'Tài khoản Vendor chỉ được xem màn Repair & Service.');
   if(!sql||typeof sql.writeApsRow!=='function')throw fail(503,'Chưa cấu hình kết nối SQL để ghi Repair & Service.');
   const entry=validateWrite(await body(req));
   await sql.writeApsRow({...entry,actor:String(actor.username||actor.name||'').slice(0,80)});
   cache=null;hasLiveCache=false;cacheAt=0;coldUntil=0;flight=null;// bỏ cache để phản hồi mang dữ liệu SQL vừa ghi
   send(res,200,{ok:true,aps:await snapshot(true)});return true;
  }
  if(url.pathname==='/api/aps-export'){
   // Cùng quy tắc tải dữ liệu của /api/download-data: Viewer và tài khoản Vendor không được tải dữ liệu nội bộ.
   if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ GET /api/aps-export.');
   if(!actor||actor.role==='viewer')throw fail(403,'Viewer không được tải dữ liệu.');
   if(actor.vendorScope)throw fail(403,'Tài khoản Vendor không được tải dữ liệu nội bộ.');
   if(!sql||typeof sql.readApsRows!=='function')throw fail(503,'Chưa cấu hình kết nối SQL — không tải được dữ liệu Repair & Service.');
   send(res,200,exportSheets(await sql.readApsRows()));return true;
  }
  if(url.pathname!=='/api/aps-live')return false;
  if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ đọc dữ liệu APS.');
  send(res,200,await snapshot(true));return true;
 }
 return{handle,live,snapshot,defaultPath:file};
}
module.exports={createAps,exportSheets,requestStatus,statusColor,pendingFlags,worklistFlags,outlook,lineStatus,LINE_STEPS,LINE_STATUS_VI};

