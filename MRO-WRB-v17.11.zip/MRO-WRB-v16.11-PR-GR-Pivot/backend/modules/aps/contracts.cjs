const fail=(status,message)=>Object.assign(new Error(message),{status});
// Hợp đồng dịch vụ (EQM_MRO_ServiceContract trên SQL Server): CRUD hẹp cho panel Repair & Service.
// 06/11/2026: PDF lưu trực tiếp trong SQL (cột PdfData varbinary(MAX) + PdfName/PdfSize/PdfUploadedAt/PdfUploadedBy),
// một PDF cho mỗi Số hợp đồng; portal không còn giữ file hay metadata PDF trên đĩa.
// GET cho mọi phiên đã đăng nhập (kể cả viewer); POST/PUT/upload PDF chỉ admin trở lên.
// DELETE chỉ trả các cột Pdf* về NULL, không bao giờ xóa bản ghi hợp đồng.
const ranks={viewer:0,user:1,admin:2,supervisor:3,developer:4};
// 30 MB theo yêu cầu người dùng 06/11/2026 (trước đây 10 MB vì cap stdout worker chỉ 20 MB).
// Cả chuỗi phải đủ rộng cho 30 MB: sql/index.cjs nâng cap stdout riêng cho hai action PDF lên 64 MB
// và deadline 5 phút; worker.ps1 nâng CommandTimeout riêng lên 300 giây; create-server.cjs nâng
// server.requestTimeout lên 5 phút để thân bài upload không bị cắt giữa chừng ("Failed to fetch").
const MAX_PDF=30*1024*1024;
const clean=value=>String(value===null||value===undefined?'':value).trim();
// 09/11/2026: PDF nhận diện theo ISO 32000-1 — chuỗi "%PDF-" xuất hiện trong 1 KB đầu file, đúng cách
// Acrobat/Chrome mở tài liệu (PDF thật có BOM EF BB BF hoặc ký tự rác trước chữ ký vẫn là PDF chuẩn).
// CÙNG NGÀY, theo quyết định của người dùng: Portal KHÔNG từ chối file vì sai định dạng — hợp đồng có thể
// là bản bị NASCA/Trend Micro DRM mã hóa hoặc Word/Excel/ảnh. Mọi định dạng đều được lưu NGUYÊN BYTE và
// tải về đúng nguyên văn; chỉ chặn file rỗng và vượt 30 MB. Định dạng nhận được báo lại để người dùng biết.
const PDF_SIGNATURE='%PDF-',PDF_SIGNATURE_WINDOW=1024;
const isPdf=data=>data.length>=PDF_SIGNATURE.length&&data.subarray(0,Math.min(data.length,PDF_SIGNATURE_WINDOW)).includes(PDF_SIGNATURE);
const fmtBytes=size=>size>=1048576?(size/1048576).toFixed(1)+' MB':Math.max(1,Math.round(size/1024))+' KB';
// Nhận dạng "best effort" chỉ để mô tả file đã lưu (DRM công ty, Word/Excel, ảnh), không phải kết luận
// tuyệt đối và không còn là điều kiện chặn upload.
const FILE_KINDS=[
  [/^\x50\x4b\x03\x04/,'định dạng ZIP/Office mới (DOCX, XLSX, PPTX) hoặc file ZIP'],
  [/^\xD0\xCF\x11\xE0/,'định dạng Office đời cũ (DOC, XLS, PPT)'],
  [/^NASCA/,'tài liệu bị NASCA DRM của công ty bảo vệ — chỉ mở được trên máy có client DRM'],
  [/^%TSD/,'tài liệu bị Trend Micro SecureDoc mã hóa — chỉ mở được trên máy có client DRM'],
  [/^\x4D\x5A/,'file chương trình Windows (EXE/DLL)'],
  [/^\x89\x50\x4E\x47/,'ảnh PNG'],
  [/^\xFF\xD8\xFF/,'ảnh JPEG'],
  [/^%!PS/,'PostScript (.ps/.eps)'],
  [/^(<\?xml|<html|<!DOCTYPE|\{)/i,'văn bản/XML/HTML']
];
function describeFile(data){
  if(isPdf(data))return {kind:'pdf',note:''};
  const head=data.subarray(0,16),text=head.toString('latin1');
  const preview=(head.toString('hex').toUpperCase().match(/../g)||[]).join(' ');
  const known=FILE_KINDS.find(([pattern])=>pattern.test(text));
  return {kind:'other',note:`File không phải PDF chuẩn (16 byte đầu: ${preview} — ${known?known[1]:'không nhận dạng được định dạng'}). File được lưu nguyên byte và tải về đúng nguyên văn.`};
}
function createApsContracts({runtime,sql,now=()=>new Date(),maxPdf=MAX_PDF}={}){
  if(!sql)throw Error('createApsContracts cần sql adapter của Repair & Service.');
  let pdfSchemaReady=true;
  const canManage=actor=>ranks[actor&&actor.role]>=2;
  const dateOrNull=(value,label)=>{const text=clean(value);if(!text)return null;if(!/^\d{4}-\d{2}-\d{2}$/.test(text)||Number.isNaN(Date.parse(text+'T00:00:00Z')))throw fail(400,label+' không đúng định dạng ngày (YYYY-MM-DD).');return text;};
  const pdfInfo=row=>row.pdfName?{name:String(row.pdfName),size:Number(row.pdfSize)||0,uploadedAt:row.pdfUploadedAt||null,uploadedBy:row.pdfUploadedBy||null}:null;
  // 06/11/2026: lỗi ghi SQL (ràng buộc CHECK, quyền INSERT, thiếu cột) phải đến được người dùng kèm nguyên nhân.
  // Lỗi 4xx tự nó đã có thông điệp rõ nên giữ nguyên; chỉ các lỗi 5xx được thêm ngữ cảnh thao tác.
  const wrap=async(prefix,task)=>{try{return await task()}catch(error){if(error&&Number.isInteger(error.status)&&error.status<500)throw error;throw fail(502,prefix+String(error&&error.message||'lỗi không rõ').slice(0,400));}};
  async function list(){
    const rows=await sql.readApsContracts();
    if(rows.pdfColumns===true||rows.pdfColumns===false)pdfSchemaReady=rows.pdfColumns===true;
    return rows.map(row=>({...row,pdf:pdfInfo(row)}));
  }
    // 06/11/2026: không bao giờ hủy socket khi từ chối file quá lớn — req.destroy() trước đây khiến
  // trình duyệt chỉ nhận "Failed to fetch" mà không thấy lý do thật. Ngừng giữ byte, thoát hết phần
  // body còn lại (req.resume) rồi trả 413 kèm giới hạn và dung lượng thực tế; content-length sai
  // lệch bị chặn sớm ngay từ header.
  function readRaw(req,limit){
    const overLimit=size=>fail(413,'File PDF vượt giới hạn '+Math.round(limit/1048576)+' MB (file gửi lên '+Math.ceil(size/1048576)+' MB). Hãy nén hoặc tách PDF nhỏ hơn.');
    return new Promise((resolve,reject)=>{
      const declared=Number(req.headers&&req.headers['content-length']||0);
      if(declared>limit){if(typeof req.resume==='function')req.resume();reject(overLimit(declared));return;}
      const chunks=[];let size=0,rejected=false;
      req.on('data',chunk=>{if(rejected)return;size+=chunk.length;if(size>limit){rejected=true;chunks.length=0;if(typeof req.resume==='function')req.resume();reject(overLimit(size));return;}chunks.push(chunk);});
      req.on('end',()=>{if(!rejected)resolve(Buffer.concat(chunks));});
      req.on('error',error=>{if(!rejected)reject(error);});
    });
  }
  function parseMultipart(buffer,contentType){
    const match=/boundary=(?:"([^"]+)"|([^;]+))/i.exec(String(contentType||''));
    if(!match)throw fail(400,'Thiếu boundary multipart/form-data.');
    const boundary=Buffer.from('--'+(match[1]||match[2]).trim());
    const fields={},files=[];
    let start=buffer.indexOf(boundary);
    while(start>=0){
      const next=buffer.indexOf(boundary,start+boundary.length);
      if(next<0)break;
      let part=buffer.slice(start+boundary.length,next);
      if(part[0]===13&&part[1]===10)part=part.slice(2);
      const headerEnd=part.indexOf('\r\n\r\n');
      if(headerEnd>=0){
        const head=part.slice(0,headerEnd).toString('utf8');
        const nameM=/name="([^"]*)"/i.exec(head),fileM=/filename="([^"]*)"/i.exec(head);
        let data=part.slice(headerEnd+4);
        if(data.length>=2&&data[data.length-2]===13&&data[data.length-1]===10)data=data.slice(0,data.length-2);
        if(fileM)files.push({name:fileM[1],data});
        else if(nameM)fields[nameM[1]]=data.toString('utf8');
      }
      start=next;
    }
    return {fields,files};
  }
  async function handle({req,res,url,actor,body,send}){
    if(url.pathname!=='/api/aps/contracts'&&url.pathname!=='/api/aps/contracts/pdf')return false;
    const method=req.method;
    if(method==='GET'){
      if(url.pathname==='/api/aps/contracts'){send(res,200,{contracts:await list(),canManage:canManage(actor),pdfSchemaReady});return true;}
      const contractNo=clean(url.searchParams.get('no'));
      if(!contractNo)throw fail(400,'Thiếu số hợp đồng.');
      const file=await sql.readApsContractPdf(contractNo);
      if(!file||!file.data||!file.data.length)throw fail(404,'Hợp đồng này chưa có file đính kèm trong SQL.');
      // 09/11/2026: file có thể không phải PDF (bản DRM, Word/Excel, ảnh) — vẫn trả đủ byte, chỉ khác
      // Content-Type để trình duyệt tải về thay vì thử mở trong tab. Không còn 502 vì sai định dạng.
      const name=/\.[A-Za-z0-9]{1,8}$/.test(file.name||'')?file.name:`${contractNo}.pdf`;
      res.writeHead(200,{'Content-Type':isPdf(file.data)?'application/pdf':'application/octet-stream','Content-Length':file.data.length,'Content-Disposition':`attachment; filename*=UTF-8''${encodeURIComponent(name)}`,'Cache-Control':'no-store'});
      res.end(req.method==='HEAD'?undefined:file.data);
      return true;
    }
    if(method==='POST'&&url.pathname==='/api/aps/contracts'){
      if(!canManage(actor))throw fail(403,'Chỉ Admin trở lên được thêm hợp đồng.');
      const b=await body(req);
      const contractNo=clean(b.contractNo),vendor=clean(b.vendor);
      if(!contractNo||contractNo.length>100)throw fail(400,'Số hợp đồng không hợp lệ (tối đa 100 ký tự).');
      if(!vendor||vendor.length>200)throw fail(400,'Vendor không hợp lệ (tối đa 200 ký tự).');
      const effectiveDate=dateOrNull(b.effectiveDate,'Ngày hiệu lực'),expiryDate=dateOrNull(b.expiryDate,'Ngày hết hạn');
      const result=await wrap('Không thêm được hợp đồng vào SQL: ',()=>sql.addApsContract({contractNo,vendor,effectiveDate,expiryDate,actor:actor.username}));
      if(result.duplicate)throw fail(409,`Số hợp đồng "${contractNo}" đã tồn tại.`);
      send(res,201,{ok:true,no:result.no,verified:result.verified===true,contracts:await list()});
      return true;
    }
    if(method==='PUT'&&url.pathname==='/api/aps/contracts'){
      if(!canManage(actor))throw fail(403,'Chỉ Admin trở lên được sửa hợp đồng.');
      const b=await body(req);
      const no=Number(b.no);
      if(!Number.isInteger(no)||no<=0)throw fail(400,'Hợp đồng không hợp lệ.');
      const vendor=clean(b.vendor);
      if(!vendor||vendor.length>200)throw fail(400,'Vendor không hợp lệ (tối đa 200 ký tự).');
      const effectiveDate=dateOrNull(b.effectiveDate,'Ngày hiệu lực'),expiryDate=dateOrNull(b.expiryDate,'Ngày hết hạn');
      const result=await wrap('Không cập nhật được hợp đồng trong SQL: ',()=>sql.updateApsContract({no,vendor,effectiveDate,expiryDate}));
      if(!result.updated)throw fail(404,'Không tìm thấy hợp đồng để cập nhật.');
      send(res,200,{ok:true,contracts:await list()});
      return true;
    }
    if(method==='POST'&&url.pathname==='/api/aps/contracts/pdf'){
      if(!canManage(actor))throw fail(403,'Chỉ Admin trở lên được tải lên PDF hợp đồng.');
      if(!/multipart\/form-data/i.test(String(req.headers['content-type']||'')))throw fail(415,'Upload file phải gửi multipart/form-data (body JSON bị chặn ở 500 KB nên không dùng cho file).');
      const raw=await readRaw(req,maxPdf+65536);
      const {fields,files}=parseMultipart(raw,req.headers['content-type']);
      const contractNo=clean(fields.no);
      const file=files[0];
      if(!file||!file.name)throw fail(400,'Thiếu file đính kèm.');
      const name=clean(file.name).slice(0,180);
      const data=file.data;
      if(!contractNo)throw fail(400,'Thiếu số hợp đồng.');
      if(!data.length)throw fail(400,'File rỗng.');
      if(data.length>maxPdf)throw fail(413,`File vượt quá giới hạn ${Math.round(maxPdf/1048576)} MB.`);
      // 09/11/2026 (quyết định người dùng): KHÔNG chặn theo định dạng — hợp đồng có thể là bản bị DRM
      // mã hóa hoặc Word/Excel/ảnh. File được lưu nguyên byte; chỉ mô tả lại những gì nhận được.
      const kind=describeFile(data);
      if(!pdfSchemaReady)throw fail(501,'Bảng EQM_MRO_ServiceContract chưa có cột PDF. Chạy npm run aps:ensure-schema trên máy chủ có kết nối SQL.');
      const saved=await wrap('Không lưu được PDF vào SQL: ',()=>sql.writeApsContractPdf({contractNo,name,data,actor:actor.username}));
      if(saved.missing)throw fail(404,`Không tìm thấy hợp đồng "${contractNo}" trong SQL.`);
      send(res,201,{ok:true,contracts:await list(),pdfSchemaReady,fileKind:kind.kind,fileKindNote:kind.note});
      return true;
    }
    if(method==='DELETE'&&url.pathname==='/api/aps/contracts/pdf'){
      /* Xóa PDF: trả các cột Pdf* về NULL. Không bao giờ xóa bản ghi hợp đồng trong SQL. */
      if(!canManage(actor))throw fail(403,'Chỉ Admin trở lên được xóa PDF hợp đồng.');
      const contractNo=clean(url.searchParams.get('no'));
      if(!contractNo)throw fail(400,'Thiếu số hợp đồng.');
      if(!pdfSchemaReady)throw fail(501,'Bảng EQM_MRO_ServiceContract chưa có cột PDF. Chạy npm run aps:ensure-schema trên máy chủ có kết nối SQL.');
      const cleared=await wrap('Không xóa được PDF trong SQL: ',()=>sql.clearApsContractPdf({contractNo}));
      if(!cleared.updated)throw fail(404,`Không tìm thấy hợp đồng "${contractNo}" trong SQL.`);
      send(res,200,{ok:true,contracts:await list(),pdfSchemaReady});
      return true;
    }
    throw fail(405,'Hợp đồng dịch vụ chỉ hỗ trợ GET/POST/PUT và DELETE PDF.');
  }
  return {handle,list,canManage};
}
module.exports={createApsContracts,ranks,MAX_PDF};
