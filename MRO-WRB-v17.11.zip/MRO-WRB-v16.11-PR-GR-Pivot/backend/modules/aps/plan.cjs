const fail=(status,message)=>Object.assign(new Error(message),{status});
// Monthly Plan (EQM_MRO_ServiceMonthlyPlan trên SQL Server): estimate tổng theo tháng cho Repair & Service.
// Mỗi lần lưu tạo PHIÊN BẢN MỚI (V1, V2…) theo UNIQUE(PlanID, Year, Month, Version); PlanID là hằng nhóm = 1
// do server ấn định (không nhận từ client). GET cho mọi phiên đã đăng nhập (kể cả viewer); POST chỉ admin trở lên.
// Không PUT/DELETE — sai số sửa bằng cách lưu phiên bản mới; worker SQL giữ INSERT-only.
const ranks={viewer:0,user:1,admin:2,supervisor:3,developer:4};
function createApsPlan({sql}={}){
  if(!sql)throw Error('createApsPlan cần sql adapter của Repair & Service.');
  const canManage=actor=>ranks[actor&&actor.role]>=2;
  const normalize=rows=>rows.map(r=>({no:Number(r.No),planId:Number(r.PlanID),year:Number(r.Year),month:Number(r.Month),amount:r.PlanAmount==null?null:Number(r.PlanAmount),currency:String(r.Currency||'').trim(),version:String(r.Version||'').trim(),yearMonth:String(r.YearMonth||''),createdAt:r.CreatedAt||null,createdBy:r.CreatedBy||null,updatedAt:r.UpdatedAt||null}));
  async function list(){
    const plan=normalize(await sql.readApsPlan());
    const latest={};
    for(const row of plan){
      const key=row.year+'-'+String(row.month).padStart(2,'0');
      const versionNumber=Number(/^V(\d+)$/.exec(row.version)?.[1]||0);
      const current=latest[key];
      if(!current||versionNumber>current.versionNumber)latest[key]={...row,versionNumber};
    }
    return {plan,latest:Object.fromEntries(Object.entries(latest).map(([key,{versionNumber,...row}])=>[key,row]))};
  }
  async function handle({req,res,url,actor,body,send}){
    if(url.pathname!=='/api/aps/plan')return false;
    const method=req.method;
    if(method==='GET'){
      send(res,200,{ok:true,...await list(),canManage:canManage(actor)});
      return true;
    }
    if(method==='POST'){
      if(!canManage(actor))throw fail(403,'Chỉ Admin trở lên được cập nhật Monthly Plan.');
      const b=await body(req);
      const year=Number(b.year),month=Number(b.month),amount=Number(b.amount),currency=String(b.currency||'').trim().toUpperCase();
      if(!Number.isInteger(year)||year<2000||year>2100)throw fail(400,'Năm kế hoạch không hợp lệ (2000–2100).');
      if(!Number.isInteger(month)||month<1||month>12)throw fail(400,'Tháng kế hoạch không hợp lệ (1–12).');
      if(!Number.isFinite(amount)||amount<0||amount>=1e15)throw fail(400,'Số tiền kế hoạch không hợp lệ.');
      if(!['USD','VND'].includes(currency))throw fail(400,'Loại tiền kế hoạch chỉ nhận USD hoặc VND.');
      const result=await sql.addApsPlan({year,month,amount,currency,actor:actor.username});
      send(res,201,{ok:true,no:result.no,version:result.version,...await list(),canManage:true});
      return true;
    }
    throw fail(405,'Monthly Plan chỉ hỗ trợ GET/POST — mỗi lần lưu tự tạo phiên bản mới.');
  }
  return {handle,list,canManage};
}
module.exports={createApsPlan,ranks};