// Bridge Portal APS đầy đủ chức năng (ported từ APS repair service Potal_ 4/server.mjs → ./app/core.mjs).
// Toàn bộ API APS chạy dưới /api/aps-app/* SAU khi auth WRB đã kiểm tra session/CSRF/role/viewer.
// Danh tính WRB được ánh xạ vào users/sessions SQLite nội bộ APS (server-side, không tin client).
// Đăng nhập/tài khoản/mật khẩu KHÔNG còn ở APS — do portal MRO WRB quản lý (các route đó trả 410).
const crypto = require('node:crypto');
const path = require('node:path');
const fs = require('node:fs');

const PREFIX = '/api/aps-app';
const BLOCKED_EXACT = ['/api/setup', '/api/login', '/api/register', '/api/forgot-password', '/api/reset-password', '/api/reset-password-token', '/api/profile'];
const BLOCKED_PREFIX = ['/api/users', '/api/registrations', '/api/reset-requests'];

// 09/11/2026: tài khoản Vendor (có vendorScope) chỉ ĐỌC ở mọi màn ngoài màn Vendor — iframe Repair &
// Service cũng phải read-only. Gán 'viewer' để core APS tự từ chối ghi (editor = admin|pic), không
// chỉ trông chờ vào whitelist "Tài khoản Vendor" trong server/auth.cjs. Người dùng WRB bình thường
// (role user, không vendorScope) vẫn là 'pic' như cũ.
function legacyRole(role, vendorScoped = false) {
  if (vendorScoped) return 'viewer';
  if (role === 'developer' || role === 'supervisor' || role === 'admin') return 'admin';
  if (role === 'user') return 'pic';
  return 'viewer';
}

function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

// APS định nghĩa users.username UNIQUE. DB sau di trú đã có sẵn tài khoản của portal cũ
// (id là UUID thật), nên INSERT một id "wrb-…" mới cho cùng username sẽ phá UNIQUE và
// mọi request /api/aps-app/* chết → tab Repair & Service trắng. Phải tra và dùng lại id cũ.
function findLegacyId(store, username) {
  if (!store || typeof store.one !== 'function') return null;
  const row = store.one('SELECT id FROM users WHERE username=? COLLATE NOCASE', username);
  return row && row.id ? row.id : null;
}

// WRB là nguồn danh tính: tạo mới hoặc dùng lại dòng users, luôn bật active, đồng bộ name/role,
// không đụng password (giữ hash cũ vì APS không còn tự đăng nhập). Trả sid/csrf nội bộ APS.
function bridgeIdentity(app, actor, username) {
  const name = String(actor.name || actor.username).slice(0, 80), role = legacyRole(actor.role, !!actor.vendorScope);
  let id = findLegacyId(app.store, username) || ('wrb-' + sha256(username).slice(0, 20));
  try {
    app.store.run(
      'INSERT INTO users(id,username,name,role,password,active) VALUES(?,?,?,?,?,1) ON CONFLICT(id) DO UPDATE SET name=excluded.name,role=excluded.role,active=1',
      id, username, name, role, 'sso-wrb-managed:' + sha256('aps-app-password:' + id));
  } catch (e) {
    const raced = findLegacyId(app.store, username); // vẫn va UNIQUE (khác hoa/thường, ghi đồng thời)
    if (!raced) throw Error('Không chuẩn bị được tài khoản APS: ' + ((e && e.message) || e));
    id = raced;
    app.store.run('UPDATE users SET name=?,role=?,active=1 WHERE id=?', name, role, id);
  }
  const sid = sha256('aps-app-session:' + id), csrf = sha256('aps-app-csrf:' + id);
  try {
    app.store.run(
      'INSERT INTO sessions(sid,user,csrf,expires) VALUES(?,?,?,?) ON CONFLICT(sid) DO UPDATE SET user=excluded.user,expires=excluded.expires',
      sid, id, csrf, Date.now() + 8 * 3600 * 1000);
  } catch (e) { throw Error('Không chuẩn bị được phiên làm việc APS: ' + ((e && e.message) || e)); }
  return { sid, csrf };
}

function createApsApp({ runtime, sourceDir, coreLoader, log = console, contractCheck = null } = {}) {
  log.log('[aps] bridge v2: dùng lại users.id của tài khoản cũ khi trùng username');
  const apsRuntime = path.join(runtime, 'aps');
  const legacySource = sourceDir !== undefined ? sourceDir : path.join(__dirname, '..', '..', '..', '..', 'APS repair service Potal_ 4');
  let corePromise = null;

  function migrateData() {
    try {
      const srcDb = path.join(legacySource, '.runtime', 'aps.sqlite');
      const dstDb = path.join(apsRuntime, 'aps.sqlite');
      if (!srcDb || !fs.existsSync(srcDb) || fs.existsSync(dstDb)) return;
      fs.mkdirSync(apsRuntime, { recursive: true });
      for (const suffix of ['', '-wal', '-shm', '-journal']) if (fs.existsSync(srcDb + suffix)) fs.copyFileSync(srcDb + suffix, dstDb + suffix);
      const srcFiles = path.join(legacySource, '.runtime', 'files');
      if (fs.existsSync(srcFiles)) fs.cpSync(srcFiles, path.join(apsRuntime, 'files'), { recursive: true });
      log.log('[aps] Đã sao chép dữ liệu portal APS cũ vào .runtime/aps.');
    } catch (e) { log.error('[aps] Không sao chép được dữ liệu cũ:', e.message); }
  }

  async function core() {
    if (!corePromise) {
      corePromise = (async () => {
        migrateData();
        const mod = coreLoader ? await coreLoader() : await import('./app/core.mjs');
        const app = mod.createApp({ runtime: apsRuntime, contractCheck });
        // Tự động sao lưu file: TẮT theo yêu cầu 05/11/2026 (dữ liệu nghiệp vụ đã đưa lên SQL).
        // Bật lại bằng cách chạy server với APS_BACKUP_AUTO=1. Vẫn còn: GET /api/backup (JSON tự tải, admin)
        // và /api/aps-app/api/backups* (liệt kê/tải/restore) cho các bản đã có sẵn.
        if (process.env.APS_BACKUP_AUTO === '1') {
          if (typeof app.startBackups === 'function') { try { app.startBackups(); } catch (e) { log.error('[aps] backup:', e.message); } }
        } else log.log('[aps] Tự động sao lưu file đã tắt (APS_BACKUP_AUTO=0) — không tạo .runtime/aps/backups.');
        if (typeof app.startNotifications === 'function') { try { app.startNotifications(); } catch (e) { log.error('[aps] notify:', e.message); } }
        return app;
      })().catch(e => { corePromise = null; throw e; });
    }
    return corePromise;
  }

  async function handle({ req, res, url, actor, send }) {
    if (url.pathname !== PREFIX && !url.pathname.startsWith(PREFIX + '/')) return false;
    const legacyPath = url.pathname === PREFIX ? '/' : url.pathname.slice(PREFIX.length) || '/';
    if (BLOCKED_EXACT.includes(legacyPath) || BLOCKED_PREFIX.some(p => legacyPath === p || legacyPath.startsWith(p + '/'))) {
      send(res, 410, { message: 'Tài khoản, đăng nhập và phân quyền do portal MRO WRB quản lý.' });
      return true;
    }
    let app;
    try { app = await core(); }
    catch (e) {
      log.error('[aps] core:', e);
      if (!res.headersSent) send(res, 503, { message: 'Chưa sẵn sàng dữ liệu APS. Chạy một lần: npm run migrate:aps' });
      return true;
    }
    const username = String(actor.username).slice(0, 80);
    let sid, csrf;
    try {
      ({ sid, csrf } = bridgeIdentity(app, actor, username));
    } catch (e) {
      // Không để lỗi SQLite lọt ra ngoài: WRB chỉ còn thấy 500 chung chung → tab trắng không rõ nguyên nhân.
      log.error('[aps] identity:', e);
      if (!res.headersSent) send(res, 500, { message: '[APS bridge v2] ' + ((e && e.message) || e) });
      return true;
    }
    req.headers.cookie = 'aps_session=' + sid;
    req.headers['x-csrf-token'] = csrf;
    req.url = legacyPath + (url.search || '');
    await app.server.listeners('request')[0](req, res);
    return true;
  }

  return { handle, apsRuntime, migrateData };
}

module.exports = { createApsApp, legacyRole, PREFIX };