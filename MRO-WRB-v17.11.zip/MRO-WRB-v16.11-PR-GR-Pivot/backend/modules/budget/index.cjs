const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const fail = (status, message) => Object.assign(new Error(message), {status});

// USD uses four decimal places, as supplied by Purchase. Add integer units, never rounded display values.
function units(value, field, allowNegative=false) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value > 1e10 || value < (allowNegative?-1e10:0))
    throw fail(400, `${field}: cần số USD ${allowNegative?'trong khoảng -10 tỷ đến 10 tỷ':'không âm, tối đa 10 tỷ'}.`);
  const match = new RegExp(`^(${allowNegative?'-?':''}\\d+)(?:\\.(\\d{1,4}))?$`).exec(String(value));
  if (!match) throw fail(400, `${field}: tối đa 4 chữ số thập phân.`);
  const fraction=BigInt((match[2] || '').padEnd(4, '0'));
  return BigInt(match[1]) * 10000n + (match[1].startsWith('-')?-fraction:fraction);
}
function keys(value, expected, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      Object.keys(value).length !== expected.length || expected.some(k => !Object.hasOwn(value, k)))
    throw fail(400, `${label}: các trường bắt buộc là ${expected.join(', ')}.`);
}
function validate(document) {
  keys(document, ['year','currency','actualThroughMonth','months'], 'JSON ngân sách');
  const {year, currency, actualThroughMonth, months} = document;
  if (!Number.isInteger(year) || year < 2000 || year > 2100) throw fail(400, 'Năm cần nằm trong 2000–2100.');
  if (currency !== 'USD') throw fail(400, 'Đơn vị phải là USD; không nhập K USD.');
  if (!Number.isInteger(actualThroughMonth) || actualThroughMonth < 0 || actualThroughMonth > 12)
    throw fail(400, 'Tháng chốt thực tế cần từ 0 đến 12.');
  if (!Array.isArray(months) || months.length !== 12) throw fail(400, 'Cần đủ 12 tháng.');
  const hasOther=months.some(row=>row&&Object.hasOwn(row,'other'));
  const seen = new Set();
  const rows = months.map(row => {
    keys(row, ['month','total','actualPR','actualGR',...(hasOther?['other']:[])], 'Dòng tháng');
    if (!Number.isInteger(row.month) || row.month < 1 || row.month > 12 || seen.has(row.month))
      throw fail(400, 'Tháng phải từ 1 đến 12 và không được trùng.');
    seen.add(row.month);
    for (const k of ['total','actualPR','actualGR',...(hasOther?['other']:[])]) units(row[k], `T${row.month} / ${k}`, k==='other');
    return {...row};
  }).sort((a,b) => a.month - b.month);
  return {year, currency, actualThroughMonth, months:rows};
}
function totals(document) {
  let p03=0n, pr=0n, actual=0n, forecast=0n;
  for (const r of document.months) {
    p03 += units(r.total, 'Total'); pr += units(r.actualPR, 'PR');
    if (r.month <= document.actualThroughMonth) actual += units(r.actualGR, 'GR')+units(r.other||0,'Other',true);
    else forecast += units(r.actualGR, 'GR')+units(r.other||0,'Other',true);
  }
  const usd = n => Number(n) / 10000;
  return {p03:usd(p03), actualPR:usd(pr), actual:usd(actual), forecast:usd(forecast), annual:usd(actual+forecast)};
}
// Calendar policy is evaluated in Vietnam, never inferred from zero/null values.
function calendar(now=new Date()) {
 const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'numeric'}).formatToParts(now).map(p=>[p.type,p.value]));
 return {year:Number(parts.year),month:Number(parts.month)};
}
function cutoff(year,now=new Date()){const c=calendar(now);return year<c.year?12:year>c.year?0:c.month-1;}
const monthNames=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function fromSql(rows,year,now=new Date()) {
 if(!Array.isArray(rows)||![3,4].includes(rows.length))throw fail(400,'MRO_OH cần 3 dòng P03, GR, PR và tối đa một dòng Other cho năm đã chọn; không được thiếu/trùng.');
 const map=new Map();
 for(const row of rows){const type=String(row.OH??'').trim().toUpperCase();if(String(row.Year??'').trim()!==String(year)||!['P03','GR','PR','OTHER'].includes(type)||map.has(type))throw fail(400,'MRO_OH có năm/loại OH không hợp lệ hoặc trùng.');map.set(type,row);}
 if(['P03','GR','PR'].some(type=>!map.has(type)))throw fail(400,'MRO_OH thiếu P03, GR hoặc PR.');
 const number=(type,m)=>{const text=map.get(type)[m],allowNegative=type==='OTHER';if(typeof text!=='string'||!(allowNegative?/^-?\d+(?:\.\d{1,4})?$/:/^\d+(?:\.\d{1,4})?$/).test(text.trim()))throw fail(400,`${type}/${m}: nvarchar phải là ${allowNegative?'số':'số không âm'}, dấu chấm thập phân, tối đa 4 số lẻ; không NULL/rỗng/dấu hàng nghìn.`);const n=Number(text.trim());units(n,type+'/'+m,allowNegative);return n;};
 return validate({year,currency:'USD',actualThroughMonth:cutoff(year,now),months:monthNames.map((m,i)=>({month:i+1,total:number('P03',m),actualGR:number('GR',m),actualPR:number('PR',m),...(map.has('OTHER')?{other:number('OTHER',m)}:{})}))});
}
function createBudget({runtime,root,sql,now=()=>new Date(),cacheFile}) {
 const directory=path.join(runtime,'budgets');
 const file=cacheFile||path.join(path.resolve(runtime)===path.resolve(root,'.runtime')?root:runtime,'data','oh-budget.json');
 const pending=new Map();
 const normalize=doc=>({...validate(doc),actualThroughMonth:cutoff(doc.year,now())});
 function catalog(){if(!fs.existsSync(file))return {version:2,years:{}};const c=JSON.parse(fs.readFileSync(file,'utf8'));if(c.version!==2||!c.years||typeof c.years!=='object'||Array.isArray(c.years))throw Error('Invalid OH cache');return c;}
 function unpack(r){const year=r.year;if(r.values&&Object.hasOwn(r.values,'Other')&&(!Array.isArray(r.values.Other)||r.values.Other.length!==12))throw Error('Invalid OH Other series');if(!r.values||['P03','GR','PR'].some(k=>!Array.isArray(r.values[k])||r.values[k].length!==12))throw Error('Invalid OH series');return {document:normalize({year,currency:'USD',actualThroughMonth:0,months:Array.from({length:12},(_,i)=>({month:i+1,total:r.values.P03[i],actualGR:r.values.GR[i],actualPR:r.values.PR[i],...(r.values.Other?{other:r.values.Other[i]}:{})}))}),revision:r.revision,updatedAt:r.updatedAt,updatedBy:r.updatedBy,source:r.source};}
 function read(year){const c=catalog();if(c.years[year])return unpack(c.years[year]);const legacy=path.join(directory,`${year}.json`);if(!fs.existsSync(legacy))return null;const r=JSON.parse(fs.readFileSync(legacy,'utf8'));return {...r,document:normalize(r.document),source:'legacy-json'};}
 function result(record,year){return record?{...record,totals:totals(record.document),budget:record.document.months.map(r=>({month:r.month,p03:r.total/1000,rawGR:r.month<=record.document.actualThroughMonth?(r.actualGR+(r.other||0))/1000:null,forecast:(r.actualGR+(r.other||0))/1000,adjustment:0}))}:{document:null,revision:null,year,actualThroughMonth:cutoff(year,now())};}
 // OH metadata stays separate: Tracking keeps its original budget snapshot.
 function overlay(data){if(!Array.isArray(data.budget))return data;const year=calendar(now()).year;return {...data,budgetOH:result(read(year),year)};}
 function preview(document,previous){return {document,rows:document.months.map(r=>{const old=previous?.document.months.find(m=>m.month===r.month);return {...r,oldTotal:old?.total??null,oldGR:old?old.actualGR+(old.other||0):null,oldPR:old?.actualPR??null,oldActual:previous? r.month<=previous.document.actualThroughMonth:null,actual:r.month<=document.actualThroughMonth};}),totals:totals(document),revision:previous?.revision||null};}
 async function handle({req,res,url,body,send,protectedTransaction,requireUser}){
  const route=url.pathname;if(!['/api/budget-oh','/api/budget-oh/preview','/api/budget-oh/template','/api/budget-oh/sql-preview','/api/budget-oh/years','/api/budget-oh/live'].includes(route))return false;
  const editable=()=>{const user=requireUser(req).user;if(!['admin','supervisor','developer'].includes(user.role))throw fail(403,'Chỉ admin trở lên được cập nhật ngân sách OH.');return user;};
  if(route==='/api/budget-oh/years'&&req.method==='GET'){
   const years=new Set(Object.keys(catalog().years).map(Number));
   if(fs.existsSync(directory))for(const f of fs.readdirSync(directory))if(/^\d{4}\.json$/.test(f))years.add(Number(f.slice(0,4)));
   let warning=null;try{if(sql?.yearsOH)for(const y of await sql.yearsOH())years.add(y);}catch(e){warning='Không đọc được danh sách năm SQL; đang dùng năm trong JSON.';}
   send(res,200,{years:[...years].filter(y=>y>=2000&&y<=2100).sort((a,b)=>b-a),warning});return true;
  }
  if(route==='/api/budget-oh/live'&&req.method==='GET'){
   const requested=Number(url.searchParams.get('year')||calendar(now()).year);
   if(!Number.isInteger(requested)||requested<2000||requested>2100)throw fail(400,'Năm không hợp lệ.');
   let years,rows,year=requested,connected=false;
   try{years=[...await sql.yearsOH()].sort((a,b)=>b-a);connected=true;if(!url.searchParams.has('year')&&!years.includes(year)&&years.length)year=years[0];rows=await sql.readOH(year);}
   catch(e){if(e.connected===true||(connected&&e.connected!==false)){send(res,200,{...result(null,year),source:'sql',offline:false,years:years||[],warning:'Không đọc được dữ liệu OH: '+e.message});return true;}send(res,200,{...result(null,year),source:'sql',offline:true,years:[],warning:'SQL chưa khả dụng: '+e.message});return true;}
   if(!rows.length){send(res,200,{...result(null,year),source:'sql',offline:false,years,warning:'SQL kết nối được nhưng năm này chưa có dữ liệu.'});return true;}
   try{const document=fromSql(rows,year,now());send(res,200,{...result({document,revision:read(year)?.revision||null,updatedAt:now().toISOString(),updatedBy:{name:'SQL Server'},source:'sql'},year),offline:false,years});}
   catch(e){send(res,200,{...result(null,year),source:'sql',offline:false,years,warning:'Dữ liệu SQL không hợp lệ: '+e.message});}return true;
  }
  const year=Number(url.searchParams.get('year')||(route.endsWith('/template')?calendar(now()).year:NaN));
  if(!Number.isInteger(year)||year<2000||year>2100)throw fail(400,'Cần chọn năm ngân sách hợp lệ (2000–2100).');
  if(route.endsWith('/template')&&req.method==='GET'){send(res,200,{year,currency:'USD',actualThroughMonth:cutoff(year,now()),months:monthNames.map((_,i)=>({month:i+1,total:0,actualPR:0,actualGR:0}))});return true;}
  if(route==='/api/budget-oh'&&req.method==='GET'){send(res,200,result(read(year),year));return true;}
  if(!((route.endsWith('/preview')||route.endsWith('/sql-preview'))&&req.method==='POST'||route==='/api/budget-oh'&&req.method==='PUT'))throw fail(405,'Phương thức không được hỗ trợ.');
  const actor=editable(),input=await body(req);
  const checkRevision=previous=>{if(input.expectedRevision!==(previous?.revision||null))throw fail(409,'Ngân sách đã thay đổi. Đóng và mở lại trước khi lưu.');};
  for(const [id,p]of pending)if(p.expires<Date.now())pending.delete(id);
  if(route.endsWith('/sql-preview')){
   keys(input,['expectedRevision'],'Yêu cầu SQL');checkRevision(read(year));if(!sql)throw fail(503,'Chưa cấu hình SQL.');
   const document=fromSql(await sql.readOH(year),year,now());const previous=read(year);editable();checkRevision(previous);
   if(pending.size>=100)throw fail(429,'Có quá nhiều bản xem trước. Thử lại sau.');
   const token=crypto.randomUUID();pending.set(token,{user:actor.id,year,document,revision:input.expectedRevision,expires:Date.now()+15*60000});send(res,200,{...preview(document,previous),sqlToken:token});return true;
  }
  keys(input,input.sqlToken===undefined?['document','expectedRevision']:['document','expectedRevision','sqlToken'],'Yêu cầu cập nhật');
  const document=normalize(input.document);if(document.year!==year)throw fail(400,'Năm trong file khác năm đang mở.');
  await protectedTransaction(async()=>{
   const user=editable(),previous=read(year);checkRevision(previous);
   if(route.endsWith('/preview')){send(res,200,preview(document,previous));return;}
   let source='table';if(input.sqlToken!==undefined){const p=pending.get(input.sqlToken);if(!p||p.user!==user.id||p.year!==year||p.revision!==input.expectedRevision||JSON.stringify(normalize(p.document))!==JSON.stringify(document))throw fail(409,'Bản xem trước SQL đã hết hạn hoặc thay đổi. Tải lại từ SQL.');source='sql';}
   if(source==='table'){if(!sql?.writeOH)throw fail(503,'Chưa có kết nối ghi SQL. Cache chưa thay đổi.');await sql.writeOH(document);source='sql-upload';}
   const record={year,values:{P03:document.months.map(r=>r.total),GR:document.months.map(r=>r.actualGR),PR:document.months.map(r=>r.actualPR),...(document.months.some(r=>Object.hasOwn(r,'other'))?{Other:document.months.map(r=>r.other||0)}:{})},revision:crypto.randomUUID(),updatedAt:now().toISOString(),updatedBy:{id:user.id,name:user.name,role:user.role},source};
   const c=catalog();
   // Preserve all existing legacy years on first explicit update, never on a GET.
   if(fs.existsSync(directory))for(const f of fs.readdirSync(directory)){if(!/^\d{4}\.json$/.test(f))continue;const y=Number(f.slice(0,4));if(c.years[y])continue;const old=read(y);if(old)c.years[y]={year:y,values:{P03:old.document.months.map(r=>r.total),GR:old.document.months.map(r=>r.actualGR),PR:old.document.months.map(r=>r.actualPR)},revision:old.revision,updatedAt:old.updatedAt,updatedBy:old.updatedBy,source:'legacy-json'};}
   if(previous){const history=path.join(directory,'history',String(year));fs.mkdirSync(history,{recursive:true});fs.writeFileSync(path.join(history,crypto.randomUUID()+'.json'),JSON.stringify(previous,null,2),{flag:'wx',mode:0o600});}
   c.years[year]=record;fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(temp,JSON.stringify(c,null,2),{flag:'wx',mode:0o600});fs.renameSync(temp,file);}catch(e){if(source==='sql-upload')throw fail(500,'SQL đã cập nhật nhưng JSON chưa lưu được. Kiểm tra ổ đĩa rồi dùng Tải từ SQL để khôi phục cache.');throw e;}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}
   if(input.sqlToken)pending.delete(input.sqlToken);send(res,200,result(unpack(record),year));
  });return true;
 }
 return {handle,overlay};
}
module.exports={createBudget,validate,totals,calendar,cutoff,fromSql};
