/**
 * SET/PBA Mock In-Memory Store (Phase 4D.2.1)
 * Mirrors the EQM_SP_* schema from scripts/sql/set-pba-v2/01-create-schema.sql.
 * Does NOT read/write any SQL or MRO data.
 *
 * Transfer return flow (confirmed Phase 4D.2.1):
 *   rejectTransfer  → status=Rejected; stock NOT returned; source must call confirmReturn.
 *   receiveTransfer → partial: received portion → dst (TransferIn); remainder stays InTransit
 *                     per-line; transfer status = PartialReceived if any line still pending.
 *   confirmReturn   → source confirms physical receipt of returned items; TransferBack recorded;
 *                     stock added to source. When all pending returns confirmed → ReturnConfirmed.
 *
 * SQL schema incompatibility (Phase 4D.2.1):
 *   CK_EQM_SP_Transfer_Status in 01-create-schema.sql must add 'PartialReceived','ReturnConfirmed'.
 *   CK_EQM_SP_Transfer_Reject must be relaxed (ConfirmedAt/By not required at Rejected; set at confirmReturn).
 *   TransferLine needs: returnConfirmedQty int NULL, returnConfirmedAt datetime2 NULL.
 *
 * API contract: each method returns plain objects matching the shape the
 * HTTP handler (index.cjs) will later pass through to SQL EquipmentPart.
 */
'use strict';

/* ---- helpers ---- */
const now = () => new Date().toISOString();
const pad3 = n => String(n).padStart(3, '0');
const yyyymmdd = (d = new Date()) =>
  d.toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' }).replace(/-/g, '');

function makeTransferNo(prefix, counters, date) {
  const key = prefix + date;
  counters[key] = (counters[key] || 0) + 1;
  return key + pad3(counters[key]);
}

/* ---- factory ---- */
function createMockStore({ seed } = {}) {
  /* ---- reference ---- */
  const HOLDERS = {
    SEV:      { holderCode: 'SEV',      holderName: 'SEV Central Warehouse', holderType: 'SEV' },
    ALT:      { holderCode: 'ALT',      holderName: 'Almus Tech',            holderType: 'VENDOR' },
    ALV:      { holderCode: 'ALV',      holderName: 'Almus Vina',            holderType: 'VENDOR' },
    BUJEON:   { holderCode: 'BUJEON',   holderName: 'Bujeon',                holderType: 'VENDOR' },
    CHITWING: { holderCode: 'CHITWING', holderName: 'Chitwing',              holderType: 'VENDOR' },
  };
  const HOLDER_ALIAS = {
    SEV: 'SEV', ALT: 'ALT', ALV: 'ALV', ALMUS: 'ALV', Almus: 'ALV',
    BUJEON: 'BUJEON', Bujeon: 'BUJEON', CHITWING: 'CHITWING', Chitwing: 'CHITWING',
  };
  function resolveHolder(raw) {
    const code = HOLDER_ALIAS[raw] || raw;
    if (!HOLDERS[code]) throw Object.assign(Error(`Holder không hợp lệ: ${raw}`), { status: 400 });
    return code;
  }

  /* ---- state ---- */
  let setSeq = 0;
  let pbaSeq = 0;
  let trSeq = 0;
  let mvSeq = 0;
  let ngSeq = 0;
  let adjReqSeq = 0;
  const counters = {};         // TransferNo counters per prefix+date
  const setUnits  = new Map(); // setUnitId → row
  const pbaStock  = new Map(); // pbaStockId → row
  const transfers = new Map(); // transferId → row
  const trLines   = new Map(); // transferLineId → row
  const movements = [];        // append-only
  const ngReports = new Map(); // ngReportId → row
  const adjReqs   = new Map(); // adjReqId → row

  /* ======== SET ======== */

  function setSN(sn) {
    for (const u of setUnits.values()) if (u.sn === sn) return u;
    return null;
  }
  function setByIMEI(imei) {
    for (const u of setUnits.values()) if (u.imei1 === imei || u.imei2 === imei) return u;
    return null;
  }

  function addSetUnit({ sn, imei1, imei2, serial, un, model, basicModel, origin,
                        holderCode, condition, location, mode, cro, remark,
                        isDemo = false, createdBy = 'system' }) {
    if (!sn || !sn.trim()) throw Object.assign(Error('SN là bắt buộc.'), { status: 400 });
    if (isDemo && !sn.startsWith('TEST-SN-'))
      throw Object.assign(Error('Demo SN phải bắt đầu bằng TEST-SN-.'), { status: 400 });
    if (!isDemo && sn.startsWith('TEST-SN-'))
      throw Object.assign(Error('SN production không được bắt đầu bằng TEST-SN-.'), { status: 400 });
    if (setSN(sn))
      throw Object.assign(Error(`SN đã tồn tại: ${sn}`), { status: 409 });
    if (imei1) {
      const dup = setByIMEI(imei1);
      if (dup) throw Object.assign(Error(`IMEI1 trùng với unit SN=${dup.sn}`), { status: 409 });
    }
    if (imei2) {
      const dup = setByIMEI(imei2);
      if (dup) throw Object.assign(Error(`IMEI2 trùng với unit SN=${dup.sn}`), { status: 409 });
    }
    if (imei1 && imei2 && imei1 === imei2)
      throw Object.assign(Error('IMEI1 và IMEI2 không được giống nhau.'), { status: 400 });

    const hc = resolveHolder(holderCode);
    if (!['OK','NG','Checking'].includes(condition))
      throw Object.assign(Error('Condition phải là OK / NG / Checking.'), { status: 400 });

    const id = ++setSeq;
    const row = { setUnitId: id, sn, imei1: imei1||null, imei2: imei2||null,
                  serial: serial||null, un: un||null, model, basicModel: basicModel||null,
                  origin: origin||null, holderCode: hc, condition,
                  stockState: 'InStock', isDemo,
                  location: location||null, mode: mode||null, cro: cro||null,
                  remark: remark||null, createdAt: now(), createdBy,
                  updatedAt: now(), updatedBy: createdBy };
    setUnits.set(id, row);
    _addMovement({ type: 'Import', itemType: 'SET', holderCode: hc, setUnitId: id,
                   sn, imei1: imei1||null, model, condition, qtyDelta: 1,
                   refNo: null, note: 'initial import', isLegacy: false, createdBy });
    return { ...row };
  }

  function listSetUnits({ holderCode, condition, stockState, includDemo = false } = {}) {
    return [...setUnits.values()].filter(u =>
      (!holderCode || u.holderCode === resolveHolder(holderCode)) &&
      (!condition  || u.condition === condition) &&
      (!stockState || u.stockState === stockState) &&
      (includDemo  || !u.isDemo)
    ).map(u => ({ ...u }));
  }

  /* ======== PBA ======== */

  function _pbaKey(model, holderCode, condition, rack) {
    return `${model}|${holderCode}|${condition}|${rack ?? ''}`;
  }
  function findPbaRow(model, holderCode, condition, rack) {
    const k = _pbaKey(model, holderCode, condition, rack);
    for (const r of pbaStock.values()) {
      if (_pbaKey(r.model, r.holderCode, r.condition, r.rack) === k) return r;
    }
    return null;
  }

  function upsertPbaStock({ model, holderCode, condition, rack = '', qty,
                            basicModel, origin, remark, movementType = 'Adjust', updatedBy = 'system' }) {
    const hc = resolveHolder(holderCode);
    if (!['OK','NG','Checking'].includes(condition))
      throw Object.assign(Error('Condition phải là OK / NG / Checking.'), { status: 400 });
    if (!Number.isInteger(qty) || qty < 0)
      throw Object.assign(Error('Qty phải là số nguyên >= 0.'), { status: 400 });

    let row = findPbaRow(model, hc, condition, rack);
    const prev = row ? row.qty : 0;
    if (!row) {
      const id = ++pbaSeq;
      row = { pbaStockId: id, model, holderCode: hc, condition, rack,
              qty: 0, basicModel: basicModel||null, origin: origin||null,
              remark: remark||null, updatedAt: now(), updatedBy };
      pbaStock.set(id, row);
    }
    row.qty = qty;
    row.updatedAt = now();
    row.updatedBy = updatedBy;
    _addMovement({ type: movementType, itemType: 'PBA', holderCode: hc, setUnitId: null,
                   sn: null, imei1: null, model, condition, qtyDelta: qty - prev,
                   refNo: null, note: `upsert rack=${rack}`, isLegacy: false, createdBy: updatedBy });
    return { ...row };
  }

  function listPbaStock({ holderCode, condition } = {}) {
    return [...pbaStock.values()].filter(r =>
      (!holderCode || r.holderCode === resolveHolder(holderCode)) &&
      (!condition  || r.condition === condition)
    ).map(r => ({ ...r }));
  }

  /* ======== Movement (private append) ======== */

  function _addMovement({ type, itemType, holderCode, counterHolder = null,
                          setUnitId, sn, imei1, model, condition, qtyDelta,
                          transferId = null, transferLineId = null, ngReportId = null,
                          refNo = null, note = null, isLegacy = false, createdBy = 'system' }) {
    movements.push({
      movementId: ++mvSeq, movementType: type, itemType, holderCode,
      counterHolder, setUnitId, sn, imei1, model, condition, qtyDelta,
      transferId, transferLineId, ngReportId, refNo, note,
      isLegacy, createdAt: now(), createdBy,
    });
  }

  function listMovements({ holderCode, model, limit = 200 } = {}) {
    return movements
      .filter(m => (!holderCode || m.holderCode === holderCode) && (!model || m.model === model))
      .slice(-limit)
      .map(m => ({ ...m }));
  }

  /* ======== Transfer ======== */

  // --- helpers shared by requestTransfer + createTransfer ---
  function _validateTransferInput(transferType, from, to, lines) {
    if (from === to)
      throw Object.assign(Error('FromHolder và ToHolder phải khác nhau.'), { status: 400 });
    if (!['Dispatch','Return','VendorToVendor'].includes(transferType))
      throw Object.assign(Error('TransferType không hợp lệ.'), { status: 400 });
    if (!Array.isArray(lines) || lines.length === 0)
      throw Object.assign(Error('Cần ít nhất một dòng TransferLine.'), { status: 400 });
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (!['SET','PBA'].includes(l.itemType))
        throw Object.assign(Error(`Line ${i}: itemType phải là SET hoặc PBA.`), { status: 400 });
      if (!['OK','NG','Checking'].includes(l.condition))
        throw Object.assign(Error(`Line ${i}: condition không hợp lệ.`), { status: 400 });
    }
  }

  // Check if a SET SN is already locked in an existing Requested or InTransit transfer
  function _setSnIsLocked(sn) {
    for (const tl of trLines.values()) {
      if (tl.sn === sn) {
        const tr = transfers.get(tl.transferId);
        if (tr && (tr.status === 'Requested' || tr.status === 'InTransit')) return true;
      }
    }
    return false;
  }

  // Create transfer as Requested (no stock lock; stock validated but not deducted)
  function requestTransfer({ transferType, fromHolder, toHolder, reason = null,
                              lines = [], requestedBy = 'system' }) {
    const from = resolveHolder(fromHolder);
    const to   = resolveHolder(toHolder);
    _validateTransferInput(transferType, from, to, lines);

    const date = yyyymmdd();
    const prefix = transferType === 'Return' ? 'RT' : transferType === 'VendorToVendor' ? 'TR' : 'GI';
    const transferNo = makeTransferNo(prefix, counters, date);
    const transferId = ++trSeq;
    const ts = now();

    const builtLines = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (l.itemType === 'SET') {
        if (!l.sn) throw Object.assign(Error(`Line ${i}: SET cần có SN.`), { status: 400 });
        const unit = setSN(l.sn);
        if (!unit) throw Object.assign(Error(`SET SN=${l.sn} không tìm thấy.`), { status: 404 });
        if (unit.holderCode !== from)
          throw Object.assign(Error(`SET SN=${l.sn} không thuộc ${from}.`), { status: 409 });
        if (unit.stockState !== 'InStock')
          throw Object.assign(Error(`SET SN=${l.sn} đang ${unit.stockState}.`), { status: 409 });
        if (_setSnIsLocked(l.sn))
          throw Object.assign(Error(`SET SN=${l.sn} đã có trong Transfer đang xử lý.`), { status: 409 });
        const lid = ++trSeq;
        const lineRow = {
          transferLineId: lid, transferId, lineNo: i + 1,
          itemType: 'SET', setUnitId: unit.setUnitId, sn: unit.sn,
          imei1: unit.imei1, imei2: unit.imei2, model: unit.model,
          basicModel: unit.basicModel, condition: l.condition, fromRack: null, toRack: null,
          qty: 1, receivedQty: null,
          returnConfirmedQty: null, returnConfirmedAt: null,
          origin: unit.origin, remark: l.remark || null,
        };
        trLines.set(lid, lineRow);
        builtLines.push(lineRow);
      } else {
        // PBA — validate availability only, no deduction yet
        const qty = l.qty;
        if (!Number.isInteger(qty) || qty <= 0)
          throw Object.assign(Error(`Line ${i}: qty PBA phải > 0.`), { status: 400 });
        const rack = l.fromRack ?? '';
        const pbRow = findPbaRow(l.model, from, l.condition, rack);
        if (!pbRow || pbRow.qty < qty)
          throw Object.assign(Error(
            `PBA ${l.model}/${from}/${l.condition}/rack="${rack}" không đủ tồn (cần ${qty}, có ${pbRow?.qty ?? 0}).`
          ), { status: 409 });
        const lid = ++trSeq;
        const lineRow = {
          transferLineId: lid, transferId, lineNo: i + 1,
          itemType: 'PBA', setUnitId: null, sn: null, imei1: null, imei2: null,
          model: l.model, basicModel: l.basicModel || null, condition: l.condition,
          fromRack: rack, toRack: l.toRack ?? '',
          qty, receivedQty: null,
          returnConfirmedQty: null, returnConfirmedAt: null,
          origin: l.origin || null, remark: l.remark || null,
        };
        trLines.set(lid, lineRow);
        builtLines.push(lineRow);
      }
    }

    const transfer = {
      transferId, transferNo, transferType, fromHolder: from, toHolder: to,
      status: 'Requested', reason,
      requestedAt: ts, requestedBy,
      approvedAt: null, approvedBy: null,
      dispatchedAt: null, dispatchedBy: null,
      receiptNo: null, confirmedAt: null, confirmedBy: null, rejectReason: null,
      createdAt: ts, createdBy: requestedBy, updatedAt: ts, updatedBy: requestedBy,
    };
    transfers.set(transferId, transfer);
    return { ...transfer, lines: builtLines.map(l => ({ ...l })) };
  }

  // Dispatch a Requested transfer → InTransit; locks SET stock and deducts PBA
  function dispatchTransfer({ transferId, dispatchedBy = 'system' }) {
    const tr = transfers.get(transferId);
    if (!tr) throw Object.assign(Error('Transfer không tìm thấy.'), { status: 404 });
    if (tr.status !== 'Requested')
      throw Object.assign(Error(`Transfer đang ở trạng thái ${tr.status}, không thể dispatch.`), { status: 409 });
    const ts = now();
    const lines = [...trLines.values()].filter(l => l.transferId === transferId);
    for (const line of lines) {
      if (line.itemType === 'SET') {
        const unit = setUnits.get(line.setUnitId);
        if (!unit) throw Object.assign(Error(`SET unit ${line.sn} không còn tồn tại.`), { status: 409 });
        if (unit.stockState !== 'InStock')
          throw Object.assign(Error(`SET SN=${line.sn} đang ${unit.stockState}, không thể dispatch.`), { status: 409 });
        unit.stockState = 'InTransit';
        unit.updatedAt = ts; unit.updatedBy = dispatchedBy;
        _addMovement({ type: 'TransferOut', itemType: 'SET', holderCode: tr.fromHolder,
                       counterHolder: tr.toHolder, setUnitId: unit.setUnitId, sn: unit.sn,
                       imei1: unit.imei1, model: unit.model, condition: line.condition,
                       qtyDelta: -1, transferId, transferLineId: line.transferLineId,
                       refNo: tr.transferNo, note: null, isLegacy: false, createdBy: dispatchedBy });
      } else {
        const rack = line.fromRack ?? '';
        const pbRow = findPbaRow(line.model, tr.fromHolder, line.condition, rack);
        if (!pbRow || pbRow.qty < line.qty)
          throw Object.assign(Error(
            `PBA ${line.model}/${tr.fromHolder}/${line.condition} không đủ tồn khi dispatch.`
          ), { status: 409 });
        pbRow.qty -= line.qty;
        pbRow.updatedAt = ts; pbRow.updatedBy = dispatchedBy;
        _addMovement({ type: 'TransferOut', itemType: 'PBA', holderCode: tr.fromHolder,
                       counterHolder: tr.toHolder, setUnitId: null, sn: null, imei1: null,
                       model: line.model, condition: line.condition, qtyDelta: -line.qty,
                       transferId, transferLineId: line.transferLineId,
                       refNo: tr.transferNo, note: `rack=${rack}`, isLegacy: false, createdBy: dispatchedBy });
      }
    }
    tr.status = 'InTransit';
    tr.dispatchedAt = ts; tr.dispatchedBy = dispatchedBy;
    tr.approvedAt = ts; tr.approvedBy = dispatchedBy;
    tr.updatedAt = ts; tr.updatedBy = dispatchedBy;
    return { ...tr, lines: lines.map(l => ({ ...l })) };
  }

  function createTransfer({ transferType, fromHolder, toHolder, reason = null,
                             lines = [], requestedBy = 'system' }) {
    const from = resolveHolder(fromHolder);
    const to   = resolveHolder(toHolder);
    if (from === to)
      throw Object.assign(Error('FromHolder và ToHolder phải khác nhau.'), { status: 400 });
    if (!['Dispatch','Return','VendorToVendor'].includes(transferType))
      throw Object.assign(Error('TransferType không hợp lệ.'), { status: 400 });
    if (!Array.isArray(lines) || lines.length === 0)
      throw Object.assign(Error('Cần ít nhất một dòng TransferLine.'), { status: 400 });

    const date = yyyymmdd();
    const prefix = transferType === 'Return' ? 'RT' : transferType === 'VendorToVendor' ? 'TR' : 'GI';
    const transferNo = makeTransferNo(prefix, counters, date);
    const transferId = ++trSeq;
    const ts = now();

    // Validate & lock source stock
    const builtLines = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (!['SET','PBA'].includes(l.itemType))
        throw Object.assign(Error(`Line ${i}: itemType phải là SET hoặc PBA.`), { status: 400 });
      if (!['OK','NG','Checking'].includes(l.condition))
        throw Object.assign(Error(`Line ${i}: condition không hợp lệ.`), { status: 400 });

      if (l.itemType === 'SET') {
        if (!l.sn) throw Object.assign(Error(`Line ${i}: SET cần có SN.`), { status: 400 });
        const unit = setSN(l.sn);
        if (!unit) throw Object.assign(Error(`SET SN=${l.sn} không tìm thấy.`), { status: 404 });
        if (unit.holderCode !== from)
          throw Object.assign(Error(`SET SN=${l.sn} không thuộc ${from}.`), { status: 409 });
        if (unit.stockState !== 'InStock')
          throw Object.assign(Error(`SET SN=${l.sn} đang ${unit.stockState}.`), { status: 409 });
        // Lock
        unit.stockState = 'InTransit';
        unit.updatedAt = ts; unit.updatedBy = requestedBy;

        const lid = ++trSeq; // reuse counter for line ids (separate in prod; fine for mock)
        const lineRow = {
          transferLineId: lid, transferId, lineNo: i + 1,
          itemType: 'SET', setUnitId: unit.setUnitId, sn: unit.sn,
          imei1: unit.imei1, imei2: unit.imei2, model: unit.model,
          basicModel: unit.basicModel, condition: l.condition, fromRack: null, toRack: null,
          qty: 1, receivedQty: null,
          returnConfirmedQty: null, returnConfirmedAt: null,  // set by confirmReturn
          origin: unit.origin, remark: l.remark || null,
        };
        trLines.set(lid, lineRow);
        builtLines.push(lineRow);
        _addMovement({ type: 'TransferOut', itemType: 'SET', holderCode: from,
                       counterHolder: to, setUnitId: unit.setUnitId, sn: unit.sn,
                       imei1: unit.imei1, model: unit.model, condition: l.condition,
                       qtyDelta: -1, transferId, transferLineId: lid,
                       refNo: transferNo, note: null, isLegacy: false, createdBy: requestedBy });
      } else {
        // PBA
        const qty = l.qty;
        if (!Number.isInteger(qty) || qty <= 0)
          throw Object.assign(Error(`Line ${i}: qty PBA phải > 0.`), { status: 400 });
        const rack = l.fromRack ?? '';
        const pbRow = findPbaRow(l.model, from, l.condition, rack);
        if (!pbRow || pbRow.qty < qty)
          throw Object.assign(Error(
            `PBA ${l.model}/${from}/${l.condition}/rack="${rack}" không đủ tồn (cần ${qty}, có ${pbRow?.qty ?? 0}).`
          ), { status: 409 });
        pbRow.qty -= qty;
        pbRow.updatedAt = ts; pbRow.updatedBy = requestedBy;

        const lid = ++trSeq;
        const lineRow = {
          transferLineId: lid, transferId, lineNo: i + 1,
          itemType: 'PBA', setUnitId: null, sn: null, imei1: null, imei2: null,
          model: l.model, basicModel: l.basicModel || null, condition: l.condition,
          fromRack: rack, toRack: l.toRack ?? '',
          qty, receivedQty: null,
          returnConfirmedQty: null, returnConfirmedAt: null,  // set by confirmReturn
          origin: l.origin || null, remark: l.remark || null,
        };
        trLines.set(lid, lineRow);
        builtLines.push(lineRow);
        _addMovement({ type: 'TransferOut', itemType: 'PBA', holderCode: from,
                       counterHolder: to, setUnitId: null, sn: null, imei1: null,
                       model: l.model, condition: l.condition, qtyDelta: -qty,
                       transferId, transferLineId: lid,
                       refNo: transferNo, note: `rack=${rack}`, isLegacy: false, createdBy: requestedBy });
      }
    }

    const transfer = {
      transferId, transferNo, transferType, fromHolder: from, toHolder: to,
      status: 'InTransit', reason,
      requestedAt: ts, requestedBy, approvedAt: ts, approvedBy: requestedBy,
      dispatchedAt: ts, dispatchedBy: requestedBy,
      receiptNo: null, confirmedAt: null, confirmedBy: null, rejectReason: null,
      createdAt: ts, createdBy: requestedBy, updatedAt: ts, updatedBy: requestedBy,
    };
    transfers.set(transferId, transfer);
    return { ...transfer, lines: builtLines.map(l => ({ ...l })) };
  }

  function receiveTransfer({ transferId, confirmedBy = 'system', partialLines = null }) {
    const tr = transfers.get(transferId);
    if (!tr) throw Object.assign(Error('Transfer không tìm thấy.'), { status: 404 });
    if (tr.status !== 'InTransit')
      throw Object.assign(Error(`Transfer đang ở trạng thái ${tr.status}, không thể nhận.`), { status: 409 });

    const date = yyyymmdd();
    const receiptNo = makeTransferNo('GR', counters, date);
    const ts = now();
    const lines = [...trLines.values()].filter(l => l.transferId === transferId);

    let hasReturn = false;

    for (const line of lines) {
      const override = partialLines?.find(p => p.transferLineId === line.transferLineId);
      const recvQty = override != null ? override.receivedQty : line.qty;
      if (!Number.isInteger(recvQty) || recvQty < 0 || recvQty > line.qty)
        throw Object.assign(Error(`receivedQty không hợp lệ cho line ${line.transferLineId}.`), { status: 400 });

      line.receivedQty = recvQty;
      const returnQty = line.qty - recvQty;
      if (returnQty > 0) hasReturn = true;

      if (line.itemType === 'SET') {
        const unit = setUnits.get(line.setUnitId);
        if (recvQty === 1) {
          // Fully received: unit moves to destination immediately.
          unit.holderCode = tr.toHolder;
          unit.stockState = 'InStock';
          unit.updatedAt = ts; unit.updatedBy = confirmedBy;
          _addMovement({ type: 'TransferIn', itemType: 'SET', holderCode: tr.toHolder,
                         counterHolder: tr.fromHolder, setUnitId: unit.setUnitId,
                         sn: unit.sn, imei1: unit.imei1, model: unit.model,
                         condition: unit.condition, qtyDelta: 1,
                         transferId, transferLineId: line.transferLineId,
                         refNo: receiptNo, note: null, isLegacy: false, createdBy: confirmedBy });
        }
        // recvQty === 0: unit stays InTransit; source confirms return via confirmReturn.
      } else {
        // PBA — add received portion to destination.
        if (recvQty > 0) {
          const toRack = line.toRack ?? '';
          let pbRow = findPbaRow(line.model, tr.toHolder, line.condition, toRack);
          if (!pbRow) {
            const id = ++pbaSeq;
            pbRow = { pbaStockId: id, model: line.model, holderCode: tr.toHolder,
                      condition: line.condition, rack: toRack, qty: 0,
                      basicModel: line.basicModel, origin: line.origin,
                      remark: null, updatedAt: ts, updatedBy: confirmedBy };
            pbaStock.set(id, pbRow);
          }
          pbRow.qty += recvQty;
          pbRow.updatedAt = ts; pbRow.updatedBy = confirmedBy;
          _addMovement({ type: 'TransferIn', itemType: 'PBA', holderCode: tr.toHolder,
                         counterHolder: tr.fromHolder, setUnitId: null, sn: null, imei1: null,
                         model: line.model, condition: line.condition, qtyDelta: recvQty,
                         transferId, transferLineId: line.transferLineId,
                         refNo: receiptNo, note: `rack=${toRack}`, isLegacy: false, createdBy: confirmedBy });
        }
        // returnQty > 0: undelivered portion stays InTransit; source confirms return via confirmReturn.
      }
    }

    tr.receiptNo = receiptNo;
    tr.confirmedAt = ts;
    tr.confirmedBy = confirmedBy;
    tr.updatedAt = ts; tr.updatedBy = confirmedBy;
    // Status: Received if everything received; PartialReceived if any return pending.
    tr.status = hasReturn ? 'PartialReceived' : 'Received';
    return { ...tr, lines: lines.map(l => ({ ...l })) };
  }

  function rejectTransfer({ transferId, rejectReason = null, confirmedBy = 'system' }) {
    const tr = transfers.get(transferId);
    if (!tr) throw Object.assign(Error('Transfer không tìm thấy.'), { status: 404 });
    if (tr.status !== 'InTransit')
      throw Object.assign(Error(`Transfer đang ở trạng thái ${tr.status}, không thể từ chối.`), { status: 409 });

    const ts = now();
    const lines = [...trLines.values()].filter(l => l.transferId === transferId);

    // Mark all lines as not received; stock stays InTransit until confirmReturn.
    for (const line of lines) {
      line.receivedQty = 0;
      // SET units remain InTransit (stockState unchanged).
      // PBA qty remains deducted from source until confirmReturn.
    }

    tr.status = 'Rejected';
    tr.rejectReason = rejectReason;
    tr.confirmedAt = ts;      // when receiver refused
    tr.confirmedBy = confirmedBy;
    tr.updatedAt = ts; tr.updatedBy = confirmedBy;
    return { ...tr, lines: lines.map(l => ({ ...l })) };
  }

  /**
   * confirmReturn — source confirms physical receipt of items coming back.
   * Valid after status Rejected or PartialReceived.
   * Only then is stock added back to the source holder.
   * When all pending returns are confirmed → status = ReturnConfirmed.
   */
  function confirmReturn({ transferId, confirmedBy = 'system', returnLines = null }) {
    const tr = transfers.get(transferId);
    if (!tr) throw Object.assign(Error('Transfer không tìm thấy.'), { status: 404 });
    if (!['Rejected', 'PartialReceived'].includes(tr.status))
      throw Object.assign(Error(`Transfer đang ở trạng thái ${tr.status}, không thể xác nhận trả hàng.`), { status: 409 });

    const ts = now();
    const lines = [...trLines.values()].filter(l => l.transferId === transferId);
    let stillPending = false;

    for (const line of lines) {
      // pendingReturn = total that needs to come back minus what source has already confirmed
      const totalReturn    = line.qty - (line.receivedQty ?? 0);
      const alreadyConfirmed = line.returnConfirmedQty ?? 0;
      const pendingReturn  = totalReturn - alreadyConfirmed;
      if (pendingReturn <= 0) continue; // this line fully handled

      const override = returnLines?.find(r => r.transferLineId === line.transferLineId);
      const confirmQty = override != null ? override.returnConfirmedQty : pendingReturn;
      if (!Number.isInteger(confirmQty) || confirmQty < 0 || confirmQty > pendingReturn)
        throw Object.assign(Error(`returnConfirmedQty không hợp lệ cho line ${line.transferLineId}.`), { status: 400 });

      if (confirmQty > 0) {
        // Accumulate (supports incremental confirmReturn calls)
        line.returnConfirmedQty = alreadyConfirmed + confirmQty;
        line.returnConfirmedAt = ts;

        if (line.itemType === 'SET') {
          const unit = setUnits.get(line.setUnitId);
          unit.holderCode = tr.fromHolder;
          unit.stockState = 'InStock';
          unit.updatedAt = ts; unit.updatedBy = confirmedBy;
          _addMovement({ type: 'TransferBack', itemType: 'SET', holderCode: tr.fromHolder,
                         counterHolder: tr.toHolder, setUnitId: unit.setUnitId,
                         sn: unit.sn, imei1: unit.imei1, model: unit.model,
                         condition: unit.condition, qtyDelta: 1,
                         transferId, transferLineId: line.transferLineId,
                         refNo: tr.receiptNo || tr.transferNo,
                         note: `return confirmed by source`, isLegacy: false, createdBy: confirmedBy });
        } else {
          const fromRack = line.fromRack ?? '';
          let pbBack = findPbaRow(line.model, tr.fromHolder, line.condition, fromRack);
          if (!pbBack) {
            const id = ++pbaSeq;
            pbBack = { pbaStockId: id, model: line.model, holderCode: tr.fromHolder,
                       condition: line.condition, rack: fromRack, qty: 0,
                       basicModel: line.basicModel, origin: line.origin,
                       remark: null, updatedAt: ts, updatedBy: confirmedBy };
            pbaStock.set(id, pbBack);
          }
          pbBack.qty += confirmQty;
          pbBack.updatedAt = ts; pbBack.updatedBy = confirmedBy;
          _addMovement({ type: 'TransferBack', itemType: 'PBA', holderCode: tr.fromHolder,
                         counterHolder: tr.toHolder, setUnitId: null, sn: null, imei1: null,
                         model: line.model, condition: line.condition, qtyDelta: confirmQty,
                         transferId, transferLineId: line.transferLineId,
                         refNo: tr.receiptNo || tr.transferNo,
                         note: `return confirmed rack=${fromRack}`, isLegacy: false, createdBy: confirmedBy });
        }
      } else {
        // confirmQty = 0 for this line: still pending
        stillPending = true;
      }
    }

    // Re-check: any line where totalReturn > returnConfirmedQty (cumulative)
    if (!stillPending) {
      for (const line of lines) {
        const totalReturn   = line.qty - (line.receivedQty ?? 0);
        const confirmed     = line.returnConfirmedQty ?? 0;
        if (totalReturn > confirmed) { stillPending = true; break; }
      }
    }

    if (!stillPending) tr.status = 'ReturnConfirmed';
    tr.updatedAt = ts; tr.updatedBy = confirmedBy;
    return { ...tr, lines: lines.map(l => ({ ...l })) };
  }

  function listTransfers({ status, fromHolder, toHolder, transferId, vendorHolder } = {}) {
    return [...transfers.values()].filter(t =>
      (!status        || t.status === status) &&
      (!fromHolder    || t.fromHolder === fromHolder) &&
      (!toHolder      || t.toHolder   === toHolder) &&
      (transferId === undefined || t.transferId === transferId) &&
      (!vendorHolder  || t.fromHolder === vendorHolder || t.toHolder === vendorHolder)
    ).map(t => {
      const lines = [...trLines.values()].filter(l => l.transferId === t.transferId).map(l => ({ ...l }));
      return { ...t, lines };
    });
  }

  /* ======== NG Report ======== */

  function reportNG({ holderCode, itemType, sn, imei1, model, basicModel,
                      qty, reason, reportedBy = 'system' }) {
    const hc = resolveHolder(holderCode);
    if (!['SET','PBA'].includes(itemType))
      throw Object.assign(Error('itemType phải là SET hoặc PBA.'), { status: 400 });
    if (!reason || !reason.trim())
      throw Object.assign(Error('Lý do báo NG là bắt buộc.'), { status: 400 });

    let setUnitId = null;
    if (itemType === 'SET') {
      if (!sn) throw Object.assign(Error('SET NG cần có SN.'), { status: 400 });
      const unit = setSN(sn);
      if (!unit) throw Object.assign(Error(`SET SN=${sn} không tìm thấy.`), { status: 404 });
      setUnitId = unit.setUnitId;
      // Update condition
      unit.condition = 'NG';
      unit.updatedAt = now(); unit.updatedBy = reportedBy;
    }

    const date = yyyymmdd();
    const reportNo = makeTransferNo('NG', counters, date);
    const id = ++ngSeq;
    const ts = now();
    const row = {
      ngReportId: id, reportNo, holderCode: hc, itemType,
      setUnitId, sn: sn || null, imei1: imei1 || null,
      model, basicModel: basicModel || null,
      qty: itemType === 'SET' ? 1 : qty,
      reason, status: 'Reported', alertStatus: 'New',
      alertReadAt: null, alertReadBy: null,
      reportedAt: ts, reportedBy,
      closedAt: null, closedBy: null, closeNote: null,
    };
    ngReports.set(id, row);
    _addMovement({ type: 'ConditionChg', itemType, holderCode: hc, setUnitId,
                   sn: sn || null, imei1: imei1 || null, model, condition: 'NG',
                   qtyDelta: 0, ngReportId: id, refNo: reportNo,
                   note: reason, isLegacy: false, createdBy: reportedBy });
    return { ...row };
  }

  function listNGAlerts({ onlyNew = true } = {}) {
    return [...ngReports.values()]
      .filter(r => !onlyNew || r.alertStatus === 'New')
      .map(r => ({ ...r }));
  }

  function acknowledgeNGAlert({ ngReportId, readBy = 'system' }) {
    const r = ngReports.get(ngReportId);
    if (!r) throw Object.assign(Error('NG Report không tìm thấy.'), { status: 404 });
    r.alertStatus = 'Read';
    r.alertReadAt = now();
    r.alertReadBy = readBy;
    r.status = 'Acknowledged';
    return { ...r };
  }

  /* ======== Destroy (Phase 4D.5B) ======== */

  const _destroyedRefs = new Set(); // idempotency: destroyRefNo

  function destroyStock({ itemType, sn, model, holderCode, condition, rack, qty,
                          reason, destroyedBy = 'system', destroyRefNo }) {
    if (!['SET', 'PBA'].includes(itemType))
      throw Object.assign(Error('itemType phải là SET hoặc PBA.'), { status: 400 });
    if (!reason || !String(reason).trim())
      throw Object.assign(Error('reason là bắt buộc.'), { status: 400 });

    // Idempotency guard
    if (destroyRefNo) {
      if (_destroyedRefs.has(destroyRefNo))
        throw Object.assign(Error(`Destroy đã được thực hiện (duplicate destroyRefNo: ${destroyRefNo}).`), { status: 409 });
    }

    const ts = now();
    const refNo = destroyRefNo || `DST-${yyyymmdd()}-${pad3(++mvSeq)}`;

    if (itemType === 'SET') {
      if (!sn || !String(sn).trim())
        throw Object.assign(Error('sn là bắt buộc cho SET Destroy.'), { status: 400 });
      const unit = setSN(String(sn).trim());
      if (!unit) throw Object.assign(Error(`SET SN=${sn} không tìm thấy.`), { status: 404 });
      if (unit.holderCode !== 'SEV')
        throw Object.assign(Error(`Chỉ SEV-held SET mới được Destroy (unit đang ở ${unit.holderCode}).`), { status: 409 });
      if (unit.condition !== 'NG')
        throw Object.assign(Error(`Chỉ SET condition=NG mới được Destroy (condition hiện tại: ${unit.condition}).`), { status: 409 });
      if (unit.stockState === 'InTransit')
        throw Object.assign(Error('SET đang InTransit, không thể Destroy.'), { status: 409 });
      if (unit.stockState === 'Destroyed')
        throw Object.assign(Error(`SET SN=${sn} đã bị Destroy trước đó.`), { status: 409 });

      unit.stockState = 'Destroyed';
      unit.updatedAt = ts; unit.updatedBy = destroyedBy;

      _addMovement({ type: 'Destroy', itemType: 'SET', holderCode: unit.holderCode,
                     counterHolder: null, setUnitId: unit.setUnitId, sn: unit.sn,
                     imei1: unit.imei1, model: unit.model, condition: unit.condition,
                     qtyDelta: -1, transferId: null, transferLineId: null,
                     refNo, note: reason, isLegacy: false, createdBy: destroyedBy });

      if (destroyRefNo) _destroyedRefs.add(destroyRefNo);
      return { itemType: 'SET', sn: unit.sn, model: unit.model, holderCode: unit.holderCode,
               condition: unit.condition, stockState: unit.stockState, refNo,
               destroyedBy, destroyedAt: ts };
    }

    // PBA
    if (!model || !String(model).trim())
      throw Object.assign(Error('model là bắt buộc cho PBA Destroy.'), { status: 400 });
    const hc = resolveHolder(holderCode || 'SEV');
    if (hc !== 'SEV')
      throw Object.assign(Error(`Chỉ SEV-held PBA mới được Destroy (holderCode: ${hc}).`), { status: 409 });
    if (!Number.isInteger(qty) || qty <= 0)
      throw Object.assign(Error('qty phải là số nguyên dương.'), { status: 400 });

    const rk = rack ?? '';
    const pbRow = findPbaRow(String(model).trim(), hc, condition, rk);
    if (!pbRow || pbRow.qty < qty)
      throw Object.assign(Error(
        `PBA ${model}/${hc}/${condition}/rack="${rk}" không đủ tồn (cần ${qty}, có ${pbRow?.qty ?? 0}).`
      ), { status: 409 });

    pbRow.qty -= qty;
    pbRow.updatedAt = ts; pbRow.updatedBy = destroyedBy;

    _addMovement({ type: 'Destroy', itemType: 'PBA', holderCode: hc,
                   counterHolder: null, setUnitId: null, sn: null, imei1: null,
                   model: String(model).trim(), condition, qtyDelta: -qty,
                   transferId: null, transferLineId: null,
                   refNo, note: reason, isLegacy: false, createdBy: destroyedBy });

    if (destroyRefNo) _destroyedRefs.add(destroyRefNo);
    return { itemType: 'PBA', model: String(model).trim(), holderCode: hc,
             condition, rack: rk, qtyDestroyed: qty, refNo,
             destroyedBy, destroyedAt: ts };
  }

  /* ======== Stock summary ======== */

  function stockSummary({ includDemo = false } = {}) {
    const out = [];
    // SET
    const setMap = {};
    for (const u of setUnits.values()) {
      if (!includDemo && u.isDemo) continue;
      if (u.stockState !== 'InStock') continue;
      const k = `SET|${u.model}|${u.holderCode}|${u.condition}`;
      setMap[k] = (setMap[k] || { itemType: 'SET', model: u.model, holderCode: u.holderCode,
                                   condition: u.condition, rack: null, qty: 0 });
      setMap[k].qty++;
    }
    out.push(...Object.values(setMap));
    // PBA
    for (const r of pbaStock.values()) {
      if (r.qty > 0) out.push({ itemType: 'PBA', model: r.model, holderCode: r.holderCode,
                                 condition: r.condition, rack: r.rack, qty: r.qty });
    }
    return out;
  }

  /* ======== Seed demo data ======== */

  if (seed !== false) {
    // ── 10 DEMO SET units — 2 per holder ──────────────────────────────────
    // SEV
    addSetUnit({ sn:'TEST-SN-001', imei1:'111111111111111', imei2:null,
                 model:'SM-S928UZKAXAR', basicModel:'SM-S928',
                 origin:'Vietnam', holderCode:'SEV', condition:'OK',
                 location:'R-SEV-01', remark:'DEMO', isDemo:true, createdBy:'seed' });
    addSetUnit({ sn:'TEST-SN-002', imei1:'222222222222222', imei2:'222222222222223',
                 model:'SM-X936BEUBXFE', basicModel:'SM-X936',
                 origin:'Korea', holderCode:'SEV', condition:'NG',
                 location:'R-SEV-02', remark:'DEMO-NG', isDemo:true, createdBy:'seed' });
    // ALT
    addSetUnit({ sn:'TEST-SN-003', imei1:'333333333333333', imei2:null,
                 model:'SM-A556EZKDXFE', basicModel:'SM-A556',
                 origin:'Vietnam', holderCode:'ALT', condition:'OK',
                 location:'R-ALT-01', remark:'DEMO', isDemo:true, createdBy:'seed' });
    addSetUnit({ sn:'TEST-SN-004', imei1:null, imei2:null,
                 model:'SM-A556EZKDXFE', basicModel:'SM-A556',
                 origin:'Vietnam', holderCode:'ALT', condition:'Checking',
                 location:'R-ALT-02', remark:'DEMO-CHK', isDemo:true, createdBy:'seed' });
    // ALV
    addSetUnit({ sn:'TEST-SN-005', imei1:'555555555555555', imei2:null,
                 model:'SM-F946BZKDXFE', basicModel:'SM-F946',
                 origin:'Vietnam', holderCode:'ALV', condition:'OK',
                 location:'R-ALV-01', remark:'DEMO', isDemo:true, createdBy:'seed' });
    addSetUnit({ sn:'TEST-SN-006', imei1:'666666666666666', imei2:null,
                 model:'SM-F946BZKDXFE', basicModel:'SM-F946',
                 origin:'Vietnam', holderCode:'ALV', condition:'NG',
                 location:'R-ALV-02', remark:'DEMO-NG', isDemo:true, createdBy:'seed' });
    // BUJEON
    addSetUnit({ sn:'TEST-SN-007', imei1:'777777777777777', imei2:null,
                 model:'SM-S921BZKDXFE', basicModel:'SM-S921',
                 origin:'Vietnam', holderCode:'BUJEON', condition:'OK',
                 location:'R-BJ-01', remark:'DEMO', isDemo:true, createdBy:'seed' });
    addSetUnit({ sn:'TEST-SN-008', imei1:null, imei2:null,
                 model:'SM-S921BZKDXFE', basicModel:'SM-S921',
                 origin:'Vietnam', holderCode:'BUJEON', condition:'OK',
                 location:'R-BJ-02', remark:'DEMO', isDemo:true, createdBy:'seed' });
    // CHITWING
    addSetUnit({ sn:'TEST-SN-009', imei1:'999999999999999', imei2:null,
                 model:'SM-R900NZKAXFE', basicModel:'SM-R900',
                 origin:'Vietnam', holderCode:'CHITWING', condition:'OK',
                 location:'R-CW-01', remark:'DEMO', isDemo:true, createdBy:'seed' });
    addSetUnit({ sn:'TEST-SN-010', imei1:null, imei2:null,
                 model:'SM-R900NZKAXFE', basicModel:'SM-R900',
                 origin:'Vietnam', holderCode:'CHITWING', condition:'NG',
                 location:'R-CW-02', remark:'DEMO-NG', isDemo:true, createdBy:'seed' });

    // ── 10 DEMO PBA rows — 2 per holder ───────────────────────────────────
    // SEV
    upsertPbaStock({ model:'PBA-MAIN-S928', holderCode:'SEV', condition:'OK', rack:'R-SEV-01',
                     qty:15, basicModel:'Mainboard S928', origin:'Vietnam', remark:'DEMO', updatedBy:'seed' });
    upsertPbaStock({ model:'PBA-DISP-X936', holderCode:'SEV', condition:'NG', rack:'R-SEV-02',
                     qty:3,  basicModel:'Display X936',   origin:'Korea',   remark:'DEMO-NG', updatedBy:'seed' });
    // ALT
    upsertPbaStock({ model:'PBA-MAIN-A556', holderCode:'ALT', condition:'OK', rack:'R-ALT-01',
                     qty:20, basicModel:'Mainboard A556', origin:'Vietnam', remark:'DEMO', updatedBy:'seed' });
    upsertPbaStock({ model:'PBA-BATT-A556', holderCode:'ALT', condition:'OK', rack:'R-ALT-02',
                     qty:12, basicModel:'Battery A556',   origin:'Vietnam', remark:'DEMO', updatedBy:'seed' });
    // ALV
    upsertPbaStock({ model:'PBA-MAIN-F946', holderCode:'ALV', condition:'OK', rack:'R-ALV-01',
                     qty:8,  basicModel:'Mainboard F946', origin:'Vietnam', remark:'DEMO', updatedBy:'seed' });
    upsertPbaStock({ model:'PBA-HINGE-F946', holderCode:'ALV', condition:'Checking', rack:'R-ALV-02',
                     qty:5,  basicModel:'Hinge F946',     origin:'Korea',   remark:'DEMO-CHK', updatedBy:'seed' });
    // BUJEON
    upsertPbaStock({ model:'PBA-MAIN-S921', holderCode:'BUJEON', condition:'OK', rack:'R-BJ-01',
                     qty:18, basicModel:'Mainboard S921', origin:'Vietnam', remark:'DEMO', updatedBy:'seed' });
    upsertPbaStock({ model:'PBA-CAM-S921',  holderCode:'BUJEON', condition:'NG', rack:'R-BJ-02',
                     qty:2,  basicModel:'Camera S921',    origin:'Vietnam', remark:'DEMO-NG', updatedBy:'seed' });
    // CHITWING
    upsertPbaStock({ model:'PBA-MAIN-R900', holderCode:'CHITWING', condition:'OK', rack:'R-CW-01',
                     qty:10, basicModel:'Mainboard R900', origin:'Vietnam', remark:'DEMO', updatedBy:'seed' });
    upsertPbaStock({ model:'PBA-SPKR-R900', holderCode:'CHITWING', condition:'OK', rack:'R-CW-02',
                     qty:7,  basicModel:'Speaker R900',   origin:'Vietnam', remark:'DEMO', updatedBy:'seed' });
  }

  /* ---------- registerBatch ---------- */
  const _processedRequests = new Set(); // idempotency

  function registerBatch({ requestId, sets = [], pbas = [], registeredBy = 'system' }) {
    if (!requestId) throw Object.assign(Error('requestId là bắt buộc.'), { status: 400 });
    if (_processedRequests.has(requestId))
      throw Object.assign(Error('Yêu cầu đã được xử lý (duplicate submission).'), { status: 409 });

    // --- Phase 1: validate everything before touching state ---
    const errors = [];

    // Validate SETs
    const snSet = new Set();
    const imei1Set = new Set();
    const imei2Set = new Set();
    sets.forEach((row, i) => {
      const sn = String(row.sn || '').trim();
      if (!sn) { errors.push({ sheet: 'NEW_SET', row: i + 2, field: 'SN', message: 'SN là bắt buộc.' }); return; }
      if (setSN(sn)) { errors.push({ sheet: 'NEW_SET', row: i + 2, field: 'SN', message: `SN đã tồn tại trong hệ thống: ${sn}` }); }
      if (snSet.has(sn)) { errors.push({ sheet: 'NEW_SET', row: i + 2, field: 'SN', message: `SN trùng trong file: ${sn}` }); }
      snSet.add(sn);
      if (row.imei1) {
        const i1 = String(row.imei1).trim();
        if (setByIMEI(i1)) errors.push({ sheet: 'NEW_SET', row: i + 2, field: 'IMEI1', message: `IMEI1 đã tồn tại: ${i1}` });
        if (imei1Set.has(i1)) errors.push({ sheet: 'NEW_SET', row: i + 2, field: 'IMEI1', message: `IMEI1 trùng trong file: ${i1}` });
        imei1Set.add(i1);
      }
      if (row.imei2) {
        const i2 = String(row.imei2).trim();
        if (setByIMEI(i2)) errors.push({ sheet: 'NEW_SET', row: i + 2, field: 'IMEI2', message: `IMEI2 đã tồn tại: ${i2}` });
        if (imei2Set.has(i2)) errors.push({ sheet: 'NEW_SET', row: i + 2, field: 'IMEI2', message: `IMEI2 trùng trong file: ${i2}` });
        imei2Set.add(i2);
      }
    });

    // Validate PBAs
    pbas.forEach((row, i) => {
      if (!row.model || !String(row.model).trim()) errors.push({ sheet: 'NEW_PBA', row: i + 2, field: 'Model', message: 'Model là bắt buộc.' });
      const qty = Number(row.qty);
      if (!Number.isInteger(qty) || qty <= 0) errors.push({ sheet: 'NEW_PBA', row: i + 2, field: 'Qty', message: `Qty phải là số nguyên dương (nhận được: ${row.qty}).` });
    });

    if (errors.length) throw Object.assign(Error(`Có ${errors.length} lỗi validation. Không đăng ký.`), { status: 422, errors });

    // --- Phase 2: atomic apply ---
    _processedRequests.add(requestId);

    const registeredSets = [];
    const registeredPbas = [];

    for (const row of sets) {
      try {
        const unit = addSetUnit({
          sn:         String(row.sn).trim(),
          imei1:      row.imei1      ? String(row.imei1).trim()      : null,
          imei2:      row.imei2      ? String(row.imei2).trim()      : null,
          model:      String(row.model      || '').trim() || null,
          basicModel: String(row.basicModel || '').trim() || null,
          serial:     String(row.serial     || '').trim() || null,
          un:         String(row.un         || '').trim() || null,
          origin:     String(row.origin     || '').trim() || null,
          mode:       String(row.mode       || '').trim() || null,
          location:   String(row.location   || '').trim() || null,
          cro:        String(row.cro        || '').trim() || null,
          remark:     String(row.remark     || '').trim() || null,
          holderCode: 'SEV',
          condition:  ['OK','NG','Checking'].includes(row.condition) ? row.condition : 'OK',
          createdBy:  registeredBy,
        });
        registeredSets.push(unit);
      } catch (e) {
        // Should not happen after validation — but defensively rollback idempotency key and rethrow
        _processedRequests.delete(requestId);
        throw Object.assign(Error(`Lỗi khi đăng ký SN=${row.sn}: ${e.message}`), { status: 500 });
      }
    }

    for (const row of pbas) {
      try {
        const model = String(row.model).trim();
        const condition = String(row.condition || 'OK').trim() || 'OK';
        const rack = String(row.rack || '').trim();
        const incoming = Number(row.qty);
        // Merge: add incoming to existing qty so registerBatch always increases stock
        const existing = findPbaRow(model, 'SEV', condition, rack);
        const mergedQty = (existing ? existing.qty : 0) + incoming;
        const pba = upsertPbaStock({
          model, holderCode: 'SEV', condition, rack,
          qty:        mergedQty,
          basicModel: String(row.basicModel || '').trim() || null,
          origin:     String(row.origin     || '').trim() || null,
          remark:     String(row.remark     || '').trim() || null,
          updatedBy:  registeredBy,
        });
        registeredPbas.push(pba);
      } catch (e) {
        _processedRequests.delete(requestId);
        throw Object.assign(Error(`Lỗi khi đăng ký PBA model=${row.model}: ${e.message}`), { status: 500 });
      }
    }

    return {
      registered: { sets: registeredSets.length, pbas: registeredPbas.length },
      sets: registeredSets,
      pbas: registeredPbas,
    };
  }

  /* ---------- previewTransferImport ---------- */
  // Phase 4D.3D-2B: validates without writing any state
  function previewTransferImport({ fromHolder, sets = [], pbas = [] }) {
    const errors = [];
    const warnings = [];
    const validSets = [];
    const validPbas = [];

    const snSeen = new Set();
    sets.forEach((row, i) => {
      const sn = String(row.sn || '').trim();
      if (!sn) { errors.push({ type: 'SET', row: i + 1, sn: '', field: 'SN', msg: 'SN trống.' }); return; }
      if (snSeen.has(sn)) { errors.push({ type: 'SET', row: i + 1, sn, field: 'SN', msg: `SN trùng trong file: ${sn}` }); return; }
      snSeen.add(sn);
      const unit = setSN(sn);
      if (!unit) { errors.push({ type: 'SET', row: i + 1, sn, field: 'SN', msg: `SN không tồn tại trong hệ thống.` }); return; }
      if (unit.holderCode !== fromHolder) { errors.push({ type: 'SET', row: i + 1, sn, field: 'Holder', msg: `SN thuộc ${unit.holderCode}, không phải ${fromHolder}.`, systemValue: unit.holderCode }); return; }
      if (unit.stockState === 'InTransit') { errors.push({ type: 'SET', row: i + 1, sn, field: 'StockState', msg: `SN đang InTransit, không thể chuyển.` }); return; }
      if (unit.stockState === 'Reserved')  { errors.push({ type: 'SET', row: i + 1, sn, field: 'StockState', msg: `SN đang Reserved.` }); return; }
      if (row.model && unit.model && String(row.model).trim() !== unit.model)
        warnings.push({ type: 'SET', row: i + 1, sn, field: 'Model', msg: `Model file: ${row.model} ≠ hệ thống: ${unit.model}`, fileValue: row.model, systemValue: unit.model });
      if (row.imei1 && unit.imei1 && String(row.imei1).trim() !== unit.imei1)
        warnings.push({ type: 'SET', row: i + 1, sn, field: 'IMEI1', msg: `IMEI1 file: ${row.imei1} ≠ hệ thống: ${unit.imei1}`, fileValue: row.imei1, systemValue: unit.imei1 });
      validSets.push({ sn, model: unit.model, imei1: unit.imei1, holderCode: unit.holderCode, stockState: unit.stockState, condition: unit.condition });
    });

    const pbaKeysSeen = new Set();
    pbas.forEach((row, i) => {
      const model = String(row.model || '').trim();
      const condition = String(row.condition || 'OK').trim() || 'OK';
      const rack = String(row.rack || '').trim();
      const qty = Number(row.qty);
      if (!model) { errors.push({ type: 'PBA', row: i + 1, model: '', field: 'Model', msg: 'Model trống.' }); return; }
      if (!Number.isInteger(qty) || qty <= 0) { errors.push({ type: 'PBA', row: i + 1, model, field: 'Qty', msg: `Qty không hợp lệ: ${row.qty}` }); return; }
      const pKey = `${model}|${condition}|${rack}`;
      if (pbaKeysSeen.has(pKey)) { errors.push({ type: 'PBA', row: i + 1, model, field: 'Model', msg: `Dòng PBA trùng: model=${model} cond=${condition} rack=${rack}` }); return; }
      pbaKeysSeen.add(pKey);
      const existing = findPbaRow(model, fromHolder, condition, rack);
      if (!existing) { errors.push({ type: 'PBA', row: i + 1, model, field: 'Model', msg: `Không tìm thấy PBA model=${model} condition=${condition} rack=${rack} tại ${fromHolder}.` }); return; }
      if (existing.qty < qty) { errors.push({ type: 'PBA', row: i + 1, model, field: 'Qty', msg: `Yêu cầu ${qty}, tồn kho chỉ còn ${existing.qty}.`, systemValue: existing.qty }); return; }
      validPbas.push({ model, condition, rack, qty, availableQty: existing.qty, holderCode: fromHolder });
    });

    return { errors, warnings, valid: { sets: validSets, pbas: validPbas } };
  }

  /* ---------- requestAdjust (Phase 4D.3F Batch 2B-1) ---------- */

  function _makeAdjReqNo(date) {
    const key = 'ADJ' + date;
    counters[key] = (counters[key] || 0) + 1;
    return 'ADJREQ-' + date + '-' + pad3(counters[key]);
  }

  // Vendor submits adjustment request (PBA). Status = Pending, no stock change.
  function submitAdjRequest({ requestId, holderCode, pbas = [], requestedBy = 'system' }) {
    if (!requestId) throw Object.assign(Error('requestId là bắt buộc.'), { status: 400 });
    if (_processedRequests.has(requestId))
      throw Object.assign(Error('Yêu cầu đã được xử lý (duplicate submission).'), { status: 409 });
    const hc = resolveHolder(holderCode);

    const errors = [];
    pbas.forEach((row, i) => {
      const model = String(row.model || '').trim();
      if (!model) { errors.push({ row: i + 2, field: 'Model', msg: 'Model trống.' }); return; }
      const qty = Number(row.qty);
      if (!Number.isInteger(qty) || qty <= 0)
        errors.push({ row: i + 2, field: 'Qty', msg: `Qty phải là số nguyên dương.` });
      const dir = String(row.direction || '').toUpperCase();
      if (!['IN','OUT'].includes(dir))
        errors.push({ row: i + 2, field: 'Direction', msg: 'Direction phải là IN hoặc OUT.' });
      const cond = String(row.condition || 'OK');
      if (!['OK','NG','Checking'].includes(cond))
        errors.push({ row: i + 2, field: 'Condition', msg: 'Condition phải là OK/NG/Checking.' });
    });
    if (errors.length)
      throw Object.assign(Error(`Có ${errors.length} lỗi validation.`), { status: 422, errors });

    _processedRequests.add(requestId);
    const date = yyyymmdd();
    const created = [];
    for (const row of pbas) {
      const id = ++adjReqSeq;
      const rec = {
        adjReqId:    id,
        requestNo:   _makeAdjReqNo(date),
        holderCode:  hc,
        itemType:    'PBA',
        model:       String(row.model).trim(),
        basicModel:  row.basicModel ? String(row.basicModel).trim() : null,
        condition:   String(row.condition || 'OK'),
        rack:        String(row.rack || '').trim(),
        qty:         Number(row.qty),
        direction:   String(row.direction || 'IN').toUpperCase(),
        reason:      String(row.reason || row.remark || '').trim() || null,
        status:      'Pending',
        requestedBy,
        requestedAt: now(),
        reviewedBy:  null,
        reviewedAt:  null,
        reviewNote:  null,
      };
      adjReqs.set(id, rec);
      created.push({ ...rec });
    }
    return { submitted: created.length, requests: created };
  }

  function listAdjRequests({ holderCode, status } = {}) {
    return [...adjReqs.values()].filter(r =>
      (!holderCode || r.holderCode === resolveHolder(holderCode)) &&
      (!status     || r.status === status)
    ).map(r => ({ ...r }));
  }

  // SEV approves a Pending adjustment request. Re-validates stock, applies change, records Movement.
  function approveAdjRequest({ adjReqId, approvedBy = 'system', note = null }) {
    const rec = adjReqs.get(adjReqId);
    if (!rec) throw Object.assign(Error(`AdjRequest ${adjReqId} không tồn tại.`), { status: 404 });
    if (rec.status !== 'Pending')
      throw Object.assign(Error(`AdjRequest đang ở trạng thái ${rec.status}, không thể phê duyệt.`), { status: 409 });

    // Re-validate stock before applying
    const { model, holderCode, condition, rack, qty, direction } = rec;
    if (direction === 'OUT') {
      const existing = findPbaRow(model, holderCode, condition, rack);
      const available = existing ? existing.qty : 0;
      if (available < qty)
        throw Object.assign(
          Error(`Tồn kho không đủ: ${model} ${condition} rack=${rack} tại ${holderCode} chỉ còn ${available}, yêu cầu OUT ${qty}.`),
          { status: 422 }
        );
    }

    // Apply stock change
    const existing = findPbaRow(model, holderCode, condition, rack);
    const delta = qty * (direction === 'OUT' ? -1 : 1);
    const newQty = (existing ? existing.qty : 0) + delta;
    upsertPbaStock({
      model, holderCode, condition, rack, qty: newQty,
      remark: rec.reason,
      movementType: 'Adjust',
      updatedBy: approvedBy,
    });

    // Update request status
    rec.status = 'Approved';
    rec.reviewedBy = approvedBy;
    rec.reviewedAt = now();
    rec.reviewNote = note || null;
    return { ...rec };
  }

  // SEV rejects a Pending adjustment request. No stock change.
  function rejectAdjRequest({ adjReqId, rejectReason = '', rejectedBy = 'system' }) {
    const rec = adjReqs.get(adjReqId);
    if (!rec) throw Object.assign(Error(`AdjRequest ${adjReqId} không tồn tại.`), { status: 404 });
    if (rec.status !== 'Pending')
      throw Object.assign(Error(`AdjRequest đang ở trạng thái ${rec.status}, không thể từ chối.`), { status: 409 });

    rec.status = 'Rejected';
    rec.reviewedBy = rejectedBy;
    rec.reviewedAt = now();
    rec.reviewNote = rejectReason || null;
    return { ...rec };
  }

  /* ---------- stockAdd (Phase 4D.3F Batch 2A) ---------- */
  // SEV adds more PBA stock (delta-add, always positive). Movement type = Import.
  function stockAdd({ requestId, pbas = [], addedBy = 'system' }) {
    if (!requestId) throw Object.assign(Error('requestId là bắt buộc.'), { status: 400 });
    if (_processedRequests.has(requestId))
      throw Object.assign(Error('Yêu cầu đã được xử lý (duplicate submission).'), { status: 409 });

    const errors = [];
    const keysSeen = new Set();
    pbas.forEach((row, i) => {
      const model = String(row.model || '').trim();
      if (!model) { errors.push({ row: i + 2, field: 'Model', msg: 'Model trống.' }); return; }
      const qty = Number(row.qty);
      if (!Number.isInteger(qty) || qty <= 0) { errors.push({ row: i + 2, field: 'Qty', msg: `Qty phải là số nguyên dương (nhận được: ${row.qty}).` }); return; }
      const condition = String(row.condition || 'OK');
      if (!['OK','NG','Checking'].includes(condition)) { errors.push({ row: i + 2, field: 'Condition', msg: `Condition phải là OK/NG/Checking.` }); return; }
      const k = `${model}|${condition}|${String(row.rack||'').trim()}`;
      if (keysSeen.has(k)) { errors.push({ row: i + 2, field: 'Model', msg: `Dòng trùng: ${model} ${condition}` }); return; }
      keysSeen.add(k);
    });
    if (errors.length) throw Object.assign(Error(`Có ${errors.length} lỗi validation.`), { status: 422, errors });

    _processedRequests.add(requestId);
    const addedRows = [];
    for (const row of pbas) {
      try {
        const model = String(row.model).trim();
        const condition = String(row.condition || 'OK');
        const rack = String(row.rack || '').trim();
        const incoming = Number(row.qty);
        const existing = findPbaRow(model, 'SEV', condition, rack);
        const newQty = (existing ? existing.qty : 0) + incoming;
        const pba = upsertPbaStock({
          model, holderCode: 'SEV', condition, rack, qty: newQty,
          basicModel: row.basicModel ? String(row.basicModel).trim() : null,
          origin:     row.origin     ? String(row.origin).trim()     : null,
          remark:     row.remark     ? String(row.remark).trim()     : null,
          movementType: 'Import',
          updatedBy: addedBy,
        });
        addedRows.push({ ...pba, _delta: incoming });
      } catch (e) {
        _processedRequests.delete(requestId);
        throw Object.assign(Error(`Lỗi khi bổ sung PBA model=${row.model}: ${e.message}`), { status: 500 });
      }
    }
    return { added: addedRows.length, rows: addedRows };
  }

  /* ---------- adjustStock (Phase 4D.3F Batch 2A) ---------- */
  // SEV adjusts PBA stock (delta IN/OUT). Movement type = Adjust.
  function adjustStock({ requestId, pbas = [], adjustedBy = 'system' }) {
    if (!requestId) throw Object.assign(Error('requestId là bắt buộc.'), { status: 400 });
    if (_processedRequests.has(requestId))
      throw Object.assign(Error('Yêu cầu đã được xử lý (duplicate submission).'), { status: 409 });

    const errors = [];
    const keysSeen = new Set();
    pbas.forEach((row, i) => {
      const model = String(row.model || '').trim();
      if (!model) { errors.push({ row: i + 2, field: 'Model', msg: 'Model trống.' }); return; }
      const qty = Number(row.qty);
      if (!Number.isInteger(qty) || qty <= 0) { errors.push({ row: i + 2, field: 'Qty', msg: `Qty phải là số nguyên dương.` }); return; }
      const direction = String(row.direction || '').toUpperCase();
      if (!['IN','OUT'].includes(direction)) { errors.push({ row: i + 2, field: 'Direction', msg: `Direction phải là IN hoặc OUT.` }); return; }
      const condition = String(row.condition || 'OK');
      if (!['OK','NG','Checking'].includes(condition)) { errors.push({ row: i + 2, field: 'Condition', msg: `Condition phải là OK/NG/Checking.` }); return; }
      const rack = String(row.rack || '').trim();
      const k = `${model}|${condition}|${rack}|${direction}`;
      if (keysSeen.has(k)) { errors.push({ row: i + 2, field: 'Model', msg: `Dòng trùng.` }); return; }
      keysSeen.add(k);
      if (direction === 'OUT') {
        const existing = findPbaRow(model, 'SEV', condition, rack);
        const available = existing ? existing.qty : 0;
        if (available < qty)
          errors.push({ row: i + 2, field: 'Qty', msg: `OUT ${qty} vượt tồn kho ${available} (model=${model} cond=${condition} rack=${rack}).` });
      }
    });
    if (errors.length) throw Object.assign(Error(`Có ${errors.length} lỗi validation.`), { status: 422, errors });

    _processedRequests.add(requestId);
    const adjustedRows = [];
    for (const row of pbas) {
      try {
        const model = String(row.model).trim();
        const condition = String(row.condition || 'OK');
        const rack = String(row.rack || '').trim();
        const direction = String(row.direction || 'IN').toUpperCase();
        const delta = Number(row.qty) * (direction === 'OUT' ? -1 : 1);
        const existing = findPbaRow(model, 'SEV', condition, rack);
        const newQty = (existing ? existing.qty : 0) + delta;
        if (newQty < 0) {
          _processedRequests.delete(requestId);
          throw Object.assign(Error(`Tồn kho âm sau điều chỉnh: model=${model}.`), { status: 422 });
        }
        const pba = upsertPbaStock({
          model, holderCode: 'SEV', condition, rack, qty: newQty,
          basicModel: row.basicModel ? String(row.basicModel).trim() : null,
          remark:     row.remark     ? String(row.remark).trim()     : null,
          movementType: 'Adjust',
          updatedBy: adjustedBy,
        });
        adjustedRows.push({ ...pba, direction, _delta: delta });
      } catch (e) {
        if (e.status) throw e;
        _processedRequests.delete(requestId);
        throw Object.assign(Error(`Lỗi điều chỉnh PBA model=${row.model}: ${e.message}`), { status: 500 });
      }
    }
    return { adjusted: adjustedRows };
  }

  return {
    // SET
    addSetUnit, listSetUnits,
    // PBA
    upsertPbaStock, listPbaStock,
    // Transfer
    requestTransfer, dispatchTransfer, createTransfer, receiveTransfer, rejectTransfer, confirmReturn, listTransfers,
    // NG
    reportNG, listNGAlerts, acknowledgeNGAlert,
    // Summary
    stockSummary,
    // Movement (read-only)
    listMovements,
    // Holders (for tests)
    getHolders: () => Object.values(HOLDERS).map(h => ({ ...h })),
    // Phase 4D.3D-1
    registerBatch,
    // Phase 4D.3D-2B
    previewTransferImport,
    // Phase 4D.3F Batch 2A
    stockAdd,
    adjustStock,
    // Phase 4D.3F Batch 2B-1
    submitAdjRequest,
    listAdjRequests,
    approveAdjRequest,
    rejectAdjRequest,
    // Phase 4D.5B
    destroyStock,
  };
}

module.exports = { createMockStore };
