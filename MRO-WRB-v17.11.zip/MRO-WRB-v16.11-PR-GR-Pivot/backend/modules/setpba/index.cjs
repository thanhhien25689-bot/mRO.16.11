/**
 * SET/PBA HTTP handler (Phase 4D.2 / 4D.3A)
 * Registered in create-server.cjs via SP_USE_MOCK=1 (mock) or SQL adapter (future).
 *
 * Permission model (Phase 4D.3A):
 *   - SEV users (no vendorScope): full read/write access
 *   - Vendor users (actor.vendorScope set): read own holder data; write own NG reports;
 *     receive/reject own transfers; no access to stock adjust, ng-ack, or other holders
 *   - VendorCode is NEVER trusted from frontend — always derived from actor.vendorScope
 *
 * API endpoints (all under /api/sp/):
 *   GET  /api/sp/stock              — stock summary (SET + PBA)
 *   GET  /api/sp/set                — list SET units
 *   POST /api/sp/set                — add SET unit   [SEV only]
 *   GET  /api/sp/pba                — list PBA stock rows
 *   POST /api/sp/pba                — upsert PBA stock [SEV only]
 *   GET  /api/sp/transfer           — list transfers
 *   POST /api/sp/transfer           — create transfer (→ InTransit) [SEV only]
 *   POST /api/sp/transfer/receive   — receiver confirms (→ Received) [vendor: own only]
 *   POST /api/sp/transfer/reject    — receiver rejects  (→ Rejected) [vendor: own only]
 *   POST /api/sp/transfer/return-confirm — source confirms return    [fromHolder only]
 *   GET  /api/sp/ng-alerts          — SEV reads NG alerts [SEV only]
 *   POST /api/sp/ng-report          — vendor reports NG   [vendor: own only]
 *   POST /api/sp/ng-ack             — SEV acknowledges alert [SEV only]
 *   GET  /api/sp/movement           — movement ledger (read-only)
 */
'use strict';

const fail = (status, message) => Object.assign(Error(message), { status });

// Map vendor display names (stored in auth accounts) → canonical SET/PBA holder codes.
// vendorScope in user accounts is the MRO display name; SET/PBA stock uses holder codes.
const VENDOR_SCOPE_TO_HOLDER = {
  'Almus Tech':  'ALT',
  'Almustech':   'ALT',
  'ALT':         'ALT',
  'Almus Vina':  'ALV',
  'Almusvina':   'ALV',
  'ALV':         'ALV',
  'Bujeon':      'BUJEON',
  'BUJEON':      'BUJEON',
  'Chitwing':    'CHITWING',
  'CHITWING':    'CHITWING',
  'SEV':         'SEV',
};

/** Resolve actor.vendorScope → canonical SET/PBA holderCode. */
function resolveHolder(vendorScope) {
  if (!vendorScope) return null;
  return VENDOR_SCOPE_TO_HOLDER[vendorScope] || null;
}

function createSetPba({ store }) {
  if (!store) throw Error('createSetPba: store is required');

  async function handle({ req, res, url, body, send, actor, requireUser }) {
    const p = url.pathname;
    if (!p.startsWith('/api/sp/')) return false;

    const method = req.method;

    /* ---- Helpers ---- */
    const json = async () => {
      const b = await body(req);
      if (!b || typeof b !== 'object' || Array.isArray(b))
        throw fail(400, 'Body phải là JSON object.');
      return b;
    };

    // actor is injected by auth.cjs — always present here (requireUser already called upstream)
    const isVendor = !!(actor && actor.vendorScope);
    // Resolve display name → canonical holder code; never trust frontend
    const vendorCode = isVendor ? resolveHolder(actor.vendorScope) : null;
    if (isVendor && !vendorCode)
      throw fail(403, `Holder không hợp lệ: ${actor.vendorScope}. Liên hệ Admin để cập nhật phạm vi Vendor.`);

    // SEV-only routes: vendor users are blocked
    const sevOnly = () => { if (isVendor) throw fail(403, 'Chỉ SEV được thực hiện thao tác này.'); };

    // Vendor GET endpoints: restrict to own holder; SEV/Admin may pass ?holder= freely.
    const holderFilter = qParam => isVendor ? vendorCode : (qParam || undefined);

    const getUser = () => (actor ? actor : { id: 'mock', role: 'admin' });

    /* ---- Routes ---- */

    // Returns resolved holderCode for the authenticated actor — used by frontend to init Holder selector.
    if (p === '/api/sp/identity') {
      if (method !== 'GET') throw fail(405, 'GET only');
      send(res, 200, {
        isVendor,
        holderCode: vendorCode || 'SEV',
        vendorScope: actor?.vendorScope || null,
      });
      return true;
    }

    if (p === '/api/sp/stock') {
      if (method !== 'GET') throw fail(405, 'GET only');
      const inclDemo = url.searchParams.get('inclDemo') === '1';
      send(res, 200, { stock: store.stockSummary({ includDemo: inclDemo }) });
      return true;
    }

    if (p === '/api/sp/set') {
      if (method === 'GET') {
        const q = {
          holderCode: holderFilter(url.searchParams.get('holder')),
          condition:  url.searchParams.get('condition') || undefined,
          stockState: url.searchParams.get('state') || undefined,
          includDemo: url.searchParams.get('inclDemo') === '1',
        };
        send(res, 200, { units: store.listSetUnits(q) });
        return true;
      }
      if (method === 'POST') {
        sevOnly();
        const user = getUser();
        const b = await json();
        const unit = store.addSetUnit({ ...b, createdBy: user.id });
        send(res, 201, { unit });
        return true;
      }
      throw fail(405, 'GET / POST only');
    }

    if (p === '/api/sp/pba') {
      if (method === 'GET') {
        const q = {
          holderCode: holderFilter(url.searchParams.get('holder')),
          condition:  url.searchParams.get('condition') || undefined,
        };
        send(res, 200, { rows: store.listPbaStock(q) });
        return true;
      }
      if (method === 'POST') {
        sevOnly();
        const user = getUser();
        const b = await json();
        const row = store.upsertPbaStock({ ...b, updatedBy: user.id });
        send(res, 200, { row });
        return true;
      }
      throw fail(405, 'GET / POST only');
    }

    if (p === '/api/sp/transfer') {
      if (method === 'GET') {
        // Vendor: always scoped to own holder; SEV/Admin may pass ?holder= freely.
        const holderParam = isVendor ? vendorCode : (url.searchParams.get('holder') || undefined);
        const q = isVendor
          ? { status: url.searchParams.get('status') || undefined }
          : {
              status:     url.searchParams.get('status') || undefined,
              fromHolder: url.searchParams.get('fromHolder') || undefined,
              toHolder:   url.searchParams.get('toHolder')   || undefined,
            };
        const transfers = holderParam
          ? store.listTransfers({ ...q, vendorHolder: holderParam, fromHolder: undefined, toHolder: undefined })
          : store.listTransfers(q);
        send(res, 200, { transfers });
        return true;
      }
      if (method === 'POST') {
        const user = getUser();
        const b = await json();
        // Vendor: fromHolder must equal their own vendorScope (server-enforced)
        if (isVendor && b.fromHolder !== vendorCode)
          throw fail(403, `Vendor chỉ được tạo Transfer từ holder của mình (${vendorCode}).`);
        const result = store.requestTransfer({ ...b, fromHolder: isVendor ? vendorCode : b.fromHolder, requestedBy: user.id });
        send(res, 201, result);
        return true;
      }
      throw fail(405, 'GET / POST only');
    }

    if (p === '/api/sp/transfer/dispatch') {
      if (method !== 'POST') throw fail(405, 'POST only');
      const user = getUser();
      const b = await json();
      if (typeof b.transferId !== 'number')
        throw fail(400, 'transferId (number) là bắt buộc.');
      // Vendor can only dispatch transfers where they are the fromHolder
      if (isVendor) {
        const tf = store.listTransfers({ transferId: b.transferId })[0];
        if (!tf || tf.fromHolder !== vendorCode)
          throw fail(403, 'Vendor chỉ được dispatch Transfer từ holder của mình.');
        if (tf.status !== 'Requested')
          throw fail(409, `Transfer đang ở trạng thái ${tf.status}, không thể dispatch.`);
      }
      const result = store.dispatchTransfer({ transferId: b.transferId, dispatchedBy: user.id });
      send(res, 200, result);
      return true;
    }

    if (p === '/api/sp/transfer/receive') {
      if (method !== 'POST') throw fail(405, 'POST only');
      const user = getUser();
      const b = await json();
      if (typeof b.transferId !== 'number')
        throw fail(400, 'transferId (number) là bắt buộc.');
      // Vendor can only receive transfers where they are the toHolder
      if (isVendor) {
        const tf = store.listTransfers({ transferId: b.transferId })[0];
        if (!tf || tf.toHolder !== vendorCode)
          throw fail(403, 'Vendor chỉ xác nhận nhận hàng Transfer của mình.');
      }
      const result = store.receiveTransfer({ ...b, confirmedBy: user.id });
      send(res, 200, result);
      return true;
    }

    if (p === '/api/sp/transfer/reject') {
      if (method !== 'POST') throw fail(405, 'POST only');
      const user = getUser();
      const b = await json();
      if (typeof b.transferId !== 'number')
        throw fail(400, 'transferId (number) là bắt buộc.');
      // Vendor can only reject transfers where they are the toHolder
      if (isVendor) {
        const tf = store.listTransfers({ transferId: b.transferId })[0];
        if (!tf || tf.toHolder !== vendorCode)
          throw fail(403, 'Vendor chỉ từ chối Transfer của mình.');
      }
      const result = store.rejectTransfer({ ...b, confirmedBy: user.id });
      send(res, 200, result);
      return true;
    }

    if (p === '/api/sp/transfer/return-confirm') {
      if (method !== 'POST') throw fail(405, 'POST only');
      const user = getUser();
      const b = await json();
      if (typeof b.transferId !== 'number')
        throw fail(400, 'transferId (number) là bắt buộc.');
      // Only the original sender (fromHolder) may confirm physical return — including SEV.
      // actorHolder: vendor → their vendorScope; SEV → 'SEV'.
      {
        const actorHolder = isVendor ? vendorCode : 'SEV';
        const tf = store.listTransfers({ transferId: b.transferId })[0];
        if (!tf || tf.fromHolder !== actorHolder)
          throw fail(403, 'Chỉ bên gửi (fromHolder) mới được xác nhận nhận lại hàng hoàn trả.');
      }
      const result = store.confirmReturn({ ...b, confirmedBy: user.id });
      send(res, 200, result);
      return true;
    }

    if (p === '/api/sp/transfer/preview') {
      if (method !== 'POST') throw fail(405, 'POST only');
      requireUser();
      const b = await json();
      // fromHolder is always authenticated actor, never from body
      const fh = isVendor ? vendorCode : (b.fromHolder || 'SEV');
      if (isVendor && fh !== vendorCode)
        throw fail(403, `Vendor chỉ được preview Transfer từ holder của mình (${vendorCode}).`);
      const result = store.previewTransferImport({
        fromHolder: fh,
        sets: b.sets || [],
        pbas: b.pbas || [],
      });
      send(res, 200, result);
      return true;
    }

    if (p === '/api/sp/register-batch') {
      if (method !== 'POST') throw fail(405, 'POST only');
      sevOnly();
      const user = getUser();
      const b = await json();
      if (!b.requestId) throw fail(400, 'requestId là bắt buộc.');
      try {
        const result = store.registerBatch({ ...b, registeredBy: user.id });
        send(res, 201, result);
      } catch (e) {
        const err = Object.assign(Error(e.message), { status: e.status || 500 });
        if (e.errors) err.errors = e.errors;
        throw err;
      }
      return true;
    }

    if (p === '/api/sp/ng-report') {
      if (method !== 'POST') throw fail(405, 'POST only');
      const user = getUser();
      const b = await json();
      // Vendor can only report NG for their own holder; override holderCode from server identity
      const holderCode = isVendor ? vendorCode : b.holderCode;
      const result = store.reportNG({ ...b, holderCode, reportedBy: user.id });
      send(res, 201, result);
      return true;
    }

    if (p === '/api/sp/ng-alerts') {
      if (method !== 'GET') throw fail(405, 'GET only');
      sevOnly();
      const onlyNew = url.searchParams.get('onlyNew') !== '0';
      send(res, 200, { alerts: store.listNGAlerts({ onlyNew }) });
      return true;
    }

    if (p === '/api/sp/ng-ack') {
      if (method !== 'POST') throw fail(405, 'POST only');
      sevOnly();
      const user = getUser();
      const b = await json();
      if (typeof b.ngReportId !== 'number')
        throw fail(400, 'ngReportId (number) là bắt buộc.');
      const result = store.acknowledgeNGAlert({ ...b, readBy: user.id });
      send(res, 200, result);
      return true;
    }

    // ---- Adjustment Requests (Phase 4D.3F Batch 2B-1) ----

    if (p === '/api/sp/adj-request') {
      if (method === 'GET') {
        // Vendor: own holder only. SEV: all.
        const holderParam = isVendor ? vendorCode : (url.searchParams.get('holder') || undefined);
        const statusParam = url.searchParams.get('status') || undefined;
        send(res, 200, { requests: store.listAdjRequests({ holderCode: holderParam, status: statusParam }) });
        return true;
      }
      if (method === 'POST') {
        const user = getUser();
        const b = await json();
        if (!b.requestId) throw fail(400, 'requestId là bắt buộc.');
        // holderCode always from server identity, never from body
        const hc = isVendor ? vendorCode : (b.holderCode || 'SEV');
        if (isVendor && hc !== vendorCode)
          throw fail(403, `Vendor chỉ được tạo yêu cầu điều chỉnh cho holder của mình (${vendorCode}).`);
        try {
          const result = store.submitAdjRequest({ ...b, holderCode: hc, requestedBy: user.id });
          send(res, 201, result);
        } catch (e) {
          const err = Object.assign(Error(e.message), { status: e.status || 500 });
          if (e.errors) err.errors = e.errors;
          throw err;
        }
        return true;
      }
      throw fail(405, 'GET / POST only');
    }

    if (p === '/api/sp/adj-request/approve') {
      if (method !== 'POST') throw fail(405, 'POST only');
      sevOnly();
      const user = getUser();
      const b = await json();
      if (typeof b.adjReqId !== 'number') throw fail(400, 'adjReqId (number) là bắt buộc.');
      try {
        const result = store.approveAdjRequest({ adjReqId: b.adjReqId, approvedBy: user.id, note: b.note || null });
        send(res, 200, result);
      } catch (e) {
        throw Object.assign(Error(e.message), { status: e.status || 500 });
      }
      return true;
    }

    if (p === '/api/sp/adj-request/reject') {
      if (method !== 'POST') throw fail(405, 'POST only');
      sevOnly();
      const user = getUser();
      const b = await json();
      if (typeof b.adjReqId !== 'number') throw fail(400, 'adjReqId (number) là bắt buộc.');
      if (!b.rejectReason?.trim()) throw fail(400, 'rejectReason là bắt buộc.');
      const result = store.rejectAdjRequest({ adjReqId: b.adjReqId, rejectReason: b.rejectReason.trim(), rejectedBy: user.id });
      send(res, 200, result);
      return true;
    }

    if (p === '/api/sp/stock-add') {
      if (method !== 'POST') throw fail(405, 'POST only');
      sevOnly();
      const user = getUser();
      const b = await json();
      if (!b.requestId) throw fail(400, 'requestId là bắt buộc.');
      try {
        const result = store.stockAdd({ ...b, addedBy: user.id });
        send(res, 201, result);
      } catch (e) {
        const err = Object.assign(Error(e.message), { status: e.status || 500 });
        if (e.errors) err.errors = e.errors;
        throw err;
      }
      return true;
    }

    if (p === '/api/sp/adjust') {
      if (method !== 'POST') throw fail(405, 'POST only');
      sevOnly();
      const user = getUser();
      const b = await json();
      if (!b.requestId) throw fail(400, 'requestId là bắt buộc.');
      try {
        const result = store.adjustStock({ ...b, adjustedBy: user.id });
        send(res, 200, result);
      } catch (e) {
        const err = Object.assign(Error(e.message), { status: e.status || 500 });
        if (e.errors) err.errors = e.errors;
        throw err;
      }
      return true;
    }

    if (p === '/api/sp/destroy') {
      if (method !== 'POST') throw fail(405, 'POST only');
      sevOnly();
      const user = getUser();
      const b = await json();
      if (!b.reason?.trim()) throw fail(400, 'reason là bắt buộc.');
      try {
        const result = store.destroyStock({ ...b, destroyedBy: user.id });
        send(res, 200, result);
      } catch (e) {
        throw Object.assign(Error(e.message), { status: e.status || 500 });
      }
      return true;
    }

    if (p === '/api/sp/movement') {
      if (method !== 'GET') throw fail(405, 'GET only');
      const q = {
        holderCode: isVendor ? vendorCode : (url.searchParams.get('holder') || undefined),
        model:      url.searchParams.get('model')  || undefined,
        limit:      parseInt(url.searchParams.get('limit') || '200', 10),
      };
      send(res, 200, { movements: store.listMovements(q) });
      return true;
    }

    return false; // not our route
  }

  return { handle };
}

module.exports = { createSetPba };
