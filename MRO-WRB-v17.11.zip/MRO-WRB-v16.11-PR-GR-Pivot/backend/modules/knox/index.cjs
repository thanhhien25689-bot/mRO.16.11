'use strict';
// Knox tích hợp Portal (06/11/2026): Portal là reverse proxy cho Knox Local Messenger (APIBOT, mặc định port 2292)
// để người dùng LAN dùng công cụ chat ngay trong Trung tâm tin nhắn, không phải mở tool riêng.
// - Trình duyệt chỉ nói chuyện với Portal (cookie phiên không bao giờ được chuyển tiếp sang APIBOT).
// - Chỉ proxy URL http trỏ về máy chủ chạy Portal (loopback) — Portal không thành proxy tùy ý ra mạng khác.
// - Gửi tin (messages/send, tables/send): supervisor/developer, cùng quy tắc "Gửi cảnh báo ngay".
//   Đọc nội dung chat và quản lý phòng đã biết: mọi vai trò trừ viewer. Xem UI, /health, bảng phòng: mọi phiên, kể cả viewer.
// - POST chỉ nhận content-type application/json và Origin (nếu có) phải trùng host Portal: Knox UI không biết
//   x-csrf-token của Portal nên chống CSRF bằng JSON+Origin (form cross-origin không gửi được JSON, DELETE phải preflight).
const DEFAULT_APIBOT='http://127.0.0.1:2292';
const LOOPBACK_HOSTS=new Set(['127.0.0.1','localhost','::1','[::1]']);
const ranks={viewer:0,user:1,admin:2,supervisor:3,developer:4};
const MAX_BODY=1024*1024,MAX_RESPONSE=4*1024*1024,TIMEOUT_MS=20000;
const fail=(status,message)=>Object.assign(new Error(message),{status});
const SEND_PATHS=new Set(['/api/v1/knox/messages/send','/api/v1/knox/tables/send']);
const SAVED_ROOM_ITEM=/^\/api\/v1\/knox\/saved-rooms\/[^/?]+$/;
const UI_PREFIX='/api/knox-app';
const errorCause=error=>(error&&error.cause&&(error.cause.code||error.cause.message))||(error&&error.message)||'unknown';
// Header toàn cục của Portal là X-Frame-Options:DENY + CSP frame-ancestors 'none' — chặn iframe KỂ CẢ same-origin.
// Knox UI được phục vụ qua /api/knox-app/ nên riêng đường đó phải nới đúng thành same-origin (cùng pattern /aps-app/
// trong backend/core/static-files.cjs); mọi response API JSON khác vẫn giữ DENY + frame-ancestors 'none' của Portal.
const FRAME_HEADERS={'X-Frame-Options':'SAMEORIGIN','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'; form-action 'self'"};
const wantsHtml=req=>/text\/html/i.test(String((req&&req.headers&&req.headers.accept)||''));
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Khi APIBOT chết, iframe không được chỉ nhận JSON thô: trả trang HTML hướng dẫn cùng nguyên nhân thật.
const uiErrorPage=(status,message)=>`<!doctype html><html lang="vi"><head><meta charset="utf-8"><title>Knox Local Messenger</title></head><body style="margin:0;padding:24px;background:#f4f6f8;color:#1c2733;font:14px/1.6 system-ui,Segoe UI,Arial,sans-serif"><div style="max-width:640px;margin:0 auto;background:#fff;border:1px solid #d3dbe2;border-top:4px solid #c0392b;border-radius:10px;padding:20px 22px"><h2 style="margin:0 0 10px;font-size:17px">Không mở được Knox Local Messenger</h2><p style="margin:0 0 10px;color:#c0392b;font-weight:600">Lỗi ${status}: ${esc(message)}</p><p style="margin:0 0 8px">Kiểm tra trên <b>máy chủ chạy Portal</b>:</p><ol style="margin:0 0 14px;padding-left:20px"><li>Chạy <code style="background:#eef2f5;padding:1px 5px;border-radius:4px">start.bat</code> trong thư mục KnoxChatbox (bản cũ: <code style="background:#eef2f5;padding:1px 5px;border-radius:4px">python run.py</code>) để mở Knox Local Messenger / APIBOT.</li><li>APIBOT mở đúng port đã cấu hình trong Trung tâm tin nhắn (mặc định 2292) và chỉ lắng nghe trên máy chủ.</li><li>URL APIBOT trong Trung tâm tin nhắn phải dạng <code style="background:#eef2f5;padding:1px 5px;border-radius:4px">http://127.0.0.1:2292</code>.</li></ol><button type="button" onclick="location.reload()" style="background:#0b6b8a;color:#fff;border:0;border-radius:8px;padding:8px 16px;font-size:14px;cursor:pointer">Thử lại</button></div></body></html>`;
function createKnox({readConfig=()=>null}={}){
 // readConfig là adapter public của messages (create-server nối): trả cấu hình đã lưu hoặc null.
 const upstream=()=>{let raw=DEFAULT_APIBOT;try{raw=String((readConfig()||{}).apibotUrl||DEFAULT_APIBOT).trim();}catch{}let url;try{url=new URL(raw);}catch{throw fail(502,`URL APIBOT "${raw}" không hợp lệ — kiểm tra lại trong Trung tâm tin nhắn.`);}if(url.protocol!=='http:'||!LOOPBACK_HOSTS.has(url.hostname.toLowerCase())||url.pathname!=='/')throw fail(502,'Portal chỉ proxy Knox APIBOT chạy http trên chính máy chủ (URL dạng http://127.0.0.1:2292 hoặc http://localhost:2292).');return url;};
 const readRaw=async req=>{const length=Number(req.headers['content-length']||0);if(length>MAX_BODY)throw fail(413,'Nội dung gửi lên Knox APIBOT vượt 1 MB.');const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>MAX_BODY)throw fail(413,'Nội dung gửi lên Knox APIBOT vượt 1 MB.');chunks.push(chunk);}return Buffer.concat(chunks);};

 async function route({req,res,url,actor}){
  if(actor&&actor.mustChangePassword)throw fail(403,'Cần đổi mật khẩu tạm trước khi tiếp tục.');
  const path=url.pathname,method=req.method,rank=ranks[actor&&actor.role]??-1;
  const uiRequest=path===UI_PREFIX||path.startsWith(UI_PREFIX+'/');
  let target;
  if(uiRequest){
   target=path.slice(UI_PREFIX.length)||'/';
   if(method!=='GET')throw fail(405,'Giao diện Knox trong Portal chỉ nhận GET; gửi tin đi qua /api/v1/knox/*.');
  }else if(SEND_PATHS.has(path)){
   if(method!=='POST')throw fail(405,'Gửi tin Knox chỉ nhận POST.');
   if(rank<ranks.supervisor)throw fail(403,'Chỉ Supervisor/Developer được gửi tin vào phòng Knox (như nút Gửi cảnh báo ngay).');
   target=path;
  }else if(path==='/api/v1/knox/rooms/read'){
   if(method!=='POST')throw fail(405,'Đọc tin Knox chỉ nhận POST.');
   if(rank<ranks.user)throw fail(403,'Viewer không được đọc nội dung chat Knox.');
   target=path;
  }else if(path==='/api/v1/knox/rooms'||path==='/api/v1/knox/saved-rooms'){
   if(method==='POST'&&rank<ranks.user)throw fail(403,'Chỉ vai trò có tài khoản được lưu phòng Knox đã biết.');
   else if(method!=='GET'&&method!=='POST')throw fail(405,'Phòng Knox chỉ nhận GET/POST.');
   target=path;
  }else if(SAVED_ROOM_ITEM.test(path)){
   if(method==='DELETE'&&rank<ranks.user)throw fail(403,'Chỉ vai trò có tài khoản được xóa phòng Knox đã biết.');
   else if(method!=='GET'&&method!=='DELETE')throw fail(405,'Phòng Knox đã biết chỉ nhận GET/DELETE.');
   target=path;
  }else if(path.startsWith('/api/v1/'))throw fail(404,'Điểm cuối Knox API không tồn tại.');
  else return false;
  const drain=()=>{if(method==='POST')req.resume().resume();return undefined;};
  if(method!=='GET'){const origin=req.headers.origin;if(origin){let parsed;try{parsed=new URL(origin);}catch{drain();throw fail(403,'Origin không hợp lệ.');}if(parsed.host!==String(req.headers.host||'')){drain();throw fail(403,'Nguồn gốc yêu cầu không khớp Portal.');}}}
  if(method==='POST'&&!/^application\/json\b/i.test(String(req.headers['content-type']||''))){drain();throw fail(400,'Knox API qua Portal chỉ nhận content-type application/json.');}
  const base=upstream();let body;
  if(method==='POST')body=await readRaw(req);
  const headers={};if(method==='POST')headers['content-type']=String(req.headers['content-type']);
  let response;
  try{response=await fetch(new URL(encodeURI(target)+(url.search||''),base),{method,headers,...(body===undefined?{}:{body}),redirect:'manual',signal:AbortSignal.timeout(TIMEOUT_MS)});}
  catch(error){if(error&&error.name==='TimeoutError')throw fail(504,`Knox APIBOT tại ${base.origin} không phản hồi sau ${TIMEOUT_MS/1000} giây.`);throw fail(502,`Không kết nối được Knox APIBOT tại ${base.origin}. Kiểm tra Knox APIBOT (python run.py) và máy Knox đang bật. (${errorCause(error)})`);}
  if(Number(response.headers.get('content-length')||0)>MAX_RESPONSE)throw fail(502,'Phản hồi của Knox APIBOT quá lớn qua Portal (tối đa 4 MB).');
  let text=await response.text();if(text.length>MAX_RESPONSE)throw fail(502,'Phản hồi của Knox APIBOT quá lớn qua Portal (tối đa 4 MB).');
  const type=response.headers.get('content-type')||'application/octet-stream';
  // Knox UI fetch('/health') theo đường dẫn tuyệt đối — đổi về đường dẫn của proxy để iframe không gọi thẳng gốc Portal.
  if(/text\/html/i.test(type))text=text.replace(/(['"`])\/health\1/g,'$1/api/knox-app/health$1');
  res.writeHead(response.status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...(uiRequest?FRAME_HEADERS:{})});
  res.end(text);return true;
 }
 function handle(input){
  const {url,res,req}=input;
  if(!url||!(url.pathname.startsWith(UI_PREFIX)||url.pathname.startsWith('/api/v1/knox/')))return false;
  return (async()=>{try{return await route(input);}catch(error){
   // iframe điều hướng tới /api/knox-app/ (Accept: text/html) thì lỗi phải là trang hướng dẫn, không phải JSON thô.
   if(url.pathname.startsWith(UI_PREFIX)&&!res.headersSent&&wantsHtml(req)&&error&&error.status){
    res.writeHead(error.status,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...FRAME_HEADERS});
    res.end(uiErrorPage(error.status,error.message||'Lỗi không xác định.'));return true;
   }
   if((res&&res.headersSent)||(error&&error.status))throw error;throw fail(503,`Không xử lý được yêu cầu Knox (${errorCause(error)}).`);}})();
 }
 return {handle};
}
module.exports={createKnox};
