const {createModelResolver,productionIndex}=require('../../integration/model-using.cjs');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const fail=(status,message)=>Object.assign(Error(message),{status});
const text=x=>String(x??'').trim();
const key=x=>text(x).normalize('NFC').toUpperCase();
function number(x,blank=false){if(x===null||x===undefined||text(x)==='')return blank?0:null;const n=Number(x);if(!Number.isFinite(n)||n<0)throw fail(400,'Số liệu tồn/sản lượng không hợp lệ.');return n;}
function week(date){const d=new Date(date.toLocaleDateString('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}));d.setUTCHours(0,0,0,0);d.setUTCDate(d.getUTCDate()+4-(d.getUTCDay()||7));const year=d.getUTCFullYear();return {year,week:Math.ceil((((d-new Date(Date.UTC(year,0,1)))/86400000)+1)/7)};}
function vendorBalances(snapshot,now){
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(now),locations=new Set(['ALT','ALV','BJ','CW']),seen=new Set(),balances=[],problems=[];
 const vendorCodeMap={'ALMUS TECH':'ALT','ALMUS VINA':'ALV','BUJEON':'BJ','CHITWING':'CW'};
 const normalizeVendor=v=>{const k=key(v);return vendorCodeMap[k]||k;};
 const masters=new Map();for(const row of snapshot.master){const code=key(row['Purchase Code'])||key(row['Item code']);if(!code)continue;const list=masters.get(code)||[];list.push(row);masters.set(code,list);}
 const transactions=new Map();for(const row of snapshot.vendorInout){const id=key(row.location)+'|'+key(row['Item Code']),list=transactions.get(id)||[];list.push(row);transactions.set(id,list);}
 for(const baseline of snapshot.vendorInventory){const location=normalizeVendor(baseline.Vendor),code=key(baseline.Purchase_Code);if(!locations.has(location)||!code){problems.push(`Bỏ qua Inventory Vendor "${text(baseline.Vendor)}|${text(baseline.Purchase_Code)}": Vendor phải thuộc ALT/ALV/BJ/CW và Purchase_Code không trống`);continue;}const id=location+'|'+code;if(seen.has(id)){problems.push(`Bỏ qua Inventory Vendor ${id}: trùng dòng Vendor/Purchase_Code`);continue;}seen.add(id);
  const matches=masters.get(code)||[];if(!matches.length){problems.push(`Bỏ qua Inventory Vendor ${id}: MasterData thiếu Item code ${code}`);continue;}if(matches.length>1){problems.push(`Bỏ qua Inventory Vendor ${id}: MasterData trùng ${matches.length} dòng Item code ${code} (kể cả chỉ khác hoa/thường)`);continue;}if(!text(matches[0]['WRB Code'])){problems.push(`Bỏ qua Inventory Vendor ${id}: MasterData của ${code} thiếu [WRB Code]`);continue;}
  const openingText=text(baseline.Opening_QTY),confirmDate=text(baseline.Confirm_date);let opening=null;try{opening=number(baseline.Opening_QTY);}catch{problems.push(`Bỏ qua Inventory Vendor ${id}: Opening_QTY không hợp lệ ("${openingText}")`);continue;}if(opening===null||!/^\d{4}-\d{2}-\d{2}$/.test(confirmDate)||!Number.isFinite(Date.parse(confirmDate+'T00:00:00Z'))||new Date(confirmDate+'T00:00:00Z').toISOString().slice(0,10)!==confirmDate||confirmDate>today){problems.push(`Bỏ qua Inventory Vendor ${id}: Opening_QTY hoặc Confirm_date không hợp lệ (Opening_QTY="${openingText}", Confirm_date="${confirmDate}")`);continue;}
  const history=(transactions.get(id)||[]).filter(row=>text(row.Date)>confirmDate&&text(row.Date)<=today);
  let balance=opening;try{balance=opening+history.reduce((sum,row)=>sum+number(row.InSEV,true)+number(row.TransferIn,true)-number(row.OutSX,true)-number(row.TransferOut,true),0);}catch(e){problems.push(`Bỏ qua lịch sử InOut của ${id}: ${e.message}; chỉ cộng Opening_QTY`);}
  balances.push({location,code,wrb:text(matches[0]['WRB Code']),master:matches[0],balance});
 }
 return {balances,problems};
}
function calculate(snapshot,now=new Date()){
 for(const k of ['inventory','master','production','history','inout','vendorInventory','vendorInout'])if(!Array.isArray(snapshot[k]))throw fail(400,'Thiếu bảng '+k);
 const resolve=createModelResolver(snapshot.modelMapping||[],snapshot.production),production=productionIndex(snapshot.production);
 const start=week(now),groups=new Map(),fmt=n=>Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
 const inventoryProblems=[];for(const r of snapshot.inventory){const code=text(r['WRB Code']);if(!code){inventoryProblems.push(`Bỏ qua dòng EQM_MRO_Inventory thiếu WRB Code (Item code "${text(r['Item code'])||'?'}")`);continue;}if(!groups.has(code))groups.set(code,[]);groups.get(code).push(r);}
 const {balances,problems:vendorProblems}=vendorBalances(snapshot,now);for(const entry of balances){if(!groups.has(entry.wrb))groups.set(entry.wrb,[]);const rows=groups.get(entry.wrb);if(!rows.some(row=>key(row['Item code'])===entry.code))rows.push({...entry.master,'STOCK SEV':0});}
 const items=[...groups].map(([code,rows])=>{try{
  const mKey=m=>text(m['Purchase Code'])||text(m['Item code']);const rKey=r=>text(r['Item code'])||text(r['Purchase Code']);
  const matching=rows.map(r=>snapshot.master.filter(m=>text(m['WRB Code'])===code&&mKey(m)===rKey(r)));
  const masters=matching.flat(),r=rows[0],problems=[];
  if(matching.some(ms=>ms.length!==1))problems.push('Thiếu hoặc trùng MasterData theo WRB Code + Item code');
  const safetyGet=m=>text(m['Safety Stock'])||text(m['Safety stock']);
  const unique=k=>k==='Safety stock'?[...new Set(masters.map(safetyGet))]:[...new Set(masters.map(m=>k==='Model Using'?resolve(m[k]).basics.join(','):text(m[k])))];
  const usage=number(masters[0]?.Usage),model=text(masters[0]?.['Model Using']),unit=text(masters[0]?.Unit);
  if((usage?['Unit','Usage','Model Using']:['Unit','Usage','Safety stock']).some(k=>unique(k).length!==1))problems.push('Các Item Code khác Unit/Usage/'+(usage?'Model Using':'Safety stock')+'; chưa thể quy đổi');
  const safetyStock=unique('Safety stock').length===1?number(safetyGet(masters[0]??{})):null;
  if(usage&&!model)problems.push('Chưa có Model Using');
  if(!usage&&!(safetyStock>0))problems.push('Safety stock chưa hợp lệ');
  const physical=rows.reduce((sum,row)=>sum+number(row['STOCK SEV'],true),0),vendorTotal=location=>balances.filter(entry=>entry.wrb===code&&entry.location===location).reduce((sum,entry)=>sum+entry.balance,0),vendors={A:vendorTotal('ALT'),B:vendorTotal('ALV'),C:vendorTotal('BJ'),D:vendorTotal('CW')};
  const stock=physical+Object.values(vendors).reduce((a,b)=>a+b,0),steps=[];let remaining=stock,covered=0,exact=false,demand=null;
  const resolved=resolve(model),models=resolved.basics;
  if(usage)problems.push(...masters.flatMap(m=>resolve(m['Model Using']).problems));
  if(usage&&!models.length)problems.push('Không có Basic hợp lệ để tính sản lượng.');
  for(let y=start.year;y<=start.year+5&&usage&&!problems.length&&!exact;y++){
   const maxWeek=week(new Date(Date.UTC(y,11,28,5))).week;
   for(let w=y===start.year?start.week:1;w<=maxWeek;w++){
    const values=models.map(model=>production.values(model,y,w));
    const produced=values.some(v=>v===null)?null:values.reduce((a,b)=>a+b,0);
    if(produced===null){problems.push('Thiếu sản lượng '+y+'/W'+String(w).padStart(2,'0'));break;}
    const need=produced/usage;if(demand===null)demand=need;
    const before=remaining;
    if(need>remaining){steps.push(`Phần tuần cuối = ${fmt(remaining)} ÷ ${fmt(need)} = ${fmt(remaining/need)} tuần; Coverage = ${fmt(covered)} + ${fmt(remaining/need)}`);covered+=remaining/need;remaining=0;exact=true;}
    else {covered++;remaining-=need;if(need>0&&remaining===0)exact=true;}
    steps.push(`${y}/W${String(w).padStart(2,'0')}: Tổng sản lượng (${models.length} Basic) ${fmt(produced)} ÷ ${fmt(usage)} = ${fmt(need)} ${unit}; tồn ${fmt(before)} → ${fmt(remaining)}`);
    if(exact)break;
   }
  }
  const valid=steps.length>0,coverage=valid?covered:null;
  const safetyRatio=!usage&&safetyStock>0?stock/safetyStock:null;
  if(!usage&&safetyRatio!==null)steps.push(`Tỷ lệ tồn = ${fmt(stock)} ÷ Safety stock ${fmt(safetyStock)} × 100 = ${fmt(safetyRatio*100)}%; ≥ 100%: Đủ tồn; ≥ 50% và < 100%: Nguy cơ thiếu; < 50%: Hết hàng`);
  const status=!usage?problems.length?'Chưa đủ dữ liệu':safetyRatio>=1?'Đủ tồn':safetyRatio>=0.5?'Nguy cơ thiếu':'Hết hàng':coverage===null?'Chưa đủ dữ liệu':!exact&&coverage<=4?'Chưa đủ dữ liệu':coverage<2?'Nguy cơ thiếu':coverage<=4?'Theo dõi':'Đủ tồn';
  const aging=calculateAging(snapshot,code,{WRBG:physical,ALT:vendors.A,ALV:vendors.B,BJ:vendors.C,CW:vendors.D},now,balances);
  return {code,aging,name:text(r['Tên Tiếng Việt']),group:text(r['Type (MRO/Spare)']),unit,physical,vendors,gmro:null,lastIssue:null,note:problems.join('; '),demand,sqlStock:true,
   stockCalculation:{method:usage?'production':'safety-stock',safetyRatio,coverage,exact,status,model,basics:models,usage,start,steps,problems,total:stock,safetyStock:unique('Safety stock').length===1?number(masters[0]?.['Safety stock']):null,orderingDays:unique('Ordering time').length===1?number(masters[0]?.['Ordering time']):null,leadDays:unique('Leadtime').length===1?number(masters[0]?.Leadtime):null,explanation:`Tổng tồn = WRBG ${fmt(physical)} + ALT ${fmt(vendors.A)} + ALV ${fmt(vendors.B)} + Bujeon ${fmt(vendors.C)} + Chitwing ${fmt(vendors.D)} = ${fmt(stock)} ${unit}`,itemCodes:rows.map(r=>text(r['Item code']))}};
 }catch(error){inventoryProblems.push(`Lỗi tính tồn mã ${code}: ${String(error&&error.message||error)}`);return {code,aging:{locations:[],warning:false,days:null},name:text(rows[0]?.['Tên Tiếng Việt']),group:text(rows[0]?.['Type (MRO/Spare)']),unit:text(rows[0]?.Unit),physical:0,vendors:{A:0,B:0,C:0,D:0},gmro:null,lastIssue:null,note:'Lỗi tính dòng này: '+String(error&&error.message||error),demand:null,sqlStock:true,stockCalculation:{method:'safety-stock',safetyRatio:null,coverage:null,exact:false,status:'Chưa đủ dữ liệu',model:'',usage:null,start,steps:[],problems:[String(error&&error.message||error)],total:0,safetyStock:null,orderingDays:null,leadDays:null,explanation:'Không tính được dòng này: '+String(error&&error.message||error),itemCodes:rows.map(r=>text(r['Item code']))}};}
 });
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(now),vendorUpdates=Object.fromEntries(['ALT','ALV','BJ','CW'].map(location=>[location,snapshot.vendorInout.filter(row=>key(row.location)===location&&/^\d{4}-\d{2}-\d{2}$/.test(text(row.Date))&&row.Date<=today).map(row=>row.Date).sort().at(-1)||null]));
 return {items,start,history:snapshot.history,vendorUpdates,updatedAt:snapshot.updatedAt,stockProblems:[...inventoryProblems,...vendorProblems]};
}
function calculateAging(snapshot,code,stocks,now,balances){
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(now);
 const labels={WRBG:'Wearable G',ALT:'Almus Tech',ALV:'Almus Vina',BJ:'Bujeon',CW:'Chitwing'};
 const locations=Object.entries(stocks).map(([location,stock])=>{
  const itemCodes=new Set(balances.filter(entry=>entry.wrb===code&&entry.location===location).map(entry=>entry.code));
  const rows=location==='WRBG'?snapshot.inout.filter(r=>text(r.location)===location&&text(r['WRB Code'])===code&&/^\d{4}-\d{2}-\d{2}$/.test(text(r.Date))&&r.Date<=today):snapshot.vendorInout.filter(r=>key(r.location)===location&&itemCodes.has(key(r['Item Code']))&&/^\d{4}-\d{2}-\d{2}$/.test(text(r.Date))&&r.Date<=today);
  const latest=direction=>rows.filter(r=>location==='WRBG'?Number(r[direction==='in'?'Nhập':'Xuất'])>0:(Number(r[direction==='in'?'InSEV':'OutSX'])||0)+(Number(r[direction==='in'?'TransferIn':'TransferOut'])||0)>0).map(r=>r.Date).sort().at(-1)||null;
  const lastIn=latest('in'),lastOut=latest('out'),days=lastIn?Math.floor((Date.parse(today)-Date.parse(lastIn))/86400000):null;
  const warning=stock>0&&days>30&&(!lastOut||lastOut<lastIn);
  return {location,name:labels[location],stock,lastIn,lastOut,days,warning,explanation:!lastIn?'Chưa đủ lịch sử nhập':`Ngày hiện tại ${today} − nhập gần nhất ${lastIn} = ${days} ngày; xuất gần nhất: ${lastOut||'chưa có'}; tồn: ${stock}. Cảnh báo khi còn tồn, quá 30 ngày và không xuất kể từ ngày nhập gần nhất.`};
 });
 const warnings=locations.filter(r=>r.warning).sort((a,b)=>b.days-a.days);
 return {locations,warning:warnings.length>0,days:warnings[0]?.days??null};
}
function createStock({root,runtime,sql,now=()=>new Date()}){
 const file=path.join(path.resolve(runtime)===path.resolve(root,'.runtime')?root:runtime,'data','stock-snapshot.json');
 const read=()=>{if(!fs.existsSync(file))return null;const snapshot=JSON.parse(fs.readFileSync(file,'utf8'));return Array.isArray(snapshot.vendorInventory)&&Array.isArray(snapshot.vendorInout)?snapshot:null;};
 let pendingLoad;
 async function load(){if(pendingLoad)return pendingLoad;pendingLoad=(async()=>{const snapshot=await sql.readStock();snapshot.updatedAt=now().toISOString();const result=calculate(snapshot,now());fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(temp,JSON.stringify(snapshot),{flag:'wx'});fs.renameSync(temp,file);}finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}return {...result,stockSource:'sql',stockError:null,stockUpdatedAt:snapshot.updatedAt};})();try{return await pendingLoad;}finally{pendingLoad=null;}}
 async function live(data){if(!Array.isArray(data.items))return data;try{return {...data,...await load()};}catch(e){const snapshot=read();return {...data,...(snapshot?calculate(snapshot,now()):{items:[],start:week(now()),history:[],stockProblems:[]}),stockSource:snapshot?'sql-cache':'empty',stockUpdatedAt:snapshot?.updatedAt,stockError:e.message};}}
 function overlay(data){const snapshot=read();return snapshot?{...data,...calculate(snapshot,now()),stockSource:'sql',stockUpdatedAt:snapshot.updatedAt}:{...data,items:[],start:week(now()),history:[],vendorUpdates:{},stockProblems:[],stockSource:'empty',stockError:'Chưa có snapshot tồn kho SQL theo nguồn Vendor mới.'};}
 async function handle({req,res,url,actor,send,protectedTransaction}){
  if(url.pathname==='/api/stock-live'&&req.method==='GET'){send(res,200,await live({items:[]}));return true;}
  if(url.pathname!=='/api/stock-sync')return false;
  if(req.method!=='POST')throw fail(405,'Chỉ hỗ trợ cập nhật POST.');
  if(!['admin','supervisor','developer'].includes(actor.role))throw fail(403,'Chỉ admin trở lên được cập nhật.');
  await protectedTransaction(async()=>send(res,200,await load()));return true;
 }
 return {handle,overlay,live};
}
module.exports={createStock,calculate,week};
