const fail=(status,message)=>Object.assign(Error(message),{status});
const text=v=>String(v??'').trim();
function currentWeek(now=new Date()){
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Ho_Chi_Minh'}).format(now),d=new Date(today+'T00:00:00Z');
 const monday=new Date(d);monday.setUTCDate(d.getUTCDate()-((d.getUTCDay()+6)%7));const sunday=new Date(monday);sunday.setUTCDate(monday.getUTCDate()+6);
 const thursday=new Date(monday);thursday.setUTCDate(monday.getUTCDate()+3);const year=thursday.getUTCFullYear();
 return {today,year,week:Math.ceil(((thursday-new Date(Date.UTC(year,0,1)))/86400000+1)/7),start:monday.toISOString().slice(0,10),end:sunday.toISOString().slice(0,10)};
}
function mapTransfers(rows){
 if(!Array.isArray(rows))throw Error('Dữ liệu giao hàng SQL không hợp lệ.');
 return rows.map((r,index)=>{
 const issues=[],qty=key=>{const value=text(r[key]);if(!value)return 0;if(!/^\+?\d+(?:\.\d+)?$/.test(value)||!Number.isFinite(Number(value))){issues.push('Số lượng '+key+' không hợp lệ: '+value);return null;}return Number(value);};
 const parts=Object.fromEntries(['ALT-Watch','ALT-Buds','ALV-Watch','ALV-Buds','Bujeon','Chitwing'].map(k=>[k,qty(k)]));
 const add=(a,b)=>a===null||b===null?null:a+b;
 const quantities={alt:add(parts['ALT-Watch'],parts['ALT-Buds']),alv:add(parts['ALV-Watch'],parts['ALV-Buds']),bujeon:parts.Bujeon,chitwing:parts.Chitwing};
 const rawDate=text(r.__transferDate??r.Date),date=/^\d{4}-\d{2}-\d{2}$/.test(rawDate)&&Number.isFinite(Date.parse(rawDate))&&new Date(rawDate).toISOString().slice(0,10)===rawDate?rawDate:'';
 if(!date)issues.push('Ngày giao không hợp lệ: '+rawDate);
 const no=text(r.No);if(!no)issues.push('Thiếu No');
 const received={alt:parts['ALT-Watch']>0||parts['ALT-Buds']>0,alv:parts['ALV-Watch']>0||parts['ALV-Buds']>0,bujeon:parts.Bujeon>0,chitwing:parts.Chitwing>0};
 const names={alt:'Almus Tech',alv:'Almus Vina',bujeon:'Bujeon',chitwing:'Chitwing'};
 return {id:no,no,date,rawDate,code:text(r['WRB Code']),itemCode:text(r['Item Code']),itemName:text(r['Item Name']),note:text(r.Note??r['Note ']),remark:text(r.Remark),bill:text(r.Bill),parts,quantities,received,vendor:Object.keys(names).filter(k=>received[k]).map(k=>names[k]).join(', '),issues,warning:issues.join('; '),sourceIndex:index};
 }).sort((a,b)=>b.date.localeCompare(a.date)||Number(b.no)-Number(a.no)||a.sourceIndex-b.sourceIndex);
}
function createDelivery({sql,now=()=>new Date()}){
 let pending,last;const attempts=new Map();
 async function load(){if(pending)return pending;pending=(async()=>{const rows=mapTransfers(await sql.readTransfers());last={deliveries:rows,deliveryUpdatedAt:now().toISOString()};return {...last,deliverySource:'sql',deliveryError:null,deliveryWeek:currentWeek(now())};})();try{return await pending;}finally{pending=null;}}
 async function live(data){if(!Array.isArray(data.deliveries))return data;try{return {...data,...await load()};}catch(e){return {...data,...(last||{deliveries:[],deliveryUpdatedAt:null}),deliverySource:last?'sql-cache':'empty',deliveryError:e.message,deliveryWeek:currentWeek(now())};}}
 async function handle({req,res,url,send,body,requireUser,protectedTransaction}){
  if(url.pathname==='/api/delivery-live'){if(req.method!=='GET')throw fail(405,'Chỉ hỗ trợ đọc dữ liệu giao hàng.');send(res,200,await live({deliveries:[]}));return true;}
  if(!['/api/delivery-master','/api/delivery-add'].includes(url.pathname))return false;
  const editable=()=>{const user=requireUser(req).user;if(!['admin','supervisor','developer'].includes(user.role))throw fail(403,'Chỉ admin trở lên được thêm dữ liệu giao hàng.');return user;};editable();
  if(url.pathname==='/api/delivery-master'){
   if(req.method!=='GET')throw fail(405,'Phương thức không hỗ trợ.');const code=text(url.searchParams.get('itemCode'));if(!code||code.length>100)throw fail(400,'Item Code không hợp lệ.');
   const rows=await sql.lookupDeliveryItem(code);send(res,200,{matches:rows.map(r=>({code:text(r['WRB Code']),itemCode:text(r['Item code']??r['Item Code']),itemName:text(r['Tên Tiếng Việt'])}))});return true;
  }
  if(req.method!=='POST')throw fail(405,'Phương thức không hỗ trợ.');const envelope=await body(req);const batch=Array.isArray(envelope?.rows);if(batch&&(Object.keys(envelope).some(k=>!['rows','requestId'].includes(k))||envelope.rows.length<1||envelope.rows.length>100))throw fail(400,'Mỗi lần nhập từ 1 đến 100 dòng.');const inputs=batch?envelope.rows.map(r=>({...r,requestId:envelope.requestId})):[envelope];
  for(const input of inputs){
  if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['date','itemCode','code','itemName','note','remark','bill','parts','requestId'].includes(k)))throw fail(400,'Phiếu không hợp lệ.');
  if(typeof input.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(input.date)||!Number.isFinite(Date.parse(input.date))||new Date(input.date).toISOString().slice(0,10)!==input.date)throw fail(400,'Ngày giao không hợp lệ.');
  for(const [k,max]of Object.entries({itemCode:100,code:50,itemName:500,note:4000,remark:4000,bill:4000}))if(typeof input[k]!=='string'||input[k].length>max)throw fail(400,'Trường '+k+' không hợp lệ.');
  if(!input.itemCode.trim())throw fail(400,'Cần nhập Item Code.');
  const names=['ALT-Watch','ALT-Buds','ALV-Watch','ALV-Buds','Bujeon','Chitwing'];
  if(!input.parts||Object.keys(input.parts).length!==6||names.some(k=>typeof input.parts[k]!=='string'||!/^\d{1,15}(?:\.\d{1,3})?$/.test(input.parts[k])))throw fail(400,'Số lượng cần không âm, tối đa 3 chữ số thập phân.');
  if(!names.some(k=>Number(input.parts[k])>0))throw fail(400,'Cần lượng giao lớn hơn 0 cho ít nhất một vendor.');
  if(!/^[a-f0-9]{32}$/.test(input.requestId||''))throw fail(400,'Mã thao tác không hợp lệ.');
  }
  const input=envelope;
  const result=await protectedTransaction(async()=>{const user=editable(),key=user.id+':'+input.requestId,digest=JSON.stringify(input),previous=attempts.get(key);
   if(previous){if(previous.digest!==digest)throw fail(409,'Mã thao tác đã được sử dụng.');if(previous.error)throw previous.error;return previous.result;}
   for(const [k,v]of attempts)if(v.at<Date.now()-1800000)attempts.delete(k);if(attempts.size>=500)throw fail(429,'Vui lòng thử lại sau.');
   const entry={digest,at:Date.now()};attempts.set(key,entry);
   try{const written=await sql.addTransfer(input);if(!written.inserted)throw fail(502,'Chưa xác nhận được kết quả ghi. Tải lại SQL trước khi thử tiếp.');if(pending)await pending.catch(()=>{});entry.result={...await live({deliveries:[]}),inserted:true};return entry.result;}
   catch(e){entry.error=e.status?e:fail(502,'Chưa xác nhận được kết quả ghi SQL. Tải lại dữ liệu trước khi thử tiếp.');throw entry.error;}
  });send(res,200,result);return true;
 }

 return {live,handle};
}
module.exports={createDelivery,mapTransfers,currentWeek};
