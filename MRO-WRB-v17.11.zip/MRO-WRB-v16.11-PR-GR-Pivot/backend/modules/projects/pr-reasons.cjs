// Kho "Lí do mua hàng" nhập tay cho các dòng PR mà PURCHASE_REQ_INFO trên ERP không dùng được.
// Project Status sở hữu Lí do mua hàng. SQL là nguồn chính khi bảng đã có;
// data/pr-reasons.json là kho tạm. PR & Tracking dùng adapter public.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {standardReason,aggregatableReason,reasonKey}=require('../../integration/pr-reason.cjs');
const {eligiblePR}=require('../../integration/pr-eligibility.cjs');
const fail=(status,message)=>Object.assign(Error(message),{status});
const text=value=>String(value??'').trim();
const code=value=>text(value).replace(/[\u0000-\u001f\u007f]/g,'');
const fields=['itemCode','prNo','prSeq','description','ignored','note','revision'];
const bulkFields=['rowNumber','itemCode','prNo','prSeq','description','revision','sourceRevision'];
const sourceRevision=rows=>crypto.createHash('sha256').update(JSON.stringify([...new Set((rows||[]).map(row=>text(row.PURCHASE_REQ_INFO)))].sort())).digest('hex');

// Excel clipboard TSV có thể quote ô chứa tab/xuống dòng bằng dấu "". Parser đọc theo ký tự,
// tuyệt đối không split dấu "-" vì Item Code và Reason đều có thể chứa dấu này.
function parseReasonTSV(value){const input=String(value??'');if(!input.trim())throw fail(400,'Chưa dán danh sách Reason.');if(input.length>1000000)throw fail(413,'Danh sách dán vượt quá 1 MB.');const table=[];let row=[],field='',quoted=false;
 for(let i=0;i<input.length;i++){const char=input[i];if(quoted){if(char==='"'){if(input[i+1]==='"'){field+='"';i++;}else quoted=false;}else field+=char;continue;}if(char==='"'&&field===''){quoted=true;continue;}if(char==='\t'){row.push(field);field='';continue;}if(char==='\r'||char==='\n'){if(char==='\r'&&input[i+1]==='\n')i++;row.push(field);table.push(row);row=[];field='';continue;}field+=char;}
 if(quoted)throw fail(400,'Dữ liệu Excel có ô chưa đóng dấu ngoặc kép.');row.push(field);table.push(row);const nonEmpty=table.filter(columns=>columns.some(cell=>String(cell).trim()!==''));const header=['ITEM_CODE','PR_NO','PR_SEQ','PURCHASE_REQ_INFO'];if(nonEmpty.length&&nonEmpty[0].map(cell=>String(cell).trim().toUpperCase()).every((cell,index)=>cell===header[index])&&nonEmpty[0].length===4)nonEmpty.shift();if(!nonEmpty.length)throw fail(400,'Danh sách không có dòng dữ liệu.');if(nonEmpty.length>500)throw fail(413,'Mỗi lần chỉ kiểm tra tối đa 500 dòng.');return nonEmpty.map((columns,index)=>({rowNumber:index+1,columns,itemCode:columns.length===4?code(columns[0]):'',prNo:columns.length===4?code(columns[1]):'',prSeq:columns.length===4?code(columns[2]):'',description:columns.length===4?text(columns[3]):'',malformed:columns.length!==4}));}

function createPRReasons({root,runtime,sql,now=()=>new Date()}={}){
  const base=path.resolve(runtime)===path.resolve(root,'.runtime')?path.join(root,'data'):path.join(runtime,'data');
  const file=path.join(base,'pr-reasons.json');
  let cached={stamp:null,map:new Map()};
  const hasSql=typeof sql?.readProjectReasons==='function'&&typeof sql?.writeProjectReason==='function';
  let sqlMap=new Map(),sqlMode='legacy',sqlError='',sqlPending=null;
  const sqlEntry=row=>({itemCode:text(row.ITEM_CODE),prNo:text(row.PR_NO),prSeq:text(row.PR_SEQ),description:text(row.PURCHASE_REQ_INFO_OVERRIDE),ignored:/^(?:1|true)$/i.test(String(row.IS_IGNORED)),note:text(row.NOTE),updatedBy:text(row.UPDATED_BY),updatedAt:text(row.UPDATED_AT),revision:text(row.REVISION).toLowerCase()});

  function read(){
    if(!fs.existsSync(file))return {version:1,entries:{}};
    let doc;
    try{doc=JSON.parse(fs.readFileSync(file,'utf8'));}
    catch(error){throw fail(500,'pr-reasons.json không đọc được ('+text(error.message).slice(0,200)+'). Kiểm tra file và bản sao lưu; chưa ghi thay đổi.');}
    if(!doc||doc.version!==1||!doc.entries||Array.isArray(doc.entries))throw fail(500,'pr-reasons.json không hợp lệ. Kiểm tra file và bản sao lưu; chưa ghi thay đổi.');
    return doc;
  }
  function write(doc){
    fs.mkdirSync(path.dirname(file),{recursive:true});
    const temp=file+'.'+crypto.randomUUID()+'.tmp';
    try{fs.writeFileSync(temp,JSON.stringify(doc,null,2),{mode:0o600});fs.renameSync(temp,file);}
    finally{if(fs.existsSync(temp))fs.unlinkSync(temp);}
    cached={stamp:null,map:new Map()};
  }
  function stamp(){try{const s=fs.statSync(file);return s.mtimeMs+'|'+s.size;}catch{return null;}}
  // Bảng khóa tra nhiều lần trong một lượt tải nên cache theo mtime+size; đổi file là đọc lại.
  // File hỏng không được làm hỏng lượt tải: trả bảng trống kèm lastError để lớp gọi báo nguyên nhân.
  function map(){
    if(sqlMode==='sql')return sqlMap;
    const at=stamp();
    if(cached.stamp===at)return cached.map;
    let entries={},error='';
    try{entries=read().entries;}
    catch(readError){error=text(readError.message);}
    cached={stamp:at,map:new Map(Object.entries(entries)),error};
    return cached.map;
  }
  function lastError(){if(sqlMode==='sql')return sqlError;map();return sqlError||cached.error||'';}
  async function refresh(){
    if(!hasSql)return;
    if(sqlPending)return sqlPending;
    sqlPending=(async()=>{
      let rows;
      try{rows=await sql.readProjectReasons();}
      catch(error){
        if(error.sqlNumber===208&&sqlMode!=='sql'){sqlMode='legacy';sqlError='Chưa có bảng EQM_MRO_PR_ReasonOverride; Lí do mua hàng tạm lưu trong file Portal.';return;}
        sqlError='Không đọc được EQM_MRO_PR_ReasonOverride từ SQL.';throw error;
      }
      if(!Array.isArray(rows))throw fail(502,'Dữ liệu bảng Lí do mua hàng SQL không hợp lệ.');
      const current=new Map(rows.map(row=>{const entry=sqlEntry(row);return [reasonKey(entry.itemCode,entry.prNo,entry.prSeq),entry];}));
      let migrationWarning='';
      if(fs.existsSync(file)&&!fs.existsSync(file+'.sql-migrated')){
        let legacy=null;try{legacy=read().entries;}catch(error){migrationWarning='File Lí do cũ không đọc được để chuyển sang SQL: '+text(error.message);}
        if(legacy){
          for(const old of Object.values(legacy)){
            if(!old||!old.itemCode||!old.prNo||!old.prSeq)continue;
            const key=reasonKey(old.itemCode,old.prNo,old.prSeq);
            if(current.has(key))continue;
            const saved=await sql.writeProjectReason({itemCode:old.itemCode,prNo:old.prNo,prSeq:old.prSeq,description:old.ignored?null:old.description,ignored:!!old.ignored,note:old.note||'',actor:old.updatedBy||'migration',at:old.updatedAt||now().toISOString(),revision:''});
            current.set(key,sqlEntry(saved));
          }
          try{fs.writeFileSync(file+'.sql-migrated',JSON.stringify({at:now().toISOString(),rows:current.size}));}catch(error){migrationWarning='Đã chuyển reason vào SQL nhưng chưa ghi được dấu hoàn tất chuyển dữ liệu: '+text(error.message);}
        }
      }
      sqlMap=current;sqlMode='sql';sqlError=migrationWarning;
    })();
    try{return await sqlPending;}finally{sqlPending=null;}
  }
  async function queue(year,month=null,since=false){
    if(month!==null&&(!Number.isInteger(month)||month<1||month>12))throw fail(400,'Tháng PR không hợp lệ.');
    await refresh();
    if(typeof sql?.readProjectPR!=='function')throw fail(503,'SQL chưa hỗ trợ đọc PR cho hàng chờ Lí do mua hàng.');
    const from='2026-11-01';
    let raw;
    if(since&&typeof sql.readProjectPRSince==='function')raw=await sql.readProjectPRSince(from);
    else if(since){const currentYear=Number(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric'}).format(now()));raw=(await Promise.all(Array.from({length:Math.max(0,currentYear-2026+1)},(_,i)=>sql.readProjectPR(2026+i)))).flat();}
    else raw=await sql.readProjectPR(year);
    const saved=map(),seen=new Set(),rows=[];let unkeyed=0;
    for(const pr of raw){
      if(!eligiblePR(pr))continue;
      if(since&&text(pr.PR_DATE).slice(0,10)<from)continue;
      if(month!==null&&!text(pr.PR_DATE).startsWith(`${year}-${String(month).padStart(2,'0')}-`))continue;
      const itemCode=code(pr.ITEM_CODE),prNo=code(pr.PR_NO),prSeq=code(pr.PR_SEQ);
      if(!itemCode||!prNo||!prSeq){if(!aggregatableReason(pr.PURCHASE_REQ_INFO))unkeyed++;continue;}
      const key=reasonKey(itemCode,prNo,prSeq);if(seen.has(key))continue;seen.add(key);
      // SQL overrides (including ignored rows) survive reload/restart; skip before reason parsing.
      if(saved.has(key)||aggregatableReason(pr.PURCHASE_REQ_INFO))continue;
      const state=stateFor(pr);if(!state?.needed)continue;
      rows.push({itemCode,prNo,prSeq,prDate:text(pr.PR_DATE),creator:text(pr.PR_CREATOR_NAME),itemName:text(pr.ITEM_NAME),purchaseReqInfo:text(pr.PURCHASE_REQ_INFO),prQty:pr.PR_QTY??null,poNo:text(pr.PO_NO),reasonRevision:state.revision});
    }
    return {year:since?null:year,month:since?null:month,from:since?from:null,rows,total:rows.length,unkeyed,storage:sqlMode,warning:lastError()};
  }
  async function previewBulk(value){await refresh();if(sqlMode!=='sql')throw fail(503,'Chức năng dán Reason hàng loạt cần bảng SQL EQM_MRO_PR_ReasonOverride.');if(typeof sql?.lookupProjectReasonRows!=='function')throw fail(503,'SQL chưa hỗ trợ đối chiếu PR lịch sử hàng loạt.');const parsed=parseReasonTSV(value),keys=parsed.filter(row=>!row.malformed&&row.itemCode&&row.itemCode.length<=50&&row.prNo&&row.prNo.length<=50&&row.prSeq&&row.prSeq.length<=20),raw=keys.length?await sql.lookupProjectReasonRows(keys):[],byKey=new Map();
    for(const pr of raw||[]){const itemCode=code(pr.ITEM_CODE),prNo=code(pr.PR_NO),prSeq=code(pr.PR_SEQ);if(!itemCode||!prNo||!prSeq)continue;const key=reasonKey(itemCode,prNo,prSeq);if(!byKey.has(key))byKey.set(key,[]);byKey.get(key).push(pr);}
    const pastedGroups=new Map();for(const row of keys){const key=reasonKey(row.itemCode,row.prNo,row.prSeq);if(!pastedGroups.has(key))pastedGroups.set(key,[]);pastedGroups.get(key).push(row);}
    const duplicateExtras=new Set(),duplicateConflicts=new Set();let duplicates=0;for(const group of pastedGroups.values()){if(group.length<2)continue;duplicates+=group.length-1;const reasons=new Set(group.map(row=>text(row.description)));if(reasons.size>1)group.forEach(row=>duplicateConflicts.add(row));else group.slice(1).forEach(row=>duplicateExtras.add(row));}
    const output=parsed.map(row=>{const key=row.itemCode&&row.prNo&&row.prSeq?reasonKey(row.itemCode,row.prNo,row.prSeq):'',matches=key?(byKey.get(key)||[]):[],found=matches.length>0,saved=key?map().get(key):null,erpReasons=[...new Set(matches.map(pr=>text(pr.PURCHASE_REQ_INFO)))],current=saved&&!saved.ignored?text(saved.description):(erpReasons.length===1?erpReasons[0]:'');let status='Đủ điều kiện',canUpdate=true,reason=standardReason(row.description);
      if(row.malformed){status='Sai định dạng: cần đúng 4 cột';canUpdate=false;}else if(!row.itemCode||!row.prNo||!row.prSeq){status='Thiếu khóa PR';canUpdate=false;}else if(row.itemCode.length>50||row.prNo.length>50||row.prSeq.length>20){status='Khóa PR không hợp lệ';canUpdate=false;}else if(!reason.ok||reason.description.length>800){status='Reason không hợp lệ';canUpdate=false;}else if(duplicateConflicts.has(row)){status='Trùng khóa có Reason khác nhau';canUpdate=false;}else if(duplicateExtras.has(row)){status='Dòng trùng khóa';canUpdate=false;}else if(!found){status='Không tìm thấy PR';canUpdate=false;}else if(erpReasons.length>1&&!saved){status='PR có nhiều Reason ERP khác nhau';canUpdate=false;}else if(current===reason.description&&saved&&!saved.ignored){status='Reason không thay đổi';canUpdate=false;}
      return{rowNumber:row.rowNumber,itemCode:row.itemCode,prNo:row.prNo,prSeq:row.prSeq,currentReason:current,newReason:reason.ok?reason.description:row.description,status,found,canUpdate,revision:saved?text(saved.revision):'',sourceRevision:sourceRevision(matches)};});
    return{summary:{totalRows:parsed.length,found:output.filter(row=>row.found).length,notFound:output.filter(row=>row.status==='Không tìm thấy PR').length,duplicates,invalidReasons:output.filter(row=>row.status==='Reason không hợp lệ').length,eligible:output.filter(row=>row.canUpdate).length},rows:output};
  }
  async function saveBulk(inputs,actor){await refresh();if(sqlMode!=='sql')throw fail(503,'Chức năng cập nhật hàng loạt cần bảng SQL EQM_MRO_PR_ReasonOverride.');if(typeof sql?.lookupProjectReasonRows!=='function'||typeof sql?.writeProjectReasons!=='function')throw fail(503,'SQL chưa hỗ trợ cập nhật Reason hàng loạt.');if(!Array.isArray(inputs)||!inputs.length)throw fail(400,'Không có dòng Reason đủ điều kiện để cập nhật.');if(inputs.length>500)throw fail(413,'Mỗi lần chỉ cập nhật tối đa 500 dòng.');const seen=new Set(),normalized=[];
    for(const [index,input] of inputs.entries()){if(!input||typeof input!=='object'||Object.keys(input).some(key=>!bulkFields.includes(key)))throw fail(400,'Payload cập nhật Reason hàng loạt không hợp lệ.');const itemCode=code(input.itemCode),prNo=code(input.prNo),prSeq=code(input.prSeq),revision=text(input.revision).toLowerCase(),erpRevision=text(input.sourceRevision).toLowerCase(),parsed=standardReason(input.description);if(!itemCode||itemCode.length>50||!prNo||prNo.length>50||!prSeq||prSeq.length>20)throw fail(400,'Khóa PR hàng loạt không hợp lệ.');if(!parsed.ok||parsed.description.length>800)throw fail(400,'Reason hàng loạt không hợp lệ tại dòng '+(Number(input.rowNumber)||index+1)+'.');if(revision&&!/^[a-f0-9]{16}$/.test(revision)||!/^[a-f0-9]{64}$/.test(erpRevision))throw fail(400,'Revision hàng loạt không hợp lệ.');const key=reasonKey(itemCode,prNo,prSeq);if(seen.has(key))throw fail(400,'Danh sách cập nhật còn trùng khóa PR.');seen.add(key);normalized.push({index,rowNumber:Number(input.rowNumber)||index+1,itemCode,prNo,prSeq,description:parsed.description,revision,sourceRevision:erpRevision,key});}
    const raw=await sql.lookupProjectReasonRows(normalized),history=new Map();for(const pr of raw||[]){const key=reasonKey(code(pr.ITEM_CODE),code(pr.PR_NO),code(pr.PR_SEQ));if(!history.has(key))history.set(key,[]);history.get(key).push(pr);}const ready=[],results=[];for(const row of normalized){const current=map().get(row.key),actual=current?text(current.revision).toLowerCase():'',matches=history.get(row.key)||[];if(!matches.length){results.push({...row,ok:false,status:'Không tìm thấy PR'});continue;}if(actual!==row.revision||sourceRevision(matches)!==row.sourceRevision){results.push({...row,ok:false,status:'Reason đã thay đổi sau Preview'});continue;}ready.push({...row,actor:text(actor?.username),at:now().toISOString(),note:'Bulk paste PR Reason'});}
    if(ready.length){const written=await sql.writeProjectReasons(ready),handled=new Set();for(const result of written){const source=ready.find(row=>row.index===Number(result.index));if(!source||handled.has(source.index))continue;handled.add(source.index);if(result.ok&&result.row){const entry=sqlEntry(result.row);sqlMap.set(source.key,entry);results.push({...source,ok:true,status:'Đã cập nhật',reason:entry});}else results.push({...source,ok:false,status:result.status||'SQL không lưu được dòng'});}for(const source of ready)if(!handled.has(source.index))results.push({...source,ok:false,status:'SQL không trả kết quả cho dòng'});}
    results.sort((a,b)=>a.rowNumber-b.rowNumber);return{summary:{total:normalized.length,updated:results.filter(row=>row.ok).length,failed:results.filter(row=>!row.ok).length},rows:results.map(row=>({rowNumber:row.rowNumber,itemCode:row.itemCode,prNo:row.prNo,prSeq:row.prSeq,status:row.status,ok:row.ok}))};
  }
  // Trạng thái của MỘT dòng PR cho lớp hiển thị. creator/purchaseReqInfo lấy từ đúng dòng PR SQL.
  // Mọi receiver, kể cả bui.thu2, cần bổ sung nếu lý do ERP chưa dùng được và chưa có bản nhập tay.
  function stateFor(row={}){
    const itemCode=code(row.itemCode??row.ITEM_CODE),prNo=code(row.prNo??row.PR_NO),prSeq=code(row.prSeq??row.PR_SEQ);
    if(!prNo||!prSeq)return null;
    const key=reasonKey(itemCode,prNo,prSeq),entry=map().get(key)||null,creator=text(row.creator??row.PR_CREATOR_NAME);
    const rawInfo=text(row.purchaseReqInfo??row.PURCHASE_REQ_INFO);
    const usable=aggregatableReason(rawInfo)||!!(entry&&!entry.ignored&&aggregatableReason(entry.description));
    const ignored=!!(entry&&entry.ignored);
    return {key,needed:!usable&&!entry,filled:!!entry,ignored,
      source:usable?(entry&&!entry.ignored&&aggregatableReason(entry.description)?'portal':(aggregatableReason(rawInfo)?'sql':'')):'',
      description:entry&&!entry.ignored?text(entry.description):'',purchaseReqInfo:rawInfo,prCreator:creator,
      note:entry?text(entry.note):'',updatedBy:entry?text(entry.updatedBy):'',updatedAt:entry?text(entry.updatedAt):'',revision:entry?text(entry.revision):''};
  }
  function save(input,actor){
    if(!input||typeof input!=='object'||Object.keys(input).some(key=>!fields.includes(key)))throw fail(400,'Thông tin Lí do mua hàng không hợp lệ.');
    const itemCode=code(input.itemCode),prNo=code(input.prNo),prSeq=code(input.prSeq);
    if(!itemCode||itemCode.length>50||!prNo||prNo.length>50||!prSeq||prSeq.length>20)throw fail(400,'Cần Item Code, PR No và PR Seq của dòng PR (tối đa 50/50/20 ký tự).');
    const ignored=input.ignored===true;
    if(input.ignored!==undefined&&typeof input.ignored!=='boolean')throw fail(400,'Cờ "không dùng cho Project Status" phải là true hoặc false.');
    const note=text(input.note);if(note.length>500)throw fail(400,'Ghi chú tối đa 500 ký tự.');
    if(input.revision!==undefined&&input.revision!==''&&!/^(?:[a-f0-9]{64}|[a-f0-9]{16})$/i.test(String(input.revision)))throw fail(400,'Revision không hợp lệ.');
    let reason={ok:true,description:''};
    if(!ignored){
      reason=standardReason(input.description);
      if(!reason.ok)throw fail(400,reason.error);
    }
    if(sqlMode==='sql')return (async()=>{
      const saved=sqlEntry(await sql.writeProjectReason({itemCode,prNo,prSeq,description:ignored?null:reason.description,ignored,note,actor:text(actor?.username),at:now().toISOString(),revision:text(input.revision)}));
      sqlMap.set(reasonKey(itemCode,prNo,prSeq),saved);return {key:reasonKey(itemCode,prNo,prSeq),reason:saved,storage:'sql'};
    })();
    const doc=read(),key=reasonKey(itemCode,prNo,prSeq),previous=doc.entries[key];
    if((previous?.revision||'')!==text(input.revision))throw fail(409,'Lí do mua hàng vừa được người khác cập nhật. Tải lại PR & Tracking trước khi lưu.');
    const entry={itemCode,prNo,prSeq,description:ignored?'':reason.description,ignored,note,
      updatedBy:actor?text(actor.username):'',updatedAt:now().toISOString(),revision:crypto.randomBytes(32).toString('hex')};
    doc.entries[key]=entry;write(doc);
    return {key,reason:{...entry},storage:'legacy'};
  }
  // Cho Project Status: toàn bộ bản nhập tay theo khóa dòng PR.
  function list(){return map();}
  function summary(){const values=[...map().values()];return {total:values.length,filled:values.filter(entry=>!entry.ignored).length,ignored:values.filter(entry=>entry.ignored).length,error:lastError()};}
  return {file,map,stateFor,save,previewBulk,saveBulk,list,summary,lastError,refresh,queue,storage:()=>sqlMode};
}

module.exports={createPRReasons};
