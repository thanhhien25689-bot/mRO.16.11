const {eligiblePR}=require('../../integration/pr-eligibility.cjs');
// 06/11/2026: form "Lí do mua hàng" + danh sách receiver chuẩn là hợp đồng tích hợp dùng chung với
// PR & Tracking (integration, không phải file nội bộ module); kho nhập tay nằm trong module Projects.
const {reasonKey,parseReasonParts}=require('../../integration/pr-reason.cjs');
const {createPRReasons}=require('./pr-reasons.cjs');
const {mapOrders}=require('../orders/index.cjs');
const crypto=require('node:crypto');
const path=require('node:path');
const text=v=>v==null||/^null$/i.test(String(v).trim())?'':String(v).trim();
const canonName=value=>String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[đĐ]/g,'d').toUpperCase().replace(/[^0-9A-Z]+/g,' ').trim();
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');
// Đơn giá/số tiền từ SQL có thể là number hoặc chuỗi ERP ("26,000,000", "(1.5)"). Chuỗi không đọc
// được trả null chứ không ép 0, giống quy tắc số an toàn của toàn dự án.
function money(value){if(typeof value==='number')return Number.isFinite(value)?value:null;if(typeof value!=='string')return null;
 let raw=value.trim();if(!raw||/^null$/i.test(raw))return null;let negative=false;if(/^\(.*\)$/.test(raw)){negative=true;raw=raw.slice(1,-1).trim();}
 raw=raw.replace(/[\u00a0\u202f]/g,' ').trim();if(/^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$/.test(raw))raw=raw.replace(/,/g,'');
 if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(raw))return null;const number=Number(raw)*(negative?-1:1);return Number.isFinite(number)?number:null;}
// Tỷ giá quy định chung của dự án: USD giữ nguyên, VND 26.000 (USD_RATE), JPY 180 (chốt 02/11/2026,
// cùng bộ số màn Data Tracking). Tiền tệ khác hoặc trống thì KHÔNG quy đổi, để trống Amount.
const fxRates={USD:1,VND:26000,JPY:180};
function amountUSD(quantity,unitPrice,currency){const rate=fxRates[String(currency??'').trim().toUpperCase()];if(!Number.isFinite(quantity)||!Number.isFinite(unitPrice)||!rate)return null;
 const value=quantity*unitPrice/rate;return Number.isFinite(value)?Math.round(value*100)/100:null;}
function parseDescription(value){const info=parseReasonParts(value);if(!info)return null;return {description:info.description,projectId:hash('project:'+canonName(info.project||info.description)),classification:!info.project?'missing-project':!info.model||!info.process?'incomplete':'complete',type:info.type,project:info.project,model:info.model,process:info.process,parseWarning:!info.project?'Thiếu Project; chưa phân loại dự án.':!info.model||!info.process?'PURCHASE_REQ_INFO có ít hơn bốn phần; giữ trống các phần chưa có.':''};}
function resolveTypes(entries){const grouped=new Map();for(const e of entries||[]){const code=text(e.purchaseCode);if(!code||!['IMK','Local','Direct'].includes(e.typeOfCode))continue;const at=Date.parse(e.updatedAt)||0,old=grouped.get(code);if(!old||at>old.at)grouped.set(code,{at,types:new Set([e.typeOfCode])});else if(at===old.at)old.types.add(e.typeOfCode);}return new Map([...grouped].map(([code,r])=>[code,{orderType:r.types.size===1?[...r.types][0]:'',orderTypeNote:r.types.size===1?'Type of code đã lưu gần nhất'+(r.at?' · '+new Date(r.at).toISOString():''):'Nhiều Order Type khác nhau cùng thời gian cập nhật; chưa tự chọn.'}]));}
// `reasons` (tùy chọn) là Map khóa reasonKey(ITEM_CODE,PR_NO,PR_SEQ) do PIC3 nhập tay ở màn
// PR & Tracking. 12/11/2026 (người dùng chốt): bản nhập tay trong EQM_MRO_PR_ReasonOverride THẮNG TUYỆT
// ĐỐI — dùng trước, PURCHASE_REQ_INFO của ERP chỉ còn là nguồn dự phòng khi chưa có bản sửa.
function mapProjects(raw,year,types,classifyPR,reasons){if(!Array.isArray(raw))throw Error('Dữ liệu PR Project không hợp lệ.');const mapping=resolveTypes(types),overrides=reasons instanceof Map?reasons:new Map(Object.entries(reasons||{})),rows=[];let excludedDates=0,missingCodes=0,excludedStatuses=0,unparsedInfo=0,reasonRows=0,ignoredReasons=0;for(const [i,r]of raw.entries()){
 if(!eligiblePR(r)){excludedStatuses++;continue;}if(!text(r.PR_NO))continue;let info=null,override=null;const saved=overrides.get(reasonKey(r.ITEM_CODE,r.PR_NO,r.PR_SEQ));
 // 12/11/2026 (người dùng chốt): bản sửa trong EQM_MRO_PR_ReasonOverride THẮNG TUYỆT ĐỐI, ERP chỉ dự phòng.
  if(saved&&!saved.ignored&&(info=parseDescription(saved.description))){override=saved;reasonRows++;}
  if(!info)info=parseDescription(r.PURCHASE_REQ_INFO);
  if(!info){if(saved&&saved.ignored){ignoredReasons++;continue;}unparsedInfo++;continue;}
 const date=text(r.PR_DATE).slice(0,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||Number(date.slice(0,4))!==year){excludedDates++;continue;}
 const quantity=k=>{const s=text(r[k]);return s!==''&&Number.isFinite(Number(s))?Number(s):null;},itemCode=text(r.ITEM_CODE),orderType=mapping.get(itemCode)||{orderType:'',orderTypeNote:'Chưa có Type of code đã lưu khớp Purchase Code.'};if(!itemCode)missingCodes++;
 rows.push({...info,rowId:hash(JSON.stringify([year,i,r])),itemCode,itemName:text(r.ITEM_NAME),category:text(r.CATEGORY_NAME),specification:text(r.SPECIFICATION),prUnitPrice:money(r.BUYING_PRICE),prCurrency:text(r.BUYING_CURRENCY).toUpperCase(),...orderType,prQty:quantity('PR_QTY'),poQty:quantity('PO_QTY'),shippingQty:quantity('SHIPPING_QTY'),grQty:quantity('GR_QTY'),purchaseReqInfo:text(r.PURCHASE_REQ_INFO),prNo:text(r.PR_NO),prSeq:text(r.PR_SEQ),poNo:text(r.PO_NO),poSeq:text(r.PO_SEQ),prDate:date,poDate:text(r.PO_DATE).slice(0,10),...classifyPR(r),...(override?{descriptionSource:'portal',descriptionEditedBy:text(override.updatedBy),descriptionEditedAt:text(override.updatedAt)}:{})});
 }return {projectRows:consolidateProjectRows(rows),projectYear:year,projectInvalidDates:excludedDates,projectMissingCodes:missingCodes,projectExcludedStatuses:excludedStatuses,projectUnparsedInfo:unparsedInfo,projectReasonRows:reasonRows,projectIgnoredReasons:ignoredReasons};}
const projectKey=(code,description)=>text(code).toUpperCase()+'\u0000'+text(description).replace(/\s+/g,' ').toUpperCase();
// "Số lượng order" của một code = tổng các dòng Order đã duyệt (và chưa bị xóa) của đúng Item Code,
// cùng bộ lọc trạng thái mà tab Code & code issue / PR & Tracking dùng làm nguồn. Dòng "Đã xóa" và
// dòng chờ duyệt không được cộng vào. Trả về Map itemCode -> {quantity,lines,vendors}.
function orderQuantities(raw){const map=new Map(),missing=new Set();let orders=[];try{orders=mapOrders(raw).ordersSQL;}catch{return map;}
 for(const row of orders){if(row.deleted||!['Đã duyệt','Đã xác nhận'].includes(row.status))continue;
  const code=text(row.itemCode),quantity=Number.isFinite(row.quantity)?row.quantity:null;if(!code)continue;if(quantity===null){missing.add(code);continue;}
  const item=map.get(code)||{quantity:0,lines:0,vendors:new Set(),units:new Set()};item.units.add(text(row.unit).toUpperCase());item.quantity=item.units.size===1&&!item.units.has('')&&item.quantity!==null&&quantity!==null?item.quantity+quantity:null;item.lines++;if(row.vendor)item.vendors.add(row.vendor);map.set(code,item);}
 for(const code of missing)if(map.has(code))map.get(code).quantity=null;return map;}
// Gắn "Số lượng order", đơn giá và Amount ( USD ) cho TỪNG dòng của bảng Chi tiết code:
//  · dòng đã có PR No   → đơn giá BUYING_PRICE của chính dòng PR đó × PR Qty của dòng đó;
//  · dòng chưa có PR No → đơn giá "Đơn giá" của tab Code & code issue (pricing theo Item Code,
//    tức USD_PRICE trong EQM_MRO_UnitPrice) × "Số lượng order".
// Mỗi dòng chỉ tính trên số lượng của chính nó nên tiền không bị cộng trùng khi một code có nhiều
// dòng PR. Thiếu số lượng, thiếu đơn giá hoặc tiền tệ ngoài bộ tỷ giá chung → Amount để trống.
async function withOrderValues(rows,orderQtyByCode,pricing){
 const needed=rows.filter(row=>!row.prNo&&row.itemCode);let priced=needed,error='';
 if(needed.length&&pricing&&typeof pricing.enrich==='function'){try{priced=await pricing.enrich(needed,row=>row.itemCode);}catch{error='Không đọc được đơn giá EQM_MRO_UnitPrice cho các dòng chưa có PR No; Amount của các dòng đó để trống.';}}
 const byRow=new Map(priced.map(row=>[row.rowId,row]));
 return {error,rows:rows.map(row=>{
  const matched=orderQtyByCode.get(row.itemCode),orderQty=row.source==='order'?row.orderQty:matched?matched.quantity:null,fromCodes=byRow.get(row.rowId);
  const price=row.prNo?{unitPrice:Number.isFinite(row.prUnitPrice)?row.prUnitPrice:null,currency:text(row.prCurrency).toUpperCase(),source:'PR'}
   :{unitPrice:fromCodes&&Number.isFinite(fromCodes.unitPrice)?fromCodes.unitPrice:null,currency:fromCodes?text(fromCodes.priceCurrency).toUpperCase():'',source:fromCodes&&Number.isFinite(fromCodes.unitPrice)?'Codes':''};
  const quantity=row.prNo?row.prQty:orderQty;
  return {...row,orderQty,orderLines:row.source==='order'?1:matched?matched.lines:0,orderVendors:row.source==='order'?row.orderVendors:matched?[...matched.vendors].join(', '):'',unitPrice:price.unitPrice,priceCurrency:price.currency,priceSource:price.source,
   priceDate:fromCodes&&!row.prNo?text(fromCodes.priceDate):'',priceWarning:fromCodes&&!row.prNo?text(fromCodes.priceWarning):'',
   amountQuantity:quantity,amountUsd:amountUSD(quantity,price.unitPrice,price.currency)};})};}
function mapOrderProjects(raw,year){const rows=[];for(const [i,order] of mapOrders(raw).ordersSQL.entries()){const cancelled=/^(?:đã\s*(?:hủy|huỷ|xóa)|hủy|huỷ|cancelled?|deleted)$/i.test(text(order.status));const info=parseDescription(order.remark);if(cancelled||order.deleted||!info||Number(String(order.date).slice(0,4))!==year)continue;rows.push({...info,rowId:hash(JSON.stringify(['order',i,order.week,order.vendor,order.code,order.itemCode])),itemCode:text(order.itemCode),orderQty:order.quantity,orderLines:1,orderVendors:text(order.vendor),category:'',specification:text(order.itemName),orderType:'',orderTypeNote:'Nguồn Order Remark',orderUnit:text(order.unit),orderDocument:{week:order.week,vendor:order.vendor,code:order.code,date:order.date,timeKey:order.timeKey},prQty:null,poQty:null,shippingQty:null,grQty:null,prNo:'',prSeq:'',poNo:'',poSeq:'',prDate:text(order.date),poDate:'',status:'Chờ Cập nhật PR',source:'order'});}return rows;}
function mergeProjectSources(prRows,orderRows){return [...prRows,...orderRows];}
// Mỗi Order là một dòng riêng; PR của cùng Item Code không được xóa Order khác.
function dropPendingPRDuplicates(rows){return {rows:Array.isArray(rows)?rows:[],skipped:0};}
function consolidateProjectRows(rows){
 if(!Array.isArray(rows))return rows;
 // Hiện hành 2026-11-06 (yêu cầu người dùng): cùng dự án chỉ khi TOÀN BỘ chuỗi Project giống nhau
 // sau chuẩn hóa canonName (bỏ dấu, hoa thường, khoảng trắng/ký tự lạ). Không gộp tên là tập con
 // từ của tên khác và không gán dòng có Project generic vào dự án khác — ví dụ "cải tiến xoay chổi"
 // và "cải tiến xoay chổi máy bonding vendor ALT" là HAI dự án riêng.
 const groups=new Map();
 for(const row of rows){const c=canonName(row.project||''),k=c||String(row.projectId);if(!groups.has(k))groups.set(k,{rows:[]});groups.get(k).rows.push(row);}
 const display=new Map();
 for(const [k,g] of groups)display.set(k,g.rows[0].project||'');
 return rows.map(row=>{const c=canonName(row.project||''),k=c||String(row.projectId);return {...row,projectId:hash('project:'+k),project:display.get(k)??row.project};});
}
// Read-only evidence. A code/project overlap is a candidate, never a document link.
function projectDiagnostics(raw,rows,overrides=new Map(),errors=[],rawOrders=[]){
 const reasons=overrides instanceof Map?overrides:new Map(Object.entries(overrides||{}));
 const report={totalSourcePRRecords:raw.length,totalProjectRecords:rows.length,uniqueProjects:0,projects:[],invalidDates:0,missingItemCodes:0,excludedStatuses:0,invalidReason:0,missingProject:0,incompleteReason:0,ignoredReason:0,overrideApplied:0,unclassifiedPR:0,unknownWorkflowStatuses:0,reconciliation:[],reasonRecords:[],sourceErrors:errors.filter(Boolean)};
 const validDate=value=>/^\d{4}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(value))&&new Date(value).toISOString().slice(0,10)===value;
 for(const r of raw){
  if(!validDate(text(r.PR_DATE).slice(0,10)))report.invalidDates++;
  if(!text(r.ITEM_CODE))report.missingItemCodes++;
  if(!eligiblePR(r)){report.excludedStatuses++;continue;}
  if(!text(r.PR_NO))continue;
  const saved=reasons.get(reasonKey(r.ITEM_CODE,r.PR_NO,r.PR_SEQ)),edited=saved&&!saved.ignored?parseDescription(saved.description):null,info=edited||parseDescription(r.PURCHASE_REQ_INFO);
  if(edited)report.overrideApplied++;
  const category=!info&&saved?.ignored?'ignoredReason':!info?'invalidReason':!info.project?'missingProject':!info.model||!info.process?'incompleteReason':'';
  if(category){report[category]++;report.reasonRecords.push({itemCode:text(r.ITEM_CODE),prNo:text(r.PR_NO),prSeq:text(r.PR_SEQ),category,purchaseReqInfo:text(r.PURCHASE_REQ_INFO),effectiveReason:info?.description||'',source:edited?'portal':'sql'});}
  if(!info||!info.project)report.unclassifiedPR++;
 }
 const projects=new Map(),candidates=new Map(),states=new Set(['Chờ Cập nhật PR','Đã cập nhật PR','Đã có PO','Đang giao','Đã nhận đủ']);
 for(const row of rows){
  if(!states.has(row.status))report.unknownWorkflowStatuses++;
  if(!row.project||row.classification==='missing-project')continue;
  if(!projects.has(row.projectId))projects.set(row.projectId,{projectId:row.projectId,project:row.project,codes:new Set()});
  if(row.itemCode)projects.get(row.projectId).codes.add(row.itemCode);
  if(!row.itemCode)continue;
  const key=JSON.stringify([row.projectId,row.itemCode]);if(!candidates.has(key))candidates.set(key,{projectId:row.projectId,itemCode:row.itemCode,orders:[],prs:[]});
  candidates.get(key)[row.source==='order'?'orders':'prs'].push(row);
 }
 report.projects=[...projects.values()].map(p=>({projectId:p.projectId,project:p.project,uniqueItemCodes:p.codes.size}));report.uniqueProjects=report.projects.length;
 report.reconciliation=[...candidates.values()].filter(c=>c.orders.length&&c.prs.length).map(c=>({projectId:c.projectId,itemCode:c.itemCode,category:'potential-overlap',confirmed:false,orderRows:c.orders.map(r=>({rowId:r.rowId,document:r.orderDocument})),prRows:c.prs.map(r=>({rowId:r.rowId,prNo:r.prNo,prSeq:r.prSeq,poNo:r.poNo,poSeq:r.poSeq})),financialStatus:'unreconciled-do-not-total'}));
 report.totalSourceOrderRecords=rawOrders.length;report.invalidOrderDates=mapOrders(rawOrders).orderInvalidDates;
 report.categories={confirmedDataErrors:{invalidPRDates:report.invalidDates,invalidOrderDates:report.invalidOrderDates,missingItemCodes:report.missingItemCodes,invalidReason:report.invalidReason},potentialDuplicatesRequiringVerification:report.reconciliation.length,expectedBusinessExceptions:{incompleteReason:report.incompleteReason,missingProject:report.missingProject,ignoredReason:report.ignoredReason,excludedStatuses:report.excludedStatuses},missingOrUnavailableSQL:report.sourceErrors.length};
 return report;
}
function createProjects({sql,getOrderTypes,classifyPR,pricing,root,runtime,now=()=>new Date()}){
 let pending,lastOrders;const last=new Map();const currentYear=()=>Number(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric'}).format(now()));
 // Kho "Lí do mua hàng" nhập tay (PIC3 bù cho PR do PIC ngoài bộ phận chuẩn tạo). Chỉ tạo khi có
 // root/runtime để test thuần SQL không chạm đĩa; PR & Tracking đọc lại qua adapter core nối.
 const reasons=(root||runtime)?createPRReasons({root,runtime:runtime||path.join(root,'.runtime'),sql,now}):null;
 async function live(data={},requestedYear=currentYear()){
 const year=Number(requestedYear);if(!Number.isInteger(year)||year<2000||year>2100)throw Object.assign(Error('Năm dự án không hợp lệ.'),{status:400});
 if(pending&&pending.year===year)return {...data,...await pending.task};
 const task=(async()=>{let raw,error=null;try{if(typeof sql.readProjectPR!=='function')throw Error('SQL adapter chưa hỗ trợ Project Status.');raw=await sql.readProjectPR(year);if(!Array.isArray(raw))throw Error('Dữ liệu PR không hợp lệ.');last.set(year,{raw,at:now().toISOString()});}catch(e){raw=last.get(year)?.raw||[];error='Không đọc được Project Status từ SQL.'+(e.connected===true?' Đã kết nối máy chủ; kiểm tra quyền SELECT, bảng/cột dbo.EQM_MRO_PR trong database PR hoặc database cấu hình.':e.status===400?' Developer cần kiểm tra cấu hình kết nối SQL.':e.status===504?' SQL phản hồi quá thời gian cho phép.':'');}
 // 12/11/2026: `getOrderTypes` là hàm async (codes.purchaseTypes đọc dbo.EQM_MRO_CodeIssue).
 // Trước đây gọi không `await` nên `types` là Promise — SQL offline là promise từ chối
 // không ai bắt, Node chết cả tiến trình ngay pha dựng snapshot (unhandled rejection).
 let types=[],typeError=null;try{types=await getOrderTypes();}catch{typeError='Không đọc được lịch sử Type of code; chưa tự gán Order Type.';}let orderRows=[],orderQtyByCode=new Map(),projectOrderError=null;try{const ordersRaw=await sql.readOrders();orderRows=mapOrderProjects(ordersRaw,year);orderQtyByCode=orderQuantities(ordersRaw);lastOrders={raw:ordersRaw,at:now().toISOString()};}catch{projectOrderError='Không đọc được EQM_MRO_RequestOrder để tổng hợp Project từ Remark.';if(lastOrders){orderRows=mapOrderProjects(lastOrders.raw,year);orderQtyByCode=orderQuantities(lastOrders.raw);}}
 // Lí do mua hàng PIC3 nhập ở PR & Tracking (SQL hoặc file tạm) bù cho các dòng PR
 // do PIC ngoài bộ phận chuẩn tạo, PURCHASE_REQ_INFO trống/không theo form. Đọc lỗi chỉ báo nguyên
 // nhân, không được làm mất dòng Project nào đã tổng hợp được từ SQL.
 let reasonMap=new Map(),projectReasonError=null,projectReasonStore={total:0,filled:0,ignored:0};
 if(reasons){try{await reasons.refresh();reasonMap=reasons.list();projectReasonStore={...reasons.summary(),storage:reasons.storage()};if(projectReasonStore.error)projectReasonError=projectReasonStore.error;}catch(reasonError){reasonMap=reasons.list();projectReasonStore={...reasons.summary(),storage:reasons.storage()};projectReasonError='Không đọc được Lí do mua hàng từ SQL: '+String(reasonError&&reasonError.message||'').slice(0,200);}}
 const mapped=mapProjects(raw,year,types,classifyPR,reasonMap),consolidated=consolidateProjectRows(mergeProjectSources(mapped.projectRows,orderRows)),deduped=dropPendingPRDuplicates(consolidated),valued=await withOrderValues(deduped.rows,orderQtyByCode,pricing);return {...mapped,projectRows:valued.rows,projectPendingPRSkipped:deduped.skipped,projectPriceError:valued.error||null,projectDiagnostics:projectDiagnostics(raw,valued.rows,reasonMap,[error,projectOrderError,typeError,projectReasonError,valued.error],lastOrders?.raw||[]),projectSource:error?(last.has(year)?'sql-cache':'empty'):'sql',projectUpdatedAt:last.get(year)?.at||null,projectError:error,projectOrderError,projectOrderSource:projectOrderError?(lastOrders?'sql-cache':'empty'):'sql',projectOrderUpdatedAt:lastOrders?.at||null,projectTypeError:typeError,projectReasonStore,projectReasonError};})();pending={year,task};try{return {...data,...await task};}finally{if(pending?.task===task)pending=null;}
 }
 // POST /api/pr-reason: PIC3 nhập lại Lí do mua hàng theo form Type - Project - Model - Process.
 // Mọi vai trò có tài khoản (user trở lên) được nhập; Viewer đã bị chặn non-GET ngay ở auth.
 // CSRF + session do auth kiểm tra trước khi gọi vào đây; ghi file đi qua protectedTransaction.
 async function handle({req,res,url,actor,body,send,protectedTransaction}){
  if(url.pathname==='/api/pr-reason-queue'){
   if(req.method!=='GET')throw Object.assign(Error('Danh sách PR cần Lí do chỉ hỗ trợ GET.'),{status:405});
   if(actor?.vendorScope)throw Object.assign(Error('Tài khoản Vendor không có quyền truy cập danh sách PR nội bộ.'),{status:403});
   if(!reasons)throw Object.assign(Error('Portal chưa bật kho Lí do mua hàng.'),{status:503});
   if(url.searchParams.has('since')){
    if(url.searchParams.get('since')!=='2026-11'||url.searchParams.has('year')||url.searchParams.has('month'))throw Object.assign(Error('Kỳ PR không hợp lệ.'),{status:400});
    send(res,200,await reasons.queue(null,null,true));return true;
   }
   const year=Number(url.searchParams.get('year')||currentYear());if(!Number.isInteger(year)||year<2000||year>2100)throw Object.assign(Error('Năm PR không hợp lệ.'),{status:400});
   const month=url.searchParams.has('month')?Number(url.searchParams.get('month')):null;
   send(res,200,await reasons.queue(year,month));return true;
  }
  if(url.pathname==='/api/pr-reason-bulk-preview'){
   if(req.method!=='POST')throw Object.assign(Error('Kiểm tra danh sách Reason chỉ hỗ trợ POST.'),{status:405});
   if(!actor||actor.role==='viewer'||actor.vendorScope)throw Object.assign(Error('Tài khoản không có quyền cập nhật Reason PIC3.'),{status:403});
   if(!reasons)throw Object.assign(Error('Portal chưa bật kho Lí do mua hàng.'),{status:503});
   const input=await body(req);
   if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>key!=='text')||typeof input.text!=='string')throw Object.assign(Error('Danh sách Reason không hợp lệ.'),{status:400});
   send(res,200,await reasons.previewBulk(input.text));return true;
  }
  if(url.pathname==='/api/pr-reason-bulk-save'){
   if(req.method!=='POST')throw Object.assign(Error('Cập nhật danh sách Reason chỉ hỗ trợ POST.'),{status:405});
   if(!actor||actor.role==='viewer'||actor.vendorScope)throw Object.assign(Error('Tài khoản không có quyền cập nhật Reason PIC3.'),{status:403});
   if(!reasons)throw Object.assign(Error('Portal chưa bật kho Lí do mua hàng.'),{status:503});
   const input=await body(req);
   if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>key!=='rows')||!Array.isArray(input.rows))throw Object.assign(Error('Danh sách cập nhật Reason không hợp lệ.'),{status:400});
   const run=typeof protectedTransaction==='function'?protectedTransaction:(fn=>fn());
   send(res,200,await run(()=>reasons.saveBulk(input.rows,actor)));return true;
  }
  if(url.pathname==='/api/pr-reason'){
   if(req.method!=='POST')throw Object.assign(Error('Lí do mua hàng chỉ hỗ trợ POST.'),{status:405});
   if(!actor||actor.role==='viewer')throw Object.assign(Error('Viewer chỉ được xem dữ liệu.'),{status:403});
   if(!reasons)throw Object.assign(Error('Portal chưa bật kho Lí do mua hàng.'),{status:503});
   const input=await body(req),run=typeof protectedTransaction==='function'?protectedTransaction:(fn=>fn());
   if(typeof sql.lookupPRNumber==='function'){
    const candidates=await sql.lookupPRNumber(String(input?.prNo||''));
    if(!candidates.some(pr=>eligiblePR(pr)&&text(pr.ITEM_CODE)===text(input.itemCode)&&text(pr.PR_NO)===text(input.prNo)&&text(pr.PR_SEQ)===text(input.prSeq)))throw Object.assign(Error('Không tìm thấy đúng dòng PR trong SQL. Tải lại trước khi nhập Lí do.'),{status:404});
   }
   await reasons.refresh();send(res,200,await run(()=>reasons.save(input,actor)));
   return true;
  }
  if(url.pathname!=='/api/project-status')return false;if(req.method!=='GET')throw Object.assign(Error('Project Status chỉ hỗ trợ đọc.'),{status:405});send(res,200,await live({},url.searchParams.get('year')||currentYear()));return true;
 }
 return {live,handle,prReasons:reasons};
}
module.exports={parseDescription,resolveTypes,mapProjects,mapOrderProjects,mergeProjectSources,dropPendingPRDuplicates,consolidateProjectRows,orderQuantities,withOrderValues,amountUSD,projectDiagnostics,createProjects};
