﻿$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.Data
$connection = $null
$connected = $false
$codeIssueFields = @(
    @('LineKey','lineKey','text',64),@('BaseKey','baseKey','text',64),@('OrderDate','orderDate','date',0),@('OrderWeek','orderWeek','text',10),
    @('Vendor','vendor','text',200),@('WRBCode','wrbCode','text',100),@('OriginalCode','originalCode','text',100),@('PurchaseCode','purchaseCode','text',100),
    @('TypeOfCode','typeOfCode','text',10),@('Action','action','text',500),@('Status','status','text',40),@('RFQItemCode','rfqItemCode','text',100),
    @('RFQNo','rfqNo','text',100),@('RFQSeq','rfqSeq','text',50),@('RFQReqSubNo','rfqReqSubNo','text',100),@('RFQStatus','rfqStatus','text',100),
    @('RequestDate','requestDate','date',0),@('ReceiptDate','receiptDate','date',0),@('ContractName','contractName','text',200),@('RFQJson','rfqJson','max',-1),
    @('CreatedAt','createdAt','datetime',0),@('CreatedBy','createdBy','text',80),@('UpdatedAt','updatedAt','datetime',0),@('UpdatedBy','updatedBy','text',80),@('Revision','revision','text',64)
)
function Set-CodeIssueParameters($sqlCommand,$row,$fields) {
    $sqlCommand.Parameters.Clear()
    foreach($field in $fields){
        $column=[string]$field[0];$property=[string]$field[1];$kind=[string]$field[2];$size=[int]$field[3];$raw=[string]$row.$property
        $dbType=[System.Data.SqlDbType]::NVarChar;$value=$raw
        switch($kind){
            'date' {$dbType=[System.Data.SqlDbType]::Date;$value=if($raw){[datetime]::ParseExact($raw,'yyyy-MM-dd',[System.Globalization.CultureInfo]::InvariantCulture)}else{[DBNull]::Value};break}
            'datetime' {$dbType=[System.Data.SqlDbType]::DateTime2;$value=([datetimeoffset]::Parse($raw,[System.Globalization.CultureInfo]::InvariantCulture,[System.Globalization.DateTimeStyles]::AdjustToUniversal)).UtcDateTime;break}
            'max' {$size=-1;$value=if($raw){$raw}else{[DBNull]::Value};break}
            default {$value=$raw}
        }
        if($kind -eq 'text'){$parameter=$sqlCommand.Parameters.Add(('@'+$column),$dbType,$size)}elseif($kind -eq 'max'){$parameter=$sqlCommand.Parameters.Add(('@'+$column),$dbType,-1)}else{$parameter=$sqlCommand.Parameters.Add(('@'+$column),$dbType)}
        $parameter.Value=$value
    }
}
try {
    $job = [Console]::In.ReadToEnd() | ConvertFrom-Json
    if ($job.action -eq 'protect') {
        $bytes = [Text.Encoding]::UTF8.GetBytes([string]$job.password)
        $sealed = [Security.Cryptography.ProtectedData]::Protect($bytes, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        @{secret=[Convert]::ToBase64String($sealed)} | ConvertTo-Json -Compress
    } elseif ($job.action -in @('test','oh','oh-years','oh-write','stock','transfers','orders','orders-add','order-append','master-item','transfer-add','code-master','code-rfq','code-rfq-batch','tracking-pr','tracking-pr-number','tracking-pr-batch','prselect-read','prselect-write','code-issue-read','code-issue-write','code-issue-migrate','vendor-stock','vendor-overview','vendor-inout-add','vendor-transfer-confirm','vendor-transfer-action','notification-stock','hhp-codes','project-pr','project-reason-list','project-reason-lookup','project-reason-save','project-reason-bulk-save','latest-prices','cost-saving','cost-saving-write','download-data','report-form','gr-report','aps-schema','aps-ensure-schema','aps-migrate','aps-contracts','aps-contract-write','aps-plan-read','aps-plan-write','aps-oh-repair','aps-contract-pdf','aps-rows','aps-row-write')) {
        $c = $job.config
        try {
            $bytes = [Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($c.secret), $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        } catch {
            # DPAPI binds the saved password to the Windows account that saved it.
            # Return only a stable code; never expose the provider/DPAPI exception.
            @{ok=$false;code='SQL_SECRET_UNAVAILABLE';connected=$false} | ConvertTo-Json -Compress
            exit 1
        }
        $builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
        $builder['Data Source'] = 'tcp:' + $c.server + ',' + $c.port
        $builder['Initial Catalog'] = $c.database
        $builder['User ID'] = $c.user
        $builder['Password'] = [Text.Encoding]::UTF8.GetString($bytes)
        $builder['Encrypt'] = $true
        $builder['TrustServerCertificate'] = [bool]$c.trustServerCertificate
        $builder['Connect Timeout'] = 3
        $builder['Pooling'] = $false
        $builder['Application Name'] = 'MRO WRB connection check'
        $connection = New-Object System.Data.SqlClient.SqlConnection($builder.ConnectionString)
        $connection.Open()
        $connected = $true
        $command = $connection.CreateCommand()
        # PDF hop dong (upload/download) co the toi 30 MB -> 300 giay; download-data 60; con lai 5.
        # So sanh DAO ('action' -eq $job.action) de khong tao chuoi "$job.action -eq 'aps-contract-*'"
        # lam lech cac oracle cat nhanh dispatch trong test.
        $isPdfJob = (('aps-contract-pdf' -eq $job.action) -or (('aps-contract-write' -eq $job.action) -and ('pdf' -eq $job.op)))
        $command.CommandTimeout = if ($job.action -in @('download-data','report-form','gr-report','stock','vendor-overview','code-issue-migrate','project-reason-bulk-save')) { 60 } elseif ($isPdfJob) { 300 } else { 5 }
        try {
            if ($job.action -eq 'code-issue-read') {
                $command.CommandText='SELECT [LineKey],[BaseKey],CONVERT(varchar(10),[OrderDate],23) AS [OrderDate],[OrderWeek],[Vendor],[WRBCode],[OriginalCode],[PurchaseCode],[TypeOfCode],[Action],[Status],[RFQItemCode],[RFQNo],[RFQSeq],[RFQReqSubNo],[RFQStatus],CONVERT(varchar(10),[RequestDate],23) AS [RequestDate],CONVERT(varchar(10),[ReceiptDate],23) AS [ReceiptDate],[ContractName],[RFQJson],CONVERT(varchar(23),[CreatedAt],126) AS [CreatedAt],[CreatedBy],CONVERT(varchar(23),[UpdatedAt],126) AS [UpdatedAt],[UpdatedBy],[Revision] FROM [dbo].[EQM_MRO_CodeIssue] ORDER BY [No]'
                $reader=$command.ExecuteReader();$rows=@()
                try { while($reader.Read()){$row=@{};for($i=0;$i -lt $reader.FieldCount;$i++){$row[$reader.GetName($i)]=if($reader.IsDBNull($i)){$null}else{[System.Convert]::ToString($reader.GetValue($i),[System.Globalization.CultureInfo]::InvariantCulture)}};$rows+=,$row} } finally {$reader.Dispose()}
                @{ok=$true;rows=$rows} | ConvertTo-Json -Depth 5 -Compress
            } elseif ($job.action -eq 'code-issue-write') {
                $inserts=@($job.inserts);$updates=@($job.updates);$deletes=@($job.deletes);$total=$inserts.Count+$updates.Count+$deletes.Count
                if($total -lt 1 -or $total -gt 400){throw 'Invalid Code Issue write count'}
                $transaction=$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction=$transaction;$inserted=0;$updated=0;$deleted=0;$conflict=$false;$reason=''
                    $sqlColumns=@($codeIssueFields | ForEach-Object {'['+[string]$_[0]+']'})
                    $sqlParams=@($codeIssueFields | ForEach-Object {'@'+[string]$_[0]})
                    foreach($row in $inserts){
                        Set-CodeIssueParameters $command $row $codeIssueFields
                        [void]$command.Parameters.Add('@ParentKey',[System.Data.SqlDbType]::NVarChar,64);$command.Parameters['@ParentKey'].Value=[string]$row.parentKey
                        [void]$command.Parameters.Add('@ParentRevision',[System.Data.SqlDbType]::NVarChar,64);$command.Parameters['@ParentRevision'].Value=[string]$row.parentExpectedRevision
                        $command.CommandText='SELECT [Revision],[BaseKey] FROM [dbo].[EQM_MRO_CodeIssue] WITH (UPDLOCK,HOLDLOCK) WHERE [LineKey]=@ParentKey'
                        $parent=$command.ExecuteReader();$parentRevision=$null;$parentBase=$null
                        try {if($parent.Read()){$parentRevision=[string]$parent.GetValue(0);$parentBase=[string]$parent.GetValue(1)}} finally {$parent.Dispose()}
                        if($parentRevision -ne $null){if($parentBase -ne [string]$row.baseKey -or $parentRevision -cne [string]$row.parentExpectedRevision){$conflict=$true;$reason='parent revision';break}}
                        elseif([string]$row.parentKey -ne [string]$row.baseKey -or [string]$row.parentExpectedRevision){$conflict=$true;$reason='parent missing';break}
                        if([string]$row.lineKey -ne [string]$row.baseKey){
                            $command.CommandText='SELECT COUNT_BIG(*) FROM [dbo].[EQM_MRO_CodeIssue] WITH (UPDLOCK,HOLDLOCK,INDEX([IX_EQM_MRO_CodeIssue_BaseKey])) WHERE [BaseKey]=@BaseKey'
                            if([long]$command.ExecuteScalar() -ge 5){$conflict=$true;$reason='five code limit';break}
                        }
                        $command.CommandText='SELECT [LineKey] FROM [dbo].[EQM_MRO_CodeIssue] WITH (UPDLOCK,HOLDLOCK) WHERE [LineKey]=@LineKey'
                        if($null -ne $command.ExecuteScalar()){$conflict=$true;$reason='duplicate LineKey';break}
                        $command.CommandText='INSERT INTO [dbo].[EQM_MRO_CodeIssue] ('+($sqlColumns -join ',')+') VALUES ('+($sqlParams -join ',')+')'
                        if($command.ExecuteNonQuery() -ne 1){throw 'Code Issue insert row count mismatch'};$inserted++
                    }
                    if(-not $conflict){foreach($row in $updates){
                        Set-CodeIssueParameters $command $row $codeIssueFields
                        [void]$command.Parameters.Add('@ExpectedRevision',[System.Data.SqlDbType]::NVarChar,64);$command.Parameters['@ExpectedRevision'].Value=[string]$row.expectedRevision
                        $setParts=@($codeIssueFields | Where-Object {[string]$_[0] -ne 'LineKey'} | ForEach-Object {'['+[string]$_[0]+']=@'+[string]$_[0]})
                        $command.CommandText='UPDATE [dbo].[EQM_MRO_CodeIssue] SET '+($setParts -join ',')+' WHERE [LineKey]=@LineKey AND [Revision]=@ExpectedRevision'
                        if($command.ExecuteNonQuery() -ne 1){$conflict=$true;$reason='revision';break};$updated++
                    }}
                    if(-not $conflict){foreach($row in $deletes){
                        $command.Parameters.Clear();[void]$command.Parameters.Add('@LineKey',[System.Data.SqlDbType]::NVarChar,64);$command.Parameters['@LineKey'].Value=[string]$row.lineKey
                        [void]$command.Parameters.Add('@ExpectedRevision',[System.Data.SqlDbType]::NVarChar,64);$command.Parameters['@ExpectedRevision'].Value=[string]$row.expectedRevision
                        $command.CommandText='SELECT [BaseKey] FROM [dbo].[EQM_MRO_CodeIssue] WITH (UPDLOCK,HOLDLOCK) WHERE [LineKey]=@LineKey AND [Revision]=@ExpectedRevision'
                        $base=$command.ExecuteScalar();if($null -eq $base -or $base -is [DBNull] -or [string]$base -ceq [string]$row.lineKey){$conflict=$true;$reason='delete revision/base row';break}
                        $command.CommandText='DELETE FROM [dbo].[EQM_MRO_CodeIssue] WHERE [LineKey]=@LineKey AND [Revision]=@ExpectedRevision'
                        if($command.ExecuteNonQuery() -ne 1){$conflict=$true;$reason='delete revision';break};$deleted++
                    }}
                    if($conflict){$transaction.Rollback();@{ok=$true;conflict=$true;reason=$reason} | ConvertTo-Json -Compress}
                    else{$transaction.Commit();@{ok=$true;inserted=$inserted;updated=$updated;deleted=$deleted} | ConvertTo-Json -Compress}
                } catch {if($transaction.Connection){$transaction.Rollback()};throw} finally {$transaction.Dispose()}
            } elseif ($job.action -eq 'code-issue-migrate') {
                $rows=@($job.rows);$maxCodeIssueMigrationRows=1000
                if($rows.Count -lt 1 -or $rows.Count -gt $maxCodeIssueMigrationRows){throw 'Code Issue migration row count must be 1..1000'}
                $transaction=$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction=$transaction;$inserted=0;$skipped=0;$conflicts=@()
                    $sqlColumns=@($codeIssueFields | ForEach-Object {'['+[string]$_[0]+']'});$sqlParams=@($codeIssueFields | ForEach-Object {'@'+[string]$_[0]})
                    $compare=@()
                    foreach($field in $codeIssueFields){$column='['+[string]$field[0]+']';$parameter='@'+[string]$field[0];if([string]$field[2] -eq 'text' -or [string]$field[2] -eq 'max'){$compare+="(CONVERT(varbinary(max),ISNULL($column,N''))=CONVERT(varbinary(max),ISNULL($parameter,N'')))"}else{$compare+="(($column=$parameter) OR ($column IS NULL AND $parameter IS NULL))"}}
                    foreach($row in $rows){
                        Set-CodeIssueParameters $command $row $codeIssueFields
                        $command.CommandText='SELECT CASE WHEN '+($compare -join ' AND ')+' THEN 1 ELSE 0 END FROM [dbo].[EQM_MRO_CodeIssue] WITH (UPDLOCK,HOLDLOCK) WHERE [LineKey]=@LineKey'
                        $match=$command.ExecuteScalar()
                        if($null -ne $match -and $match -isnot [DBNull]){if([int]$match -eq 1){$skipped++}else{$conflicts+=([string]$row.lineKey);break};continue}
                        $command.CommandText='INSERT INTO [dbo].[EQM_MRO_CodeIssue] ('+($sqlColumns -join ',')+') VALUES ('+($sqlParams -join ',')+')'
                        if($command.ExecuteNonQuery() -ne 1){throw 'Code Issue migration insert row count mismatch'};$inserted++
                    }
                    if($conflicts.Count){$transaction.Rollback();@{ok=$true;inserted=0;skipped=0;conflicts=$conflicts} | ConvertTo-Json -Depth 4 -Compress}
                    else{$transaction.Commit();@{ok=$true;inserted=$inserted;skipped=$skipped;conflicts=@()} | ConvertTo-Json -Depth 4 -Compress}
                } catch {if($transaction.Connection){$transaction.Rollback()};throw} finally {$transaction.Dispose()}
            } elseif ($job.action -eq 'test') {
                $command.CommandText = 'SELECT DB_NAME()'
                $database = [string]$command.ExecuteScalar()
                @{ok=$true;database=$database} | ConvertTo-Json -Compress
            } elseif ($job.action -eq 'vendor-inout-add') {
                $batch=$null -ne $job.rows
                $rows=if($batch){@($job.rows)}else{@($job.row)}
                $transfer=if($batch -or $job.row.transferId){$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)}else{$null}
                $inserted=0
                $duplicateLine=$null
                try {
                    if($transfer){$command.Transaction=$transfer}
                    foreach($r in $rows){
                        $command.Parameters.Clear()
                        $command.CommandText='INSERT INTO [dbo].[EQM_MRO_InOut_Vendor] ([Vendor],[Date],[Vendor Item Name],[Purchase Code],[WRB Code],[IN SEV],[OUT SX],[Transfer IN],[Transfer OUT],[Loại Transfer],[Vendor khác],[Reference ID],[Note]) VALUES (@vendor,@date,@name,@code,@wrb,@in,@out,@transferIn,@transferOut,@type,@other,@reference,@note)'
                        [void]$command.Parameters.Add('@vendor',[System.Data.SqlDbType]::NVarChar,3);$command.Parameters['@vendor'].Value=[string]$r.vendorCode
                        [void]$command.Parameters.Add('@date',[System.Data.SqlDbType]::Date);$command.Parameters['@date'].Value=[datetime]::ParseExact([string]$r.date,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
                        foreach($spec in @(@('name',500,[string]$r.vendorItemName),@('code',100,[string]$r.purchaseCode),@('wrb',100,[string]$r.wrbCode),@('type',100,[string]$r.transferType),@('other',100,[string]$r.otherVendor),@('reference',100,[string]$r.referenceId),@('note',1000,[string]$r.note))) { [void]$command.Parameters.Add('@'+$spec[0],[System.Data.SqlDbType]::NVarChar,[int]$spec[1]);$command.Parameters['@'+$spec[0]].Value=[string]$spec[2] }
                        foreach($field in @('in','out','transferIn','transferOut')) { $p=$command.Parameters.Add('@'+$field,[System.Data.SqlDbType]::Decimal);$p.Precision=18;$p.Scale=3;$p.Value=[decimal]::Parse([string]$r.$field,[Globalization.CultureInfo]::InvariantCulture) }
                        if($batch){
                            $insertSql=$command.CommandText
                            $command.CommandText='SELECT TOP (1) 1 FROM [dbo].[EQM_MRO_InOut_Vendor] WITH (UPDLOCK,HOLDLOCK) WHERE [Vendor]=@vendor AND [Date]=@date AND [Purchase Code]=@code AND COALESCE([IN SEV],0)=@in AND COALESCE([OUT SX],0)=@out AND COALESCE([Transfer IN],0)=@transferIn AND COALESCE([Transfer OUT],0)=@transferOut AND COALESCE([Loại Transfer],N'''')=@type AND COALESCE([Vendor khác],N'''')=@other AND COALESCE([Reference ID],N'''')=@reference AND COALESCE([Note],N'''')=@note'
                            if($command.ExecuteScalar() -eq 1){$duplicateLine=[int]$r.line;break}
                            $command.CommandText=$insertSql
                        }
                        if($command.ExecuteNonQuery() -ne 1){throw 'In/Out row was not inserted'}
                        $inserted++
                        if($r.transferId){
                            $command.Parameters.Clear()
                            [void]$command.Parameters.Add('@id',[System.Data.SqlDbType]::UniqueIdentifier);$command.Parameters['@id'].Value=[guid]$r.transferId
                            foreach($spec in @(@('from',3,[string]$r.vendorCode),@('to',3,[string]$r.otherVendor),@('name',500,[string]$r.vendorItemName),@('code',100,[string]$r.purchaseCode),@('wrb',100,[string]$r.wrbCode),@('type',100,[string]$r.transferType),@('reference',100,[string]$r.referenceId),@('note',1000,[string]$r.note),@('actor',40,[string]$r.actor))) { [void]$command.Parameters.Add('@'+$spec[0],[System.Data.SqlDbType]::NVarChar,[int]$spec[1]);$command.Parameters['@'+$spec[0]].Value=[string]$spec[2] }
                            [void]$command.Parameters.Add('@date',[System.Data.SqlDbType]::Date);$command.Parameters['@date'].Value=[datetime]::ParseExact([string]$r.date,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
                            $p=$command.Parameters.Add('@quantity',[System.Data.SqlDbType]::Decimal);$p.Precision=18;$p.Scale=3;$p.Value=[decimal]::Parse([string]$r.transferOut,[Globalization.CultureInfo]::InvariantCulture)
                            $command.CommandText='INSERT INTO [dbo].[EQM_MRO_VendorTransferConfirm] ([TransferId],[FromVendor],[ToVendor],[TransferDate],[VendorItemName],[PurchaseCode],[WRBCode],[Quantity],[TransferType],[ReferenceId],[Note],[RequestedBy]) VALUES (@id,@from,@to,@date,@name,@code,@wrb,@quantity,@type,@reference,@note,@actor)'
                            if($command.ExecuteNonQuery() -ne 1){throw 'Transfer confirmation row was not inserted'}
                        }
                    }
                    if($duplicateLine){
                        $transfer.Rollback()
                        @{ok=$true;duplicateLine=$duplicateLine;inserted=0} | ConvertTo-Json -Compress
                    }else{
                        if($transfer){$transfer.Commit()}
                        $savedTransferId=if(!$batch -and $job.row.transferId){[string]$job.row.transferId}else{$null}
                        @{ok=$true;inserted=$inserted;transferId=$savedTransferId} | ConvertTo-Json -Compress
                    }
                } catch { if($transfer -and $transfer.Connection){$transfer.Rollback()};throw } finally { if($transfer){$transfer.Dispose()} }
            } elseif ($job.action -eq 'vendor-transfer-confirm') {
                $transaction=$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction=$transaction
                    [void]$command.Parameters.Add('@id',[System.Data.SqlDbType]::UniqueIdentifier);$command.Parameters['@id'].Value=[guid]$job.transferId
                    [void]$command.Parameters.Add('@receiver',[System.Data.SqlDbType]::NVarChar,3);$command.Parameters['@receiver'].Value=[string]$job.receiver
                    [void]$command.Parameters.Add('@actor',[System.Data.SqlDbType]::NVarChar,40);$command.Parameters['@actor'].Value=[string]$job.actor
                    [void]$command.Parameters.Add('@date',[System.Data.SqlDbType]::Date);$command.Parameters['@date'].Value=[datetime]::ParseExact([string]$job.date,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
                    $command.CommandText='SELECT [FromVendor],[ToVendor],[VendorItemName],[PurchaseCode],[WRBCode],[Quantity],[TransferType],[ReferenceId],[Note],[Status],CONVERT(varchar(10),[TransferDate],23) AS [TransferDate] FROM [dbo].[EQM_MRO_VendorTransferConfirm] WITH (UPDLOCK,HOLDLOCK) WHERE [TransferId]=@id'
                    $reader=$command.ExecuteReader();$row=$null
                    try { if($reader.Read()){$row=@{};for($i=0;$i -lt $reader.FieldCount;$i++){$row[$reader.GetName($i)]=$reader.GetValue($i)}} } finally {$reader.Dispose()}
                    if($null -eq $row){$transaction.Rollback();@{ok=$true;missing=$true} | ConvertTo-Json -Compress}
                    elseif($row.Status -ne 'Pending' -or $row.ToVendor -ne [string]$job.receiver){$transaction.Rollback();@{ok=$true;conflict=$true} | ConvertTo-Json -Compress}
                    elseif([string]$job.date -lt [string]$row.TransferDate){$transaction.Rollback();@{ok=$true;conflict=$true} | ConvertTo-Json -Compress}
                    else {
                        foreach($spec in @(@('from',3,[string]$row.FromVendor),@('name',500,[string]$row.VendorItemName),@('code',100,[string]$row.PurchaseCode),@('wrb',100,[string]$row.WRBCode),@('type',100,[string]$row.TransferType),@('reference',100,[string]$row.ReferenceId),@('note',1000,[string]$row.Note))) { [void]$command.Parameters.Add('@'+$spec[0],[System.Data.SqlDbType]::NVarChar,[int]$spec[1]);$command.Parameters['@'+$spec[0]].Value=[string]$spec[2] }
                        $p=$command.Parameters.Add('@quantity',[System.Data.SqlDbType]::Decimal);$p.Precision=18;$p.Scale=3;$p.Value=[decimal]$row.Quantity
                        $command.CommandText='INSERT INTO [dbo].[EQM_MRO_InOut_Vendor] ([Vendor],[Date],[Vendor Item Name],[Purchase Code],[WRB Code],[IN SEV],[OUT SX],[Transfer IN],[Transfer OUT],[Loại Transfer],[Vendor khác],[Reference ID],[Note]) VALUES (@receiver,@date,@name,@code,@wrb,0,0,@quantity,0,@type,@from,@reference,@note)'
                        [void]$command.ExecuteNonQuery()
                        $command.CommandText='UPDATE [dbo].[EQM_MRO_VendorTransferConfirm] SET [Status]=N''Confirmed'',[ConfirmedBy]=@actor,[ConfirmedAt]=SYSUTCDATETIME() WHERE [TransferId]=@id AND [Status]=N''Pending'' AND [ToVendor]=@receiver'
                        if($command.ExecuteNonQuery() -ne 1){throw 'Transfer state changed during confirmation'}
                        $transaction.Commit();@{ok=$true;confirmed=1} | ConvertTo-Json -Compress
                    }
                } catch { if($transaction.Connection){$transaction.Rollback()};throw } finally {$transaction.Dispose()}
            } elseif ($job.action -eq 'vendor-transfer-action') {
                $transaction=$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction=$transaction;$command.Parameters.Clear()
                    [void]$command.Parameters.Add('@id',[System.Data.SqlDbType]::UniqueIdentifier);$command.Parameters['@id'].Value=[guid]$job.transferId
                    $command.CommandText='SELECT [FromVendor],[ToVendor],[TransferDate],[VendorItemName],[PurchaseCode],[WRBCode],[Quantity],[TransferType],[ReferenceId],[Note],[Status] FROM [dbo].[EQM_MRO_VendorTransferConfirm] WITH (UPDLOCK,HOLDLOCK) WHERE [TransferId]=@id'
                    $reader=$command.ExecuteReader();$row=$null
                    try { if($reader.Read()){$row=@{};for($i=0;$i -lt $reader.FieldCount;$i++){$row[$reader.GetName($i)]=$reader.GetValue($i)}} } finally {$reader.Dispose()}
                    if($null -eq $row){$transaction.Rollback();@{ok=$true;missing=$true} | ConvertTo-Json -Compress;return}
                    if([string]$row.Status -ne 'Pending'){$transaction.Rollback();@{ok=$true;conflict=$true} | ConvertTo-Json -Compress;return}
                    $action=[string]$job.actionName
                    if($action -notin @('cancel','reject','edit')){$transaction.Rollback();throw 'Transfer action không hợp lệ'}
                    if(($action -eq 'cancel' -or $action -eq 'edit') -and [string]$row.FromVendor -ne [string]$job.vendor){$transaction.Rollback();@{ok=$true;conflict=$true} | ConvertTo-Json -Compress;return}
                    if($action -eq 'reject' -and [string]$row.ToVendor -ne [string]$job.vendor){$transaction.Rollback();@{ok=$true;conflict=$true} | ConvertTo-Json -Compress;return}
                    if($action -eq 'edit'){
                        $command.Parameters.Clear()
                        foreach($spec in @(@('from',3,[string]$row.FromVendor),@('oldCode',100,[string]$row.PurchaseCode),@('oldType',100,[string]$row.TransferType),@('oldOther',100,[string]$row.ToVendor),@('oldReference',100,[string]$row.ReferenceId),@('oldNote',1000,[string]$row.Note),@('newType',100,[string]$job.transferType),@('newReference',100,[string]$job.referenceId),@('newNote',1000,[string]$job.note))) {[void]$command.Parameters.Add('@'+$spec[0],[System.Data.SqlDbType]::NVarChar,[int]$spec[1]);$command.Parameters['@'+$spec[0]].Value=[string]$spec[2]}
                        [void]$command.Parameters.Add('@oldDate',[System.Data.SqlDbType]::Date);$command.Parameters['@oldDate'].Value=[datetime]$row.TransferDate
                        [void]$command.Parameters.Add('@newDate',[System.Data.SqlDbType]::Date);$command.Parameters['@newDate'].Value=[datetime]::ParseExact([string]$job.date,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
                        $p=$command.Parameters.Add('@oldQty',[System.Data.SqlDbType]::Decimal);$p.Precision=18;$p.Scale=3;$p.Value=[decimal]$row.Quantity
                        $p=$command.Parameters.Add('@newQty',[System.Data.SqlDbType]::Decimal);$p.Precision=18;$p.Scale=3;$p.Value=[decimal]$job.quantity
                        $command.CommandText='UPDATE [dbo].[EQM_MRO_InOut_Vendor] SET [Date]=@newDate,[Transfer OUT]=@newQty,[Loại Transfer]=@newType,[Reference ID]=@newReference,[Note]=@newNote WHERE [Vendor]=@from AND [Date]=@oldDate AND [Purchase Code]=@oldCode AND COALESCE([Transfer OUT],0)=@oldQty AND COALESCE([IN SEV],0)=0 AND COALESCE([OUT SX],0)=0 AND COALESCE([Transfer IN],0)=0 AND COALESCE([Loại Transfer],N'''')=@oldType AND COALESCE([Vendor khác],N'''')=@oldOther AND COALESCE([Reference ID],N'''')=@oldReference AND COALESCE([Note],N'''')=@oldNote'
                        if($command.ExecuteNonQuery() -ne 1){$transaction.Rollback();@{ok=$true;conflict=$true} | ConvertTo-Json -Compress;return}
                        $command.Parameters.Clear();[void]$command.Parameters.Add('@id',[System.Data.SqlDbType]::UniqueIdentifier);$command.Parameters['@id'].Value=[guid]$job.transferId
                        [void]$command.Parameters.Add('@date',[System.Data.SqlDbType]::Date);$command.Parameters['@date'].Value=[datetime]::ParseExact([string]$job.date,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
                        $p=$command.Parameters.Add('@quantity',[System.Data.SqlDbType]::Decimal);$p.Precision=18;$p.Scale=3;$p.Value=[decimal]$job.quantity
                        foreach($spec in @(@('type',100,[string]$job.transferType),@('reference',100,[string]$job.referenceId),@('note',1000,[string]$job.note))) {[void]$command.Parameters.Add('@'+$spec[0],[System.Data.SqlDbType]::NVarChar,[int]$spec[1]);$command.Parameters['@'+$spec[0]].Value=[string]$spec[2]}
                        $command.CommandText='UPDATE [dbo].[EQM_MRO_VendorTransferConfirm] SET [TransferDate]=@date,[Quantity]=@quantity,[TransferType]=@type,[ReferenceId]=@reference,[Note]=@note WHERE [TransferId]=@id AND [Status]=N''Pending'''
                        if($command.ExecuteNonQuery() -ne 1){throw 'Transfer state changed during edit'}
                    }else{
                        $command.Parameters.Clear();[void]$command.Parameters.Add('@vendor',[System.Data.SqlDbType]::NVarChar,3);$command.Parameters['@vendor'].Value=[string]$row.FromVendor
                        [void]$command.Parameters.Add('@date',[System.Data.SqlDbType]::Date);$command.Parameters['@date'].Value=[datetime]::ParseExact([string]$job.date,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
                        foreach($spec in @(@('name',500,[string]$row.VendorItemName),@('code',100,[string]$row.PurchaseCode),@('wrb',100,[string]$row.WRBCode),@('type',100,('Transfer '+$action)),@('other',100,[string]$row.ToVendor),@('reference',100,([string]$row.ReferenceId+' / '+$action)),@('note',1000,('Hoàn tồn do '+$action+' Transfer '+[string]$row.TransferId)))) {[void]$command.Parameters.Add('@'+$spec[0],[System.Data.SqlDbType]::NVarChar,[int]$spec[1]);$command.Parameters['@'+$spec[0]].Value=[string]$spec[2]}
                        $p=$command.Parameters.Add('@quantity',[System.Data.SqlDbType]::Decimal);$p.Precision=18;$p.Scale=3;$p.Value=[decimal]$row.Quantity
                        $command.CommandText='INSERT INTO [dbo].[EQM_MRO_InOut_Vendor] ([Vendor],[Date],[Vendor Item Name],[Purchase Code],[WRB Code],[IN SEV],[OUT SX],[Transfer IN],[Transfer OUT],[Loại Transfer],[Vendor khác],[Reference ID],[Note]) VALUES (@vendor,@date,@name,@code,@wrb,0,0,@quantity,0,@type,@other,@reference,@note)'
                        if($command.ExecuteNonQuery() -ne 1){throw 'Transfer compensation was not inserted'}
                        $command.Parameters.Clear();[void]$command.Parameters.Add('@id',[System.Data.SqlDbType]::UniqueIdentifier);$command.Parameters['@id'].Value=[guid]$job.transferId
                        [void]$command.Parameters.Add('@status',[System.Data.SqlDbType]::NVarChar,20);$command.Parameters['@status'].Value=if($action -eq 'cancel'){'Cancelled'}else{'Rejected'}
                        $command.CommandText='UPDATE [dbo].[EQM_MRO_VendorTransferConfirm] SET [Status]=@status WHERE [TransferId]=@id AND [Status]=N''Pending'''
                        if($command.ExecuteNonQuery() -ne 1){throw 'Transfer state changed during action'}
                    }
                    $transaction.Commit();@{ok=$true;action=$action} | ConvertTo-Json -Compress
                } catch { if($transaction.Connection){$transaction.Rollback()};throw } finally {$transaction.Dispose()}
            } elseif ($job.action -eq 'project-reason-save') {
                $transaction=$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction=$transaction
                    foreach($spec in @(@('item',50,[string]$job.itemCode),@('pr',50,[string]$job.prNo),@('seq',20,[string]$job.prSeq),@('reason',1000,[string]$job.description),@('note',500,[string]$job.note),@('actor',40,[string]$job.actor))) {
                        [void]$command.Parameters.Add('@'+$spec[0],[System.Data.SqlDbType]::NVarChar,[int]$spec[1]);$command.Parameters['@'+$spec[0]].Value=[string]$spec[2]
                    }
                    [void]$command.Parameters.Add('@ignored',[System.Data.SqlDbType]::Bit);$command.Parameters['@ignored'].Value=[bool]$job.ignored
                    [void]$command.Parameters.Add('@at',[System.Data.SqlDbType]::DateTime2);$command.Parameters['@at'].Value=([datetimeoffset]::Parse([string]$job.at)).UtcDateTime
                    $command.CommandText='SELECT CONVERT(varchar(16),[ROW_VERSION],2) FROM [dbo].[EQM_MRO_PR_ReasonOverride] WITH (UPDLOCK,HOLDLOCK) WHERE [ITEM_CODE]=@item AND [PR_NO]=@pr AND [PR_SEQ]=@seq'
                    $found=$command.ExecuteScalar();$actual=if($null -eq $found -or $found -is [DBNull]){''}else{[string]$found};$expected=[string]$job.revision
                    if($actual -ine $expected){$transaction.Commit();@{ok=$true;conflict=$true} | ConvertTo-Json -Compress}
                    else {
                        if($actual){$command.CommandText='UPDATE [dbo].[EQM_MRO_PR_ReasonOverride] SET [PURCHASE_REQ_INFO_OVERRIDE]=@reason,[IS_IGNORED]=@ignored,[NOTE]=@note,[UPDATED_BY]=@actor,[UPDATED_AT]=@at WHERE [ITEM_CODE]=@item AND [PR_NO]=@pr AND [PR_SEQ]=@seq'}
                        else{$command.CommandText='INSERT INTO [dbo].[EQM_MRO_PR_ReasonOverride] ([ITEM_CODE],[PR_NO],[PR_SEQ],[PURCHASE_REQ_INFO_OVERRIDE],[IS_IGNORED],[NOTE],[CREATED_BY],[CREATED_AT],[UPDATED_BY],[UPDATED_AT]) VALUES (@item,@pr,@seq,@reason,@ignored,@note,@actor,@at,@actor,@at)'}
                        if([bool]$job.ignored){$command.Parameters['@reason'].Value=[DBNull]::Value}
                        [void]$command.ExecuteNonQuery()
                        $command.CommandText='SELECT [ITEM_CODE],[PR_NO],[PR_SEQ],[PURCHASE_REQ_INFO_OVERRIDE],[IS_IGNORED],[NOTE],[UPDATED_BY],CONVERT(varchar(33),[UPDATED_AT],127) AS [UPDATED_AT],CONVERT(varchar(16),[ROW_VERSION],2) AS [REVISION] FROM [dbo].[EQM_MRO_PR_ReasonOverride] WHERE [ITEM_CODE]=@item AND [PR_NO]=@pr AND [PR_SEQ]=@seq'
                        $reader=$command.ExecuteReader();$row=@{}
                        try{if(-not $reader.Read()){throw 'Reason row missing after save'};for($i=0;$i -lt $reader.FieldCount;$i++){$row[$reader.GetName($i)]=if($reader.IsDBNull($i)){$null}else{[System.Convert]::ToString($reader.GetValue($i))}}}finally{$reader.Dispose()}
                        $transaction.Commit();@{ok=$true;row=$row} | ConvertTo-Json -Depth 4 -Compress
                    }
                } catch {if($transaction.Connection){$transaction.Rollback()};throw} finally {$transaction.Dispose()}
            } elseif ($job.action -eq 'project-reason-bulk-save') {
                $entries=@($job.entries)
                if($entries.Count -lt 1 -or $entries.Count -gt 500){throw 'Invalid bulk reason count'}
                $results=@()
                foreach($entry in $entries){
                    $transaction=$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                    try {
                        $command.Transaction=$transaction;$command.Parameters.Clear()
                        foreach($spec in @(@('item',50,[string]$entry.itemCode),@('pr',50,[string]$entry.prNo),@('seq',20,[string]$entry.prSeq),@('reason',1000,[string]$entry.description),@('note',500,[string]$entry.note),@('actor',80,[string]$entry.actor))) {
                            [void]$command.Parameters.Add('@'+$spec[0],[System.Data.SqlDbType]::NVarChar,[int]$spec[1]);$command.Parameters['@'+$spec[0]].Value=[string]$spec[2]
                        }
                        [void]$command.Parameters.Add('@at',[System.Data.SqlDbType]::DateTime2);$command.Parameters['@at'].Value=([datetimeoffset]::Parse([string]$entry.at)).UtcDateTime
                        $command.CommandText='SELECT CONVERT(varchar(16),[ROW_VERSION],2) FROM [dbo].[EQM_MRO_PR_ReasonOverride] WITH (UPDLOCK,HOLDLOCK) WHERE [ITEM_CODE]=@item AND [PR_NO]=@pr AND [PR_SEQ]=@seq'
                        $found=$command.ExecuteScalar();$actual=if($null -eq $found -or $found -is [DBNull]){''}else{[string]$found};$expected=[string]$entry.revision
                        if($actual -ine $expected){
                            $transaction.Rollback();$results+=,@{index=[int]$entry.index;ok=$false;status='Reason đã thay đổi sau Preview'}
                        } else {
                            if($actual){$command.CommandText='UPDATE [dbo].[EQM_MRO_PR_ReasonOverride] SET [PURCHASE_REQ_INFO_OVERRIDE]=@reason,[IS_IGNORED]=0,[NOTE]=@note,[UPDATED_BY]=@actor,[UPDATED_AT]=@at WHERE [ITEM_CODE]=@item AND [PR_NO]=@pr AND [PR_SEQ]=@seq'}
                            else{$command.CommandText='INSERT INTO [dbo].[EQM_MRO_PR_ReasonOverride] ([ITEM_CODE],[PR_NO],[PR_SEQ],[PURCHASE_REQ_INFO_OVERRIDE],[IS_IGNORED],[NOTE],[CREATED_BY],[CREATED_AT],[UPDATED_BY],[UPDATED_AT]) VALUES (@item,@pr,@seq,@reason,0,@note,@actor,@at,@actor,@at)'}
                            if($command.ExecuteNonQuery() -ne 1){throw 'Unexpected reason write count'}
                            $command.CommandText='SELECT [ITEM_CODE],[PR_NO],[PR_SEQ],[PURCHASE_REQ_INFO_OVERRIDE],[IS_IGNORED],[NOTE],[UPDATED_BY],CONVERT(varchar(33),[UPDATED_AT],127) AS [UPDATED_AT],CONVERT(varchar(16),[ROW_VERSION],2) AS [REVISION] FROM [dbo].[EQM_MRO_PR_ReasonOverride] WHERE [ITEM_CODE]=@item AND [PR_NO]=@pr AND [PR_SEQ]=@seq'
                            $reader=$command.ExecuteReader();$row=@{}
                            try{if(-not $reader.Read()){throw 'Reason row missing after bulk save'};for($i=0;$i -lt $reader.FieldCount;$i++){$row[$reader.GetName($i)]=if($reader.IsDBNull($i)){$null}else{[System.Convert]::ToString($reader.GetValue($i))}}}finally{$reader.Dispose()}
                            $transaction.Commit();$results+=,@{index=[int]$entry.index;ok=$true;status='Đã cập nhật';row=$row}
                        }
                    } catch {
                        if($transaction.Connection){$transaction.Rollback()}
                        $results+=,@{index=[int]$entry.index;ok=$false;status='SQL không lưu được dòng'}
                    } finally {$command.Transaction=$null;$transaction.Dispose()}
                }
                @{ok=$true;results=$results} | ConvertTo-Json -Depth 5 -Compress
            } elseif ($job.action -eq 'transfer-add') {
                $transaction=$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction=$transaction
                    $command.CommandText='SELECT ISNULL(MAX([No]),0) FROM [dbo].[EQM_MRO_TranferVendor] WITH (TABLOCKX,HOLDLOCK)'
                    $next=[long]$command.ExecuteScalar()+1
                    $command.CommandText="SELECT [name],is_identity,is_computed,system_type_id FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.EQM_MRO_TranferVendor') ORDER BY column_id"
                    $reader=$command.ExecuteReader();$columns=@();try{while($reader.Read()){if(!$reader.GetBoolean(1) -and !$reader.GetBoolean(2) -and $reader.GetByte(3) -ne 189){$columns += [string]$reader.GetValue(0)}}}finally{$reader.Dispose()}
                    $transfers=if($null -ne $job.transfers){@($job.transfers)}else{@($job.transfer)}
                    foreach($t in $transfers){
                    $command.Parameters.Clear()
                    $fields=@{'No'=[string]$next;'Date'=[string]$t.date;'Item Code'=[string]$t.itemCode;'WRB Code'=[string]$t.code;'Item Name'=[string]$t.itemName;'Note'=[string]$t.note;'Remark'=[string]$t.remark;'Bill'=[string]$t.bill}
                    foreach($key in @('ALT-Watch','ALT-Buds','ALV-Watch','ALV-Buds','Bujeon','Chitwing')){$fields[$key]=[string]$t.parts.$key}
                    $names=@();$values=@();$i=0
                    foreach($column in $columns){$key=$column.Trim();if(!$fields.ContainsKey($key)){continue};$parameter='@v'+$i;$i++;$names+='['+$column.Replace(']',']]')+']';$values+=$parameter;[void]$command.Parameters.Add($parameter,[System.Data.SqlDbType]::NVarChar,-1);$command.Parameters[$parameter].Value=$fields[$key]}
                    $command.CommandText='INSERT INTO [dbo].[EQM_MRO_TranferVendor] ('+($names -join ',')+') VALUES ('+($values -join ',')+'); SELECT @@ROWCOUNT'
                    if([int]$command.ExecuteScalar() -ne 1){throw 'Unexpected insert count'}
                    $next++
                    }
                    $transaction.Commit();@{ok=$true;inserted=$true}|ConvertTo-Json -Compress
                }catch{if($transaction.Connection){$transaction.Rollback()};throw}finally{$transaction.Dispose()}
            } elseif ($job.action -eq 'orders-add') {
                $transaction=$connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction=$transaction
                    $command.CommandText="SELECT [name] FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.EQM_MRO_RequestOrder') AND is_identity=0 AND is_computed=0 AND system_type_id<>189 ORDER BY column_id"
                    $reader=$command.ExecuteReader();$columns=@();try{while($reader.Read()){$columns += [string]$reader.GetValue(0)}}finally{$reader.Dispose()}
                                        foreach($required in @('Date','Time','IP','Vendor','Item Code','Item Name','Quantity','Status')){if($columns -notcontains $required){throw 'Missing required Order column'}}
                    $count=0;$conflict=$false;$seen=@{}
                    # 06/11/2026: nhieu dong CUNG khoa Vendor+WRB+Item trong cung mot lan gui duoc phep (yeu cau nguoi dung);
                    # moi dong nhan mot moc Time rieng (phan thap phan tang dan) de thu tu trang thai theo Date+Time van xac dinh duoc.
                    # Guard idempotency chi cham khi da co dong cua LAN GUI KHAC cung giay: so dong ton tai (Time>=thoi diem chen)
                    # phai dung bang so dong cung khoa da chen trong lo nay ($seen) - vuot la ban ghi doi thu tranh, rollback ca lo.
                    foreach($row in $job.rows){
                        $rowKey=[string]$row.vendor+'|'+[string]$row.code+'|'+[string]$row.itemCode
                        $seenCount=0;if($seen.ContainsKey($rowKey)){$seenCount=[int]$seen[$rowKey]}
                        $command.Parameters.Clear()
                        foreach($pair in @(@('vendor',$row.vendor),@('wrb',$row.code),@('item',$row.itemCode),@('date',$job.date),@('time',$job.time))){[void]$command.Parameters.Add('@'+$pair[0],[System.Data.SqlDbType]::NVarChar,4000);$command.Parameters['@'+$pair[0]].Value=[string]$pair[1]}
                        $command.CommandText="SELECT COUNT(*) FROM [dbo].[EQM_MRO_RequestOrder] WITH (TABLOCKX,HOLDLOCK) WHERE COALESCE(LTRIM(RTRIM([Vendor])),N'') COLLATE Latin1_General_100_BIN2=@vendor COLLATE Latin1_General_100_BIN2 AND COALESCE(LTRIM(RTRIM([WRB Code])),N'') COLLATE Latin1_General_100_BIN2=@wrb COLLATE Latin1_General_100_BIN2 AND COALESCE(LTRIM(RTRIM([Item Code])),N'') COLLATE Latin1_General_100_BIN2=@item COLLATE Latin1_General_100_BIN2 AND [Date]=CONVERT(date,@date,23) AND [Time]>=CONVERT(time,@time)"
                        if([int]$command.ExecuteScalar() -gt $seenCount){$conflict=$true;break}
                        $command.Parameters.Clear();$names=@();$values=@();$i=0
                        $data=@{'Date'=$job.date;'Time'=[string]$job.time+'.'+([string]$count).PadLeft(7,'0');'IP'=$job.ip;'Vendor'=$row.vendor;'Requester'=$row.requester;'WRB Code'=$row.code;'Item Code'=$row.itemCode;'Item Name'=$row.itemName;'Quantity'=$row.quantity;'Unit'=$row.unit;'Reason'=$row.reason;'Status'='Chờ duyệt';'Approver'='';'Remark'=$row.remark;'Remake'=$row.remark;'Comment'='';'Bill'=''}
                        foreach($column in $columns){if(!$data.ContainsKey($column)){continue};$names+='['+$column.Replace(']',']]')+']';$param='@p'+$i;$i++;$values+=$param;[void]$command.Parameters.Add($param,[System.Data.SqlDbType]::NVarChar,-1);$command.Parameters[$param].Value=[string]$data[$column]}
                        $command.CommandText='INSERT INTO [dbo].[EQM_MRO_RequestOrder] ('+($names -join ',')+') VALUES ('+($values -join ',')+'); SELECT @@ROWCOUNT'
                        if([int]$command.ExecuteScalar() -ne 1){throw 'Unexpected Order insert count'};$seen[$rowKey]=$seenCount+1;$count++
                    }
                    if($conflict){$transaction.Rollback();@{ok=$true;conflict=$true}|ConvertTo-Json -Compress}else{$transaction.Commit();@{ok=$true;inserted=$count}|ConvertTo-Json -Compress}
                }catch{if($transaction.Connection){$transaction.Rollback()};throw}finally{$transaction.Dispose()}
            } elseif ($job.action -eq 'order-append') {
                # Append-only approval: lock source selection and insert in one transaction.
                $transaction = $connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction = $transaction
                    foreach ($key in @('vendor','code','itemCode','start','end')) {
                        [void]$command.Parameters.Add('@'+$key,[System.Data.SqlDbType]::NVarChar,4000)
                        $command.Parameters['@'+$key].Value=[string]$job.$key
                    }
                    $where = "COALESCE(LTRIM(RTRIM([Vendor])),N'') COLLATE Latin1_General_100_BIN2=@vendor COLLATE Latin1_General_100_BIN2 AND COALESCE(LTRIM(RTRIM([WRB Code])),N'') COLLATE Latin1_General_100_BIN2=@code COLLATE Latin1_General_100_BIN2 AND COALESCE(LTRIM(RTRIM([Item Code])),N'') COLLATE Latin1_General_100_BIN2=@itemCode COLLATE Latin1_General_100_BIN2 AND [Date]>=CONVERT(date,@start,23) AND [Date]<=CONVERT(date,@end,23)"
                    # 12/11/2026 (loi nguoi dung bao: duyet/xoa ma da dat tu tuan truoc luon 409 "lich-su-thay-doi"):
                    # historyCount phia Node dem so dong cua khoa TRONG TUAN quyet dinh (dung nhu ghi chu 06/11 duoi day) —
                    # COUNT phai dung cung khoang [Date] voi $where. Ban tach [Date] khoi dieu kien (dem toan bo lich su)
                    # luon lech voi khoa co dong o tuan khac, nen moi quyet dinh cua khoa do bi chan nham.
                    $command.CommandText='SELECT COUNT(*) FROM [dbo].[EQM_MRO_RequestOrder] WITH (TABLOCKX,HOLDLOCK) WHERE '+$where
                    $historyCount=[int]$command.ExecuteScalar()
                    $command.CommandText='SELECT *,CONVERT(varchar(10),[Date],23) AS [__orderDate],CONVERT(varchar(16),[Time]) AS [__orderTime] FROM [dbo].[EQM_MRO_RequestOrder] WITH (TABLOCKX,HOLDLOCK) WHERE '+$where+' ORDER BY [Date] DESC,[Time] DESC'
                    $reader=$command.ExecuteReader();$selected=@()
                    try { while ($reader.Read()) { $r=@{};for($i=0;$i -lt $reader.FieldCount;$i++) { $r[$reader.GetName($i)]=if($reader.IsDBNull($i)){$null}else{[Convert]::ToString($reader.GetValue($i),[Globalization.CultureInfo]::InvariantCulture)} };$selected+=,$r } } finally { $reader.Dispose() }
                                        $matched=$null
                    # 06/11/2026: mỗi dòng Order là độc lập (nhiều dòng cùng khóa được phép) — so khớp nguồn với
                    # BẤT KỲ dòng nào của khóa trong tuần; INSERT từ đúng dòng đã khớp. Chống đổi trống do
                    # historyCount (số dòng của khóa trong tuần) + revision phía portal đảm nhận.
                    if($selected.Count -gt 0){
                        foreach($candidate in $selected){
                            $same=$true
                            foreach($property in $job.source.PSObject.Properties){if(!($candidate.ContainsKey($property.Name)) -or $candidate[$property.Name] -cne $property.Value){$same=$false;break}}
                            if($same){$matched=$candidate;break}
                        }
                    }
                    $conflictReason=if($selected.Count -eq 0){'khong-con-dong'}elseif($historyCount -ne [int]$job.historyCount){'lich-su-thay-doi'}elseif($null -eq $matched){'nguon-khong-khop'}else{$null}
                    $conflict=($null -ne $conflictReason)
                    if($conflict){$transaction.Rollback();@{ok=$true;conflict=$true;reason=$conflictReason} | ConvertTo-Json -Compress}
                    else {
                        $command.Parameters.Clear()
                        $command.CommandText="SELECT [name] FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.EQM_MRO_RequestOrder') AND is_identity=0 AND is_computed=0 AND system_type_id<>189 ORDER BY column_id"
                        $reader=$command.ExecuteReader();$columns=@();try{while($reader.Read()){$columns += [string]$reader.GetValue(0)}}finally{$reader.Dispose()}
                        $names=@();$values=@();$i=0
                        foreach($column in $columns){
                            $names+='['+$column.Replace(']',']]')+']';$parameter='@p'+$i;$i++;$values+=$parameter
                            $value=$matched[$column]
                            if($column -eq 'Status'){$value=[string]$job.status}
                            if($column -eq 'Comment' -and $job.PSObject.Properties.Name -contains 'comment'){$value=[string]$job.comment}
                            if($column -eq 'Approver'){$value=[string]$job.approver}
                            if($column -eq 'Date'){$value=[string]$job.date}
                            if($column -eq 'Time'){$value=[string]$job.time}
                            [void]$command.Parameters.Add($parameter,[System.Data.SqlDbType]::NVarChar,-1)
                            $command.Parameters[$parameter].Value=if($null -eq $value){[DBNull]::Value}else{[string]$value}
                        }
                        $command.CommandText='INSERT INTO [dbo].[EQM_MRO_RequestOrder] ('+($names -join ',')+') VALUES ('+($values -join ',')+'); SELECT @@ROWCOUNT'
                        if([int]$command.ExecuteScalar() -ne 1){throw 'Unexpected insert count'}
                        $transaction.Commit();@{ok=$true;inserted=$true} | ConvertTo-Json -Compress
                    }
                } catch { if($transaction.Connection){$transaction.Rollback()};throw } finally { $transaction.Dispose() }
            } elseif ($job.action -eq 'oh-write') {
                $transaction = $connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction = $transaction
                    $command.CommandText = 'SELECT COUNT(*) FROM [dbo].[MRO_OH] WITH (UPDLOCK,HOLDLOCK) WHERE LTRIM(RTRIM([Year]))=@year'
                    [void]$command.Parameters.Add('@year',[System.Data.SqlDbType]::NVarChar,4)
                    $command.Parameters['@year'].Value = [string]$job.year
                    [void]$command.ExecuteScalar()
                    $command.CommandText="SELECT COUNT(*) FROM [dbo].[MRO_OH] WHERE LTRIM(RTRIM([Year]))=@year AND ([OH] IS NULL OR UPPER(LTRIM(RTRIM([OH]))) NOT IN ('P03','GR','PR','OTHER'))"
                    if ([int]$command.ExecuteScalar() -gt 0) { throw 'Unsupported OH types; transaction cancelled' }
                    $names = @('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
                    foreach ($row in $job.rows) {
                        $command.Parameters.Clear()
                        [void]$command.Parameters.Add('@year',[System.Data.SqlDbType]::NVarChar,4)
                        $command.Parameters['@year'].Value = [string]$job.year
                        [void]$command.Parameters.Add('@oh',[System.Data.SqlDbType]::NVarChar,5)
                        $command.Parameters['@oh'].Value = [string]$row.OH
                        $command.CommandText = 'SELECT COUNT(*) FROM [dbo].[MRO_OH] WHERE LTRIM(RTRIM([Year]))=@year AND UPPER(LTRIM(RTRIM([OH])))=UPPER(@oh)'
                        $count = [int]$command.ExecuteScalar()
                        if ($count -gt 1) { throw 'Duplicate OH rows' }
                        $sets=@();$columns=@();$values=@()
                        for ($i=0;$i -lt 12;$i++) {
                            $parameterName='@m'+$i
                            [void]$command.Parameters.Add($parameterName,[System.Data.SqlDbType]::NVarChar,32)
                            $command.Parameters[$parameterName].Value=[string]$row.values[$i]
                            $sets += '['+$names[$i]+']='+$parameterName
                            $columns += '['+$names[$i]+']';$values += $parameterName
                        }
                        if ($count -eq 1) {
                            $command.CommandText='UPDATE [dbo].[MRO_OH] SET '+($sets -join ',')+' WHERE LTRIM(RTRIM([Year]))=@year AND UPPER(LTRIM(RTRIM([OH])))=UPPER(@oh)'
                        } else {
                            $command.CommandText='INSERT INTO [dbo].[MRO_OH] ([Year],[OH],'+($columns -join ',')+') VALUES (@year,@oh,'+($values -join ',')+')'
                        }
                        [void]$command.ExecuteNonQuery()
                    }
                    $transaction.Commit()
                    @{ok=$true} | ConvertTo-Json -Compress
                } catch { $transaction.Rollback();throw } finally { $transaction.Dispose() }
            } elseif ($job.action -eq 'cost-saving-write') {
                # 05/11/2026: luu o Plan/Actual cua EQM_CostSavingActivity. Khoa No phai duy nhat;
                # ten cot thang lay tu mang co dinh Jan..Dec, moi gia tri di qua tham so, chi UPDATE.
                $savingNames = @('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
                $transaction = $connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction = $transaction
                    $savingUpdated = 0
                    foreach ($change in $job.changes) {
                        $command.Parameters.Clear()
                        $savingMonth = [int]$change.month
                        if ($savingMonth -lt 1 -or $savingMonth -gt 12) { throw 'Invalid Cost Saving month' }
                        [void]$command.Parameters.Add('@no',[System.Data.SqlDbType]::NVarChar,50)
                        $command.Parameters['@no'].Value = [string]$change.no
                        $command.CommandText = 'SELECT COUNT(*) FROM [dbo].[EQM_CostSavingActivity] WITH (UPDLOCK,HOLDLOCK) WHERE LTRIM(RTRIM([No]))=@no'
                        if ([int]$command.ExecuteScalar() -ne 1) { throw 'Cost Saving row not found or No is not unique' }
                        [void]$command.Parameters.Add('@value',[System.Data.SqlDbType]::NVarChar,32)
                        if ($null -eq $change.value -or [string]$change.value -eq '') { $command.Parameters['@value'].Value = [DBNull]::Value } else { $command.Parameters['@value'].Value = [string]$change.value }
                        $command.CommandText = 'UPDATE [dbo].[EQM_CostSavingActivity] SET [' + $savingNames[$savingMonth-1] + ']=@value WHERE LTRIM(RTRIM([No]))=@no'
                        $savingUpdated += [int]$command.ExecuteNonQuery()
                    }
                    $transaction.Commit()
                    @{ok=$true;updated=$savingUpdated} | ConvertTo-Json -Compress
                } catch { if($transaction.Connection){$transaction.Rollback()};throw } finally { $transaction.Dispose() }
            } elseif ($job.action -eq 'aps-schema') {
                # Read-only metadata report for the four Repair & Service tables. Table names are fixed literals; no user input reaches SQL text.
                $apsTables = @('EQM_MRO_REPAIR','EQM_MRO_SERVICE','EQM_MRO_ServiceContract','EQM_MRO_ServiceMonthlyPlan')
                $schema = @{}
                foreach ($apsTable in $apsTables) {
                    if ($apsTable -notmatch '^[A-Za-z0-9_]+$') { throw 'Unsupported table' }
                    $command.Parameters.Clear()
                    $command.Parameters.Add('@t',[System.Data.SqlDbType]::NVarChar,128).Value = $apsTable
                    $command.CommandText = 'SELECT CASE WHEN EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = N''dbo'' AND TABLE_NAME = @t) THEN 1 ELSE 0 END'
                    $apsExists = ([int]$command.ExecuteScalar()) -eq 1
                    $entry = @{ exists = $apsExists }
                    if ($apsExists) {
                        $command.CommandText = 'SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, IS_NULLABLE, CAST(COLUMN_DEFAULT AS nvarchar(200)) AS COLUMN_DEFAULT, ISNULL(COLUMNPROPERTY(OBJECT_ID(N''dbo.'' + @t), COLUMN_NAME, ''IsIdentity''), 0) AS IsIdentity FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = N''dbo'' AND TABLE_NAME = @t ORDER BY ORDINAL_POSITION'
                        $apsColumns = @()
                        $reader = $command.ExecuteReader(); try { while ($reader.Read()) { $apsColumns += @{ name = [string]$reader.GetValue(0); type = [string]$reader.GetValue(1); maxLen = $(if ($reader.IsDBNull(2)) { $null } else { [int]$reader.GetValue(2) }); precision = $(if ($reader.IsDBNull(3)) { $null } else { [int]$reader.GetValue(3) }); scale = $(if ($reader.IsDBNull(4)) { $null } else { [int]$reader.GetValue(4) }); nullable = ([string]$reader.GetValue(5) -eq 'YES'); defaultValue = $(if ($reader.IsDBNull(6)) { $null } else { [string]$reader.GetValue(6) }); identity = ([int]$reader.GetValue(7)) -eq 1 } } } finally { $reader.Dispose() }
                        $entry.columns = $apsColumns
                        $command.CommandText = 'SELECT tc.CONSTRAINT_NAME, tc.CONSTRAINT_TYPE, kcu.COLUMN_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu ON kcu.CONSTRAINT_NAME = tc.CONSTRAINT_NAME AND kcu.TABLE_SCHEMA = tc.TABLE_SCHEMA WHERE tc.TABLE_SCHEMA = N''dbo'' AND tc.TABLE_NAME = @t ORDER BY tc.CONSTRAINT_NAME, kcu.ORDINAL_POSITION'
                        $apsConstraints = @()
                        $reader = $command.ExecuteReader(); try { while ($reader.Read()) { $apsConstraints += @{ name = [string]$reader.GetValue(0); type = [string]$reader.GetValue(1); column = $(if ($reader.IsDBNull(2)) { $null } else { [string]$reader.GetValue(2) }) } } } finally { $reader.Dispose() }
                        $entry.constraints = $apsConstraints
                        $command.CommandText = 'SELECT COUNT_BIG(*) FROM [dbo].[' + $apsTable + ']'
                        $entry.rowCount = [long]$command.ExecuteScalar()
                    }
                    $schema[$apsTable] = $entry
                }
                @{ok = $true; schema = $schema} | ConvertTo-Json -Depth 6 -Compress
            } elseif ($job.action -eq 'aps-ensure-schema') {
                # Additive DDL only, each guarded by IF COL_LENGTH(...) IS NULL so re-running changes nothing.
                # 2026-10-29: EQM_MRO_SERVICE.[Request ID]. 2026-11-06: EQM_MRO_ServiceContract PDF columns (hợp đồng + PDF một nguồn SQL).
                # No other DDL lives in this worker; no DROP/CREATE/TRUNCATE anywhere.
                $command.CommandText = 'IF COL_LENGTH(''dbo.EQM_MRO_SERVICE'',''Request ID'') IS NULL ALTER TABLE [dbo].[EQM_MRO_SERVICE] ADD [Request ID] nvarchar(50) NULL'
                [void]$command.ExecuteNonQuery()
                $command.CommandText = 'IF COL_LENGTH(''dbo.EQM_MRO_ServiceContract'',''PdfData'') IS NULL ALTER TABLE [dbo].[EQM_MRO_ServiceContract] ADD [PdfData] varbinary(MAX) NULL'
                [void]$command.ExecuteNonQuery()
                $command.CommandText = 'IF COL_LENGTH(''dbo.EQM_MRO_ServiceContract'',''PdfName'') IS NULL ALTER TABLE [dbo].[EQM_MRO_ServiceContract] ADD [PdfName] nvarchar(180) NULL'
                [void]$command.ExecuteNonQuery()
                $command.CommandText = 'IF COL_LENGTH(''dbo.EQM_MRO_ServiceContract'',''PdfSize'') IS NULL ALTER TABLE [dbo].[EQM_MRO_ServiceContract] ADD [PdfSize] int NULL'
                [void]$command.ExecuteNonQuery()
                $command.CommandText = 'IF COL_LENGTH(''dbo.EQM_MRO_ServiceContract'',''PdfUploadedAt'') IS NULL ALTER TABLE [dbo].[EQM_MRO_ServiceContract] ADD [PdfUploadedAt] datetime NULL'
                [void]$command.ExecuteNonQuery()
                $command.CommandText = 'IF COL_LENGTH(''dbo.EQM_MRO_ServiceContract'',''PdfUploadedBy'') IS NULL ALTER TABLE [dbo].[EQM_MRO_ServiceContract] ADD [PdfUploadedBy] nvarchar(80) NULL'
                [void]$command.ExecuteNonQuery()
                # 2026-11-09: cot noi tro de tab Repair & Service doc/ghi truc tiep SQL (phuong an C).
                # Reject date/Reject reason/Buyer/IBM chua tung co tren Excel/SQLite migration; UpdatedAt/
                # UpdatedBy de phat hien sua dong thoi. Chi ADD, khong doi cot cu, khong DROP.
                foreach ($apsWriteTable in @('EQM_MRO_REPAIR','EQM_MRO_SERVICE')) {
                    foreach ($apsWriteColumn in @(@{ name = 'Reject date'; type = 'date NULL' }, @{ name = 'Reject reason'; type = 'nvarchar(1000) NULL' }, @{ name = 'Buyer'; type = 'nvarchar(100) NULL' }, @{ name = 'IBM'; type = 'nvarchar(100) NULL' }, @{ name = 'UpdatedAt'; type = 'datetime NULL' }, @{ name = 'UpdatedBy'; type = 'nvarchar(80) NULL' })) {
                        $command.CommandText = ('IF COL_LENGTH(''dbo.' + $apsWriteTable + ''',''' + $apsWriteColumn.name + ''') IS NULL ALTER TABLE [dbo].[' + $apsWriteTable + '] ADD [' + $apsWriteColumn.name + '] ' + $apsWriteColumn.type)
                        [void]$command.ExecuteNonQuery()
                    }
                }
                @{ok = $true; ensured = 'EQM_MRO_SERVICE.Request ID; EQM_MRO_ServiceContract.PdfData/PdfName/PdfSize/PdfUploadedAt/PdfUploadedBy; EQM_MRO_REPAIR + EQM_MRO_SERVICE Reject date/Reject reason/Buyer/IBM/UpdatedAt/UpdatedBy'} | ConvertTo-Json -Compress
            } elseif ($job.action -eq 'aps-migrate') {
                # INSERT-only migration for EQM_MRO_REPAIR / EQM_MRO_SERVICE. Column names validated against fixed per-table allowlists; values only ever bind as parameters.
                $apsRepairColumns = @('Request date','Vendor APS','Cost Center','Model / Project','BQMS code','Jig /Eqm Name','Current Status / Fault','Detail Request','Q''ty','Service code','Estimated cost','Final price','Currency','Final Price (USD)','Amount','Amount 2 (USD)','Vendor Repair','Payment Status','PO NO','Pic request','Month Payment','Year Payment','Local/Oversea','Service Type','Note of service','GL','Remark','Request ID','WRB request','Pur accept','Price confirm date')
                $apsServiceColumns = @('Request date','Vendor APS','Cost Center','Model / Project','Pic request','Current Status / Request','Q''ty','Estimated cost','Final price','Cur','Final Price (USD)','Amount','Amount 2 (USD)','Vendor Repair','Payment Status','Month Payment','Year Payment','Local/Oversea','Type','GL','Remark','Start date','End Date','Before approval','Contract','Contract signed','ContractNo','Request ID')
                $transaction = $connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction = $transaction
                    $apsInserted = 0; $apsSkipped = 0
                    foreach ($apsRow in @($job.rows)) {
                        $command.Parameters.Clear()
                        $apsTableName = [string]$apsRow.table
                        if ($apsTableName -eq 'EQM_MRO_REPAIR') { $apsAllowed = $apsRepairColumns } elseif ($apsTableName -eq 'EQM_MRO_SERVICE') { $apsAllowed = $apsServiceColumns } else { throw 'Unsupported table' }
                        $apsProps = @($apsRow.cols.PSObject.Properties.Name)
                        foreach ($apsBad in @($apsProps | Where-Object { $apsAllowed -notcontains $_ })) { throw ('Unsupported column ' + $apsBad) }
                        $apsCols = @(); $apsVals = @(); $apsIndex = 0
                        foreach ($apsName in $apsAllowed) {
                            if ($apsProps -contains $apsName) {
                                $apsCols += '[' + $apsName + ']'
                                $apsParamName = '@v' + $apsIndex; $apsIndex += 1
                                $apsParam = $command.Parameters.Add($apsParamName,[System.Data.SqlDbType]::NVarChar,4000)
                                $apsValue = $apsRow.cols.$apsName
                                if ($null -eq $apsValue) { $apsParam.Value = [DBNull]::Value } else { $apsParam.Value = [string]$apsValue }
                                $apsVals += $apsParamName
                            }
                        }
                        if ($apsCols.Count -eq 0) { throw 'Empty migration row' }
                        $apsGuard = @(); $apsGuardIndex = 0
                        foreach ($apsKey in @($apsRow.guard)) {
                            $apsKeyName = [string]$apsKey.name
                            if ($apsAllowed -notcontains $apsKeyName) { throw ('Unsupported guard column ' + $apsKeyName) }
                            $apsGuardParamName = '@g' + $apsGuardIndex; $apsGuardIndex += 1
                            $apsGuardParam = $command.Parameters.Add($apsGuardParamName,[System.Data.SqlDbType]::NVarChar,4000)
                            $apsGuardValue = $apsKey.value
                            if ($null -eq $apsGuardValue) { $apsGuardParam.Value = [DBNull]::Value } else { $apsGuardParam.Value = [string]$apsGuardValue }
                            $apsGuard += ('(([' + $apsKeyName + '] IS NULL AND ' + $apsGuardParamName + ' IS NULL) OR ([' + $apsKeyName + '] = ' + $apsGuardParamName + '))')
                        }
                        if ($apsGuard.Count -eq 0) { throw 'Migration row requires a guard' }
                        $command.CommandText = 'IF NOT EXISTS (SELECT 1 FROM [dbo].[' + $apsTableName + '] WHERE ' + ($apsGuard -join ' AND ') + ') INSERT INTO [dbo].[' + $apsTableName + '] (' + ($apsCols -join ',') + ') VALUES (' + ($apsVals -join ',') + ')'
                        if ($command.ExecuteNonQuery() -gt 0) { $apsInserted += 1 } else { $apsSkipped += 1 }
                    }
                    $transaction.Commit()
                    @{ok = $true; inserted = $apsInserted; skipped = $apsSkipped} | ConvertTo-Json -Compress
                } catch { $transaction.Rollback(); throw } finally { $transaction.Dispose() }
            } elseif ($job.action -in @('oh','oh-years','stock','transfers','orders','master-item','code-master','code-rfq','code-rfq-batch','tracking-pr','tracking-pr-number','tracking-pr-batch','notification-stock','hhp-codes','project-pr','project-reason-list','project-reason-lookup','latest-prices','cost-saving','download-data','report-form','gr-report','vendor-stock','vendor-overview')) {
                # 06/11/2026: trc day la "} else {" ngat giua chuoi if/elseif nen sau no la code chet:
                # aps-contracts / aps-contract-write / aps-contract-pdf / aps-plan-* / aps-oh-repair bi nan
                # vao nhanh doc chung nay (SELECT MRO_OH), khong INSERT => "Them hop dong" bao
                # "SQL khong hoan tat them hop dong" ma khong co ma SQL. Nay la nhanh liet ke tuong minh.
                $command.CommandText = 'SELECT TOP (5) [Year],[OH],[Jan],[Feb],[Mar],[Apr],[May],[Jun],[Jul],[Aug],[Sep],[Oct],[Nov],[Dec] FROM [dbo].[MRO_OH] WHERE LTRIM(RTRIM([Year])) = @year'
                if ($job.action -eq 'oh-years') { $command.CommandText = 'SELECT DISTINCT LTRIM(RTRIM([Year])) AS [Year] FROM [dbo].[MRO_OH]' }
                if ($job.action -eq 'stock') { $command.CommandText = 'SELECT * FROM [dbo].[EQM_MRO_Inventory]; SELECT * FROM [dbo].[EQM_MRO_MasterData]; SELECT * FROM [dbo].[Production]; SELECT * FROM [dbo].[EQM_MRO_UpdateHistory]; SELECT ''WRBG'' AS [location],CONVERT(varchar(10),[Date],23) AS [Date],[WRB Code],[Nhập],[Xuất] FROM [dbo].[EQM_MRO_InOut_WRBG]; SELECT [Vendor],[Purchase_Code],CONVERT(varchar(10),[Confirm_date],23) AS [Confirm_date],[Opening_QTY] FROM [dbo].[EQM_MRO_Inventory_vendor]; SELECT [Vendor] AS [location],CONVERT(varchar(10),[Date],23) AS [Date],[Purchase Code] AS [Item Code],[IN SEV] AS [InSEV],[OUT SX] AS [OutSX],[Transfer IN] AS [TransferIn],[Transfer OUT] AS [TransferOut] FROM [dbo].[EQM_MRO_InOut_Vendor]; SELECT [Model],[Atb1],[Atb2] FROM [dbo].[EQM_MRO_Model]' }
                if ($job.action -eq 'vendor-stock') { $command.CommandText = 'SELECT [Vendor],[Purchase_Code],CONVERT(varchar(10),[Confirm_date],23) AS [Confirm_date],[Opening_QTY] FROM [dbo].[EQM_MRO_Inventory_vendor]; SELECT * FROM [dbo].[EQM_MRO_MasterData]; SELECT * FROM [dbo].[Production]; SELECT [Vendor] AS [location],CONVERT(varchar(10),[Date],23) AS [Date],[Purchase Code] AS [Item Code],[IN SEV] AS [InSEV],[OUT SX] AS [OutSX],[Transfer IN] AS [TransferIn],[Transfer OUT] AS [TransferOut],[Loại Transfer] AS [TransferType],[Vendor khác] AS [OtherVendor],[Reference ID] AS [ReferenceId],[Note] AS [Note] FROM [dbo].[EQM_MRO_InOut_Vendor]; SELECT [TransferId],[FromVendor],[ToVendor],CONVERT(varchar(10),[TransferDate],23) AS [TransferDate],[VendorItemName],[PurchaseCode],[WRBCode],[Quantity],[TransferType],[ReferenceId],[Note],[RequestedBy],[Status] FROM [dbo].[EQM_MRO_VendorTransferConfirm] WHERE [Status]=N''Pending''; SELECT [Model],[Atb1],[Atb2] FROM [dbo].[EQM_MRO_Model]' }
                if ($job.action -eq 'vendor-overview') { $command.CommandText = 'SELECT [Vendor],[Purchase_Code],CONVERT(varchar(10),[Confirm_date],23) AS [Confirm_date],[Opening_QTY] FROM [dbo].[EQM_MRO_Inventory_vendor]; SELECT * FROM [dbo].[EQM_MRO_MasterData]; SELECT [Vendor],[Atb1],[Atb2],[Year],[Model],[W01],[W02],[W03],[W04],[W05],[W06],[W07],[W08],[W09],[W10],[W11],[W12],[W13],[W14],[W15],[W16],[W17],[W18],[W19],[W20],[W21],[W22],[W23],[W24],[W25],[W26],[W27],[W28],[W29],[W30],[W31],[W32],[W33],[W34],[W35],[W36],[W37],[W38],[W39],[W40],[W41],[W42],[W43],[W44],[W45],[W46],[W47],[W48],[W49],[W50],[W51],[W52],[W53],[W54] FROM [dbo].[Production]; SELECT [Vendor] AS [location],CONVERT(varchar(10),[Date],23) AS [Date],[Purchase Code] AS [Item Code],[IN SEV] AS [InSEV],[OUT SX] AS [OutSX],[Transfer IN] AS [TransferIn],[Transfer OUT] AS [TransferOut],[Loại Transfer] AS [TransferType],[Vendor khác] AS [OtherVendor],[Reference ID] AS [ReferenceId],[Note] AS [Note] FROM [dbo].[EQM_MRO_InOut_Vendor]; SELECT [TransferId],[FromVendor],[ToVendor],CONVERT(varchar(10),[TransferDate],23) AS [TransferDate],[VendorItemName],[PurchaseCode],[WRBCode],[Quantity],[TransferType],[ReferenceId],[Note],[RequestedBy],[Status] FROM [dbo].[EQM_MRO_VendorTransferConfirm] WHERE [Status]=N''Pending''; SELECT [Model],[Atb1],[Atb2] FROM [dbo].[EQM_MRO_Model]' }
                if ($job.action -eq 'master-item') { $command.CommandText='SELECT DISTINCT [WRB Code],[Item code],[Tên Tiếng Việt] FROM [dbo].[EQM_MRO_MasterData] WHERE LTRIM(RTRIM([Item code])) COLLATE Latin1_General_100_BIN2=@itemCode COLLATE Latin1_General_100_BIN2';[void]$command.Parameters.Add('@itemCode',[System.Data.SqlDbType]::NVarChar,100);$command.Parameters['@itemCode'].Value=[string]$job.itemCode }
                if ($job.action -eq 'notification-stock') { $command.CommandText='SELECT [Vendor],[Time],[Type] FROM [dbo].[EQM_MRO_UpdateHistory] WHERE [Type]=N''stock''' }
                if ($job.action -in @('project-pr','project-reason-lookup','tracking-pr','tracking-pr-number','tracking-pr-batch') -or $job.action -in @('report-form','gr-report') -or ($job.action -eq 'download-data' -and $job.kind -in @('PR','ALL'))) {
                    # Prefer the original PR database; use the configured database only when that exact table is not visible there.
                    $prTable = $null
                    $candidates = @('[WearableCheckSheet].[dbo].[EQM_MRO_PR]', ('[' + $connection.Database.Replace(']',']]') + '].[dbo].[EQM_MRO_PR]')) | Select-Object -Unique
                    foreach ($table in $candidates) {
                        $probe = $connection.CreateCommand()
                        try { $probe.CommandText = 'SELECT OBJECT_ID(@table, N''U'')'; [void]$probe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $probe.Parameters['@table'].Value=$table; if ($probe.ExecuteScalar() -isnot [DBNull]) { $prTable=$table; break } } catch [System.Data.SqlClient.SqlException] { if ($_.Exception.Number -notin @(229,916,911)) { throw } } finally { $probe.Dispose() }
                    }
                    if (-not $prTable) { throw [InvalidOperationException]::new('PR table unavailable') }
                    # 12/11/2026: Project Status và hàng chờ "PR cần bổ sung Lí do" cần Item Name của mọi dòng PR,
                    # kể cả mã ngoài phạm vi PIC3 (trước đây phải tra dataset Tracking trong phiên, hiện "—").
                    # EQM_MRO_PR không có cột ITEM_NAME — dò COL_LENGTH với chính xác tên bảng ba phần vừa chọn,
                    # ưu tiên ITEM_NAME rồi DESCRIPTION; không có cột nào thì SELECT bỏ hẳn cột (không bịa cột,
                    # không làm hỏng cả câu đọc của Project Status). Dùng -in @('project-pr') để dòng dò cột
                    # không lẫn vào dòng SELECT mà test đang khóa bằng chuỗi "-eq 'project-pr'".
                    $prNameSelect=''
                    if ($job.action -in @('project-pr')) {
                        $prNameColumn=$null
                        $nameProbe=$connection.CreateCommand()
                        try { $nameProbe.CommandText="SELECT CASE WHEN COL_LENGTH(@table,N'ITEM_NAME') IS NOT NULL THEN N'ITEM_NAME' WHEN COL_LENGTH(@table,N'DESCRIPTION') IS NOT NULL THEN N'DESCRIPTION' ELSE N'' END"; [void]$nameProbe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $nameProbe.Parameters['@table'].Value=$prTable; $found=[string]$nameProbe.ExecuteScalar(); if ($found -in @('ITEM_NAME','DESCRIPTION')) { $prNameColumn=$found } } catch { $prNameColumn=$null } finally { $nameProbe.Dispose() }
                        if ($prNameColumn) { $prNameSelect='ISNULL(['+$prNameColumn+'],N'''') AS [ITEM_NAME],' }
                    }
                }
                if ($job.action -eq 'latest-prices') {
                    # Shared unit price table EQM_MRO_UnitPrice (USD_PRICE), one row per item code.
                    $unitPriceTable = $null
                    $unitCandidates = @('[WearableCheckSheet].[dbo].[EQM_MRO_UnitPrice]', ('[' + $connection.Database.Replace(']',']]') + '].[dbo].[EQM_MRO_UnitPrice]')) | Select-Object -Unique
                    foreach ($table in $unitCandidates) {
                        $probe = $connection.CreateCommand()
                        try { $probe.CommandText = 'SELECT OBJECT_ID(@table, N''U'')'; [void]$probe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $probe.Parameters['@table'].Value=$table; if ($probe.ExecuteScalar() -isnot [DBNull]) { $unitPriceTable=$table; break } } catch [System.Data.SqlClient.SqlException] { if ($_.Exception.Number -notin @(229,916,911)) { throw } } finally { $probe.Dispose() }
                    }
                    if (-not $unitPriceTable) { throw [InvalidOperationException]::new('Unit price table unavailable') }
                    $command.CommandText='SELECT LTRIM(RTRIM([ITEM_CODE])) AS [ITEM_CODE],[USD_PRICE] FROM ' + $unitPriceTable + ' WHERE [ITEM_CODE] IS NOT NULL AND LTRIM(RTRIM([ITEM_CODE]))<>N'''''
                }
                if ($job.action -eq 'project-pr') { $command.CommandText='SELECT '+$prNameSelect+'[ITEM_CODE],[PURCHASE_REQ_INFO],[PR_CREATOR_NAME],[CATEGORY_NAME],[SPECIFICATION],[PR_QTY],[PO_QTY],[SHIPPING_QTY],[GR_QTY],[BUYING_PRICE],[BUYING_CURRENCY],[PR_NO],[PR_SEQ],[PO_NO],[PO_SEQ],[STATUS],[PR_STATUS],[PO_STATUS],CONVERT(varchar(10),[PO_DATE],23) AS [PO_DATE],CONVERT(varchar(10),[PR_DATE],23) AS [PR_DATE] FROM ' + $prTable + ' WHERE [PR_DATE]>=@from AND [PR_DATE]<@until ORDER BY [PR_DATE] DESC,[PR_NO],[PR_SEQ],[PO_NO],[PO_SEQ]';[void]$command.Parameters.Add('@from',[System.Data.SqlDbType]::Date);[void]$command.Parameters.Add('@until',[System.Data.SqlDbType]::Date);if ($job.from) { if ([string]$job.from -ne '2026-11-01') { throw 'Invalid PR start date' };$command.Parameters['@from'].Value=[datetime]::new(2026,11,1);$command.Parameters['@until'].Value=[datetime]::new(2101,1,1) } else { $command.Parameters['@from'].Value=[datetime]::new([int]$job.year,1,1);$command.Parameters['@until'].Value=[datetime]::new(([int]$job.year+1),1,1) } }
                if ($job.action -eq 'report-form') {
                    $reportYear=[int]$job.year
                    if ($reportYear -lt 2000 -or $reportYear -gt 2100) { throw 'Invalid report year' }
                    $glTable=$null
                    $glCandidates=@('[WearableCheckSheet].[dbo].[EQM_MRO_GL_Account]', ('[' + $connection.Database.Replace(']',']]') + '].[dbo].[EQM_MRO_GL_Account]')) | Select-Object -Unique
                    foreach ($table in $glCandidates) {
                        $probe=$connection.CreateCommand()
                        try { $probe.CommandText='SELECT OBJECT_ID(@table, N''U'')'; [void]$probe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $probe.Parameters['@table'].Value=$table; if ($probe.ExecuteScalar() -isnot [DBNull]) { $glTable=$table; break } } catch [System.Data.SqlClient.SqlException] { if ($_.Exception.Number -notin @(229,916,911)) { throw } } finally { $probe.Dispose() }
                    }
                    if (-not $glTable) { throw [InvalidOperationException]::new('GL Account table unavailable') }
                    # 12/11/2026 (người dùng chốt): bản sửa Lí do trong dbo.EQM_MRO_PR_ReasonOverride (PIC nhập ở
                    # màn PR & Tracking) THẮNG TUYỆT ĐỐI so với PURCHASE_REQ_INFO của ERP. Bảng do Portal tạo nên
                    # chưa chắc đã có trên mọi máy -> dò kiểu $glTable nhưng KHÔNG fatal: thiếu bảng thì Report
                    # Form tiếp tục dùng chuỗi ERP. Không JOIN thẳng vì $prTable có thể là tên 4 phần (linked
                    # server); lấy riêng một result set rồi ghép theo ITEM_CODE+PR_NO+PR_SEQ trong reportForm(),
                    # đúng cách bảng GL Account vẫn được ghép.
                    $reasonTable=$null
                    $reasonCandidates=@('[dbo].[EQM_MRO_PR_ReasonOverride]', ('[' + $connection.Database.Replace(']',']]') + '].[dbo].[EQM_MRO_PR_ReasonOverride]')) | Select-Object -Unique
                    foreach ($table in $reasonCandidates) {
                        $probe=$connection.CreateCommand()
                        try { $probe.CommandText='SELECT OBJECT_ID(@table, N''U'')'; [void]$probe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $probe.Parameters['@table'].Value=$table; if ($probe.ExecuteScalar() -isnot [DBNull]) { $reasonTable=$table; break } } catch [System.Data.SqlClient.SqlException] { if ($_.Exception.Number -notin @(229,916,911)) { throw } } finally { $probe.Dispose() }
                    }
                    # Receiver của PR Detail lấy đúng EQM_MRO_PR.RECEIVER_NAME (cùng nguồn CHECK PR),
                    # không suy từ creator/ID. PO_NO giữ nguyên trên từng dòng PR; Node chỉ gom các PO
                    # của cùng ITEM_CODE+PR_NO+PR_SEQ để popup không nhân bản một PR line.
                    $command.CommandText='SELECT [RECEIVER_NAME],[PR_NO],[COST_CENTER],[PO_NO],[ITEM_CODE],[PR_SEQ],[GL_ACCOUNT],[PURCHASE_REQ_INFO],[PR_Month],[PR_BUYING_AMOUNT],[BUYING_CURRENCY] FROM ' + $prTable + ' WHERE [PR_DATE]>=@from AND [PR_DATE]<@until ORDER BY [PR_DATE],[PR_NO],[PR_SEQ],[PO_NO]; SELECT [GL_Account],[GL_Class] FROM ' + $glTable
                    if ($reasonTable) { $command.CommandText += '; SELECT LTRIM(RTRIM([ITEM_CODE])) AS [ITEM_CODE],LTRIM(RTRIM([PR_NO])) AS [PR_NO],LTRIM(RTRIM([PR_SEQ])) AS [PR_SEQ],[PURCHASE_REQ_INFO_OVERRIDE],[IS_IGNORED] FROM ' + $reasonTable }
                    [void]$command.Parameters.Add('@from',[System.Data.SqlDbType]::Date); [void]$command.Parameters.Add('@until',[System.Data.SqlDbType]::Date)
                    $command.Parameters['@from'].Value=[datetime]::new($reportYear,1,1)
                    $command.Parameters['@until'].Value=[datetime]::new($reportYear+1,1,1)
                }
                if ($job.action -eq 'gr-report') {
                    $reportYear=[int]$job.year
                    if ($reportYear -lt 2000 -or $reportYear -gt 2100) { throw 'Invalid GR report year' }

                    # Xác minh đúng schema GMRO đang chạy trước khi SELECT. Không giả định cột bổ sung,
                    # không DDL và không fallback dữ liệu mẫu khi bảng/cột thật chưa sẵn sàng.
                    $gmroRequired=@('GR_NO','GR_DATE','PO_NO','PO_SEQ','ITEM_CODE','ITEM_NAME','GR_QTY','GR_AMOUNT','CURRENCY','COST_CENTER_CODE')
                    $gmroProbe=$connection.CreateCommand()
                    try {
                        $gmroProbe.CommandText="SELECT [COLUMN_NAME] FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=N'dbo' AND TABLE_NAME=N'EQM_MRO_GMRO'"
                        $gmroFound=@();$gmroReader=$gmroProbe.ExecuteReader()
                        try { while($gmroReader.Read()){ $gmroFound += [string]$gmroReader.GetValue(0) } } finally { $gmroReader.Dispose() }
                    } finally { $gmroProbe.Dispose() }
                    foreach($required in $gmroRequired){if($required -notin $gmroFound){throw [InvalidOperationException]::new('GR Report missing dbo.EQM_MRO_GMRO.'+$required)}}

                    $glTable=$null
                    $glCandidates=@('[WearableCheckSheet].[dbo].[EQM_MRO_GL_Account]', ('[' + $connection.Database.Replace(']',']]') + '].[dbo].[EQM_MRO_GL_Account]')) | Select-Object -Unique
                    foreach ($table in $glCandidates) {
                        $probe=$connection.CreateCommand()
                        try { $probe.CommandText='SELECT OBJECT_ID(@table, N''U'')'; [void]$probe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $probe.Parameters['@table'].Value=$table; if ($probe.ExecuteScalar() -isnot [DBNull]) { $glTable=$table; break } } catch [System.Data.SqlClient.SqlException] { if ($_.Exception.Number -notin @(229,916,911)) { throw } } finally { $probe.Dispose() }
                    }
                    if (-not $glTable) { throw [InvalidOperationException]::new('GL Account table unavailable') }

                    $reasonTable=$null
                    $reasonCandidates=@('[dbo].[EQM_MRO_PR_ReasonOverride]', ('[' + $connection.Database.Replace(']',']]') + '].[dbo].[EQM_MRO_PR_ReasonOverride]')) | Select-Object -Unique
                    foreach ($table in $reasonCandidates) {
                        $probe=$connection.CreateCommand()
                        try { $probe.CommandText='SELECT OBJECT_ID(@table, N''U'')'; [void]$probe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $probe.Parameters['@table'].Value=$table; if ($probe.ExecuteScalar() -isnot [DBNull]) { $reasonTable=$table; break } } catch [System.Data.SqlClient.SqlException] { if ($_.Exception.Number -notin @(229,916,911)) { throw } } finally { $probe.Dispose() }
                    }

                    # Bốn result set tách biệt. PR chỉ được thu hẹp bằng EXISTS PO_NO+ITEM_CODE của GR
                    # trong năm; PO_SEQ được phân giải chính xác/loose ở Node để không JOIN nhiều-nhiều.
                    $command.CommandText='SELECT [GR_NO],CONVERT(varchar(10),[GR_DATE],23) AS [GR_DATE],[PO_NO],[PO_SEQ],[ITEM_CODE],[ITEM_NAME],[GR_QTY],[GR_AMOUNT],[CURRENCY],[COST_CENTER_CODE] FROM [dbo].[EQM_MRO_GMRO] WHERE [GR_DATE]>=@from AND [GR_DATE]<@until AND COALESCE(LTRIM(RTRIM([COST_CENTER_CODE])),N'''')<>N''C5H0Z861'' ORDER BY [GR_DATE],[GR_NO],[PO_NO],[PO_SEQ],[ITEM_CODE]; SELECT [PR_NO],[PR_SEQ],[PO_NO],[PO_SEQ],[ITEM_CODE],[GL_ACCOUNT],[PURCHASE_REQ_INFO],[RECEIVER_NAME] FROM ' + $prTable + ' AS [p] WHERE EXISTS (SELECT 1 FROM [dbo].[EQM_MRO_GMRO] AS [g] WHERE [g].[GR_DATE]>=@from AND [g].[GR_DATE]<@until AND COALESCE(LTRIM(RTRIM([g].[COST_CENTER_CODE])),N'''')<>N''C5H0Z861'' AND UPPER(LTRIM(RTRIM(CONVERT(nvarchar(100),[g].[PO_NO]))))=UPPER(LTRIM(RTRIM(CONVERT(nvarchar(100),[p].[PO_NO])))) AND UPPER(LTRIM(RTRIM(CONVERT(nvarchar(100),[g].[ITEM_CODE]))))=UPPER(LTRIM(RTRIM(CONVERT(nvarchar(100),[p].[ITEM_CODE]))))); SELECT [GL_Account],[GL_Class] FROM ' + $glTable
                    if ($reasonTable) { $command.CommandText += '; SELECT LTRIM(RTRIM([ITEM_CODE])) AS [ITEM_CODE],LTRIM(RTRIM([PR_NO])) AS [PR_NO],LTRIM(RTRIM([PR_SEQ])) AS [PR_SEQ],[PURCHASE_REQ_INFO_OVERRIDE],[IS_IGNORED] FROM ' + $reasonTable }
                    [void]$command.Parameters.Add('@from',[System.Data.SqlDbType]::Date); [void]$command.Parameters.Add('@until',[System.Data.SqlDbType]::Date)
                    $command.Parameters['@from'].Value=[datetime]::new($reportYear,1,1)
                    $command.Parameters['@until'].Value=[datetime]::new($reportYear+1,1,1)
                }
                if ($job.action -eq 'project-reason-list') { $command.CommandText='SELECT [ITEM_CODE],[PR_NO],[PR_SEQ],[PURCHASE_REQ_INFO_OVERRIDE],[IS_IGNORED],[NOTE],[UPDATED_BY],CONVERT(varchar(33),[UPDATED_AT],127) AS [UPDATED_AT],CONVERT(varchar(16),[ROW_VERSION],2) AS [REVISION] FROM [dbo].[EQM_MRO_PR_ReasonOverride]' }
                if ($job.action -eq 'project-reason-lookup') {
                    $prNos=@($job.prNos | ForEach-Object {[string]$_} | Where-Object { $_.Length -gt 0 -and $_.Length -le 50 } | Select-Object -Unique)
                    if($prNos.Count -lt 1 -or $prNos.Count -gt 500){throw 'Invalid project reason lookup'}
                    $names=@();for($i=0;$i -lt $prNos.Count;$i++){$name='@bulkPr'+$i;$names+=$name;[void]$command.Parameters.Add($name,[System.Data.SqlDbType]::NVarChar,50);$command.Parameters[$name].Value=$prNos[$i]}
                    $command.CommandText='SELECT [ITEM_CODE],[PR_NO],[PR_SEQ],[PURCHASE_REQ_INFO] FROM '+$prTable+' WHERE LTRIM(RTRIM([PR_NO])) COLLATE Latin1_General_100_BIN2 IN ('+($names -join ',')+') ORDER BY [PR_NO],[PR_SEQ],[ITEM_CODE]'
                }
                if ($job.action -in @('tracking-pr','tracking-pr-number')) {
                    $predicate = 'LTRIM(RTRIM([ITEM_CODE])) COLLATE Latin1_General_100_BIN2=@code COLLATE Latin1_General_100_BIN2'
                    if ($job.action -eq 'tracking-pr-number') { $predicate='LTRIM(RTRIM([PR_NO])) COLLATE Latin1_General_100_BIN2=@pr COLLATE Latin1_General_100_BIN2'; [void]$command.Parameters.Add('@pr',[System.Data.SqlDbType]::NVarChar,50); $command.Parameters['@pr'].Value=[string]$job.pr }
                    else { [void]$command.Parameters.Add('@code',[System.Data.SqlDbType]::NVarChar,50); $command.Parameters['@code'].Value=[string]$job.code }
                    $command.CommandText='SELECT [ITEM_CODE],[PURCHASE_REQ_INFO],[PR_SEQ],[PR_CREATOR_NAME],[COST_CENTER],[PR_NO],[PO_NO],[PO_SEQ],[PR_QTY],[STATUS],[PR_STATUS],[PO_STATUS],CONVERT(varchar(10),[PR_DATE],23) AS [PR_DATE],[PO_QTY],CONVERT(varchar(10),[PO_DATE],23) AS [PO_DATE],[SHIPPING_QTY],[GR_QTY] FROM ' + $prTable + ' WHERE ' + $predicate + ' ORDER BY [PR_DATE] DESC,[PR_NO],[PR_SEQ],[PO_NO],[PO_SEQ]'
                }
                if ($job.action -eq 'tracking-pr-batch') { $codes=@($job.codes | ForEach-Object {[string]$_} | Where-Object { $_.Length -gt 0 -and $_.Length -le 50 } | Select-Object -Unique); if($codes.Count -lt 1 -or $codes.Count -gt 200){throw 'Invalid PR batch'}; $names=@(); for($i=0;$i -lt $codes.Count;$i++){ $name='@code'+$i; $names+=$name; [void]$command.Parameters.Add($name,[System.Data.SqlDbType]::NVarChar,50);$command.Parameters[$name].Value=$codes[$i] }; $command.CommandText='SELECT [ITEM_CODE],[PURCHASE_REQ_INFO],[PR_SEQ],[PR_CREATOR_NAME],[COST_CENTER],[PR_NO],[PO_NO],[PO_SEQ],[PR_QTY],[STATUS],[PR_STATUS],[PO_STATUS],CONVERT(varchar(10),[PR_DATE],23) AS [PR_DATE],[PO_QTY],CONVERT(varchar(10),[PO_DATE],23) AS [PO_DATE],[SHIPPING_QTY],[GR_QTY] FROM ' + $prTable + ' WHERE LTRIM(RTRIM([ITEM_CODE])) COLLATE Latin1_General_100_BIN2 IN ('+($names -join ',')+') ORDER BY [ITEM_CODE],[PR_DATE] DESC,[PR_NO],[PR_SEQ],[PO_NO],[PO_SEQ]' }
                if ($job.action -eq 'code-master') { $command.CommandText='SELECT [Item code],[Type (MRO/Spare)] FROM [dbo].[EQM_MRO_MasterData]' }
                if ($job.action -eq 'code-rfq') { $command.CommandText='SELECT [ITEM_CODE],[QT_REQ_NO],[QT_REQ_SEQ],[RFQ_REQ_SUB_NO],[RFQ_STATUS_NAME],CONVERT(varchar(10),[REQUEST_DATE],23) AS [REQUEST_DATE],CONVERT(varchar(10),[RECEIPT_DATE],23) AS [RECEIPT_DATE],[CONTRACT_NAME] FROM [dbo].[EQM_MRO_RFQ] WHERE LTRIM(RTRIM([ITEM_CODE])) COLLATE Latin1_General_100_BIN2=@code COLLATE Latin1_General_100_BIN2 ORDER BY [REQUEST_DATE] DESC,[RECEIPT_DATE] DESC,[QT_REQ_NO],[QT_REQ_SEQ]';[void]$command.Parameters.Add('@code',[System.Data.SqlDbType]::NVarChar,50);$command.Parameters['@code'].Value=[string]$job.code }
                if ($job.action -eq 'code-rfq-batch') { $codes=@($job.codes | ForEach-Object {[string]$_} | Where-Object { $_.Length -gt 0 } | Select-Object -Unique); if($codes.Count -lt 1 -or $codes.Count -gt 200){throw 'Invalid RFQ batch'}; $names=@(); for($i=0;$i -lt $codes.Count;$i++){ $name='@code'+$i; $names+=$name; [void]$command.Parameters.Add($name,[System.Data.SqlDbType]::NVarChar,50);$command.Parameters[$name].Value=$codes[$i] }; $command.CommandText='SELECT [ITEM_CODE],[QT_REQ_NO],[QT_REQ_SEQ],[RFQ_REQ_SUB_NO],[RFQ_STATUS_NAME],CONVERT(varchar(10),[REQUEST_DATE],23) AS [REQUEST_DATE],CONVERT(varchar(10),[RECEIPT_DATE],23) AS [RECEIPT_DATE],[CONTRACT_NAME] FROM [dbo].[EQM_MRO_RFQ] WHERE LTRIM(RTRIM([ITEM_CODE])) COLLATE Latin1_General_100_BIN2 IN ('+($names -join ',')+') ORDER BY [ITEM_CODE],[REQUEST_DATE] DESC,[RECEIPT_DATE] DESC,[QT_REQ_NO],[QT_REQ_SEQ]' }
                if ($job.action -eq 'orders') { $command.CommandText = 'SELECT *, CONVERT(varchar(10),[Date],23) AS [__orderDate],CONVERT(varchar(16),[Time]) AS [__orderTime] FROM [dbo].[EQM_MRO_RequestOrder] ORDER BY [Date] DESC,[Time] DESC' }
                if ($job.action -eq 'transfers') { $command.CommandText = 'SELECT *, CONVERT(varchar(10),[Date],23) AS [__transferDate] FROM [dbo].[EQM_MRO_TranferVendor] ORDER BY [Date] DESC,[No] DESC' }
                if ($job.action -eq 'cost-saving') { $command.CommandText = 'SELECT * FROM [dbo].[EQM_CostSavingActivity]' }
                if ($job.action -eq 'hhp-codes') {
                    # 06/11/2026: doc danh sach ma HHP (cot BQMS Code) phuc vu canh bao "Confirm for order" man PR & PR Tracking.
                    # Chi SELECT, khong nhan tham so tu caller; tim bang theo cung pattern EQM_MRO_PR (WearableCheckSheet truoc, database cau hinh sau).
                    $hhpTable = $null
                    $hhpCandidates = @('[WearableCheckSheet].[dbo].[EQM_MRO_HhpOrderCode]', ('[' + $connection.Database.Replace(']',']]') + '].[dbo].[EQM_MRO_HhpOrderCode]')) | Select-Object -Unique
                    foreach ($table in $hhpCandidates) {
                        $probe = $connection.CreateCommand()
                        try { $probe.CommandText = 'SELECT OBJECT_ID(@table, N''U'')'; [void]$probe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $probe.Parameters['@table'].Value=$table; if ($probe.ExecuteScalar() -isnot [DBNull]) { $hhpTable=$table; break } } catch [System.Data.SqlClient.SqlException] { if ($_.Exception.Number -notin @(229,916,911)) { throw } } finally { $probe.Dispose() }
                    }
                    if (-not $hhpTable) { throw [InvalidOperationException]::new('HHP order code table unavailable') }
                    # Cot luu ma co the ten "BQMS Code" (co khoang trang) hoac BQMS_CODE; chi chap nhan dung hai ten da kiem.
                    $hhpProbe = $connection.CreateCommand()
                    $hhpProbe.CommandText = 'SELECT TOP (1) [c].[name] FROM sys.columns AS [c] WHERE [c].[object_id] = OBJECT_ID(@table) AND UPPER(REPLACE([c].[name],N'' '',N'''')) IN (N''BQMSCODE'',N''BQMS_CODE'')'
                    [void]$hhpProbe.Parameters.Add('@table',[System.Data.SqlDbType]::NVarChar,776); $hhpProbe.Parameters['@table'].Value=$hhpTable
                    $hhpColumn = $hhpProbe.ExecuteScalar(); $hhpProbe.Dispose()
                    if ($null -eq $hhpColumn -or $hhpColumn -is [DBNull]) { throw [InvalidOperationException]::new('BQMS Code column unavailable in EQM_MRO_HhpOrderCode') }
                    $hhpQuoted = '[' + ([string]$hhpColumn).Replace(']',']]') + ']'
                    $command.CommandText = 'SELECT DISTINCT LTRIM(RTRIM(' + $hhpQuoted + ')) AS [BQMS_CODE] FROM ' + $hhpTable + ' WHERE ' + $hhpQuoted + ' IS NOT NULL AND LTRIM(RTRIM(' + $hhpQuoted + '))<>N'''''
                }
                if ($job.action -eq 'download-data') {
                    if ($job.kind -notin @('PR','RFQ','GMRO','ALL')) { throw 'Unsupported export' }
                    $downloadNames = @(if ($job.kind -eq 'ALL') { 'PR';'RFQ';'GMRO' } else { [string]$job.kind })
                    $tables = @{PR=$prTable;RFQ='[dbo].[EQM_MRO_RFQ]';GMRO="[dbo].[EQM_MRO_GMRO] WHERE COALESCE(LTRIM(RTRIM([COST_CENTER_CODE])),N'')<>N'C5H0Z861'"}
                    $command.CommandText = ($downloadNames | ForEach-Object { 'SELECT * FROM ' + $tables[$_] }) -join ';'
                }
                $parameter = $command.Parameters.Add('@year',[System.Data.SqlDbType]::NVarChar,4)
                $parameter.Value = [string]$job.year
                $reader = $command.ExecuteReader()
                try {
                    $sets = @(); $schemas = @()
                    do {
                    $rows = @(); if ($job.action -eq 'download-data') { $rows = New-Object 'System.Collections.Generic.List[object]' }; $columns = @(); for ($i=0; $i -lt $reader.FieldCount; $i++) { $columns += @{name=$reader.GetName($i);type=$reader.GetDataTypeName($i)} }; $schemas += ,@($columns)
                    while ($reader.Read()) {
                        $row = @{}
                        for ($i=0; $i -lt $reader.FieldCount; $i++) {
                            $row[$reader.GetName($i)] = if ($reader.IsDBNull($i)) {$null} else {[System.Convert]::ToString($reader.GetValue($i),[System.Globalization.CultureInfo]::InvariantCulture)}
                        }
                        if ($job.action -eq 'download-data') { [void]$rows.Add($row) } else { $rows += $row }
                    }
                    if ($job.action -eq 'download-data') { $rows = @($rows.ToArray()) }; $sets += ,@($rows)
                    } while ($reader.NextResult())
                    if ($job.action -eq 'download-data') { $sheets=@();for($i=0;$i -lt $downloadNames.Count;$i++){ $sheets+=@{name=$downloadNames[$i];columns=@($schemas[$i]);rows=@($sets[$i])} }; @{ok=$true;sheets=@($sheets)} | ConvertTo-Json -Depth 8 -Compress }
                    elseif ($job.action -eq 'stock') { @{ok=$true;inventory=@($sets[0]);master=@($sets[1]);production=@($sets[2]);history=@($sets[3]);inout=@($sets[4]);vendorInventory=@($sets[5]);vendorInout=@($sets[6]);modelMapping=@($sets[7])} | ConvertTo-Json -Depth 8 -Compress }
                    elseif ($job.action -eq 'vendor-stock') { @{ok=$true;vendorInventory=@($sets[0]);master=@($sets[1]);production=@($sets[2]);inout=@($sets[3]);transfers=@($sets[4]);modelMapping=@($sets[5])} | ConvertTo-Json -Depth 8 -Compress }
                    elseif ($job.action -eq 'vendor-overview') { @{ok=$true;vendorInventory=@($sets[0]);master=@($sets[1]);plan=@($sets[2]);inout=@($sets[3]);transfers=@($sets[4]);modelMapping=@($sets[5])} | ConvertTo-Json -Depth 8 -Compress }
                    elseif ($job.action -eq 'report-form') { $reasonRows=@(); if ($sets.Count -gt 2) { $reasonRows=@($sets[2]) }; @{ok=$true;pr=@($sets[0]);gl=@($sets[1]);reason=$reasonRows} | ConvertTo-Json -Depth 6 -Compress }
                    elseif ($job.action -eq 'gr-report') { $reasonRows=@(); if ($sets.Count -gt 3) { $reasonRows=@($sets[3]) }; @{ok=$true;gr=@($sets[0]);pr=@($sets[1]);gl=@($sets[2]);reason=$reasonRows} | ConvertTo-Json -Depth 7 -Compress }
                    else { @{ok=$true;rows=@($rows)} | ConvertTo-Json -Depth 5 -Compress }
                } finally { $reader.Dispose() }
            } elseif ($job.action -eq 'aps-contracts') {
                # Read-only list of EQM_MRO_ServiceContract. Fixed columns; no caller input reaches SQL text.
                # PDF metadata columns are selected only when the additive DDL has run; [PdfData] bytes are NEVER selected here.
                $pdfMetaColumns = @()
                # 06/11/2026: dò cột qua INFORMATION_SCHEMA.COLUMNS — nguồn đã chứng minh thấy đủ cột Pdf*
                # trên máy chủ (báo cáo aps:schema-report), trong khi sys.columns+OBJECT_ID từng trả thiếu
                # khiến pdfColumns=false dù cột thật đã tồn tại.
                $command.CommandText = "SELECT [COLUMN_NAME] FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = N'dbo' AND TABLE_NAME = N'EQM_MRO_ServiceContract' AND [COLUMN_NAME] IN (N'PdfName',N'PdfSize',N'PdfUploadedAt',N'PdfUploadedBy')"
                $metaReader = $command.ExecuteReader()
                try { while ($metaReader.Read()) { $pdfMetaColumns += [string]$metaReader.GetValue(0) } } finally { $metaReader.Dispose() }
                $hasPdfMeta = $pdfMetaColumns.Count -eq 4
                $contractSelect = if ($hasPdfMeta) {
                    'SELECT [No], [ContractNo], [Vendor], CONVERT(varchar(10), [EffectiveDate], 23) AS [EffectiveDate], CONVERT(varchar(10), [ExpiryDate], 23) AS [ExpiryDate], CONVERT(varchar(19), [CreatedAt], 120) AS [CreatedAt], [CreatedBy], CONVERT(varchar(19), [UpdatedAt], 120) AS [UpdatedAt], [PdfName], [PdfSize], CONVERT(varchar(19), [PdfUploadedAt], 120) AS [PdfUploadedAt], [PdfUploadedBy] FROM [dbo].[EQM_MRO_ServiceContract] ORDER BY [No]'
                } else {
                    'SELECT [No], [ContractNo], [Vendor], CONVERT(varchar(10), [EffectiveDate], 23) AS [EffectiveDate], CONVERT(varchar(10), [ExpiryDate], 23) AS [ExpiryDate], CONVERT(varchar(19), [CreatedAt], 120) AS [CreatedAt], [CreatedBy], CONVERT(varchar(19), [UpdatedAt], 120) AS [UpdatedAt] FROM [dbo].[EQM_MRO_ServiceContract] ORDER BY [No]'
                }
                $command.CommandText = $contractSelect
                $reader = $command.ExecuteReader(); $rows = @()
                try {
                    while ($reader.Read()) {
                        $r = @{}
                        for ($i=0;$i -lt $reader.FieldCount;$i++) { $r[$reader.GetName($i)] = if ($reader.IsDBNull($i)) { $null } else { [System.Convert]::ToString($reader.GetValue($i)) } }
                        $rows += $r
                    }
                } finally { $reader.Dispose() }
                @{ok=$true;rows=@($rows);pdfColumns=$hasPdfMeta} | ConvertTo-Json -Depth 5 -Compress
            } elseif ($job.action -eq 'aps-contract-write') {
                # Contract panel write: SELECT-before-INSERT duplicate check on ContractNo, or targeted UPDATE by [No].
                # Only EQM_MRO_ServiceContract is touched; INSERT/UPDATE only, never DELETE. CreatedBy comes from the portal session.
                $transaction = $connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction = $transaction
                    $command.Parameters.Clear()
                    if ($job.op -eq 'insert') {
                        [void]$command.Parameters.Add('@cno',[System.Data.SqlDbType]::NVarChar,100); $command.Parameters['@cno'].Value = [string]$job.contractNo
                        $command.CommandText = 'SELECT [No] FROM [dbo].[EQM_MRO_ServiceContract] WITH (UPDLOCK) WHERE [ContractNo] = @cno'
                        $existing = $command.ExecuteScalar()
                        if ($null -ne $existing) {
                            $transaction.Rollback()
                            @{ok=$true;duplicate=$true} | ConvertTo-Json -Compress
                        } else {
                            [void]$command.Parameters.Add('@vendor',[System.Data.SqlDbType]::NVarChar,200); $command.Parameters['@vendor'].Value = [string]$job.vendor
                            [void]$command.Parameters.Add('@eff',[System.Data.SqlDbType]::Date); $command.Parameters['@eff'].Value = $(if ([string]::IsNullOrWhiteSpace([string]$job.effectiveDate)) { [DBNull]::Value } else { [string]$job.effectiveDate })
                            [void]$command.Parameters.Add('@exp',[System.Data.SqlDbType]::Date); $command.Parameters['@exp'].Value = $(if ([string]::IsNullOrWhiteSpace([string]$job.expiryDate)) { [DBNull]::Value } else { [string]$job.expiryDate })
                            [void]$command.Parameters.Add('@user',[System.Data.SqlDbType]::NVarChar,80); $command.Parameters['@user'].Value = [string]$job.actor
                            $command.CommandText = 'INSERT INTO [dbo].[EQM_MRO_ServiceContract] ([ContractNo],[Vendor],[EffectiveDate],[ExpiryDate],[CreatedAt],[CreatedBy]) VALUES (@cno,@vendor,@eff,@exp,GETDATE(),@user); SELECT CAST(SCOPE_IDENTITY() AS int)'
                            $no = [int]$command.ExecuteScalar()
                            $transaction.Commit()
                            @{ok=$true;duplicate=$false;no=$no} | ConvertTo-Json -Compress
                        }
                    } elseif ($job.op -eq 'update') {
                        [void]$command.Parameters.Add('@no',[System.Data.SqlDbType]::Int); $command.Parameters['@no'].Value = [int]$job.no
                        [void]$command.Parameters.Add('@vendor',[System.Data.SqlDbType]::NVarChar,200); $command.Parameters['@vendor'].Value = [string]$job.vendor
                        [void]$command.Parameters.Add('@eff',[System.Data.SqlDbType]::Date); $command.Parameters['@eff'].Value = $(if ([string]::IsNullOrWhiteSpace([string]$job.effectiveDate)) { [DBNull]::Value } else { [string]$job.effectiveDate })
                        [void]$command.Parameters.Add('@exp',[System.Data.SqlDbType]::Date); $command.Parameters['@exp'].Value = $(if ([string]::IsNullOrWhiteSpace([string]$job.expiryDate)) { [DBNull]::Value } else { [string]$job.expiryDate })
                        $command.CommandText = 'UPDATE [dbo].[EQM_MRO_ServiceContract] SET [Vendor] = @vendor, [EffectiveDate] = @eff, [ExpiryDate] = @exp, [UpdatedAt] = GETDATE() WHERE [No] = @no; SELECT @@ROWCOUNT'
                        # 06/11/2026: nhánh này từng chỉ gán CommandText rồi rơi ra ngoài if/elseif,
                        # không ExecuteScalar/Commit/in JSON nên "Sửa hợp đồng" im lặng và Node không nhận được kết quả.
                        $updated = [int]$command.ExecuteScalar()
                        $transaction.Commit()
                        @{ok=$true;duplicate=$false;updated=$updated} | ConvertTo-Json -Compress
                    } elseif ($job.op -eq 'pdf') {
                        # Replace the single PDF of one contract. UPDATE-only on the same table; bytes arrive base64 and bind as one VarBinary parameter.
                        [void]$command.Parameters.Add('@cno',[System.Data.SqlDbType]::NVarChar,100); $command.Parameters['@cno'].Value = [string]$job.contractNo
                        $command.CommandText = 'SELECT [No] FROM [dbo].[EQM_MRO_ServiceContract] WITH (UPDLOCK) WHERE [ContractNo] = @cno'
                        $target = $command.ExecuteScalar()
                        if ($null -eq $target) {
                            $transaction.Rollback()
                            @{ok=$true;missing=$true} | ConvertTo-Json -Compress
                        } else {
                            $command.Parameters.Clear()
                            [void]$command.Parameters.Add('@cno',[System.Data.SqlDbType]::NVarChar,100); $command.Parameters['@cno'].Value = [string]$job.contractNo
                            [void]$command.Parameters.Add('@pdf',[System.Data.SqlDbType]::VarBinary,-1); $command.Parameters['@pdf'].Value = [Convert]::FromBase64String([string]$job.data)
                            [void]$command.Parameters.Add('@name',[System.Data.SqlDbType]::NVarChar,180); $command.Parameters['@name'].Value = [string]$job.name
                            [void]$command.Parameters.Add('@user',[System.Data.SqlDbType]::NVarChar,80); $command.Parameters['@user'].Value = [string]$job.actor
                            $command.CommandText = 'UPDATE [dbo].[EQM_MRO_ServiceContract] SET [PdfData] = @pdf, [PdfName] = @name, [PdfSize] = DATALENGTH(@pdf), [PdfUploadedAt] = GETDATE(), [PdfUploadedBy] = @user WHERE [ContractNo] = @cno; SELECT @@ROWCOUNT'
                            $updated = [int]$command.ExecuteScalar()
                            $transaction.Commit()
                            @{ok=$true;updated=$updated} | ConvertTo-Json -Compress
                        }
                    } elseif ($job.op -eq 'pdf-clear') {
                        # Clear the PDF columns only — the contract row itself is never deleted.
                        [void]$command.Parameters.Add('@cno',[System.Data.SqlDbType]::NVarChar,100); $command.Parameters['@cno'].Value = [string]$job.contractNo
                        $command.CommandText = 'UPDATE [dbo].[EQM_MRO_ServiceContract] SET [PdfData] = NULL, [PdfName] = NULL, [PdfSize] = NULL, [PdfUploadedAt] = NULL, [PdfUploadedBy] = NULL WHERE [ContractNo] = @cno; SELECT @@ROWCOUNT'
                        $updated = [int]$command.ExecuteScalar()
                        $transaction.Commit()
                        @{ok=$true;updated=$updated} | ConvertTo-Json -Compress
                    } else { throw 'Unsupported contract op' }
                } catch { if ($transaction.Connection) { $transaction.Rollback() }; throw } finally { $transaction.Dispose() }
            } elseif ($job.action -eq 'aps-contract-pdf') {
                # Read one contract PDF as base64 for the panel download. SELECT-only; only the contract number comes from the caller.
                $pdfDataColumn = @()
                $command.CommandText = "SELECT [COLUMN_NAME] FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = N'dbo' AND TABLE_NAME = N'EQM_MRO_ServiceContract' AND [COLUMN_NAME] = N'PdfData'"
                $schemaReader = $command.ExecuteReader()
                try { while ($schemaReader.Read()) { $pdfDataColumn += [string]$schemaReader.GetValue(0) } } finally { $schemaReader.Dispose() }
                if ($pdfDataColumn.Count -eq 0) {
                    @{ok=$true;noSchema=$true;row=$null} | ConvertTo-Json -Depth 4 -Compress
                } else {
                    $command.Parameters.Clear()
                    [void]$command.Parameters.Add('@cno',[System.Data.SqlDbType]::NVarChar,100); $command.Parameters['@cno'].Value = [string]$job.contractNo
                    $command.CommandText = 'SELECT [PdfName], DATALENGTH([PdfData]) AS [PdfSize], CONVERT(varchar(19), [PdfUploadedAt], 120) AS [PdfUploadedAt], [PdfData] FROM [dbo].[EQM_MRO_ServiceContract] WHERE [ContractNo] = @cno'
                    $reader = $command.ExecuteReader(); $row = $null
                    try {
                        if ($reader.Read()) {
                            $row = @{
                                name = $(if ($reader.IsDBNull(0)) { $null } else { [string]$reader.GetValue(0) })
                                size = $(if ($reader.IsDBNull(1)) { $null } else { [long]$reader.GetValue(1) })
                                uploadedAt = $(if ($reader.IsDBNull(2)) { $null } else { [string]$reader.GetValue(2) })
                                data = $(if ($reader.IsDBNull(3)) { $null } else { [Convert]::ToBase64String([byte[]]$reader.GetValue(3)) })
                            }
                        }
                    } finally { $reader.Dispose() }
                    @{ok=$true;noSchema=$false;row=$row} | ConvertTo-Json -Depth 4 -Compress
                }
            } elseif ($job.action -eq 'aps-plan-read') {
                # Read-only list of EQM_MRO_ServiceMonthlyPlan. Fixed columns; no caller input reaches SQL text.
                $command.CommandText = 'SELECT [No], [PlanID], [Year], [Month], [PlanAmount], [Currency], [Version], [YearMonth], CONVERT(varchar(19), [CreatedAt], 120) AS [CreatedAt], [CreatedBy], CONVERT(varchar(19), [UpdatedAt], 120) AS [UpdatedAt] FROM [dbo].[EQM_MRO_ServiceMonthlyPlan] ORDER BY [Year], [Month], [No]'
                $reader = $command.ExecuteReader(); $rows = @()
                try {
                    while ($reader.Read()) {
                        $r = @{}
                        for ($i=0;$i -lt $reader.FieldCount;$i++) { $r[$reader.GetName($i)] = if ($reader.IsDBNull($i)) { $null } else { [System.Convert]::ToString($reader.GetValue($i)) } }
                        $rows += $r
                    }
                } finally { $reader.Dispose() }
                @{ok=$true;rows=@($rows)} | ConvertTo-Json -Depth 5 -Compress
            } elseif ($job.action -eq 'aps-plan-write') {
                # Monthly Plan write: each save inserts a NEW version per (PlanID, Year, Month) - UNIQUE
                # UX_SMP_Plan_Period. Only EQM_MRO_ServiceMonthlyPlan is touched; INSERT only, never
                # UPDATE/DELETE. CreatedBy comes from the portal session, never from the client.
                $transaction = $connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction = $transaction
                    $command.Parameters.Clear()
                    if ($job.op -eq 'insert') {
                        [void]$command.Parameters.Add('@pid',[System.Data.SqlDbType]::Int); $command.Parameters['@pid'].Value = [int]$job.planId
                        [void]$command.Parameters.Add('@yr',[System.Data.SqlDbType]::SmallInt); $command.Parameters['@yr'].Value = [int]$job.year
                        [void]$command.Parameters.Add('@mo',[System.Data.SqlDbType]::TinyInt); $command.Parameters['@mo'].Value = [int]$job.month
                        $apsAmt = $command.Parameters.Add('@amt',[System.Data.SqlDbType]::Decimal); $apsAmt.Precision = 18; $apsAmt.Scale = 4; $apsAmt.Value = [decimal]$job.amount
                        [void]$command.Parameters.Add('@cur',[System.Data.SqlDbType]::Char,3); $command.Parameters['@cur'].Value = [string]$job.currency
                        [void]$command.Parameters.Add('@ym',[System.Data.SqlDbType]::VarChar,7); $command.Parameters['@ym'].Value = [string]$job.yearMonth
                        [void]$command.Parameters.Add('@user',[System.Data.SqlDbType]::NVarChar,100); $command.Parameters['@user'].Value = [string]$job.actor
                        $command.CommandText = 'SELECT [Version] FROM [dbo].[EQM_MRO_ServiceMonthlyPlan] WITH (UPDLOCK) WHERE [PlanID] = @pid AND [Year] = @yr AND [Month] = @mo'
                        $reader = $command.ExecuteReader(); $apsMaxVersion = 0
                        try {
                            while ($reader.Read()) {
                                $apsVersionText = [string]$reader.GetValue(0)
                                $apsVersionNum = 0
                                if ($apsVersionText.Length -gt 1 -and [int]::TryParse($apsVersionText.Substring(1), [ref]$apsVersionNum) -and $apsVersionNum -gt $apsMaxVersion) { $apsMaxVersion = $apsVersionNum }
                            }
                        } finally { $reader.Dispose() }
                        $apsNewVersion = 'V' + ($apsMaxVersion + 1)
                        [void]$command.Parameters.Add('@ver',[System.Data.SqlDbType]::NVarChar,20); $command.Parameters['@ver'].Value = $apsNewVersion
                        $command.CommandText = 'INSERT INTO [dbo].[EQM_MRO_ServiceMonthlyPlan] ([PlanID],[Year],[Month],[PlanAmount],[Currency],[Version],[YearMonth],[CreatedAt],[CreatedBy]) VALUES (@pid,@yr,@mo,@amt,@cur,@ver,@ym,GETDATE(),@user); SELECT CAST(SCOPE_IDENTITY() AS int)'
                        $no = [int]$command.ExecuteScalar()
                        $transaction.Commit()
                        @{ok=$true;no=$no;version=$apsNewVersion} | ConvertTo-Json -Compress
                    } else { throw 'Unsupported plan op' }
                } catch { if ($transaction.Connection) { $transaction.Rollback() }; throw } finally { $transaction.Dispose() }
            } elseif ($job.action -eq 'aps-oh-repair') {
                # Read-only OH Repair for the Overview chart. One UNION result set:
                #   GR  = SUM([Amount 2 (USD)]) per Year/Month Payment from EQM_MRO_REPAIR + EQM_MRO_SERVICE
                #         (Service 'Setup new MC' excluded, matching the WRB portal rule)
                #   PLAN= newest version per (Year, Month) from EQM_MRO_ServiceMonthlyPlan
                # Fixed table/column names only - no caller input reaches SQL text; never writes.
                $command.CommandText = "SELECT CAST('GR' AS nvarchar(4)) AS [Kind], [Year Payment] AS [Yr], [Month Payment] AS [Mo], SUM(ISNULL([Amount 2 (USD)],0)) AS [AmountUSD], COUNT_BIG(*) AS [Cnt], CAST(NULL AS nvarchar(3)) AS [Cur], CAST(NULL AS nvarchar(20)) AS [Ver] FROM [dbo].[EQM_MRO_REPAIR] WHERE [Month Payment] IS NOT NULL AND [Year Payment] IS NOT NULL GROUP BY [Year Payment], [Month Payment] UNION ALL SELECT CAST('GR' AS nvarchar(4)), [Year Payment], [Month Payment], SUM(ISNULL([Amount 2 (USD)],0)), COUNT_BIG(*), CAST(NULL AS nvarchar(3)), CAST(NULL AS nvarchar(20)) FROM [dbo].[EQM_MRO_SERVICE] WHERE [Month Payment] IS NOT NULL AND [Year Payment] IS NOT NULL AND LOWER(LTRIM(RTRIM(ISNULL([Type],'')))) <> 'setup new mc' GROUP BY [Year Payment], [Month Payment] UNION ALL SELECT CAST('PLAN' AS nvarchar(4)), [Year], [Month], ISNULL([PlanAmount],0), 1, CAST([Currency] AS nvarchar(3)), CAST([Version] AS nvarchar(20)) FROM (SELECT [Year], [Month], [PlanAmount], [Currency], [Version], ROW_NUMBER() OVER (PARTITION BY [Year], [Month] ORDER BY [No] DESC) AS [Rn] FROM [dbo].[EQM_MRO_ServiceMonthlyPlan]) AS [P] WHERE [P].[Rn] = 1"
                $reader = $command.ExecuteReader(); $rows = @()
                try {
                    while ($reader.Read()) {
                        $r = @{}
                        for ($i=0;$i -lt $reader.FieldCount;$i++) { $r[$reader.GetName($i)] = if ($reader.IsDBNull($i)) { $null } else { [System.Convert]::ToString($reader.GetValue($i)) } }
                        $rows += $r
                    }
                } finally { $reader.Dispose() }
                @{ok=$true;rows=@($rows)} | ConvertTo-Json -Depth 5 -Compress
            } elseif ($job.action -eq 'aps-rows') {
                # 2026-11-09: nguon van hanh cua tab Repair & Service la SQL Server (khong con SQLite).
                # Chi SELECT tren dung EQM_MRO_REPAIR + EQM_MRO_SERVICE, ten bang/cot co dinh, khong nhan
                # gia tri nao tu caller. Cot noi tro (Reject/Buyer/IBM/UpdatedAt/UpdatedBy) chi duoc
                # SELECT khi da co o CA HAI bang (npm run aps:ensure-schema); chua co thi tra NULL + extras=false.
                # Buoc 1 (09/11/2026): lay DANH SACH COT THAT cua tung bang tu metadata roi moi ghep cau
                # UNION. Gate cu dem COUNT(DISTINCT TABLE_NAME)=2 nghia la chi can MOT trong sau cot bo
                # sung ton tai o moi bang la hoi het sau cot -> SQL 207 "Invalid column name", ca tab
                # khong tai duoc. Doc metadata cho phep: cot bo sung bang nao chua co thi ben do tra NULL.
                $command.CommandText = 'SELECT TABLE_NAME,COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = N''dbo'' AND TABLE_NAME IN (N''EQM_MRO_REPAIR'',N''EQM_MRO_SERVICE'')'
                $apsMetaReader = $command.ExecuteReader(); $apsSchema = @{}
                try { while ($apsMetaReader.Read()) { $apsMetaTable = [string]$apsMetaReader.GetValue(0); $apsMetaColumn = ([string]$apsMetaReader.GetValue(1)).ToLowerInvariant(); if (-not $apsSchema.ContainsKey($apsMetaTable)) { $apsSchema[$apsMetaTable] = @{} }; $apsSchema[$apsMetaTable][$apsMetaColumn] = 1 } } finally { $apsMetaReader.Dispose() }
                if (-not $apsSchema.ContainsKey('EQM_MRO_REPAIR') -or $apsSchema['EQM_MRO_REPAIR'].Count -eq 0) { throw 'Không tìm thấy bảng dbo.EQM_MRO_REPAIR (hoặc tài khoản SQL không có quyền SELECT) trong database đang kết nối.' }
                if (-not $apsSchema.ContainsKey('EQM_MRO_SERVICE') -or $apsSchema['EQM_MRO_SERVICE'].Count -eq 0) { throw 'Không tìm thấy bảng dbo.EQM_MRO_SERVICE (hoặc tài khoản SQL không có quyền SELECT) trong database đang kết nối.' }
                # Buoc 2: cot nghiep vu co ban (453 + 61 dong da migrate) bat buoc phai co. Thieu thi
                # bao RO TEN bang.cot de nguoi van hanh biet bo sung gi, khong de 207 mo ho.
                $apsBaseRepair = @('No','Request ID','Request date','Vendor APS','Cost Center','Model / Project','Pic request','Payment Status','Month Payment','Year Payment',"Q'ty",'Estimated cost','Final price','Final Price (USD)','Amount','Amount 2 (USD)','Vendor Repair','Local/Oversea','GL','Remark','BQMS code','Jig /Eqm Name','Current Status / Fault','Detail Request','Service code','Currency','PO NO','Note of service','WRB request','Pur accept','Price confirm date')
                $apsBaseService = @('No','Request ID','Request date','Vendor APS','Cost Center','Model / Project','Pic request','Payment Status','Month Payment','Year Payment',"Q'ty",'Estimated cost','Final price','Final Price (USD)','Amount','Amount 2 (USD)','Vendor Repair','Local/Oversea','GL','Remark','Cur','Current Status / Request','Type','Start date','End Date','Before approval','Contract','Contract signed','ContractNo')
                $apsMissingBase = @()
                foreach ($apsCheckName in $apsBaseRepair) { if (-not $apsSchema['EQM_MRO_REPAIR'].ContainsKey($apsCheckName.ToLowerInvariant())) { $apsMissingBase += ('dbo.EQM_MRO_REPAIR.' + $apsCheckName) } }
                foreach ($apsCheckName in $apsBaseService) { if (-not $apsSchema['EQM_MRO_SERVICE'].ContainsKey($apsCheckName.ToLowerInvariant())) { $apsMissingBase += ('dbo.EQM_MRO_SERVICE.' + $apsCheckName) } }
                if ($apsMissingBase.Count -gt 0) { throw ('Thiếu cột bắt buộc của màn Repair & Service: ' + ($apsMissingBase -join ', ') + '. Đối chiếu cấu trúc bằng npm run aps:schema-report trên máy chủ Portal.') }
                # Buoc 3: sau cot bo sung la TUY CHON theo tung bang. Bang nao chua co thi ben do SELECT
                # NULL (kieu du de UNION khong lech), tab van tai; payload bao ten cột thieu + extras=false.
                $apsExtraNames = @('Reject date','Reject reason','Buyer','IBM','UpdatedAt','UpdatedBy')
                $apsExtraReal = @('CONVERT(varchar(10),[Reject date],23) AS [RejectDate]','[Reject reason] AS [RejectReason]','[Buyer] AS [Buyer]','[IBM] AS [IBM]','CONVERT(varchar(19),[UpdatedAt],120) AS [UpdatedAt]','[UpdatedBy] AS [UpdatedBy]')
                $apsExtraNull = @('CAST(NULL AS varchar(10)) AS [RejectDate]','CAST(NULL AS nvarchar(1000)) AS [RejectReason]','CAST(NULL AS nvarchar(100)) AS [Buyer]','CAST(NULL AS nvarchar(100)) AS [IBM]','CAST(NULL AS varchar(19)) AS [UpdatedAt]','CAST(NULL AS nvarchar(80)) AS [UpdatedBy]')
                $apsExtraFor = { param($apsTableFor) $apsOut = ''; for ($apsIndex = 0; $apsIndex -lt $apsExtraNames.Count; $apsIndex++) { if ($apsSchema[$apsTableFor].ContainsKey($apsExtraNames[$apsIndex].ToLowerInvariant())) { $apsOut += ', ' + $apsExtraReal[$apsIndex] } else { $apsOut += ', ' + $apsExtraNull[$apsIndex] } }; $apsOut }
                $apsExtraR = & $apsExtraFor 'EQM_MRO_REPAIR'
                $apsExtraS = & $apsExtraFor 'EQM_MRO_SERVICE'
                # extras=true chi khi CA HAI bang co du sau cột (ban ghi can UpdatedAt/UpdatedBy).
                $apsWriteColumns = $true; $apsMissingExtras = @()
                foreach ($apsMissingTable in @('EQM_MRO_REPAIR','EQM_MRO_SERVICE')) { foreach ($apsExtraName in $apsExtraNames) { if (-not $apsSchema[$apsMissingTable].ContainsKey($apsExtraName.ToLowerInvariant())) { $apsWriteColumns = $false; $apsMissingExtras += ($apsMissingTable + '.' + $apsExtraName) } } }
                $apsCols = ", [No] AS [No], [Request ID] AS [RequestId], CONVERT(varchar(10),[Request date],23) AS [RequestDate], [Vendor APS] AS [Vendor], [Cost Center] AS [CostCenter], [Model / Project] AS [Model], [Pic request] AS [Pic], [Payment Status] AS [PaymentStatus], [Month Payment] AS [MonthPayment], [Year Payment] AS [YearPayment], [Q'ty] AS [Qty], [Estimated cost] AS [EstimatedCost], [Final price] AS [FinalPrice], [Final Price (USD)] AS [FinalUSD], [Amount] AS [Amount], [Amount 2 (USD)] AS [AmountUSD], [Vendor Repair] AS [VendorRepair], [Local/Oversea] AS [Local], [GL] AS [GL], [Remark] AS [Remark]"
                $apsRepairOnly = ", [BQMS code] AS [BQMSCode], [Jig /Eqm Name] AS [JigName], [Current Status / Fault] AS [Fault], [Detail Request] AS [DetailRequest], [Service code] AS [ServiceCode], [Currency] AS [Cur], [PO NO] AS [PO], [Note of service] AS [NoteOfService], [WRB request] AS [WRB], [Pur accept] AS [PurAccept], CONVERT(varchar(10),[Price confirm date],23) AS [PriceConfirmDate], CAST(NULL AS nvarchar(100)) AS [StatusRequest], CAST(NULL AS nvarchar(50)) AS [ServiceType], CAST(NULL AS varchar(10)) AS [StartDate], CAST(NULL AS varchar(10)) AS [EndDate], CAST(NULL AS nvarchar(200)) AS [BeforeApproval], CAST(NULL AS nvarchar(500)) AS [Contract], CAST(NULL AS nvarchar(200)) AS [ContractSigned], CAST(NULL AS nvarchar(200)) AS [ContractNo]"
                $apsServiceOnly = ", CAST(NULL AS nvarchar(50)) AS [BQMSCode], CAST(NULL AS nvarchar(200)) AS [JigName], CAST(NULL AS nvarchar(100)) AS [Fault], CAST(NULL AS nvarchar(1000)) AS [DetailRequest], CAST(NULL AS nvarchar(50)) AS [ServiceCode], [Cur] AS [Cur], CAST(NULL AS nvarchar(50)) AS [PO], CAST(NULL AS nvarchar(1000)) AS [NoteOfService], CAST(NULL AS nvarchar(100)) AS [WRB], CAST(NULL AS nvarchar(100)) AS [PurAccept], CAST(NULL AS varchar(10)) AS [PriceConfirmDate], [Current Status / Request] AS [StatusRequest], [Type] AS [ServiceType], CONVERT(varchar(10),[Start date],23) AS [StartDate], CONVERT(varchar(10),[End Date],23) AS [EndDate], [Before approval] AS [BeforeApproval], [Contract] AS [Contract], [Contract signed] AS [ContractSigned], [ContractNo] AS [ContractNo]"
                $command.CommandText = "SELECT CAST('R' AS nvarchar(1)) AS [Src]" + $apsCols + $apsRepairOnly + $apsExtraR + " FROM [dbo].[EQM_MRO_REPAIR] UNION ALL SELECT CAST('S' AS nvarchar(1)) AS [Src]" + $apsCols + $apsServiceOnly + $apsExtraS + " FROM [dbo].[EQM_MRO_SERVICE]"
                $reader = $command.ExecuteReader(); $rows = @()
                try {
                    while ($reader.Read()) {
                        $r = @{}
                        for ($i=0;$i -lt $reader.FieldCount;$i++) { $r[$reader.GetName($i)] = if ($reader.IsDBNull($i)) { $null } else { [System.Convert]::ToString($reader.GetValue($i)) } }
                        $rows += $r
                    }
                } finally { $reader.Dispose() }
                @{ok=$true;rows=@($rows);extras=$apsWriteColumns;missing=@($apsMissingExtras)} | ConvertTo-Json -Depth 5 -Compress
            } elseif ($job.action -eq 'aps-row-write') {
                # 2026-11-09 (phuong an C): tab Repair & Service ghi thang SQL Server.
                # UPDATE/INSERT-only tren dung EQM_MRO_REPAIR / EQM_MRO_SERVICE, trong 1 transaction
                # Serializable. Ten cot khong bao gio noi chuoi tu client: chi lay tu allowlist [ordered]
                # co dinh; moi gia tri la tham so. WHERE theo [No] + [Request ID] + [UpdatedAt] de phat
                # hien hai nguoi cung sua mot dong. Khong UPDATE/DELETE bang khac, khong DDL o day.
                # Chi ghi khi MOI BANG co du sau cột bổ sung. Gate cu dem COUNT(DISTINCT TABLE_NAME)=2
                # nên bang chi can 1/6 cột là "đạt" rồi UPDATE/INSERT bao 207 khong ro nguyen nhan.
                $command.CommandText = 'SELECT COUNT(*) AS [Ready] FROM (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = N''dbo'' AND TABLE_NAME IN (N''EQM_MRO_REPAIR'',N''EQM_MRO_SERVICE'') AND COLUMN_NAME IN (N''Reject date'',N''Reject reason'',N''Buyer'',N''IBM'',N''UpdatedAt'',N''UpdatedBy'') GROUP BY TABLE_NAME HAVING COUNT(DISTINCT COLUMN_NAME) = 6) AS [APS]'
                $apsWriteReady = $command.ExecuteScalar()
                [void]$command.Parameters.Clear()
                if ($null -eq $apsWriteReady -or $apsWriteReady -eq [System.DBNull]::Value -or [int]$apsWriteReady -ne 2) { throw 'Hai bảng EQM_MRO_REPAIR / EQM_MRO_SERVICE chưa có đủ cột Reject date / Reject reason / Buyer / IBM / UpdatedAt / UpdatedBy (mỗi bảng phải đủ 6 cột). Chạy npm run aps:ensure-schema trên máy chủ Portal rồi thử lại.' }
                $apsSrc = [string]$job.src
                $apsOp = [string]$job.op
                $apsTable = if ($apsSrc -eq 'R') { 'EQM_MRO_REPAIR' } elseif ($apsSrc -eq 'S') { 'EQM_MRO_SERVICE' } else { throw 'src phải là R (Repair) hoặc S (Service).' }
                if (@('line','service','status','payment') -notcontains $apsOp) { throw 'op không được hỗ trợ.' }
                if (($apsOp -eq 'line' -and $apsSrc -ne 'R') -or ($apsOp -eq 'service' -and $apsSrc -ne 'S')) { throw 'op không khớp loại request.' }
                # Lay cot that cua bang dinh ghi roi moi ghep cau LENH: cột nao khong ton tai thi bao
                # RO TEN (thay vi 207 mo ho). Ten cột lay tu allowlist [ordered] o duoi, khong tu client.
                $command.CommandText = 'SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = N''dbo'' AND TABLE_NAME = N''' + $apsTable + ''''
                $apsWriteMeta = $command.ExecuteReader(); $apsWriteCols = @{}
                try { while ($apsWriteMeta.Read()) { $apsWriteCols[([string]$apsWriteMeta.GetValue(0)).ToLowerInvariant()] = 1 } } finally { $apsWriteMeta.Dispose() }
                $apsNeedColumn = { param($apsTargetColumn) $apsClean = ([string]$apsTargetColumn).Trim('[', ']').Trim(); if (-not $apsWriteCols.ContainsKey($apsClean.ToLowerInvariant())) { throw ('Bảng dbo.' + $apsTable + ' chưa có cột ' + $apsClean + ' — kiểm tra bằng npm run aps:schema-report hoặc chạy npm run aps:ensure-schema trên máy chủ Portal.') } }
                & $apsNeedColumn '[No]'
                & $apsNeedColumn '[Request ID]'
                $apsActor = [string]$job.actor
                if ($apsActor.Length -eq 0 -or $apsActor.Length -gt 80) { throw 'Không xác định được người ghi.' }
                $apsCurColumn = if ($apsSrc -eq 'R') { '[Currency]' } else { '[Cur]' }
                $apsLineMap = [ordered]@{ bqms = '[BQMS code]'; jigName = '[Jig /Eqm Name]'; fault = '[Current Status / Fault]'; detail = '[Detail Request]'; serviceCode = '[Service code]'; qty = '[Q''ty]'; estimatedCost = '[Estimated cost]'; finalPrice = '[Final price]'; finalUSD = '[Final Price (USD)]'; gl = '[GL]'; local = '[Local/Oversea]'; remark = '[Remark]'; vendorRepair = '[Vendor Repair]'; wrb = '[WRB request]'; accept = '[Pur accept]'; priceDate = '[Price confirm date]'; po = '[PO NO]'; rejectDate = '[Reject date]'; rejectReason = '[Reject reason]'; buyer = '[Buyer]'; ibm = '[IBM]' }
                $apsServiceMap = [ordered]@{ statusRequest = '[Current Status / Request]'; qty = '[Q''ty]'; estimatedCost = '[Estimated cost]'; finalPrice = '[Final price]'; finalUSD = '[Final Price (USD)]'; cur = 'CUR'; gl = '[GL]'; local = '[Local/Oversea]'; remark = '[Remark]'; vendorRepair = '[Vendor Repair]'; type = '[Type]'; startDate = '[Start date]'; endDate = '[End Date]'; beforeApproval = '[Before approval]'; contract = '[Contract]'; contractSigned = '[Contract signed]'; contractNo = '[ContractNo]'; paymentStatus = '[Payment Status]'; monthPayment = '[Month Payment]'; yearPayment = '[Year Payment]' }
                $apsStatusMap = [ordered]@{ paymentStatus = '[Payment Status]'; monthPayment = '[Month Payment]'; yearPayment = '[Year Payment]'; cur = 'CUR' }
                $apsPaymentMap = [ordered]@{ paymentStatus = '[Payment Status]'; monthPayment = '[Month Payment]'; yearPayment = '[Year Payment]'; cur = 'CUR'; amount = '[Amount]'; amountUSD = '[Amount 2 (USD)]'; remark = '[Remark]' }
                $apsNo = 0
                if ($apsOp -ne 'status' -and -not [int]::TryParse([string]$job.no, [ref]$apsNo)) { throw 'no phải là số dòng SQL (cột No).' }
                $apsRid = [string]$job.requestId
                if ($apsRid.Length -eq 0 -or $apsRid.Length -gt 50) { throw 'requestId không hợp lệ.' }
                $apsExpect = [string]$job.expectedUpdatedAt
                $apsFields = $job.fields
                $apsSet = @(); $apsInsertCols = @(); $apsInsertVals = @(); $apsIndex = 0
                if ($apsOp -eq 'payment') {
                    foreach ($apsName in @($apsPaymentMap.Keys)) {
                        if (-not ($apsFields.PSObject.Properties.Name -contains $apsName)) { throw ('Thiếu trường thanh toán: ' + $apsName) }
                        $apsTarget = [string]$apsPaymentMap[$apsName]; if ($apsTarget -eq 'CUR') { $apsTarget = $apsCurColumn }
                        & $apsNeedColumn $apsTarget
                        $apsRaw = if ($null -eq $apsFields.$apsName) { '' } else { [string]$apsFields.$apsName }
                        if ($apsRaw.Length -gt 1000) { throw ('Giá trị của ' + $apsName + ' vượt 1000 ký tự.') }
                        if ($apsRaw -ne '' -and $apsName -match '^(monthPayment|yearPayment|amount|amountUSD)$' -and $apsRaw -notmatch '^-?\d{1,14}(\.\d{1,4})?$') { throw ('Giá trị số của ' + $apsName + ' không hợp lệ.') }
                        $apsParam = '@v' + $apsIndex
                        $apsInsertCols += $apsTarget; $apsInsertVals += $apsParam
                        [void]$command.Parameters.AddWithValue($apsParam, $(if ($apsRaw -eq '') { [System.DBNull]::Value } else { $apsRaw }))
                        $apsIndex++
                    }
                } else {
                    if ($null -eq $apsFields) { throw 'Không có trường nào để sửa.' }
                    $apsMap = if ($apsOp -eq 'line') { $apsLineMap } elseif ($apsOp -eq 'service') { $apsServiceMap } else { $apsStatusMap }
                    foreach ($apsName in @($apsFields.PSObject.Properties.Name)) {
                        if (-not $apsMap.Contains($apsName)) { throw ('Trường không được phép sửa: ' + $apsName) }
                        $apsTarget = [string]$apsMap[$apsName]; if ($apsTarget -eq 'CUR') { $apsTarget = $apsCurColumn }
                        & $apsNeedColumn $apsTarget
                        $apsRaw = if ($null -eq $apsFields.$apsName) { '' } else { [string]$apsFields.$apsName }
                        if ($apsRaw.Length -gt 1000) { throw ('Giá trị của ' + $apsName + ' vượt 1000 ký tự.') }
                        if ($apsRaw -ne '' -and $apsName -match 'Date$' -and $apsRaw -notmatch '^\d{4}-\d{2}-\d{2}$') { throw ('Ngày tháng của ' + $apsName + ' phải theo dạng YYYY-MM-DD.') }
                        if ($apsRaw -ne '' -and $apsName -match '^(qty|estimatedCost|finalPrice|finalUSD|monthPayment|yearPayment)$' -and $apsRaw -notmatch '^-?\d{1,14}(\.\d{1,4})?$') { throw ('Giá trị số của ' + $apsName + ' không hợp lệ.') }
                        $apsParam = '@v' + $apsIndex
                        $apsSet += ($apsTarget + ' = ' + $apsParam)
                        [void]$command.Parameters.AddWithValue($apsParam, $(if ($apsRaw -eq '') { [System.DBNull]::Value } else { $apsRaw }))
                        $apsIndex++
                    }
                    if ($apsSet.Count -eq 0) { throw 'Không có trường nào để sửa.' }
                }
                [void]$command.Parameters.AddWithValue('@rid', $apsRid)
                [void]$command.Parameters.AddWithValue('@by', $apsActor)
                if ($apsOp -ne 'status') { [void]$command.Parameters.AddWithValue('@no', $apsNo) }
                if ($apsOp -eq 'line' -or $apsOp -eq 'service') { [void]$command.Parameters.AddWithValue('@expect', $(if ($apsExpect -eq '') { [System.DBNull]::Value } else { $apsExpect })) }
                $transaction = $connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                $command.Transaction = $transaction
                try {
                    $apsRows = 0
                    if ($apsOp -eq 'payment') {
                        foreach ($apsBaseColumn in @('[Request date]','[Vendor APS]','[Cost Center]','[Model / Project]','[Pic request]','[Vendor Repair]','[GL]','[Local/Oversea]','[UpdatedAt]','[UpdatedBy]')) { & $apsNeedColumn $apsBaseColumn }
                        $command.CommandText = 'INSERT INTO [dbo].[' + $apsTable + '] ([Request ID],[Request date],[Vendor APS],[Cost Center],[Model / Project],[Pic request],[Vendor Repair],[GL],[Local/Oversea],' + ($apsInsertCols -join ',') + ',[UpdatedAt],[UpdatedBy]) SELECT @rid,[Request date],[Vendor APS],[Cost Center],[Model / Project],[Pic request],[Vendor Repair],[GL],[Local/Oversea],' + ($apsInsertVals -join ',') + ',GETDATE(),@by FROM [dbo].[' + $apsTable + '] WHERE [No] = @no AND [Request ID] = @rid'
                        $apsRows = $command.ExecuteNonQuery()
                        if ($apsRows -eq 0) { throw 'Không tìm thấy dòng gốc để ghi nhận thanh toán (No/Request ID không khớp) — tải lại tab.' }
                    } elseif ($apsOp -eq 'status') {
                        $command.CommandText = 'UPDATE [dbo].[' + $apsTable + '] SET ' + ($apsSet -join ', ') + ', [UpdatedAt] = GETDATE(), [UpdatedBy] = @by WHERE [Request ID] = @rid'
                        $apsRows = $command.ExecuteNonQuery()
                        if ($apsRows -eq 0) { throw 'Không tìm thấy request trong bảng (Request ID không khớp) — tải lại tab.' }
                    } else {
                        $command.CommandText = 'UPDATE [dbo].[' + $apsTable + '] SET ' + ($apsSet -join ', ') + ', [UpdatedAt] = GETDATE(), [UpdatedBy] = @by WHERE [No] = @no AND [Request ID] = @rid AND ((CONVERT(varchar(19),[UpdatedAt],120) = @expect AND @expect IS NOT NULL) OR ([UpdatedAt] IS NULL AND @expect IS NULL))'
                        $apsRows = $command.ExecuteNonQuery()
                        if ($apsRows -eq 0) { throw 'Dòng dữ liệu vừa thay đổi hoặc không còn trùng bản đang mở — tải lại tab rồi thử lại.' }
                    }
                    $transaction.Commit()
                    @{ok = $true; op = $apsOp; table = $apsTable; rows = $apsRows} | ConvertTo-Json -Compress
                } catch { if ($transaction.Connection) { $transaction.Rollback() }; throw } finally { $transaction.Dispose() }
            } elseif ($job.action -eq 'prselect-read') {
                # 09-11-2026: PIC3 xac nhan PR luu tren SQL (EQM_MRO_PRSelect thay data/pic3.json theo yeu cau nguoi dung).
                # CHI SELECT; cot liet ke co dinh; khong nhan bat ky tham so nao tu caller. Date/DateTime dung CONVERT
                # de JSON luon la van hoa bat bien (YYYY-MM-DD / ISO khong coi) khong phu thuoc culture may chu.
                $command.CommandText = 'SELECT [LineKey],[PurchaseCode],[OriginalCode],[ItemName],[Vendor],CONVERT(varchar(10),[OrderDate],23) AS [OrderDate],[PRNo],[PRSeq],[BuyQty],[Note],[SourceJson],[PRJson],[Revision],CONVERT(varchar(23),[UpdatedAt],126) AS [UpdatedAt],[UpdatedBy] FROM [dbo].[EQM_MRO_PRSelect] ORDER BY [No]'
                $reader = $command.ExecuteReader(); $prSelectRows = @()
                try {
                    while ($reader.Read()) {
                        $r = @{}
                        for ($i=0;$i -lt $reader.FieldCount;$i++) { $r[$reader.GetName($i)] = if ($reader.IsDBNull($i)) { $null } else { [System.Convert]::ToString($reader.GetValue($i), [System.Globalization.CultureInfo]::InvariantCulture) } }
                        $prSelectRows += $r
                    }
                } finally { $reader.Dispose() }
                @{ok=$true;rows=$prSelectRows} | ConvertTo-Json -Depth 5 -Compress
            } elseif ($job.action -eq 'prselect-write') {
                # 09-11-2026: ghi delta xac nhan PR cua man PR & Tracking (module tracking).
                # DUNG mot bang [dbo].[EQM_MRO_PRSelect]; danh sach 15 cot co dinh (ten cot KHONG lay tu payload);
                # gia tri luon la tham so dinh kieu (NVarChar/Decimal/Date/DateTime). MOT transaction SERIALIZABLE:
                # insert kiem LineKey va (PurchaseCode,PRNo,PRSeq) bang WITH (UPDLOCK,HOLDLOCK); update/delete
                # yeu cau Revision (baseline) va rowcount = 1, nguoc lai rollback toan bo va bao CONFLICT.
                $prSelectColumns = @(
                    @{name = 'LineKey'; type = 'text'; nullable = $false},
                    @{name = 'PurchaseCode'; type = 'text'; nullable = $false},
                    @{name = 'OriginalCode'; type = 'text'; nullable = $true},
                    @{name = 'ItemName'; type = 'text'; nullable = $true},
                    @{name = 'Vendor'; type = 'text'; nullable = $true},
                    @{name = 'OrderDate'; type = 'date'; nullable = $true},
                    @{name = 'PRNo'; type = 'text'; nullable = $true},
                    @{name = 'PRSeq'; type = 'text'; nullable = $true},
                    @{name = 'BuyQty'; type = 'decimal'; nullable = $true},
                    @{name = 'Note'; type = 'text'; nullable = $true},
                    @{name = 'SourceJson'; type = 'text'; nullable = $false},
                    @{name = 'PRJson'; type = 'text'; nullable = $true},
                    @{name = 'Revision'; type = 'text'; nullable = $false},
                    @{name = 'UpdatedAt'; type = 'datetime'; nullable = $false},
                    @{name = 'UpdatedBy'; type = 'text'; nullable = $false}
                )
                $prSelectOpsTotal = @($job.inserts).Count + @($job.updates).Count + @($job.deletes).Count
                if ($prSelectOpsTotal -eq 0) {
                    @{ok=$true;inserted=0;updated=0;deleted=0} | ConvertTo-Json -Compress
                } elseif ($prSelectOpsTotal -gt 400) {
                    throw 'Too many PR-select write operations'
                } else {
                $transaction = $connection.BeginTransaction([System.Data.IsolationLevel]::Serializable)
                try {
                    $command.Transaction = $transaction
                    $inserted = 0; $updated = 0; $deleted = 0
                    foreach ($op in @($job.inserts)) {
                        $command.Parameters.Clear()
                        $columnParts = @(); $valueParts = @()
                        foreach ($column in $prSelectColumns) {
                            $raw = $op.($column.name); if ($null -eq $raw) { $raw = '' }; $raw = [string]$raw
                            $dbType = [System.Data.SqlDbType]::NVarChar; $size = 4000; $value = $raw
                            switch ($column.type) {
                                'date' { $dbType = [System.Data.SqlDbType]::Date; $size = 0; $value = if ($raw -eq '') { [DBNull]::Value } else { [datetime]::ParseExact($raw,'yyyy-MM-dd',[System.Globalization.CultureInfo]::InvariantCulture) }; break }
                                'decimal' { $dbType = [System.Data.SqlDbType]::Decimal; $size = 0; $value = if ($raw -eq '') { [DBNull]::Value } else { [System.Convert]::ToDecimal($raw,[System.Globalization.CultureInfo]::InvariantCulture) }; break }
                                'datetime' { $dbType = [System.Data.SqlDbType]::DateTime; $size = 0; $value = [datetime]::Parse($raw,[System.Globalization.CultureInfo]::InvariantCulture,[System.Globalization.DateTimeStyles]::AdjustToUniversal); break }
                                default { $value = if ($raw -eq '' -and $column.nullable) { [DBNull]::Value } else { $raw }; if ($column.name -eq 'PRJson') { $size = -1 }; break }
                            }
                            $prParameter = $command.Parameters.Add(('@w_' + $column.name), $dbType, $size); $prParameter.Value = $value
                            $columnParts += ('[' + $column.name + ']'); $valueParts += ('@w_' + $column.name)
                        }
                        $command.CommandText = 'SELECT [LineKey] FROM [dbo].[EQM_MRO_PRSelect] WITH (UPDLOCK,HOLDLOCK) WHERE [LineKey] = @w_LineKey'
                        if ($null -ne $command.ExecuteScalar()) { throw ('CONFLICT insert ' + [string]$op.LineKey) }
                        if ([string]$op.PRNo -ne '') {
                            $command.CommandText = 'SELECT [LineKey] FROM [dbo].[EQM_MRO_PRSelect] WITH (UPDLOCK,HOLDLOCK) WHERE [PurchaseCode] = @w_PurchaseCode AND [PRNo] = @w_PRNo AND [PRSeq] = @w_PRSeq AND [LineKey] <> @w_LineKey'
                            if ($null -ne $command.ExecuteScalar()) { throw ('CONFLICT pr-selected ' + [string]$op.LineKey) }
                        }
                        $command.CommandText = 'INSERT INTO [dbo].[EQM_MRO_PRSelect] (' + ($columnParts -join ',') + ') VALUES (' + ($valueParts -join ',') + '); SELECT @@ROWCOUNT'
                        if ([int]$command.ExecuteScalar() -ne 1) { throw ('CONFLICT insert ' + [string]$op.LineKey) }
                        $inserted++
                    }
                    foreach ($op in @($job.updates)) {
                        $command.Parameters.Clear()
                        $setParts = @()
                        foreach ($column in $prSelectColumns) {
                            if ($column.name -eq 'LineKey') { continue }
                            $raw = $op.($column.name); if ($null -eq $raw) { $raw = '' }; $raw = [string]$raw
                            $dbType = [System.Data.SqlDbType]::NVarChar; $size = 4000; $value = $raw
                            switch ($column.type) {
                                'date' { $dbType = [System.Data.SqlDbType]::Date; $size = 0; $value = if ($raw -eq '') { [DBNull]::Value } else { [datetime]::ParseExact($raw,'yyyy-MM-dd',[System.Globalization.CultureInfo]::InvariantCulture) }; break }
                                'decimal' { $dbType = [System.Data.SqlDbType]::Decimal; $size = 0; $value = if ($raw -eq '') { [DBNull]::Value } else { [System.Convert]::ToDecimal($raw,[System.Globalization.CultureInfo]::InvariantCulture) }; break }
                                'datetime' { $dbType = [System.Data.SqlDbType]::DateTime; $size = 0; $value = [datetime]::Parse($raw,[System.Globalization.CultureInfo]::InvariantCulture,[System.Globalization.DateTimeStyles]::AdjustToUniversal); break }
                                default { $value = if ($raw -eq '' -and $column.nullable) { [DBNull]::Value } else { $raw }; if ($column.name -eq 'PRJson') { $size = -1 }; break }
                            }
                            $prParameter = $command.Parameters.Add(('@w_' + $column.name), $dbType, $size); $prParameter.Value = $value
                            $setParts += ('[' + $column.name + '] = @w_' + $column.name)
                        }
                        if ($setParts.Count -eq 0) { throw 'Update requires at least one column' }
                        [void]$command.Parameters.Add('@k',[System.Data.SqlDbType]::NVarChar,64); $command.Parameters['@k'].Value = [string]$op.LineKey
                        [void]$command.Parameters.Add('@e',[System.Data.SqlDbType]::NVarChar,64); $command.Parameters['@e'].Value = [string]$op.expectedRevision
                        if ([string]$op.PRNo -ne '') {
                            $command.CommandText = 'SELECT [LineKey] FROM [dbo].[EQM_MRO_PRSelect] WITH (UPDLOCK,HOLDLOCK) WHERE [PurchaseCode] = @w_PurchaseCode AND [PRNo] = @w_PRNo AND [PRSeq] = @w_PRSeq AND [LineKey] <> @k'
                            if ($null -ne $command.ExecuteScalar()) { throw ('CONFLICT pr-selected ' + [string]$op.LineKey) }
                        }
                        $command.CommandText = 'UPDATE [dbo].[EQM_MRO_PRSelect] SET ' + ($setParts -join ', ') + ' WHERE [LineKey] = @k AND [Revision] = @e; SELECT @@ROWCOUNT'
                        if ([int]$command.ExecuteScalar() -ne 1) { throw ('CONFLICT update ' + [string]$op.LineKey) }
                        $updated++
                    }
                    foreach ($op in @($job.deletes)) {
                        $command.Parameters.Clear()
                        [void]$command.Parameters.Add('@k',[System.Data.SqlDbType]::NVarChar,64); $command.Parameters['@k'].Value = [string]$op.LineKey
                        [void]$command.Parameters.Add('@e',[System.Data.SqlDbType]::NVarChar,64); $command.Parameters['@e'].Value = [string]$op.expectedRevision
                        $command.CommandText = 'DELETE FROM [dbo].[EQM_MRO_PRSelect] WHERE [LineKey] = @k AND [Revision] = @e; SELECT @@ROWCOUNT'
                        if ([int]$command.ExecuteScalar() -ne 1) { throw ('CONFLICT delete ' + [string]$op.LineKey) }
                        $deleted++
                    }
                    $transaction.Commit()
                    @{ok=$true;inserted=$inserted;updated=$updated;deleted=$deleted} | ConvertTo-Json -Compress
                } catch {
                    if ($transaction.Connection) { $transaction.Rollback() }
                    $prSelectFailure = [string]$_.Exception.Message
                    if ($prSelectFailure.StartsWith('CONFLICT ')) { @{ok=$true;conflict=$true;reason=$prSelectFailure} | ConvertTo-Json -Compress }
                    else { @{ok=$false;error=$prSelectFailure} | ConvertTo-Json -Compress }
                } finally { $transaction.Dispose() }
                }
            } else { throw 'Unsupported action' }
        } finally { $command.Dispose() }
            } else { throw 'Unsupported action' }
} catch {
    # Never return provider errors/connection strings/passwords to the browser or logs.
    $errorObject = $_.Exception
    while ($null -ne $errorObject.InnerException) { $errorObject = $errorObject.InnerException }
    $category = 'SQL_LOCAL_ERROR'
    if ($_.Exception -is [System.Data.SqlClient.SqlException]) { $category = 'SQL_PROVIDER_ERROR' }
    if ($errorObject -is [System.Data.SqlClient.SqlException]) { $category = 'SQL_PROVIDER_ERROR' }
    # Method invocation wraps SqlException; inspect its immediate inner exception as well.
    if ($_.Exception.InnerException -is [System.Data.SqlClient.SqlException]) { $category = 'SQL_PROVIDER_ERROR' }
    @{ok=$false;code=$category;sqlNumber=$(if ($errorObject -is [System.Data.SqlClient.SqlException]) { $errorObject.Number } elseif ($_.Exception.InnerException -is [System.Data.SqlClient.SqlException]) { $_.Exception.InnerException.Number } else { $null });connected=($connected -and $null -ne $connection -and $connection.State -eq [System.Data.ConnectionState]::Open)} | ConvertTo-Json -Compress
    exit 1
} finally {
    if ($null -ne $connection) { $connection.Dispose() }
}
