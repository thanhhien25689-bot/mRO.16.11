const net=require('node:net');
const CONNECT_PROBE_MS=1500;
const RETRY_MS=5000;
function unavailable(){return Object.assign(Error('Không thể kết nối SQL. Đang dùng cache nếu có; hệ thống sẽ thử lại sau ít giây. Kiểm tra mạng/VPN, thông tin đăng nhập và chứng chỉ TLS.'),{status:502,connected:false,code:'SQL_PROVIDER_ERROR'});}
function probeTcp(config,{timeout=CONNECT_PROBE_MS,createSocket=()=>new net.Socket()}={}){
 return new Promise((resolve,reject)=>{
  const socket=createSocket();let finished=false;
  const finish=ok=>{if(finished)return;finished=true;clearTimeout(timer);socket.destroy();ok?resolve():reject(unavailable());};
  const timer=setTimeout(()=>finish(false),timeout);
  socket.once('connect',()=>finish(true));socket.once('error',()=>finish(false));
  try{socket.connect({host:config.server,port:config.port});}catch{finish(false);}
 });
}
module.exports={probeTcp,unavailable,RETRY_MS};
