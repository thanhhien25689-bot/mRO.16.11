@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title MRO WRB Server
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20+ is required. Install Node.js and run this file again.
  pause
  exit /b 1
)

REM Trim whitespace and validate the port before PowerShell uses it.
REM Priority: PORT, tree.config.json.port, default 8000.
set "MRO_START_PORT="
for /f "delims=" %%P in ('node scripts\startup-check.cjs port') do set "MRO_START_PORT=%%P"
if not defined MRO_START_PORT (
  echo Could not determine a valid port. Check PORT and tree.config.json.
  pause
  exit /b 1
)
REM The listener and the port preparation step must use the SAME value.
set "PORT=%MRO_START_PORT%"

echo Checking required libraries...
node scripts\startup-check.cjs dependencies
if errorlevel 1 (
  echo Required libraries are missing or incomplete. See the message above.
  pause
  exit /b 1
)

REM === SSO / MySingle (optional) ===
REM Server co gia tri mac dinh KCC60TRAY0095 trong server/sso.cjs. Chi set khi mang doi.
REM MRO_SSO_DEVICE_ID chi la gia tri gai cho trinh duyet (fallback). Moi may PIC
REM dung ma thiet bi rieng cua minh, luu trong trinh duyet (localStorage key
REM "mro-sso-device"), nhap 1 lan o man dang nhap.
REM set "MRO_SSO_DEVICE_ID=KCC60TRAY0095"
REM set "MRO_SSO_MEG_URL=https://107.107.124.31"
REM set "MRO_SSO_PMP_URL=http://107.124.125.89/pmp-api"
REM set "MRO_SSO_WS_URL=ws://localhost:29282/"
REM set "MRO_SSO_WS_FALLBACK=wss://localhost:29283/"
REM set "MRO_SSO_TIMEOUT_MS=20000"
REM set "MRO_SSO_MEG_VERIFY_TLS=1"

REM === SET/PBA: in-memory demo store (Phase 4D). Khong co SQL adapter; phai set de hien thi man hinh SET/PBA. ===
set "SP_USE_MOCK=1"

REM === Repair & Service: khong tao file backup tu dong (du lieu nghiep vu da dua len SQL, 05/11/2026). ===
REM === Can bat lai bo nao file .runtime/aps/backups moi 4 gio: doi 0 thanh 1 roi khoi dong portal. ===
set "APS_BACKUP_AUTO=0"

echo Checking port %MRO_START_PORT%...
powershell.exe -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; $port=[int]$env:MRO_START_PORT; $owners=[System.Collections.Generic.HashSet[int]]::new(); foreach($connection in @(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)){ [void]$owners.Add($connection.OwningProcess) }; foreach($ownerPid in $owners){ $process=Get-Process -Id $ownerPid -ErrorAction Stop; Write-Host ('Stopping existing process on port {0}: {1} (PID {2})' -f $port,$process.ProcessName,$ownerPid); Stop-Process -Id $ownerPid -Force -ErrorAction Stop }; $deadline=(Get-Date).AddSeconds(5); while((Get-Date) -lt $deadline -and (Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)){ Start-Sleep -Milliseconds 100 }; if(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue){ throw ('Port {0} could not be closed. Run start.bat as Administrator.' -f $port) }"
if errorlevel 1 (
  echo Could not prepare port %MRO_START_PORT%.
  pause
  exit /b 1
)

echo Starting MRO WRB local server...
echo Browser opens when ready. Keep this window open; closing it stops the server.
node server.cjs --open --console-bound
if errorlevel 1 pause
endlocal
