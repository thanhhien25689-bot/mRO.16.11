@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\diagnose-masterdata-vendor.ps1"
echo.
pause