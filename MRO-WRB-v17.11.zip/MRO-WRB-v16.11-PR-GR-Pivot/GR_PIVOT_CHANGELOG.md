# MRO-WRB v16.11 – GR Report Form Smart Pivot

## Scope
Frontend-only improvement to **PR & Tracking → GR Report Form**, layered on the previous **PR Smart Pivot** release.
No changes to SQL worker, backend GR/PR matching, SQL tables, currency rates, GR_DATE, GR_AMOUNT or existing PR/other-tab business logic.

## Changes
- GR report now shares PR's readable Excel-like Pivot presentation: navy header, horizontal scrolling, sticky header/first column, responsive column widths, subtotals, Grand Total, and nested expand/collapse controls.
- Unlike the diagnostic fields, the selected Type/Project/Model dimensions can be used for meaningful nested grouping. Group totals are calculated from leaf rows; displayed subtotal rows are never double-counted.
- Same page-independent **Xuất đúng View** workflow as PR: respects current visible columns, months, Cost Center, search, column filters, grouping, and collapsed state. Excel report is a **formatted static table**, not a drag-and-drop Excel PivotTable.
- Four scoped KPI cards: GR Amount, Matched, Unmatched/Ambiguous, Data Issues. Clicking a status card filters the table. KPI counts come from unique GMRO source detail IDs, not aggregated Pivot lines. KPI scope uses current report filters and displayed months; the expandable full-year source audit is labeled separately to prevent confusion.
- Clicking a GR Amount/month cell opens source GMRO lines for that amount/month, preserving negative/return amounts and highlighting any amount discrepancy. Clicking a normal row still shows its associated source lines.
- Main GR Excel export adds worksheets **GR detail**, **Loi doi soat**, alongside the existing **Reason can cap nhat**. Detail and error sheets contain only source GMRO lines in the current filtered scope/month; Reason sheet preserves the existing rule of Cost Center scope only. Separate **GR chi tiết** download is also available.
- Missing/ambiguous PR links, missing/invalid Reason, missing GL Class and unconverted currency remain visible and eligible for the error report. No automatic amount adjustment or inferred missing PR is performed.

## Verification
- New pure-data GR tests cover source-to-pivot amounts, negative GR, subtotal/grand total, collapse, month/Cost Center scope, and source-level problem matching.
- Existing PR tests and Data Tracking regression tests pass.
- Spreadsheet XML writer verified by re-opening a four-sheet `.xlsx` with openpyxl, checking sheet names, numbers, and frozen panes.
- `node --check` passes on the changed modules.
- Full preexisting test suite: 35 pass and 1 blocked by missing environment dependency `fflate` in vendor test module; original code untouched.
- Browser preview and live corporate SQL integration **not verified in this execution environment**; on-site testing is required before promoting this release.

## Trial steps
1. Back up running Portal. Extract ZIP to a **new folder**, not over the running folder.
2. Run Portal normally and open PR & Tracking → GR Report Form.
3. Select year 2026 (or a year with real GMRO), enable Type + Project and month 11 + Amount. Check group/grand totals.
4. Expand/collapse a group and export Excel; verify the GR report sheet corresponds to that state and Cost Center selection.
5. Click one GR Amount cell; reconcile popup with source GMRO lines and verify that a negative GR stays negative.
6. Click Unmatched/Ambiguous and Data Issues; verify errors and check GR detail / Loi doi soat / Reason can cap nhat worksheets.
7. Revisit PR Report Form and a non-report tab to confirm baseline behavior.
