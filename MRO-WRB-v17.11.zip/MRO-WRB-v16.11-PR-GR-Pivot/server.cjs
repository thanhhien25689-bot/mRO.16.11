const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {createServer}=require('./backend/core/create-server.cjs');
const {getStartupConfig}=require('./backend/core/config.cjs');
if(require.main===module){
 const {port,host,runtime}=getStartupConfig(__dirname);fs.mkdirSync(runtime,{recursive:true});
 const lock=path.join(runtime,'server.lock');try{fs.writeFileSync(lock,String(process.pid),{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;const pid=Number(fs.readFileSync(lock,'utf8'));let alive=false;try{process.kill(pid,0);alive=true;}catch{}if(alive){console.error('Account store is already open. Use its running server, or stop it first.');process.exit(1);}fs.unlinkSync(lock);fs.writeFileSync(lock,String(process.pid),{flag:'wx'});}
 let parentWatch;const cleanup=()=>{if(parentWatch)clearInterval(parentWatch);try{if(fs.readFileSync(lock,'utf8')===String(process.pid))fs.unlinkSync(lock);}catch{}};process.on('exit',cleanup);
 const server=createServer({runtime});server.on('error',err=>{console.error(err.code==='EADDRINUSE'?`Port ${port} is already in use.`:err.message);process.exitCode=1;cleanup();});
 server.listen(port,host,()=>{console.log(`MRO WRB: http://localhost:${port}/`);for(const list of Object.values(os.networkInterfaces()))for(const nic of list||[])if(nic.family==='IPv4'&&!nic.internal)console.log(`LAN: http://${nic.address}:${port}/`);if(process.argv.includes('--open')&&process.env.MRO_NO_BROWSER!=='1'){const browser=require('node:child_process').spawn('powershell.exe',['-NoProfile','-NonInteractive','-Command',`Start-Process -FilePath 'http://localhost:${port}/' -ErrorAction Stop`],{windowsHide:true,stdio:'ignore'});const warn=()=>console.error('Could not open browser automatically. Open http://localhost:'+port+'/ manually.');browser.on('error',warn);browser.on('exit',code=>{if(code!==0)warn();});}
 console.log('First run: create your developer account on localhost. Ctrl+C stops the server.');});
 let stopping=false;const shutdown=()=>{if(stopping)return;stopping=true;const timer=setTimeout(()=>{cleanup();process.exit(0);},3000);timer.unref();server.close(()=>{cleanup();process.exit(0);});};
 for(const signal of ['SIGINT','SIGTERM','SIGBREAK'])process.on(signal,shutdown);
 if(process.argv.includes('--console-bound')){const parentPid=process.ppid;parentWatch=setInterval(()=>{try{process.kill(parentPid,0);}catch{shutdown();}},250);parentWatch.unref();}
}
module.exports={createServer};
