@echo off
cd /d "%~dp0"
echo This creates a Windows Firewall rule for this tree's port, local subnet only.
echo If Access is denied: close this window, right-click this file and choose Run as administrator.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0enable-lan.ps1"
pause
